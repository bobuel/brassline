# Brassline screen-pattern audit

Historical design record, retained for rationale. The individual Pass verdicts below are not current release certification: the 1.2.0 browser playthrough subsequently found large-text overflows in late-route, aftermath and live combat text. See the 1.2.0 release verification for the corrections and actual retests.

Audited against the current Godot screens in `campaign_ui.gd`,
`autobattle_ui.gd`, and `crew_ledger_ui.gd`, plus the rendered capture suite.
This is a pattern audit: it documents what a player must see first, what they
can do next, and which established interfaces supply the precedent. It does
not copy another game's art, layout, text, or assets.

## Reference set

| Reference | Usable pattern |
|---|---|
| [XCOM 2 manual](https://www.feralinteractive.com/en/manuals/xcom2/latest/steam/) | Selected-soldier information, action availability, ammo, health, mission objectives, and strategy/tactical separation. |
| [Into the Breach postmortem](https://media.gdcvault.com/gdc2019/presentations/Into%20the%20Breach%20Postmortem%20Final.pdf) | Board-first, consequence-visible tactical decisions. |
| [Divinity: Original Sin 2 interface guide](https://www.gamepressure.com/originalsinii/interface/z491a9) | Persistent party identifiers; one selected hero; a separate character/inventory view with tabs and a silhouette. |
| [FTL interface archive](https://interfaceingame.com/games/ftl-faster-than-light/) | Distinct main-menu, map, event, system, crew, and result states rather than one overloaded global screen. |
| [Darkest Dungeon II Inn reference](https://darkestdungeon.wiki.gg/wiki/Inn) | A between-region recovery stop where healing, supplies, and longer-running party effects are handled together. |

## Audit rule

Each screen gets one **anchor**, one immediate **action**, and at most three
visible fact groups. Exact math, lore, logs, and exhaustive statistics must be
secondary. A state passes only when both the code path and the rendered capture
support that rule.

## 1. Job brief / title

**Player question:** What am I starting, and what is the next action?

- **Anchor:** the Brassline mark and seven-car train strip.
- **Immediate action:** `START HEIST`.
- **Visible facts:** premise, run shape, optional Continue/Daily/Settings.
- **Pattern proof:** FTL separates its main-menu state from ship management;
  XCOM separates strategy entry from a mission's tactical HUD.
- **Evidence:** `CampaignUI.show_intro()` and `preview_intro.png`.
- **Verdict:** Pass. The primary action is visually dominant; run continuation
  is explicitly secondary.

## 2. How to play

**Player question:** Where can I check the rules without delaying the heist?

- **Anchor:** five-step run loop.
- **Immediate action:** return to the job brief.
- **Visible facts:** draft, plan, fallback, read fight, continue campaign.
- **Pattern proof:** FTL exposes help as a separate tutorial/help state;
  XCOM's manual separates tactical instructions from the live mission screen.
- **Evidence:** `CampaignUI.show_how_to_play()` and `preview_how_to.png`.
- **Verdict:** Pass as an optional reference. It is intentionally not a first-
  session gate; in-context prompts teach the same loop during play.

## 3. Settings

**Player question:** Which rules and accessibility choices apply to this run?

- **Anchor:** difficulty selection.
- **Immediate action:** choose difficulty or toggle an accessibility option,
  then save.
- **Visible facts:** difficulty, motion, audio/captions, input reference.
- **Pattern proof:** FTL's options state is separate from the game state;
  XCOM cleanly distinguishes mission rules from tactical actions.
- **Evidence:** `CampaignUI.show_settings()` and `preview_settings.png`.
- **Verdict:** Pass. Each control changes one category and the effect is stated
  underneath the selected difficulty.

## 4. Crew manifest

**Player question:** Who boards, and what does each person bring?

- **Anchor:** one animated, rotatable focused operative.
- **Immediate action:** inspect a portrait; explicitly add or remove the
  focused operative.
- **Visible facts:** role/signature, weapon/core numbers, scars/bonds.
- **Pattern proof:** Divinity lets party portraits switch the focused hero while
  deeper stats remain about that hero; XCOM's unit flag/action area centers the
  currently selected soldier.
- **Evidence:** `CampaignUI.show_crew_selection()`,
  `CrewSelectionStage`, and live deployment commit `0df0b83`.
- **Verdict:** Pass after the UI clarity correction. Portrait focus and roster
  assignment are now different actions; a player can cycle Ada, Marlow, and
  Nix without removing them from the crew.

## 5. Route selection

**Player question:** Which car should we enter next, and what does it cost or
pay?

- **Anchor:** the train progress strip and three equal choice cards.
- **Immediate action:** select a car.
- **Visible facts:** threat, hazard, reward; the prior result is one compact
  status strip.
- **Pattern proof:** FTL's map is a forward route decision rather than an
  inventory ledger; XCOM's strategy layer separates a mission choice from
  soldier preparation.
- **Evidence:** `CampaignUI.show_intermission()` and
  `_build_offer_column()`.
- **Verdict:** Pass after this audit's route-card correction. The former
  vertical text ledger was removed; detail remains in each card's tooltip and
  the following preparation screen.

## 6. Crew preparation / recovery

**Player question:** Can this team safely board this car, and what treatment
  helps?

- **Anchor:** the focused crew member in the three-person stage.
- **Immediate action:** select a crew member, apply a specific treatment, or
  board.
- **Visible facts:** destination card, three readiness chips, exact treatment
  outcome for the focused person.
- **Pattern proof:** Darkest Dungeon II's Inn concentrates recovery, supplies,
  and persistent effects between regions; XCOM keeps wound/medkit facts tied to
  named soldiers and equipment.
- **Evidence:** `CampaignUI.show_crew_prep()`, `_build_crew_stage_column()`,
  `_build_prep_management_column()`, `preview_prep.png`, and
  `preview_recovery.png`.
- **Verdict:** Pass. It has a focused person rather than a generic inventory
  dump, and treatment declares its before/after result.

## 7. Crew council

**Player question:** Which lasting crew stance do we take?

- **Anchor:** one short situation line and three equally weighted choices.
- **Immediate action:** choose a council answer.
- **Visible facts:** immediate effect, risk, persistence.
- **Pattern proof:** FTL uses isolated event/choice states instead of burying
  consequences in the ship HUD; Darkest Dungeon II uses region breaks to make
  party-changing decisions legible outside combat.
- **Evidence:** `CampaignUI.show_crew_scene()` and `preview_crew_council.png`.
- **Verdict:** Pass. This state avoids tactical HUD information and tells the
  player the choice will persist.

## 8. Non-combat car event

**Player question:** What trade-off does this car offer right now?

- **Anchor:** car identity and one concise situation.
- **Immediate action:** choose one of two outcomes.
- **Visible facts:** healing, supplies, persistence warning.
- **Pattern proof:** FTL presents event choices as a dedicated encounter state;
  Darkest Dungeon II makes recovery/supplies a deliberate between-fight choice.
- **Evidence:** `CampaignUI.show_car_event()` and `preview_event.png`.
- **Verdict:** Pass. The two cards expose concrete outcomes before choice.

## 9. Heist planning

**Player question:** What will the team attempt before initiative starts?

- **Anchor:** the full active carriage with ghost deployment, target, cover,
  and intent lines.
- **Immediate action:** select one plan and one fallback, then commit.
- **Visible facts:** four tactical families, opening chance/risk, one fallback.
- **Pattern proof:** Into the Breach's core clarity comes from projecting
  consequences on the board; XCOM presents selected-unit action outcomes,
  movement/hazard information, and current weapon state in the tactical layer.
- **Evidence:** `AutobattleUI.show_planning()`, `_build_planning()`,
  `preview_teen_planning_1280x720.png`.
- **Verdict:** Pass. The board explains the card; Plan Details contains the
  authored prose and exact math rather than competing with selection.

## 10. Autobattle combat

**Player question:** What is happening now, and can I slow or inspect it?

- **Anchor:** the carriage and current consequential action.
- **Immediate action:** pause/change pace or open the Ledger.
- **Visible facts:** plan integrity, initiative, three crew condition chips,
  current action/hazard warning.
- **Pattern proof:** XCOM reserves tactical space for the map while the selected
  soldier's health/ammo/actions stay compact; Into the Breach keeps the board
  as the primary explanation for tactical state.
- **Evidence:** `AutobattleUI.show_combat()`, `_build_combat()`, and live
  graphics build `69a669f`.
- **Verdict:** Pass. The log is optional history rather than a permanent
  decision surface; key beats earn the closer camera.

## 11. Crew Ledger

**Player question:** What can this specific operative do, carry, or survive?

- **Anchor:** one selected operative, body zones, weapon, and inventory.
- **Immediate action:** switch Crew, Gear, Injuries, or Train tabs.
- **Visible facts:** the current tab only.
- **Pattern proof:** Divinity uses portrait switching plus a character
  silhouette/equipment/inventory panel; XCOM exposes a selected soldier's
  health, status, weapon, ammo, and special actions together.
- **Evidence:** `CrewLedgerUI.show_context()` and `preview_teen_ledger_1280x720.png`.
- **Verdict:** Pass. Full management is deliberately outside the live combat
  HUD and preserves the selected-character anchor.

## 12. Combat aftermath

**Player question:** What happened, who changed, and what did we gain?

- **Anchor:** one outcome headline plus three cards.
- **Immediate action:** continue to route selection.
- **Visible facts:** plan/fallback, crew condition, reward.
- **Pattern proof:** XCOM mission results make the mission outcome and soldier
  consequences explicit after the tactical layer; Darkest Dungeon II resolves
  recovery and longer-term party state between encounters.
- **Evidence:** `AutobattleUI.show_aftermath()`, `_build_aftermath()`, and
  `preview_teen_aftermath_1280x720.png`.
- **Verdict:** Pass. Detailed chronology remains optional rather than being
  forced ahead of the reward.

## 13. Failed heist

**Player question:** Why did this plan fail, and what can I change safely?

- **Anchor:** failure headline and four causal cards.
- **Immediate action:** retry the exact pre-fight state or abandon.
- **Visible facts:** break cause, fallback effect, decisive injury, adjustment.
- **Pattern proof:** FTL uses a distinct game-over state rather than leaving
  defeat ambiguous inside the ship HUD; XCOM treats soldier loss/injury as
  meaningful persistent state rather than invisible post-combat math.
- **Evidence:** `CampaignUI.show_run_failed()` and
  `preview_failure_recovery.png`.
- **Verdict:** Pass. Retry explicitly restores the pre-fight state, making the
  adjustment actionable rather than punitive.

## 14. Run completion / heist card

**Player question:** What did this run mean, and what can I share or replay?

- **Anchor:** grade/title and the seized train route.
- **Immediate action:** inspect details, save a heist card, copy the challenge
  code, or start another run.
- **Visible facts:** survivors, three highlights, Blueprint Knowledge/run code.
- **Pattern proof:** FTL has distinct result/stat states; XCOM's strategy loop
  converts mission outcomes into the next campaign state rather than leaving
  them as an in-combat overlay.
- **Evidence:** `CampaignUI.show_run_complete()`, `preview_complete.png`, and
  `preview_heist_card.png`.
- **Verdict:** Pass. Telemetry and long crew epilogues are hidden behind
  Details, preserving a readable completion beat.

## Audit conclusion

All fourteen shipped player-facing states now have a declared anchor, a clear
next action, and precedent from at least two reference games. The only
structural failure found in this pass—the vertical route text ledger—was
replaced with equal visual route cards. Future UI work must update this record
and preserve each screen's anchor/action/fact budget.
