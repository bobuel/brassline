# Brassline: Train Heist

Current build: **1.2.0 / Character & Clarity Lift** (September 9, 2026). See `CHANGELOG_1.2.md` for this release. Open `project.godot` in Godot 4.7.1, let assets import, and press F5. The older release-candidate descriptions and certification records below are historical, not a claim of commercial certification.

A free, playable Godot 4 release candidate for a seven-car steampunk narrative-heist autobattler. The player chooses authored, context-sensitive approaches; Brassline converts each plan into deployment, initiative, movement, cover, abilities, environmental actions, body-part priorities, and fallback behavior. It combines a compliant roguelite route, persistent squad wounds and supplies, Fallout-style anatomical consequences, rigged CC0 characters, modular CC0 train environments, a full CC0 effects pass, and no paid dependencies.

Build 1.1.0-rc1 adds the **Teen Readiness** first-session and plan-to-action pass. Start Heist leads through animated crew selection and four contextual Boarding prompts; every offer now contains four distinct tactical families with a three-beat board preview. Consequential combat events drive optional cinematic focus, aftermath explains the exact failure chain, and a separate versioned profile tracks Blueprint Knowledge, sidegrade plans, mastery, cosmetics, scars, relationships, grades, and deterministic challenge codes without changing run checkpoints.

## Play it

In the packaged Windows build, double-click `Brassline.exe`. From source, double-click `PLAY_BRASSLINE.bat`, or open `project.godot` in Godot 4.7.1 and press **F6/F5**.

### Objective

Draft three operatives, take control of six carriages, and seize the Engine Car as the seventh car. Optional event cars need not contain a fight. The Boarding Car is always first and contains supplies plus one easy guard. After a clear, choose from the eligible next-car offers. Wounded crew enter preparation; healthy crew can board directly. Review Crew remains available for deliberate inspection and management.

Every completed run contains the Dining, Bar, Crew, Armory, and Engine cars plus exactly one optional car. The Engine is reserved for the finale; offer eligibility is enforced so no route choice can make the seven-car takeover impossible.

### Controls

| Input | Action |
|---|---|
| Left click | Choose a plan, contingency, crew card, route, or treatment |
| Space | Pause or resume the autobattle between initiative actions |
| 1 / 2 / 4 | Set battle speed to 1x, 2x, or 4x |
| I | Open or close the operative body/weapon/buff inspector |
| WASD | Slightly pan within the active carriage |
| Mouse wheel | Zoom |
| Home | Reframe the complete active carriage |
| Controller | D-pad/stick navigates focus; A confirms; B closes; X opens plan details; Y opens stats; Start pauses; LB/RB changes speed |

## What is implemented

- A full title/job-brief screen before combat
- Built-in field manual, Story/Standard/Brutal difficulties, reduced-motion exterior-scenery setting, master-audio mute, and optional combat sound captions
- Native 1280x720 presentation with a 12–15px tactical readability floor, enlarged world labels, a clean movement state, contextual called-shot rail, consolidated command bar, optional Stats inspector, and compact/expandable combat feed
- Automatic run checkpoints plus a Continue Run title-screen option
- Six-person crew manifest with a meaningful three-operative draft; damage, range, movement, role, and character model follow the selected roster
- A tag-driven authored-template system that binds carriage features, enemy roles, operative specialties, injuries, route buffs, and recent choices into three or four valid narrative plans
- Nine authored combat-car identities, each with a unique Living Train hazard, physical control action, guaranteed counter plan, enemy doctrine, role composition, and anatomical break
- Purposeful one-round train-event telegraphs rendered on the real carriage floor; exposed lanes can damage limbs, strip cover, or stagger the next activation, while plan-specific actions lash freight, lock the service cart, or redirect steam
- Named enemy doctrines with visible exact effects and direct body counters: Railhand Arms end concentrated fire, Officer Arms end protected volleys, and Voss's Head ends the finale-wide aim bonus
- Battlefield-first planning: the entire carriage is camera-fitted into an unobstructed viewport above a compact decision dock; full narrative and crew/enemy inspectors replace the dock without hiding the train
- Live plan staging at actual starting cells, clear-shot versus repositioning intent lines, priority-target and risk-carrier rings, exact opening hit chance, physical-cover state, body priority, and fallback doctrine
- Shared deployment constraints keep crew on the boarding side, guards beyond a five-tile minimum gap, and both teams off occupied/blocked/hazard tiles; commit revalidates the complete formation atomically
- Automatic discrete initiative that interleaves crew and guards while retaining the established pathfinding, line-of-sight, cover, role AI, animation, ammunition, and four-zone damage systems
- Visible per-operative intent and plan integrity states: on-plan, adapting, and broken; conservative plans provide an explicitly previewed covered-formation defense
- Contextual environmental execution, including the Dining Car chandelier, Bar Car bottle fire, and Engine Car pressure valve
- Physical plan props and reactions: deck rings and freight restraints, a lit swinging chandelier and wheeled service cart, red pressure valves and gauge, carriage lean, sliding trunks, warning lamps, and animated impact pulses
- A restrained autobattle HUD with initiative timeline, current plan/fallback, intent feed, live crew condition, pause, 1x/2x/4x speed, and optional detailed inspector
- Narrative carriage aftermath covering plan/fallback performance, key combat beats, new injuries, reward, synergy, and the next route transition
- Persistent plan history, recent-plan memory, three mandatory act-break crew councils, and legacy-contract migration in version-seven checkpoints
- A crew campaign layer recording Trust, Nerve, and shared memories after every battle; protecting the risk carrier, holding a broken plan, clean clears, wounds, and casualties create explicit consequences and small visible aim/critical modifiers
- A deterministic seven-car run model with a guaranteed Boarding Car opener, five mandatory archetypes, one optional archetype, and up to three compliant offers after each clear
- A dedicated first-step post-car route table showing the assembled train, exact numerical clear rewards, the cumulative permanent-buff ledger, and future unrouted slots without competing treatment controls
- A checkpointed second-step crew-preparation bay staging all three animated 3D operatives, with previous/next carousel navigation, clickable name tabs, drag-to-rotate inspection, exact body-zone status, treatment, back-to-route, and explicit boarding
- Persistent per-body-zone squad wounds, severed limbs, automatic post-car field triage, exact treatment previews, Medkits, Limb Braces, grenades, Focus Tonics, and between-car management
- Plan-aware automatic use of Clockwork Grenades and Focus Tonics, with illustrated inventory art, visible commitments, approach-to-range behavior, an animated physical grenade throw, explained intent/milestones, AP costs, blast splash, and one-shot accuracy/critical bonuses
- Six distinct crew weapons with individual damage, range, accuracy, critical chance, and magazine sizes; firing consumes ammunition and reloading costs 1 AP
- Six once-per-car signature abilities plus a full Overwatch reaction-fire action
- Order-sensitive squad buffs and named synergies affecting damage, range, movement, accuracy, critical chance, and maximum body-zone health; exact upcoming and already-earned values remain visible through route, prep, combat, and operative Stats views
- A one-guard easy opening checkpoint followed by threat- and depth-scaled enemy groups deployed at car-aware posts: bruisers hold boarding chokes, marksmen take rear/window lines, and support guards begin behind functional scenery
- A tested variable encounter curve: an easy one-round opener, short two-to-four-round standard fights, and a longer engine takeover; ordinary guards use reduced body-zone durability while bosses and bruisers retain distinct staying power
- Seven single-car combat sets with their own architecture, window treatment, accent lighting, signage, floor palette, modular dressing, and tactical cover plan
- Car-specific threat profiles: armored Armory guards, Observation marksmen, Bar/Casino duelists, crowded Crew shifts, Cargo heavies, and Engine steam hazards
- A two-choice Sleeper Car event trading deep recovery against portable medical supplies
- Persistent casualties: an operative who goes down stays down for the rest of the run
- A dedicated failed-heist screen with atomic Retry This Car restoration of pre-fight crew, supplies, telemetry, and planning, plus an explicit Abandon Run path
- A locked active-car cutaway camera that shows one bounded carriage at playable character scale instead of a repeated multi-car strip
- Passenger windows with moving exterior scenery, armored firing slits in the Armory, Engine portholes, and a panoramic glass wall and roof in Observation
- Distinct focal sets: luggage racks and freight stacks, white-cloth Dining tables, a full crimson Bar, Crew bunks and lockers, Armory cages, Engine boiler machinery, and an Observation lounge
- A unified weathered iron, aged brass, dark wood, soot, and faction-accent material treatment across 38 selected CC0 modular models; subtle riveted maker's plates replace unexplained luminous cover badges
- Three-player crew versus encounter-scaled rail guards, each represented by a rigged human character rather than block placeholders
- Blended idle, run, shoot, hit-react, and death animation integration with paced grid locomotion and eased facing turns
- Interleaved automatic initiative built on the existing two-action-point economy
- Grid pathfinding, movement ranges, line-of-sight, and visible physical-cover props aligned one-to-one with the blocker map; subtle riveted maker's plates identify real cover, while contextual teal/full and brass/half move markers appear only after a guard is selected
- Old-Fallout-inspired body priorities with exact opening hit chance, per-zone AP costs, and conditional switching when a limb is already disabled, a shot becomes untenable, or the engagement runs long
- Four readable body zones—Head, Torso, Arms, and Legs—with visible condition states and tactical consequences
- Crippled arms wreck weapon handling, crippled legs wreck mobility, and critical finishing hits physically detach the paired limbs
- Seven enemy roles—Railhand, Duelist, Marksman, Bruiser, Surgeon, Officer, and Boss—with distinct stats and support/positioning behavior
- Seed-varied role AI: Bruisers close, Duelists flank, Marksmen preserve range, support guards seek cover/formation, and exposed guards brace instead of blindly double-sprinting
- A true seventh-car finale: break Voss's command, clear or force the surviving guard to surrender, and seize the locomotive controls
- Capability-driven surrender: guards with ruined arms can yield when isolated, immobilized, or cut off from active command; surrendered enemies leave initiative and targeting immediately
- Car-clear, route-choice, complete-run, squad-loss, combat telegraph, hit-chance, and combat-log states
- An end-of-run tactical report covering crew performance plus guard shots, movement, cover use, bracing, and flanks
- Forward+ desktop renderer, local carriage lamps, dynamic shadows, animated steam, atmospheric fog, railway silhouettes, and a lower tactical camera
- Restrained movement/path overlays, a compact current-car/buff strip instead of seven persistent route boxes, a closed-by-default operative Stats card, and a narrower contextual targeting HUD that reveals itself only when an enemy is inspected
- A 27-cue CC0 sound pass for weapons, impacts, hazards, doctrine breaks, environmental controls, consumables, casino props, and interface actions, plus synthesized looping train ambience and accessible sound captions
- Six named campaign endings driven by survival, crew trust, plan cleanliness, doctrine breaks, train-event counters, and crew-council promises

`preview_intro.png`, `preview_how_to.png`, `preview_settings.png`, `preview_crew.png`, `preview_route.png`, `preview_prep.png`, `preview_recovery.png`, `preview_event.png`, and `preview_complete.png` show the run front end. `preview_autobattle_planning.png`, `preview_autobattle_combat.png`, `preview_autobattle_stats.png`, and `preview_autobattle_aftermath.png` show the narrative planning-to-resolution loop. `preview_car_*.png` provides a visual-regression frame for each combat-car identity, and `preview.png` is the train-focused presentation frame.

## Release-candidate boundary

The complete seven-car narrative-autobattler campaign is playable and checkpointed, with all nine combat-car archetypes carrying authored Living Train mechanics, persistent crew consequences, act-break councils, multiple endings, audio feedback, accessibility controls, and recoverable failure. The release candidate is visually reviewed at 1280x720 and 1920x1080 and must pass the complete automated regression matrix plus three frozen-build playthroughs before packaging. A broader commercial launch would still benefit from platform certification, localization, controller support, store assets, professional music/voice, and external playtest telemetry; those are publishing-production needs rather than missing campaign logic.

## Project map

- `scripts/grid_board.gd` - train grid, invisible blockers, pathfinding, and line of sight
- `scripts/environment_art.gd` - per-archetype cutaway carriage architecture, rolling stock, windows, focal props, lamps, and steam
- `scripts/tactical_unit.gd` - units, body-zone health, status effects, and presentation
- `scripts/character_visual.gd` - rigged model loading, animation playback, limb bones, reticle, and revolver
- `scripts/turn_controller.gd` - player actions, shooting, objectives, and enemy AI
- `scripts/plan_catalog.gd` - tag-driven authored plans, role binding, exact preview data, and fallback catalog
- `scripts/autobattle_director.gd` - initiative, intent, automatic action choice, contingencies, environment actions, and aftermath data
- `scripts/autobattle_ui.gd` - planning, live autobattle, inspector, pace controls, and aftermath presentation
- `scripts/heist_ui.gd` - retained manual-tactics HUD used by the compatibility regression path
- `scripts/campaign_ui.gd` - title screen, crew draft, train-car progression, and carriage navigator
- `scripts/crew_preview_stage.gd` - animated three-operative preparation lineup, lighting, model carousel, and drag rotation
- `scripts/run_state.gd` - seven-car compliance, eligible offers, ordered buffs, inventory, and persistent squad state
- `scripts/signature_arc.gd` - authored Boarding/Dining/Engine hazards, telegraphs, doctrine identities, and anatomical counters
- `scripts/audio_director.gd` - pooled sound effects, Living Train ambience, interface hooks, and accessible combat captions
- `scripts/target_silhouette.gd` - clickable body hit-map, condition colors, and percentages
- `scripts/camera_rig.gd` - locked active-car framing, bounded pan, zoom, reset, and presentation focus
- `scripts/main.gd` - scene assembly, input, world lighting, and moving Kenney tracks
- `tests/combat_smoke.gd` - automated called-shot, AP-cost, and dismemberment regression
- `tests/character_asset_smoke.gd` - verifies all six rigs, required bones, and combat animations
- `tests/environment_asset_smoke.gd` - verifies all 38 models, palette textures, train dressing, and blocker preservation
- `tests/campaign_flow_smoke.gd` - verifies intro, crew drafting, route-first choice, 3D prep lineup, operative rotation, treatment targeting, and final boarding
- `tests/between_car_recovery_smoke.gd` - verifies automatic triage, exact zone readouts and supply previews, treatment effects, feedback, and persistence
- `tests/run_state_smoke.gd` - simulates 360 adversarial runs and proves the seven-car compliance invariant
- `tests/seven_car_integration_smoke.gd` - verifies the live opener, clear, management, offer, and persistent encounter transition
- `tests/car_archetype_smoke.gd` - verifies all car identities, distinct threat profiles, and the Sleeper event path
- `tests/car_presentation_smoke.gd` - verifies seven single-car sets, unique windows, floor plans, aligned visible cover props, through-routes, and locked framing
- `tests/logical_spawn_smoke.gd` - verifies seven car-aware guard deployments, role depth, safe tiles, formation variety, and cover posts
- `tests/full_run_soak.gd` - drives the real scene from crew selection through all seven cars and verifies the final contract
- `tests/full_turn_playthrough.gd` - completes seven cars using real movement, AP, attacks, enemy turns, wounds, supplies, casualties, save/continue, and victory cleanup
- `tests/hud_layout_smoke.gd` - verifies native-resolution type sizing and non-overlapping clean, targeting, command, and combat-feed regions
- `tests/car_buff_ui_smoke.gd` - verifies exact car rewards, cumulative buff summaries, crew-prep explanations, and the optional operative stat breakdown
- `tests/enemy_tactics_smoke.gd` - verifies contextual cover previews, stance defense/AP rules, role-specific destinations, and move-then-brace enemy behavior
- `tests/enemy_tactics_simulation.gd` - evaluates seeded role decisions and cover selection across seven car layouts
- `tests/autobattle_vertical_slice_smoke.gd` - verifies Boarding planning, deployment, pace, initiative, body doctrine, persistence, aftermath, and route transition
- `tests/autobattle_dining_smoke.gd` - verifies Dining context, Officer/Bruiser composition, plan variety, and chandelier leg damage
- `tests/autobattle_plan_permutations.gd` - verifies roster/injury/casualty compatibility and the safe-plan guarantee
- `tests/autobattle_consumable_smoke.gd` - verifies plan-aware Focus Tonic use, persistent inventory, telemetry, and combat explanation
- `tests/autobattle_grenade_smoke.gd` - verifies explicit grenade commitment, approach to legal range, throw execution, damage, inventory, and telemetry
- `tests/autobattle_deployment_safety.gd` - sweeps nine cars, three variants, six operatives, and one-to-three survivors to prove preview/commit separation and safe starts
- `tests/planning_visibility_smoke.gd` - checks full-car framing, every starting unit, docked details, and world-click enemy inspection at 1280x720 and 1920x1080
- `tests/takeover_refinement_smoke.gd` - verifies distinct plan families, split threat assignments, gear commitments, surrender, control capture, and takeover victory
- `tests/autobattle_full_run.gd` - drives real authored plans through all seven cars, including the Engine control takeover
- `tests/signature_arc_smoke.gd` - verifies all three train events, floor telegraphs, doctrine/body counters, trust, nerve, memories, and save migration
- `tests/signature_arc_playthrough.gd` - wins Boarding, Dining, and Engine through real initiative while proving environmental control, aftermath persistence, and train capture
- `tests/full_car_authorship_smoke.gd` - verifies all nine combat-car hazards, controls, plans, doctrines, physical focal props, and anatomical breaks
- `tests/full_authored_arc_playthrough.gd` - wins all nine archetypes through real automatic initiative
- `tests/crew_council_smoke.gd` - verifies the three act-break choices, campaign effects, persistence, and ending influence
- `tests/campaign_epilogue_smoke.gd` - verifies named endings, grades, routes, and crew epilogues
- `tests/audio_director_smoke.gd` - verifies CC0 cue loading, pooled playback, ambience, interface hooks, and captions
- `tests/failure_recovery_smoke.gd` - verifies the failed-heist screen and atomic pre-fight restoration
- `tests/teen_readiness_plan_smoke.gd` - verifies four-family offers, repetition caps, safe deployments, previews, and item eligibility
- `tests/onboarding_controller_smoke.gd` - verifies Start Heist, the animated default trio, four contextual prompts, controller legends/focus, and scalable text
- `tests/presentation_failure_smoke.gd` - verifies ordered presentation beats and causal failure/fallback/injury explanations
- `tests/profile_progression_smoke.gd` - verifies independent schema migration, sidegrade progression, daily seeds, and challenge-code determinism
- `tests/heist_share_card_smoke.gd` - verifies the 1280x720 visual heist record and copyable challenge code
- `ASSET_CREDITS.md` - sources, CC0 license copies, and generated-icon provenance

## Autobattle rules in this build

- Plans assign torso, head, arms, or legs as the opening body priority. Torso shots cost 1 AP; head and limb shots cost 2 AP and carry accuracy penalties.
- The director changes to a secondary zone when the priority is disabled, uses a finishing shot when the planned capability is already broken, and preserves a disabling setup across activations when it lacks the second action point.
- Head shots have the highest critical chance and damage multiplier.
- Crippled arms impose -36% accuracy, halve weapon damage, and prevent reloads and Overwatch.
- Crippled legs reduce movement to one tile and prevent Take Cover.
- Zero health cripples a paired zone; a critical finishing hit severs both modeled limbs. Severed arms and legs are baked from the posed, textured character mesh, fall onto the carriage using physics, and cannot be targeted again.
- The director commits Clockwork Grenades to aggressive, flanking, hazard, or decisive plans with a viable blast target. The carrier closes to six-tile range before throwing; the grenade costs 1 AP, injures a target limb and torso, and splashes adjacent guards.
- The director commits Focus Tonics when a difficult non-torso called shot falls below 90% and no signature aim buff is already active. They grant +18% hit and +16% critical chance to the next shot, hit or miss.
- Take Cover costs 1 AP and lasts until that unit's next activation: ducking imposes -10% incoming hit on top of any half/full-cover penalty from nearby scenery.

Godot is MIT-licensed and has no royalties. The Quaternius characters and all Kenney environment/audio packs are CC0; full provenance is in `ASSET_CREDITS.md`. The release candidate contains no paid dependencies.
