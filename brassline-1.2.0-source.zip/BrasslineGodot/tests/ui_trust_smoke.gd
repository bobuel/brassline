extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const RunState := preload("res://scripts/run_state.gd")
const Campaign := preload("res://scripts/campaign_ui.gd")

var failures: Array[String] = []

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for frame in range(8): await process_frame
	_check(_contains_text(scene.campaign_ui.front_content, "BUILD " + String(ProjectSettings.get_setting("application/config/version", "DEV"))), "Title does not identify the current build.")
	var crew: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew, 771203)
	var ui: AutobattleUI = scene.autobattle_ui
	ui.set_text_scale(1.3)
	for frame in range(3): await process_frame
	for button in ui.plan_buttons:
		var icon := button.get_node_or_null("FamilyIcon") as Control
		_check(is_instance_valid(icon), "Plan tile has no family icon.")
		if is_instance_valid(icon):
			for state in ["normal", "hover", "pressed", "focus"]:
				_check(icon.position.x + icon.size.x < button.get_theme_stylebox(state).content_margin_left, "Family icon overlaps plan text in %s state." % state)
	for button in ui.planning_crew_row.get_children():
		var portrait := button.get_node_or_null("CrewPortrait") as TextureRect
		_check(is_instance_valid(portrait) and portrait.texture != null and portrait.size.x >= 26 and portrait.size.y >= 34, "A planning portrait vanished or shrank below its reserved column.")
		if is_instance_valid(portrait):
			_check(portrait.position.x + portrait.size.x < button.get_theme_stylebox("normal").content_margin_left, "Planning portrait overlaps operative details.")
	_check("▾" not in ui.fallback_button.text, "Fallback picker still uses unsupported Web arrow glyph.")
	ui.plan_buttons[2].grab_focus()
	ui.show_inspector("ada")
	for frame in range(3): await process_frame
	var ledger: CrewLedgerUI = ui.inspector_panel
	ledger._select_crew("marlow")
	ledger._select_tab("gear")
	(ledger.tabs["gear"] as Button).grab_focus()
	var prior_focus := root.gui_get_focus_owner()
	var prior_visual := ledger.stage.active_visual
	prior_visual.rotation.y = 0.71
	for update in range(8): ui.refresh_combat_crew()
	_check(ledger.selected_roster_id == "marlow" and ledger.selected_tab == "gear", "Ledger refresh changed selected actor or tab.")
	_check(root.gui_get_focus_owner() == prior_focus, "Ledger refresh moved controller focus.")
	_check(ledger.stage.active_visual == prior_visual and is_equal_approx(prior_visual.rotation.y, 0.71), "Ledger refresh rebuilt the character or lost drag rotation.")
	_check(ledger.crew_list.get_child(0).get_theme_font_size("font_size") == 17, "Dynamic crew rows ignored 130% text.")
	_check(ledger.body_grid.get_child(0).get_theme_font_size("font_size") == 17, "Dynamic body zones ignored 130% text.")
	ledger.close()
	await process_frame
	_check(root.gui_get_focus_owner() == ui.plan_buttons[2], "Closing Ledger failed to restore the invoking control.")
	var enemy: TacticalUnit = scene.turn.enemy_units(true)[0]
	ui.show_unit_inspector(enemy)
	await process_frame
	_check(ledger._selected_unit() == enemy and ledger.selected_roster_id != "ada", "Enemy inspection switched to friendly crew.")
	_check(ledger.context_label.text.begins_with("ENEMY") and "NERVE" not in ledger.detail_body.text, "Enemy inspection showed friendly campaign facts.")
	ledger._select_tab("gear")
	_check("Crew supplies are separate" in ledger.detail_body.text, "Enemy gear leaked shared crew inventory.")
	ledger.close()
	var director: AutobattleDirector = scene.autobattle_director
	director.running = true
	director.paused = false
	director.set_speed(2.0)
	ui.show_inspector("nix")
	_check(director.inspection_paused and is_zero_approx(director.effective_time_scale()), "Opening Ledger did not stop combat time.")
	ledger.close()
	_check(not director.inspection_paused and not director.paused and is_equal_approx(director.effective_time_scale(), 1.0), "Closing Ledger changed the selected pace or left inspection paused.")
	director.set_paused(true)
	ui.show_inspector("nix")
	ledger.close()
	_check(director.paused, "Closing Ledger resumed a fight the player had already paused.")
	director.stop()
	ui.hide_all()
	var run: RefCounted = scene.run_state
	run.complete_current_car()
	run.prepare_next_car(run.current_offers[0])
	var body: Dictionary = run.body_state_for("ada")
	body[Types.BodyZone.TORSO]["hp"] = 1
	run.record_crew_body_state("ada", body)
	var campaign: CampaignUI = scene.campaign_ui
	campaign.text_scale = 1.3
	campaign.show_crew_prep(run)
	for frame in range(5): await process_frame
	_check(_contains_text(campaign.front_content, "CRITICAL TORSO"), "Critical torso injury is not visible on preparation.")
	_check(_contains_text(campaign.front_content, "RECOMMENDED / MEDKIT"), "Critical torso did not recommend a Medkit.")
	_check(not _contains_text(campaign.front_content, "NO TREATMENT NEEDED"), "Critical operative still says no treatment needed.")
	_check(Rect2(Vector2.ZERO, root.size).encloses(campaign.prep_board_button.get_global_rect()), "Preparation Board action overflows at 130%%/720p: %s." % campaign.prep_board_button.get_global_rect())
	if not Rect2(Vector2.ZERO, root.size).encloses(campaign.prep_board_button.get_global_rect()):
		for child in campaign.front_content.get_children():
			if child is Control: print("PREP_LAYOUT %s %s" % [child.get_class(), child.get_global_rect()])
	var save_path := "user://ui_trust_settings_%d.cfg" % OS.get_process_id()
	campaign.reduced_motion_enabled = true
	campaign.audio_captions_enabled = true
	campaign.cinematic_focus_mode = "off"
	_check(campaign.save_settings(save_path), "Settings could not be written to isolated path.")
	var restored := Campaign.new()
	_check(restored.load_settings(save_path), "Saved settings could not load.")
	_check(is_equal_approx(restored.text_scale, 1.3) and restored.reduced_motion_enabled and restored.audio_captions_enabled and restored.cinematic_focus_mode == "off", "Comfort settings failed round trip.")
	restored.free()
	DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
	campaign.show_challenge_import()
	campaign._validate_challenge_input("not a code")
	_check(campaign.challenge_start_button.disabled, "Invalid challenge code enabled Start.")
	var code: String = scene.profile_state.build_challenge_code(12345, "standard", crew)
	campaign._validate_challenge_input(code)
	_check(not campaign.challenge_start_button.disabled and "ADA" in campaign.challenge_feedback.text.to_upper(), "Valid challenge did not show crew and enable Start.")
	for resolution in [Vector2i(1280, 720), Vector2i(1280, 800), Vector2i(1920, 1080)]:
		root.size = resolution
		ui.show_inspector("ada")
		for frame in range(4): await process_frame
		_check(Rect2(Vector2.ZERO, resolution).encloses(ledger.tabs["train"].get_global_rect()), "Ledger tabs overflow at %s/130%%." % resolution)
		ledger.close()
	if failures.is_empty(): print("BRASSLINE UI TRUST: PASS - stable actor/tab/focus/rotation, enemy inspection, overlay pause ownership, 130% text, critical injury advice, persistent settings, challenge import and viewport controls verified.")
	else:
		for failure in failures: push_error("BRASSLINE UI TRUST: FAIL - " + failure)
	quit(0 if failures.is_empty() else 1)

func _check(condition: bool, message: String) -> void:
	if not condition: failures.append(message)

func _contains_text(node: Node, fragment: String) -> bool:
	if node is Label and fragment in node.text: return true
	for child in node.get_children():
		if _contains_text(child, fragment): return true
	return false
