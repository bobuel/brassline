extends SceneTree

const ROSTER := [["ada","Casual_2","longshot_rifle"],["marlow","Adventurer","breach_gun"],["nix","Punk","coil_pistol"],["iona","Worker","rivet_carbine"],["silas","Suit","duelist_revolver"],["rook","Swat","hand_cannon"]]

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var suffix := "before" if "--before" in OS.get_cmdline_user_args() else "after"
	root.size = Vector2i(1280,900)
	var stage := Node3D.new(); root.add_child(stage); current_scene = stage
	var world := WorldEnvironment.new(); var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR; environment.background_color = Color("#15272c")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; environment.ambient_light_color = Color("#acb9b4"); environment.ambient_light_energy = 0.85
	world.environment = environment; stage.add_child(world)
	var key := DirectionalLight3D.new(); key.rotation_degrees = Vector3(-35,-30,0); key.light_energy=1.8; stage.add_child(key)
	var rim := DirectionalLight3D.new(); rim.rotation_degrees = Vector3(-20,145,0); rim.light_color=Color("#7eb5bc"); rim.light_energy=0.7; stage.add_child(rim)
	var camera := Camera3D.new(); camera.fov=32; stage.add_child(camera); camera.look_at_from_position(Vector3(2.8,1.8,3.2),Vector3(0,1.04,0.18),Vector3.UP); camera.current=true
	var label := Label.new(); label.position=Vector2(30,24); label.add_theme_font_size_override("font_size",26); root.add_child(label)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://../../work/graphics-lift"))
	for member in ROSTER:
		var visual := CharacterVisual.new(); stage.add_child(visual)
		visual.setup("res://assets/characters/quaternius/%s.gltf"%member[1],0); visual.build_weapon(member[2])
		if "--probe" in OS.get_cmdline_user_args():
			for bone in ["Hips","Spine","Chest","UpperArm.R","LowerArm.R","Wrist.R","UpperArm.L","LowerArm.L","Wrist.L"]:
				var bone_id := visual.skeleton.find_bone(bone)
				if bone_id >= 0: print(member[0]," ",bone," ",visual.skeleton.global_transform * visual.skeleton.get_bone_global_pose(bone_id))
		for pose in ["idle","aim"]:
			visual.animation_player.play("Idle_Gun" if pose == "idle" else "Idle_Gun_Pointing"); visual.animation_player.advance(0.12); visual.animation_player.pause()
			label.text="%s / %s / %s / %s"%[String(member[0]).to_upper(),String(member[2]).replace("_"," ").to_upper(),pose.to_upper(),suffix.to_upper()]
			for frame in range(12): await process_frame
			if DisplayServer.get_name() != "headless":
				await RenderingServer.frame_post_draw
				root.get_texture().get_image().save_png("res://../../work/graphics-lift/%s_%s_%s.png"%[member[0],pose,suffix])
		if suffix == "after":
			Engine.time_scale=0.1
			visual.play_shoot();label.text="%s / FIRING / AFTER"%String(member[0]).to_upper()
			for frame in range(5):await process_frame
			if DisplayServer.get_name() != "headless":
				await RenderingServer.frame_post_draw
				root.get_texture().get_image().save_png("res://../../work/graphics-lift/%s_fire_after.png"%member[0])
			Engine.time_scale=1.0
		visual.free()
	print("WEAPON UPLIFT CAPTURE: PASS - six rigs, two poses, "+suffix)
	quit(0)
