extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
const Types := preload("res://scripts/game_types.gd")
const CampaignUI := preload("res://scripts/campaign_ui.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	root.size = Vector2i(1280, 720)
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	var run := RunState.new()
	run.start_new_run(crew_ids, 55051)
	var ada_body := run.body_state_for("ada")
	ada_body[Types.BodyZone.HEAD]["hp"] = 2
	ada_body[Types.BodyZone.TORSO]["hp"] = 5
	ada_body[Types.BodyZone.ARMS]["hp"] = 1
	run.record_crew_body_state("ada", ada_body)
	var marlow_body := run.body_state_for("marlow")
	marlow_body[Types.BodyZone.HEAD]["hp"] = 0
	marlow_body[Types.BodyZone.HEAD]["disabled"] = true
	run.record_crew_status("marlow", marlow_body, false)
	var completion: Dictionary = run.complete_current_car()
	if not bool(completion.get("ok", false)) or int(run.last_recovery.get("total", 0)) != 3:
		_fail("Securing a car did not apply one point of automatic triage to each wounded intact zone.")
		return
	ada_body = run.body_state_for("ada")
	if int(ada_body[Types.BodyZone.HEAD]["hp"]) != 3 or int(ada_body[Types.BodyZone.TORSO]["hp"]) != 6 or int(ada_body[Types.BodyZone.ARMS]["hp"]) != 2:
		_fail("Automatic triage did not persist the expected per-zone recovery.")
		return
	if int(run.body_state_for("marlow")[Types.BodyZone.HEAD]["hp"]) != 0:
		_fail("Automatic triage altered a permanently downed operative.")
		return

	var campaign := CampaignUI.new()
	root.add_child(campaign)
	await process_frame
	campaign.show_intermission(run, true)
	await process_frame
	if campaign.management_feedback_label != null or not _tree_contains_text(campaign.front_content, "3 HP RESTORED"):
		_fail("The route step did not summarize automatic recovery without mixing in treatment controls.")
		return
	if not run.prepare_next_car(run.current_offers[0]):
		_fail("Recovery testing could not advance from route selection into crew preparation.")
		return
	campaign.show_crew_prep(run)
	for _frame in range(8):
		await process_frame
	if campaign._management_crew_id != "ada" or "3 HP RESTORED" not in campaign.management_feedback_label.text:
		_fail("Crew preparation did not select a living operative and explain automatic recovery.")
		return
	if not _tree_contains_text(campaign.front_content, "TORSO 6/8 WOUNDED"):
		_fail("The management panel does not expose exact selected body-zone health.")
		return
	var medkit_button := _find_button_containing(campaign.front_content, "MEDKIT  x2")
	if medkit_button == null or medkit_button.disabled or "+5 HP ACROSS 3 WOUNDED ZONES" not in medkit_button.text:
		_fail("The Medkit control did not preview its exact recoverable HP.")
		return
	var panel_bounds: Rect2 = campaign.front_panel.get_global_rect()
	var viewport_bounds := Rect2(Vector2.ZERO, root.size)
	for control: Control in [campaign.crew_preview_stage, medkit_button, campaign.management_feedback_label, campaign.prep_board_button]:
		if not panel_bounds.encloses(control.get_global_rect()):
			_fail("The recovery controls overflow the native 1280x720 route panel.")
			return
		if not viewport_bounds.encloses(control.get_global_rect()):
			_fail("The recovery controls overflow the visible viewport.")
			return
	if campaign.prep_board_button.get_global_rect().end.y > root.size.y - 12.0:
		_fail("The Board Car transition is below the native 720p fold.")
		return
	if _contains_scroll_container(campaign.front_content):
		_fail("Crew preparation added scrolling instead of fitting the transition on screen.")
		return
	if campaign.crew_preview_stage.get_global_rect().intersects(medkit_button.get_global_rect()):
		_fail("The animated crew lineup overlaps the operative treatment controls.")
		return

	var preview: Dictionary = run.item_use_preview("medkit", "ada")
	if not bool(preview.get("can_use", false)) or int(preview.get("healed", 0)) != 5:
		_fail("The Medkit preview disagreed with the wounded body state.")
		return
	var medkit_result: Dictionary = run.use_item("medkit", "ada")
	if not bool(medkit_result.get("ok", false)) or int(medkit_result.get("healed", 0)) != 5 or int(run.inventory["medkit"]) != 1:
		_fail("Using a Medkit did not heal and consume exactly what its preview promised.")
		return
	var brace_preview: Dictionary = run.item_use_preview("limb_brace", "ada")
	if not bool(brace_preview.get("can_use", false)) or int(brace_preview.get("zone", -1)) != Types.BodyZone.ARMS:
		_fail("The Limb Brace did not identify Ada's weakest attached limb.")
		return
	var brace_result: Dictionary = run.use_item("limb_brace", "ada")
	if not bool(brace_result.get("ok", false)) or int(run.body_state_for("ada")[Types.BodyZone.ARMS]["hp"]) != 8:
		_fail("The Limb Brace did not restore the advertised limb health.")
		return
	var no_change: Dictionary = run.item_use_preview("medkit", "nix")
	if bool(no_change.get("can_use", true)) or "already full" not in String(no_change.get("reason", "")):
		_fail("A healthy operative still presents a misleading usable Medkit.")
		return
	campaign.set_management_feedback("ADA BRASS / Medkit restored 5 HP.", true)
	campaign.show_crew_prep(run)
	if "restored 5 HP" not in campaign.management_feedback_label.text:
		_fail("Successful treatment feedback disappeared when the panel refreshed.")
		return

	# Maximum-health rewards must preserve a healthy body instead of manufacturing
	# an apparent wound on the route screen.
	var dining_run := RunState.new()
	dining_run.start_new_run(crew_ids, 55052)
	dining_run.current_car_id = "dining"
	dining_run.complete_current_car()
	var dining_body: Dictionary = dining_run.body_state_for("ada")
	for zone in dining_body:
		if int(dining_body[zone]["hp"]) != int(dining_body[zone]["max_hp"]):
			_fail("Dining's maximum-health reward made a healthy zone appear wounded.")
			return

	var restored := RunState.new()
	if not restored.load_from_save_data(run.to_save_data()) or int(restored.last_recovery.get("total", -1)) != 3:
		_fail("Recovery feedback did not survive an intermission checkpoint.")
		return

	print("BRASSLINE BETWEEN-CAR RECOVERY SMOKE: PASS - automatic triage, exact zone readouts, treatment previews, supply effects, downed crew handling, reward math, feedback, and checkpoint persistence verified.")
	quit(0)


func _find_button_containing(root_node: Node, text_fragment: String) -> Button:
	for child in root_node.get_children():
		if child is Button and text_fragment in child.text:
			return child
		var nested := _find_button_containing(child, text_fragment)
		if nested != null:
			return nested
	return null


func _tree_contains_text(root_node: Node, text_fragment: String) -> bool:
	for child in root_node.get_children():
		if child is Label and text_fragment in child.text:
			return true
		if _tree_contains_text(child, text_fragment):
			return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE BETWEEN-CAR RECOVERY SMOKE: FAIL - %s" % message)
	quit(1)


func _contains_scroll_container(node: Node) -> bool:
	if node is ScrollContainer:
		return true
	for child in node.get_children():
		if _contains_scroll_container(child):
			return true
	return false
