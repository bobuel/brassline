extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")

const COMBAT_CARS: Array[String] = [
	"baggage", "dining", "bar", "crew", "armory", "observation", "cargo", "casino", "engine",
]
const REQUIRED_PLANS := {
	"baggage": ["lash_the_freight", "break_the_hands"],
	"dining": ["lock_the_service_cart", "pin_the_command"],
	"bar": ["light_the_backbar", "spoil_the_draw"],
	"crew": ["dog_the_lockers", "break_the_relief"],
	"armory": ["jam_the_press", "break_the_cage_line"],
	"observation": ["drop_storm_shutters", "blind_the_spotters"],
	"cargo": ["set_the_cargo_brake", "cripple_the_loader"],
	"casino": ["lock_the_tables", "beat_the_house_edge"],
	"engine": ["bleed_the_pressure", "break_voss_timing"],
}
const FOCAL_PROPS := {
	"baggage": "FreightRestraint",
	"dining": "DiningServiceCart",
	"bar": "BackbarIgniter",
	"crew": "CrewLocker",
	"armory": "AmmoPress",
	"observation": "StormShutter",
	"cargo": "CargoBrakeWheel",
	"casino": "CasinoTimingWheel",
	"engine": "RedlineGauge",
}


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	scene.campaign_ui.selected_difficulty = "story"
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 928417)
	for _frame in range(4):
		await process_frame

	var doctrine_ids: Array[String] = []
	for car_id in COMBAT_CARS:
		if car_id != "baggage":
			scene.autobattle_director.stop()
			scene.run_state.completed_car_ids.assign(
				["baggage", "dining", "bar", "crew", "armory", "observation"]
				if car_id == "engine" else ["baggage"]
			)
			scene.run_state.current_car_id = car_id
			scene.run_state.phase = "encounter"
			await scene._load_run_encounter()
			for _frame in range(4):
				await process_frame

		var profile: Dictionary = SignatureArc.car_profile(car_id)
		if profile.is_empty():
			_fail("%s has no authored Living Train/doctrine profile." % car_id)
			return
		var doctrine_id := String(profile.get("doctrine_id", ""))
		if doctrine_id.is_empty() or doctrine_id in doctrine_ids:
			_fail("%s does not own a unique enemy doctrine." % car_id)
			return
		doctrine_ids.append(doctrine_id)

		var warning := SignatureArc.event_for_round(car_id, 1)
		var impact := SignatureArc.event_for_round(car_id, 2)
		if String(warning.get("phase", "")) != "warning" or String(impact.get("phase", "")) != "impact" or Array(impact.get("cells", [])).is_empty():
			_fail("%s does not telegraph a physical floor hazard one round before impact." % car_id)
			return
		if String(impact.get("counter_action", "")) != String(profile.get("counter_action", "")):
			_fail("%s hazard and authored counter action disagree." % car_id)
			return

		var offered_ids: Array[String] = []
		for plan in scene.autobattle_ui.plans:
			offered_ids.append(String(plan.get("id", "")))
		for required_id in Array(REQUIRED_PLANS[car_id]):
			if String(required_id) not in offered_ids:
				_fail("%s hid required plan %s. Offered: %s" % [car_id, required_id, ", ".join(offered_ids)])
				return

		if not _has_direct_child_named(scene.train_art._active_dressing, String(FOCAL_PROPS[car_id])):
			_fail("%s is missing physical focal prop %s." % [car_id, FOCAL_PROPS[car_id]])
			return
		scene.train_art.set_living_train_event(warning, {})
		if scene.train_art._train_event_root.get_child_count() != Array(warning.get("cells", [])).size():
			_fail("%s did not render every telegraphed hazard cell." % car_id)
			return

		var counter_plan := _plan_with_id(scene.autobattle_ui.plans, String(REQUIRED_PLANS[car_id][0]))
		var action_id := String(counter_plan.get("environment_action", ""))
		if action_id != String(profile.get("counter_action", "")):
			_fail("%s control plan does not execute its declared train counter." % car_id)
			return
		var actor: TacticalUnit = scene.turn.player_units(true)[0]
		actor.action_points = 2
		scene.turn.autobattle_enabled = true
		scene.turn.phase = Types.Phase.PLAYER
		var action_result: Dictionary = await scene.turn.perform_plan_environment_action(action_id, actor)
		if not bool(action_result.get("ok", false)) or not bool(action_result.get("train_counter", false)):
			_fail("%s physical counter action could not execute in live combat." % car_id)
			return

		var doctrine: Dictionary = scene.turn.apply_enemy_doctrine_round()
		if String(doctrine.get("id", "")) != doctrine_id or bool(doctrine.get("broken", true)) or String(doctrine.get("round_effect", "")).is_empty():
			_fail("%s doctrine did not become active with an explicit mechanical effect." % car_id)
			return
		var break_role := String(profile.get("break_role", ""))
		var break_zone: Types.BodyZone = int(profile.get("break_zone", Types.BodyZone.ARMS))
		var counter_count := 0
		for enemy in scene.turn.enemy_units(true):
			if enemy.role_id == break_role:
				counter_count += 1
				enemy.apply_damage(break_zone, 999, true)
		if counter_count == 0:
			_fail("%s doctrine names a counter role that the encounter never spawns." % car_id)
			return
		doctrine = scene.turn.apply_enemy_doctrine_round()
		if not bool(doctrine.get("broken", false)):
			_fail("%s doctrine survived its advertised anatomical counter." % car_id)
			return

	print("BRASSLINE FULL CAR AUTHORSHIP: PASS - 9 combat cars own unique hazards, floor telegraphs, physical controls, guaranteed counter plans, live doctrine effects, and anatomical breaks.")
	quit(0)


func _plan_with_id(plans: Array[Dictionary], plan_id: String) -> Dictionary:
	for plan in plans:
		if String(plan.get("id", "")) == plan_id:
			return plan
	return {}


func _has_direct_child_named(parent: Node, child_name: String) -> bool:
	for child in parent.get_children():
		if child.name == child_name:
			return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE FULL CAR AUTHORSHIP: FAIL - %s" % message)
	quit(1)
