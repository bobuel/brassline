extends SceneTree

const CARS: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "observation", "cargo", "casino", "engine"]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var capture := "--capture-planning" in OS.get_cmdline_user_args()
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8): await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 98520)
	var states_checked := 0
	for size in [Vector2i(1280, 720), Vector2i(1280, 800), Vector2i(1920, 1080)]:
		root.content_scale_size = size
		root.size = size
		for _frame in range(4): await process_frame
		for car_id in CARS:
			scene.run_state.current_car_id = car_id
			scene.run_state.phase = "encounter"
			scene.run_state.completed_car_ids.clear()
			if car_id == "engine":
				scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew", "armory", "observation"])
			elif car_id != "baggage":
				scene.run_state.completed_car_ids.assign(["baggage"])
			await scene._load_run_encounter()
			if scene.autobattle_ui.plans.is_empty():
				_fail("No plan offers were exercised. Run this test with -- --autobattle-test.")
				return
			for plan_index in range(scene.autobattle_ui.plans.size()):
				scene.autobattle_ui._select_plan(plan_index)
				for _frame in range(3): await process_frame
				var world_rect: Rect2 = scene.autobattle_ui.planning_battlefield_rect()
				if not world_rect.encloses(scene.camera_rig.planning_projected_bounds()):
					_fail("%s at %s clips the carriage behind UI." % [car_id, str(size)])
					return
				for unit in scene.turn.units:
					for height in [0.12, 2.5]:
						var point: Vector2 = scene.camera_rig.camera.unproject_position(scene.board.cell_to_world(unit.grid_cell) + Vector3(0, height, 0))
						if not world_rect.has_point(point):
							_fail("%s / plan %d hides %s at %s." % [car_id, plan_index, unit.display_name, str(size)])
							return
				states_checked += 1
			scene.autobattle_ui._select_plan(0)
			for _frame in range(12): await process_frame
			if capture:
				root.get_texture().get_image().save_png("res://preview_planning_%s_%dx%d.png" % [car_id, size.x, size.y])
			# Use the same world-click path as the player, not merely the inspector API.
			await physics_frame
			var guard: TacticalUnit = scene.turn.enemy_units(true)[0]
			var guard_point: Vector2 = scene.camera_rig.camera.unproject_position(guard.global_position + Vector3(0, 0.9, 0))
			scene._handle_planning_inspection(guard_point)
			for _frame in range(3): await process_frame
			var ledger := scene.autobattle_ui.inspector_panel as CrewLedgerUI
			if ledger == null or not ledger.is_visible_in_tree() or not ledger.operative_title.is_visible_in_tree() or guard.display_name.to_upper() not in ledger.operative_title.text or ledger.context_label.text != "ENEMY / INSPECTION":
				_fail("Clicking a guard did not show that exact enemy in the visible Ledger title/context.")
				return
			if ledger.selected_roster_id != CrewLedgerUI.unit_key(guard) or ledger.detail_title.text != "ENEMY" or "POST /" not in ledger.detail_body.text:
				_fail("Visible enemy inspection does not show the clicked guard's identity, role and post.")
				return
			if not scene.autobattle_ui.inspector_panel.get_global_rect().encloses(scene.autobattle_ui.planning_battlefield_rect()):
				_fail("Enemy inspection is not the intended full-screen Ledger.")
				return
			if capture and car_id == "dining" and size.x == 1280:
				root.get_texture().get_image().save_png("res://preview_planning_enemy_inspector.png")
			scene.autobattle_ui.inspector_panel.visible = false
			scene.autobattle_ui.toggle_plan_details()
			for _frame in range(3): await process_frame
			if scene.autobattle_ui.planning_battlefield_rect().intersects(scene.autobattle_ui.planning_details.get_global_rect()):
				_fail("Expanded plan details cover the carriage.")
				return
			scene.autobattle_ui.toggle_plan_details()
	if states_checked < CARS.size() * 3 * 4:
		_fail("The full four-plan offer matrix was not exercised."); return
	print("BRASSLINE PLANNING VISIBILITY: PASS - %d live plan views / all 9 combat-car archetypes / 1280x720, 1280x800 and 1920x1080; full carriage, exact visible enemy Ledger, and docked details verified." % states_checked)
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE PLANNING VISIBILITY: FAIL - %s" % message)
	quit(1)
