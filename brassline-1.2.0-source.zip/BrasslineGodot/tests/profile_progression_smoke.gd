extends SceneTree

const ProfileState := preload("res://scripts/profile_state.gd")
const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	var profile := ProfileState.new()
	profile.ensure_roster(["ada", "marlow", "nix"])
	var reward: Dictionary = profile.award_car_clear("dining", ["ada", "marlow", "nix"], true, 1, 1)
	if int(reward.get("amount", 0)) != 6 or profile.blueprint_knowledge != 6:
		_fail("Blueprint Knowledge did not combine clear, discovery, risk, cripple, and environment rewards.")
		return
	if "blueprint_crossfire" not in profile.unlocked_plan_ids:
		_fail("The first sidegrade plan did not unlock without a raw-stat reward.")
		return
	profile.record_injuries([{"roster_id": "ada", "changes": ["arms crippled"], "down": false}])
	profile.record_relationships([{"key": "ada|marlow", "crew_ids": ["ada", "marlow"], "bond": 2, "label": "RELIABLE", "shared_jobs": 3, "history": ["Held the line."]}])
	if "arms crippled" not in profile.scars_for("ada") or "MARLOW / RELIABLE" not in profile.relationship_summary_for("ada"):
		_fail("Persistent scars or relationship history did not survive profile recording.")
		return
	var code := profile.record_run_complete(782341, "standard", "A", ["ada", "marlow", "nix"])
	var parsed: Dictionary = profile.parse_challenge_code(code)
	if not bool(parsed.get("ok", false)) or int(parsed.get("seed", 0)) != 782341 or String(parsed.get("difficulty", "")) != "standard":
		_fail("Challenge-code round trip was not deterministic: %s" % code)
		return
	var fixture_date := {"year": 2026, "month": 8, "day": 29}
	if profile.daily_seed(fixture_date) != profile.daily_seed(fixture_date):
		_fail("Daily challenge seed changed for the same calendar day.")
		return
	var save_path := "user://brassline_profile_smoke_%d.json" % OS.get_process_id()
	if not profile.save_to_disk(save_path):
		_fail("Versioned profile could not be saved.")
		return
	var restored := ProfileState.new()
	if not restored.load_from_disk(save_path) or restored.blueprint_knowledge != 6 or restored.scars_for("ada").is_empty():
		_fail("Versioned profile migration/save round trip lost progression.")
		return
	var run_state := RunState.new()
	var crew: Array[String] = ["ada", "marlow", "nix"]
	run_state.start_new_run(crew, 782341, "standard")
	if int(run_state.to_save_data().get("version", -1)) != 7:
		_fail("Profile work changed the independent run-checkpoint schema.")
		return
	DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path))
	print("BRASSLINE PROFILE PROGRESSION: PASS - v2 migration, Blueprint Knowledge, sidegrades, scars, relationships, mastery, deterministic daily/challenge codes, and run-save independence verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE PROFILE PROGRESSION: FAIL - %s" % message)
	quit(1)
