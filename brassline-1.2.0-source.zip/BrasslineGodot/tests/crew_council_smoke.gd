extends SceneTree

const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	var run = RunState.new()
	run.start_new_run(crew_ids, 71377, "standard")
	if not bool(run.complete_current_car().get("ok", false)):
		_fail("Boarding could not seed the crew-council campaign.")
		return
	_complete_for_test(run, "dining")
	if not run.has_pending_crew_scene() or String(run.crew_scene_data().get("title", "")) != "THE FIRST COST" or Array(run.crew_scene_data().get("choices", [])).size() != 3:
		_fail("Car two did not pause on the first three-way crew council.")
		return
	var saved: Dictionary = run.to_save_data()
	if int(saved.get("version", 0)) != 7:
		_fail("Crew councils were not written through save schema v7.")
		return
	var restored = RunState.new()
	if not restored.load_from_save_data(saved) or not restored.has_pending_crew_scene():
		_fail("An unresolved crew council did not survive checkpoint restoration.")
		return
	var result: Dictionary = restored.resolve_crew_scene_choice("share_the_weight")
	if not bool(result.get("ok", false)) or restored.has_pending_crew_scene() or restored.crew_scene_history.size() != 1:
		_fail("The first council choice did not resolve exactly once and persist its history.")
		return
	for key in restored.crew_relationships:
		if int(restored.crew_relationships[key].get("bond", 0)) != 1:
			_fail("Share the Weight did not increase every crew relationship.")
			return

	_complete_for_test(restored, "bar")
	_complete_for_test(restored, "armory")
	if String(restored.crew_scene_data().get("title", "")) != "THE TRAIN ANSWERS":
		_fail("Car four did not enter the doctrine-response council.")
		return
	var accuracy_before := float(restored.squad_bonuses.get("accuracy", 0.0))
	restored.resolve_crew_scene_choice("study_the_doctrines")
	if absf(float(restored.squad_bonuses.get("accuracy", 0.0)) - accuracy_before - 0.03) > 0.001:
		_fail("Study the Doctrines did not grant its exact +3% accuracy effect.")
		return

	_complete_for_test(restored, "crew")
	_complete_for_test(restored, "observation")
	if String(restored.crew_scene_data().get("title", "")) != "WHAT DO WE PROMISE?":
		_fail("Car six did not pause for the final Engine promise.")
		return
	var max_hp_before := int(restored.squad_bonuses.get("max_zone_hp", 0))
	restored.resolve_crew_scene_choice("bring_them_home")
	if int(restored.squad_bonuses.get("max_zone_hp", 0)) != max_hp_before + 2 or restored.crew_scene_history.size() != 3:
		_fail("Everyone Comes Home did not grant its finale health package or complete the three-act history.")
		return
	_complete_for_test(restored, "engine")
	if restored.phase != "complete" or not restored.pending_crew_scene_id.is_empty():
		_fail("The Engine victory did not close the run after all three councils.")
		return
	var ending: Dictionary = restored.campaign_epilogue()
	if String(ending.get("title", "")) != "EVERY SEAT FILLED":
		_fail("Keeping the final promise with a bonded full crew did not alter the named ending.")
		return
	print("BRASSLINE CREW COUNCILS: PASS - three act-break decisions, exact tradeoffs, v7 pending-scene recovery, memories, relationship effects, finale promise, and choice-shaped epilogue verified.")
	quit(0)


func _complete_for_test(run, car_id: String) -> void:
	run.current_car_id = car_id
	run.pending_car_id = ""
	run.phase = "encounter"
	run.complete_current_car()


func _fail(message: String) -> void:
	push_error("BRASSLINE CREW COUNCILS: FAIL - %s" % message)
	quit(1)
