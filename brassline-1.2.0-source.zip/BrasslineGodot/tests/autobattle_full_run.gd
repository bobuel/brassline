extends SceneTree

const Types := preload("res://scripts/game_types.gd")

const PLAYTEST_ROSTERS: Array[Array] = [
	["ada", "marlow", "nix"],
	["iona", "silas", "rook"],
	["ada", "iona", "silas"],
]

var player_shots := 0
var limb_shots := 0
var environment_actions := 0


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var seed := int(_argument_value("auto-seed", "96001"))
	var strategy := int(_argument_value("auto-strategy", "0"))
	var roster_index := posmod(int(_argument_value("auto-roster", "0")), PLAYTEST_ROSTERS.size())
	var difficulty := _argument_value("auto-difficulty", "story")
	var selected_pace := clampf(float(_argument_value("auto-speed", "4.0")), 1.0, 4.0)
	var risky_plans := _argument_value("auto-risky", "false") == "true"
	var force_hazard := _argument_value("auto-hazard", "false") == "true"
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = []
	crew_ids.assign(PLAYTEST_ROSTERS[roster_index])
	scene.campaign_ui.selected_difficulty = difficulty
	scene.turn.attack_resolved.connect(func(attacker: TacticalUnit, _target: TacticalUnit, zone: Types.BodyZone, _result: Dictionary) -> void:
		if attacker.team == Types.Team.PLAYER:
			player_shots += 1
			if zone in [Types.BodyZone.ARMS, Types.BodyZone.LEGS]: limb_shots += 1
	)
	scene.turn.environment_resolved.connect(func(_action_id: String, _actor: TacticalUnit, _result: Dictionary) -> void: environment_actions += 1)
	await scene._on_crew_confirmed(crew_ids, seed)
	var transitions := 0
	var combat_cars := 0
	var route: Array[String] = []
	while scene.run_state.phase != "complete" and transitions < 24:
		transitions += 1
		match scene.run_state.phase:
			"encounter":
				var car_id: String = scene.run_state.current_car_id
				var car_data: Dictionary = scene.run_state.car_data(car_id)
				if String(car_data.get("kind", "combat")) == "event":
					scene.run_state.resolve_event_choice("rest" if posmod(strategy, 2) == 0 else "scavenge")
					scene._on_event_resolved()
					await process_frame
					continue
				if not scene.autobattle_ui.planning_root.visible or scene.autobattle_ui.plans.is_empty():
					_fail("Combat car %s did not stop for a valid authored plan." % car_id)
					return
				combat_cars += 1
				var plan_index := posmod(strategy + combat_cars - 1, scene.autobattle_ui.plans.size())
				if not risky_plans:
					var safe_indices: Array[int] = []
					for index in range(scene.autobattle_ui.plans.size()):
						if bool(scene.autobattle_ui.plans[index].get("safe", false)):
							safe_indices.append(index)
					if not safe_indices.is_empty():
						plan_index = safe_indices[posmod(strategy + combat_cars - 1, safe_indices.size())]
				# Make one Dining run explicitly exercise its environment template.
				if car_id == "dining" and force_hazard:
					for index in range(scene.autobattle_ui.plans.size()):
						if String(scene.autobattle_ui.plans[index].get("id", "")) == "break_the_room":
							plan_index = index
				var fallback_index := posmod(strategy + combat_cars, scene.autobattle_ui.fallback_buttons.size()) if risky_plans else 1
				scene.autobattle_ui._select_plan(plan_index)
				scene.autobattle_ui._select_fallback(fallback_index)
				scene.autobattle_ui._confirm_plan()
				scene.autobattle_director.set_speed(selected_pace)
				var timeout := 36000
				while not scene.autobattle_ui.aftermath_root.visible and timeout > 0:
					timeout -= 1
					await process_frame
				if timeout <= 0:
					_fail("Autobattle timed out in %s after %d activations." % [car_id, scene.autobattle_director.activation_count])
					return
				if not scene._pending_autobattle_victory:
					var failed_aftermath: Dictionary = scene._pending_autobattle_completion.get("aftermath", {})
					print("AUTOBATTLE DEFEAT ANALYSIS / %s / %s" % [car_id, JSON.stringify(failed_aftermath.get("failure_analysis", {}))])
					print("AUTOBATTLE DEFEAT BEATS / %s" % JSON.stringify(failed_aftermath.get("decisive_beats", [])))
					_fail("The crew was defeated in %s using %s. %s" % [car_id, String(scene.autobattle_director.active_plan.get("id", "unknown")), _crew_status(scene)])
					return
				print("AUTOBATTLE CAR / %s / plan=%s / rounds=%d / %s" % [car_id, String(scene.autobattle_director.active_plan.get("id", "unknown")), int(scene._pending_autobattle_completion.get("aftermath", {}).get("rounds", 0)), _crew_status(scene)])
				scene._on_aftermath_continue_requested()
				await process_frame
			"intermission":
				if scene.run_state.has_pending_crew_scene():
					var council_choices: Array = scene.run_state.crew_scene_data().get("choices", [])
					var council_choice := String(Dictionary(council_choices[posmod(strategy, council_choices.size())]).get("id", ""))
					scene._on_crew_scene_choice_requested(council_choice)
					await process_frame
					continue
				_attempt_treatment(scene)
				if scene.run_state.current_offers.is_empty():
					_fail("Route selection had no eligible next car.")
					return
				var choice_index := posmod(strategy + scene.run_state.completed_car_ids.size(), scene.run_state.current_offers.size())
				var choice: String = scene.run_state.current_offers[choice_index]
				route.append(choice)
				scene._on_car_prep_requested(choice)
				await process_frame
				await scene._on_next_car_chosen(choice)
				for _frame in range(3): await process_frame
			_:
				_fail("The automatic campaign entered unsupported phase %s." % scene.run_state.phase)
				return

	if scene.run_state.phase != "complete" or scene.run_state.completed_car_ids.size() != 7:
		_fail("The narrative autobattler did not complete the seven-car campaign.")
		return
	if scene.run_state.plan_history.size() != combat_cars or combat_cars < 6:
		_fail("Plan history count did not match the number of combat cars.")
		return
	var final_car_id: String = scene.run_state.completed_car_ids[-1]
	if final_car_id != "engine" or int(scene.run_state.run_stats.get("train_seized", 0)) != 1 or int(scene.run_state.run_stats.get("control_claims", 0)) < 1:
		_fail("Car seven did not resolve as the Voss engine-control takeover finale.")
		return
	if player_shots < combat_cars or limb_shots < 1:
		_fail("The full run did not exercise automatic fire and body-part priorities.")
		return
	if not scene.campaign_ui.is_frontend_open():
		_fail("The completed autobattler campaign did not reach its run result screen.")
		return
	print("AUTOBATTLE OUTCOME / %s" % JSON.stringify({"completed_cars": scene.run_state.completed_car_ids, "crew_states": scene.run_state.crew_states, "inventory": scene.run_state.inventory, "squad_bonuses": scene.run_state.squad_bonuses, "run_stats": scene.run_state.run_stats, "relationships": scene.run_state.crew_relationships, "shots": player_shots, "limb_shots": limb_shots, "environment_actions": environment_actions}))
	print("BRASSLINE AUTOBATTLER FULL RUN: PASS - seed=%d strategy=%d difficulty=%s pace=%dx crew=%s combat_cars=%d shots=%d limb_shots=%d environment=%d route=%s" % [seed, strategy, difficulty, int(selected_pace), ",".join(PackedStringArray(crew_ids)), combat_cars, player_shots, limb_shots, environment_actions, " > ".join(PackedStringArray(route))])
	quit(0)


func _attempt_treatment(scene: Node) -> void:
	for crew_id in scene.run_state.selected_crew_ids:
		if scene.run_state.crew_is_down(crew_id):
			continue
		for item_id in ["limb_brace", "medkit"]:
			if int(scene.run_state.inventory.get(item_id, 0)) <= 0:
				continue
			var preview: Dictionary = scene.run_state.item_use_preview(item_id, crew_id)
			if bool(preview.get("can_use", false)):
				scene._on_item_requested(item_id, crew_id)
				return


func _crew_status(scene: Node) -> String:
	var parts: Array[String] = []
	for crew_id in scene.run_state.selected_crew_ids:
		var member: Dictionary = scene.campaign_ui.roster_member(crew_id)
		if scene.run_state.crew_is_down(crew_id):
			parts.append("%s:DOWN" % String(member.get("name", crew_id)))
			continue
		var body: Dictionary = scene.run_state.body_state_for(crew_id)
		parts.append("%s:T%d A%d L%d" % [String(member.get("name", crew_id)), int(body[Types.BodyZone.TORSO]["hp"]), int(body[Types.BodyZone.ARMS]["hp"]), int(body[Types.BodyZone.LEGS]["hp"])])
	return " | ".join(parts)


func _argument_value(key: String, fallback: String) -> String:
	var prefix := "--%s=" % key
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with(prefix):
			return argument.trim_prefix(prefix)
	return fallback


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER FULL RUN: FAIL - %s" % message)
	quit(1)
