extends SceneTree

const CARS: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "engine", "observation", "cargo", "casino"]
const ROSTERS: Array[Array] = [["ada", "marlow", "nix"], ["iona", "silas", "rook"]]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8): await process_frame
	var scenarios := 0
	var plans_checked := 0
	var minimum_gap := 999
	for roster in ROSTERS:
		var crew_ids: Array[String] = []
		crew_ids.assign(roster)
		await scene._on_crew_confirmed(crew_ids, 81420)
		for survivors in range(1, 4):
			for index in range(crew_ids.size()):
				scene.run_state.crew_states[crew_ids[index]]["down"] = index >= survivors
			for car_id in CARS:
				scene.run_state.current_car_id = car_id
				scene.run_state.phase = "encounter"
				scene.run_state.completed_car_ids.clear()
				if car_id != "baggage":
					scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar"])
				if car_id == "engine":
					# The authored Engine is the seventh-car boss encounter, not a
					# fabricated mid-route carriage without its required Voss target.
					scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew", "armory", "observation"])
				for variant in range(3):
					while scene.run_state.encounter_variant_index() != variant:
						scene.run_state.run_seed += 1
					await scene._load_run_encounter()
					scenarios += 1
					if scene.autobattle_ui.plans.size() != 4:
						_fail("%s / %d survivors / variant %d did not offer four tactical families." % [car_id, survivors, variant])
						return
					for plan_index in range(scene.autobattle_ui.plans.size()):
						var plan: Dictionary = scene.autobattle_ui.plans[plan_index]
						var deployment: Dictionary = plan["deployment_cells"]
						if not scene.autobattle_director.deployment_is_safe(deployment):
							_fail("Generated unsafe formation: %s / %s." % [car_id, String(plan.get("id", ""))])
							return
						scene.autobattle_ui._select_plan(plan_index)
						var occupied := {}
						for unit in scene.turn.units:
							if occupied.has(unit.grid_cell) or not scene.board.is_walkable(unit.grid_cell) or scene.board.hazard_cells.has(unit.grid_cell):
								_fail("Plan preview stacks a unit or puts it in scenery/hazards.")
								return
							occupied[unit.grid_cell] = true
						for crew in scene.turn.player_units(true):
							if crew.grid_cell != Vector2i(deployment[crew.roster_id]) or crew.grid_cell.x > GridBoard.CREW_DEPLOYMENT_MAX_X or crew.grid_cell.y in [0, 4]:
								_fail("Preview model is not at its safe, visible boarding-side start.")
								return
							for guard in scene.turn.enemy_units(true):
								var gap: int = scene.board.grid_distance(crew.grid_cell, guard.grid_cell)
								minimum_gap = mini(minimum_gap, gap)
								if guard.grid_cell.x < GridBoard.ENEMY_DEPLOYMENT_MIN_X or gap < GridBoard.MIN_DEPLOYMENT_DISTANCE:
									_fail("%s / %s puts %s at %s only %d tiles from %s at %s." % [car_id, String(plan.get("id", "")), crew.display_name, str(crew.grid_cell), gap, guard.display_name, str(guard.grid_cell)])
									return
						plans_checked += 1
					# The commit boundary must reject stale or malicious coordinates
					# atomically, not merely rely on the generator doing the right thing.
					var invalid: Dictionary = scene.autobattle_ui.plans[0]["deployment_cells"].duplicate(true)
					var first: TacticalUnit = scene.turn.player_units(true)[0]
					var before := first.grid_cell
					invalid[first.roster_id] = scene.turn.enemy_units(true)[0].grid_cell
					if scene.autobattle_director.apply_deployment(invalid) or first.grid_cell != before:
						_fail("The commit boundary accepted or partially applied an overlapping deployment.")
						return
	print("BRASSLINE AUTOBATTLER DEPLOYMENT SAFETY: PASS - %d scenarios / %d plans / all six operatives / 1-3 survivors / 9 cars / 3 variants / minimum opposing gap %d tiles; preview and commit validation verified." % [scenarios, plans_checked, minimum_gap])
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER DEPLOYMENT SAFETY: FAIL - %s" % message)
	quit(1)
