extends SceneTree

func _initialize() -> void: _run.call_deferred()

func _run() -> void:
	var suffix := "before" if "--before" in OS.get_cmdline_user_args() else "after"
	root.size=Vector2i(1600,900)
	var stage:=Node3D.new(); root.add_child(stage); current_scene=stage
	var world:=WorldEnvironment.new(); var environment:=Environment.new()
	environment.background_mode=Environment.BG_COLOR; environment.background_color=Color("#102025")
	environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; environment.ambient_light_color=Color("#afc4bf"); environment.ambient_light_energy=0.68
	world.environment=environment; stage.add_child(world)
	var key:=DirectionalLight3D.new(); key.rotation_degrees=Vector3(-45,-25,0); key.light_color=Color("#f6d8b1"); key.light_energy=1.35; key.shadow_enabled=true; stage.add_child(key)
	var board:=GridBoard.new(); stage.add_child(board)
	var art:=EnvironmentArt.new(); board.add_child(art); art.setup(board)
	var rig:=TacticalCameraRig.new(); stage.add_child(rig)
	var label:=Label.new(); label.position=Vector2(25,20); label.add_theme_font_size_override("font_size",24); root.add_child(label)
	for car_id in ["baggage","dining","armory"]:
		board.prepare_run_encounter(car_id); art.set_active_run_car(car_id,2)
		var actors:Array[TacticalUnit]=[]
		for index in range(4):
			var cell:Vector2i=[Vector2i(1,1),Vector2i(3,3),Vector2i(10,2),Vector2i(16,1)][index]
			while not board.is_walkable(cell): cell.y=posmod(cell.y+1,GridBoard.BOARD_SIZE.y)
			var actor:=TacticalUnit.new(); actor.visual_model_path="res://assets/characters/quaternius/"+(["Casual_2.gltf","Adventurer.gltf","Worker.gltf","Suit.gltf"][index]); stage.add_child(actor)
			actor.setup(["Ada","Marlow","Railhand","Officer"][index],0 if index<2 else 1,cell,board)
			actor.configure_combat_identity(["longshot_rifle","breach_gun","rivet_carbine","service_revolver"][index]); actors.append(actor)
		rig.frame_active_car(); label.text=car_id.to_upper()+" / "+suffix.to_upper()
		for frame in range(16): await process_frame
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png("res://../../work/graphics-lift/%s_%s.png"%[car_id,suffix])
		for actor in actors: actor.free()
	print("ENVIRONMENT UPLIFT CAPTURE: PASS - Boarding, Dining, Armory / "+suffix)
	quit(0)
