extends SceneTree

const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	root.size = Vector2i(1280, 720)
	root.content_scale_size = Vector2i(1280, 720)
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8): await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 97001)
	for _frame in range(3): await process_frame
	var auto_ui: AutobattleUI = scene.autobattle_ui
	if scene._save_path == "user://brassline_run.json":
		_fail("Automated UI testing is not isolated from the player's Continue Run checkpoint.")
		return
	if not _inside_view(auto_ui.confirm_button) or auto_ui.confirm_button.get_global_rect().end.y > 720.0:
		_fail("The planning commitment control is clipped below 1280x720: button=%s viewport=%s." % [auto_ui.confirm_button.get_global_rect(), root.get_visible_rect()])
		return
	if auto_ui.plan_buttons.size() < 3 or auto_ui.fallback_buttons.size() != 5:
		_fail("Planning does not expose its required plan and contingency controls (plans=%d fallbacks=%d)." % [auto_ui.plan_buttons.size(), auto_ui.fallback_buttons.size()])
		return
	if scene.campaign_ui.navigator.visible or scene.ui.hud_root.visible:
		_fail("Legacy navigation or manual combat HUD overlaps the planning dossier.")
		return
	var ghost_root: Node = scene.board.get_node_or_null("PlanDeploymentGhosts")
	if ghost_root == null or int(ghost_root.get_meta("deployment_count", 0)) != 3 or ghost_root.get_node_or_null("PriorityTarget") == null:
		_fail("The live carriage does not show each deployment mark and its priority target.")
		return
	var battlefield := auto_ui.planning_battlefield_rect()
	if battlefield.get_area() < 1280.0 * 720.0 * 0.58 or battlefield.intersects(auto_ui.planning_dock.get_global_rect()):
		_fail("The decision dock consumes or overlaps the reserved full-width battlefield.")
		return
	if not battlefield.encloses(scene.camera_rig.planning_projected_bounds()):
		_fail("The complete carriage is not framed inside the unobstructed planning viewport.")
		return
	for unit in scene.turn.units:
		for height in [0.12, 2.4]:
			var screen_point: Vector2 = scene.camera_rig.camera.unproject_position(scene.board.cell_to_world(unit.grid_cell) + Vector3(0, height, 0))
			if not battlefield.has_point(screen_point):
				_fail("A starting operative/guard or its label lies behind planning UI.")
				return
	auto_ui.toggle_plan_details()
	await process_frame
	if battlefield.intersects(auto_ui.planning_details.get_global_rect()) or not _inside_view(auto_ui.planning_details):
		_fail("Expanded narrative details cover the carriage instead of replacing the dock.")
		return
	auto_ui.toggle_plan_details()
	var guard: TacticalUnit = scene.turn.enemy_units(true)[0]
	auto_ui.show_unit_inspector(guard)
	await process_frame
	if not auto_ui.inspector_panel.is_visible_in_tree() or not _inside_view(auto_ui.inspector_panel) or "ENEMY POST" not in auto_ui.inspector_combat.text:
		_fail("The full-screen Ledger does not fit or cannot explain an enemy.")
		return
	auto_ui.inspector_panel.visible = false

	auto_ui._confirm_plan()
	await process_frame
	scene.autobattle_director.set_paused(true)
	for _frame in range(3): await process_frame
	for control in [auto_ui.combat_round_label, auto_ui.timeline_row, auto_ui.intent_label, auto_ui.combat_crew_row, auto_ui.pause_button]:
		if not _inside_view(control):
			_fail("A primary autobattle HUD control is outside the native viewport.")
			return
	if auto_ui.combat_crew_row.get_global_rect().intersects(auto_ui.pause_button.get_global_rect()):
		_fail("Crew condition cards overlap the pause and speed controls.")
		return
	var carriage_height := auto_ui.combat_crew_row.get_global_rect().position.y - auto_ui.combat_round_label.get_global_rect().end.y
	if carriage_height < 720.0 * 0.80:
		_fail("The compact combat HUD leaves less than 80% vertical carriage space.")
		return
	auto_ui.toggle_inspector("ada")
	await process_frame
	if not auto_ui.inspector_panel.visible or not _inside_view(auto_ui.inspector_panel) or "ARMS" not in auto_ui.inspector_body.text or "CAR BUFFS" not in auto_ui.inspector_combat.text:
		_fail("The optional inspector does not fit or explain body zones and car buffs.")
		return

	auto_ui.inspector_panel.close()
	scene.autobattle_director.set_paused(false)
	for enemy in scene.turn.enemy_units(true):
		enemy.apply_damage(Types.BodyZone.TORSO, 999, true)
	var timeout := 600
	while not auto_ui.aftermath_root.visible and timeout > 0:
		timeout -= 1
		await process_frame
	# Killing the last enemy can show the screen synchronously. Containers lay
	# out the newly visible scroll body/footer on the following process frames.
	for _frame in range(3): await process_frame
	if timeout <= 0 or not _inside_view(auto_ui.aftermath_continue):
		_fail("Aftermath did not appear with a fully visible continuation control: remaining_frames=%d visible=%s continue=%s viewport=%s scale=%s." % [timeout,auto_ui.aftermath_root.visible,auto_ui.aftermath_continue.get_global_rect(),root.get_visible_rect(),Engine.time_scale])
		return
	if scene.campaign_ui.navigator.visible:
		_fail("The route navigator overlaps the narrative aftermath.")
		return
	print("BRASSLINE AUTOBATTLER UI LAYOUT: PASS - full planning carriage, docked details, full-screen Ledger, 80% combat carriage space, and aftermath fit verified.")
	quit(0)


func _inside_view(control: Control) -> bool:
	var rect := control.get_global_rect()
	return rect.position.x >= -0.5 and rect.position.y >= -0.5 and rect.end.x <= 1280.5 and rect.end.y <= 720.5


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER UI LAYOUT: FAIL - %s" % message)
	quit(1)
