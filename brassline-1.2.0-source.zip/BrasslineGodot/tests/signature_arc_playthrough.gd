extends SceneTree

var run_seed := 61013


func _initialize() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--signature-seed="):
			run_seed = int(argument.trim_prefix("--signature-seed="))
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8): await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	scene.campaign_ui.selected_difficulty = "story"
	await scene._on_crew_confirmed(crew_ids, run_seed)
	for _frame in range(4): await process_frame

	var baggage := await _play_current_car(scene, "baggage", "lash_the_freight")
	if not bool(baggage.get("ok", false)): return
	scene._on_aftermath_continue_requested()
	await process_frame
	_triage(scene.run_state)

	scene.run_state.current_car_id = "dining"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	for _frame in range(4): await process_frame
	var dining := await _play_current_car(scene, "dining", "lock_the_service_cart")
	if not bool(dining.get("ok", false)): return
	scene._on_aftermath_continue_requested()
	await process_frame
	_triage(scene.run_state)

	# The signature slice jumps to the climax while preserving the two authored
	# car outcomes. Route soak tests separately cover all seven legal selections.
	# Apply the same build rewards a legal seven-car route would have earned before
	# the finale; merely changing the car index would create a false naked-stat boss test.
	for skipped_car in ["bar", "crew", "armory", "observation"]:
		scene.run_state.completed_car_ids.append(skipped_car)
		scene.run_state._apply_car_reward_and_buff(skipped_car)
	scene.run_state.current_car_id = "engine"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	for _frame in range(4): await process_frame
	var engine := await _play_current_car(scene, "engine", "bleed_the_pressure")
	if not bool(engine.get("ok", false)): return

	var campaign: Dictionary = scene.run_state.crew_campaign_context()
	var worked_relationship := false
	for raw_relationship in Array(campaign.get("relationships", [])):
		var relationship := Dictionary(raw_relationship)
		if int(relationship.get("shared_jobs", 0)) > 0 and not Array(relationship.get("history", [])).is_empty():
			worked_relationship = true
	if not worked_relationship or scene.run_state.crew_consequence_history.size() < 3:
		_fail("The three real battles did not leave persistent crew relationship history.")
		return
	if scene.run_state.phase != "complete" or int(scene.run_state.run_stats.get("train_seized", 0)) != 1:
		_fail("The signature climax did not finish with the Green Rail seized.")
		return
	print("BRASSLINE SIGNATURE PLAYTHROUGH: PASS seed=%d / Boarding, Dining, Engine won through real automatic initiative / train warnings and counters resolved / doctrines stayed live / three crew consequence reports persisted / train seized." % run_seed)
	quit(0)


func _play_current_car(scene, expected_car: String, preferred_plan: String) -> Dictionary:
	if scene.run_state.current_car_id != expected_car or not scene.autobattle_ui.planning_root.visible:
		_fail("%s did not load into the planning phase." % expected_car)
		return {}
	var selected := -1
	for index in range(scene.autobattle_ui.plans.size()):
		if String(scene.autobattle_ui.plans[index].get("id", "")) == preferred_plan:
			selected = index
	if selected < 0:
		_fail("%s did not offer required plan %s." % [expected_car, preferred_plan])
		return {}
	scene.autobattle_ui._select_plan(selected)
	scene.autobattle_ui._select_fallback(1)
	scene.autobattle_ui._confirm_plan()
	scene.autobattle_director.set_speed(4.0)
	var timeout := 12000
	while not scene.autobattle_ui.aftermath_root.visible and timeout > 0:
		timeout -= 1
		await process_frame
	if timeout <= 0:
		_fail("%s did not resolve within the playthrough limit." % expected_car)
		return {}
	if not scene._pending_autobattle_victory:
		_fail("%s defeated the story-difficulty crew during the signature run." % expected_car)
		return {}
	var aftermath: Dictionary = scene._pending_autobattle_completion.get("aftermath", {})
	var train_events: Array = aftermath.get("train_events", [])
	if train_events.is_empty() or Dictionary(aftermath.get("doctrine", {})).is_empty():
		_fail("%s completed without recording its living-train event and doctrine." % expected_car)
		return {}
	if Array(aftermath.get("crew_consequences", [])).is_empty():
		_fail("%s completed without a crew-campaign consequence." % expected_car)
		return {}
	if expected_car in ["baggage", "dining", "engine"] and not scene.autobattle_director.environment_action_used:
		_fail("%s plan did not physically use its authored environmental control." % expected_car)
		return {}
	return {"ok": true, "aftermath": aftermath}


func _triage(run_state) -> void:
	for crew_id in run_state.selected_crew_ids:
		if int(run_state.inventory.get("medkit", 0)) <= 0:
			break
		var preview: Dictionary = run_state.item_use_preview("medkit", crew_id)
		if bool(preview.get("can_use", false)):
			run_state.use_item("medkit", crew_id)


func _fail(message: String) -> void:
	push_error("BRASSLINE SIGNATURE PLAYTHROUGH: FAIL seed=%d - %s" % [run_seed, message])
	quit(1)
