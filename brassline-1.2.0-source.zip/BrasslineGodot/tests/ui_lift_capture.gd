extends SceneTree

const Types := preload("res://scripts/game_types.gd")
var failed := false
var output_dir := "res://../../work/ui-lift-20260909/captures"

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(output_dir))
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene); current_scene = scene
	for frame in range(12): await process_frame
	var crew: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew, 882610)
	var ui: AutobattleUI = scene.autobattle_ui
	var ledger: CrewLedgerUI = ui.inspector_panel
	# Controlled fixture: carried supplies and a wounded head, not a balance scenario.
	scene.run_state.inventory = {"clockwork_grenade": 1, "focus_tonic": 1, "medkit": 2, "limb_brace": 1}
	scene._begin_autobattle_planning(ui.current_car, ui.current_bonuses)
	for resolution in [Vector2i(1280, 720), Vector2i(1280, 800), Vector2i(1920, 1080)]:
		root.size = resolution; root.content_scale_size = resolution
		for scale in [1.0, 1.3]:
			ui.set_text_scale(scale); scene.campaign_ui.text_scale = scale
			scene.campaign_ui.front_overlay.visible = false
			ui.planning_root.visible = true; ui.combat_root.visible = false
			ui._select_plan(3)
			await _capture("risk_planning", resolution, scale, [ui.confirm_button])
			ui.toggle_plan_details()
			await _capture("doctrine_details", resolution, scale, [ui.plan_detail_body])
			ui.toggle_plan_details()
			ui.show_inspector("nix"); ledger._select_tab("gear"); ledger._select_item("clockwork_grenade")
			await _capture("gear", resolution, scale, [ledger.settings_button, ledger.item_grid, ledger.tabs["train"]])
			ledger._selected_unit().body_state[Types.BodyZone.HEAD]["hp"] = 2
			ledger._inspect_zone(Types.BodyZone.HEAD)
			await _capture("injuries", resolution, scale, [ledger.item_grid, ledger.detail_body])
			ledger.settings_button.pressed.emit()
			await _capture("in_run_settings", resolution, scale, [scene.campaign_ui.front_content])
			scene.campaign_ui._save_settings_and_return()
			ledger.close()
			ui.show_unit_inspector(scene.turn.enemy_units(true)[0])
			await _capture("enemy_counter", resolution, scale, [ledger.detail_body])
			ledger.close()
			ui.show_combat(ui.plans[3], {}, ui.current_crew, ui.current_car, ui.current_bonuses)
			await _capture("combat_settings", resolution, scale, [ui.settings_button, ui.pause_button, ui.combat_crew_row])
			ui.combat_root.visible = false
	print("BRASSLINE UI LIFT CAPTURE: %s - seven states x three resolutions x two text scales." % ("FAIL" if failed else "PASS"))
	scene.queue_free()
	for frame in range(3): await process_frame
	quit(1 if failed else 0)

func _capture(screen: String, resolution: Vector2i, scale: float, controls: Array) -> void:
	for frame in range(8): await process_frame
	for control in controls:
		if not Rect2(Vector2.ZERO, resolution).encloses(control.get_global_rect()):
			failed = true; push_error("UI LIFT CLIP %s %s scale%s %s" % [screen, resolution, scale, control.get_global_rect()])
	await RenderingServer.frame_post_draw
	var picture := root.get_texture().get_image()
	if picture == null or picture.save_png("%s/%s_%dx%d_%d.png" % [output_dir, screen, resolution.x, resolution.y, roundi(scale * 100)]) != OK:
		failed = true; push_error("Could not save UI lift screenshot " + screen)
