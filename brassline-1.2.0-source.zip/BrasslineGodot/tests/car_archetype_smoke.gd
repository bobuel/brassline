extends SceneTree

const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	var armory: Dictionary = scene._encounter_profile("armory")
	var observation: Dictionary = scene._encounter_profile("observation")
	var casino: Dictionary = scene._encounter_profile("casino")
	if int(armory.get("hp_bonus", 0)) < 3 or int(observation.get("range_bonus", 0)) < 3 or float(casino.get("damage_multiplier", 1.0)) <= 1.0:
		_fail("Armory, Observation, and Casino did not expose distinct threat profiles.")
		return

	var active_root: Node = scene.train_art.get_node_or_null("ActiveRunCarDressing")
	for car_id in RunState.CAR_CATALOG:
		scene.board.prepare_run_encounter(String(car_id), 0)
		scene.train_art.set_active_run_car(String(car_id), 3)
		for _frame in range(2):
			await process_frame
		var sign: Label3D
		if active_root != null:
			sign = active_root.get_node_or_null("ActiveCarSign") as Label3D
		if sign == null or String(car_id).to_upper() not in sign.text or active_root.get_child_count() < 3:
			_fail("%s did not build its active sign, light, and unique dressing." % car_id)
			return

	var event_run: RefCounted
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	for seed in range(1, 200):
		var candidate := RunState.new()
		candidate.start_new_run(crew_ids, seed)
		candidate.complete_current_car()
		if "sleeper" in candidate.current_offers:
			event_run = candidate
			break
	if not is_instance_valid(event_run):
		_fail("No deterministic seed exposed the Sleeper event in the search window.")
		return
	scene.run_state = event_run
	await scene._on_next_car_chosen("sleeper")
	if event_run.current_car_id != "sleeper" or event_run.phase != "encounter" or not scene.campaign_ui.is_frontend_open():
		_fail("Choosing the Sleeper did not open its non-combat event.")
		return
	scene._on_event_resolved()
	if "sleeper" not in event_run.completed_car_ids or event_run.phase != "intermission":
		_fail("Resolving the Sleeper event did not award recovery and return to routing.")
		return

	print("BRASSLINE CAR ARCHETYPE SMOKE: PASS - threat profiles, dynamic dressing, and non-combat event verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE CAR ARCHETYPE SMOKE: FAIL - %s" % message)
	quit(1)
