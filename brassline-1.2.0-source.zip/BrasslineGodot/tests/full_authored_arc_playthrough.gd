extends SceneTree

const CARS: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "observation", "cargo", "casino", "engine"]
const COUNTER_PLANS := {
	"baggage": "lash_the_freight",
	"dining": "lock_the_service_cart",
	"bar": "light_the_backbar",
	"crew": "dog_the_lockers",
	"armory": "jam_the_press",
	"observation": "drop_storm_shutters",
	"cargo": "set_the_cargo_brake",
	"casino": "lock_the_tables",
	"engine": "bleed_the_pressure",
}
const BUILD_ROUTE: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "observation"]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	var doctrine_ids: Array[String] = []
	var total_rounds := 0
	for car_index in range(CARS.size()):
		var car_id := CARS[car_index]
		scene.campaign_ui.selected_difficulty = "story"
		await scene._on_crew_confirmed(crew_ids, 44100 + car_index * 137)
		if car_id != "baggage":
			var build_prefix: Array[String] = BUILD_ROUTE.duplicate()
			if car_id != "engine":
				build_prefix.clear()
				build_prefix.assign(["baggage", "dining", "bar"])
				build_prefix.erase(car_id)
			for reward_car in build_prefix:
				scene.run_state._apply_car_reward_and_buff(reward_car)
			scene.run_state.completed_car_ids.assign(build_prefix)
			scene.run_state.current_car_id = car_id
			scene.run_state.phase = "encounter"
			await scene._load_run_encounter()
		for _frame in range(4):
			await process_frame
		if not scene.autobattle_ui.planning_root.visible:
			_fail("%s did not reach the narrative planning phase." % car_id)
			return
		var plan_index := -1
		for index in range(scene.autobattle_ui.plans.size()):
			if String(scene.autobattle_ui.plans[index].get("id", "")) == String(COUNTER_PLANS[car_id]):
				plan_index = index
		if plan_index < 0:
			_fail("%s did not offer its required control plan %s." % [car_id, COUNTER_PLANS[car_id]])
			return
		scene.autobattle_ui._select_plan(plan_index)
		scene.autobattle_ui._select_fallback(1)
		scene.autobattle_ui._confirm_plan()
		scene.autobattle_director.set_speed(4.0)
		var timeout := 18000
		while not scene.autobattle_ui.aftermath_root.visible and timeout > 0:
			timeout -= 1
			await process_frame
		if timeout <= 0:
			_fail("%s did not resolve within the real-autobattle timeout." % car_id)
			return
		if not scene._pending_autobattle_victory:
			print("AUTHORED DEFEAT / %s / %s" % [car_id, JSON.stringify(scene._pending_autobattle_completion.get("aftermath", {}))])
			_fail("%s defeated a fresh story-difficulty crew using its authored control plan." % car_id)
			return
		var aftermath: Dictionary = scene._pending_autobattle_completion.get("aftermath", {})
		var doctrine: Dictionary = aftermath.get("doctrine", {})
		var doctrine_id := String(doctrine.get("id", ""))
		if doctrine_id.is_empty() or doctrine_id in doctrine_ids:
			_fail("%s did not record a unique live doctrine during automatic combat." % car_id)
			return
		doctrine_ids.append(doctrine_id)
		if Array(aftermath.get("train_events", [])).is_empty() or not scene.autobattle_director.environment_action_used:
			_fail("%s resolved without its living-train warning or physical control action." % car_id)
			return
		total_rounds += int(aftermath.get("rounds", 0))
		print("AUTHORED CAR / %s / plan=%s / doctrine=%s / rounds=%d" % [car_id, COUNTER_PLANS[car_id], doctrine_id, int(aftermath.get("rounds", 0))])
	print("BRASSLINE FULL AUTHORED ARC: PASS - all 9 combat-car archetypes won through real automatic initiative; 9 unique doctrines, 9 train warnings, and 9 physical counter actions resolved across %d rounds." % total_rounds)
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE FULL AUTHORED ARC: FAIL - %s" % message)
	quit(1)
