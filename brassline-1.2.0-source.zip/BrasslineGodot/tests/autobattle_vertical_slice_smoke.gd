extends SceneTree

const Types := preload("res://scripts/game_types.gd")

var player_zones: Array[int] = []
var timeline_saw_crew := false
var timeline_saw_guard := false


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame

	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	scene.campaign_ui.selected_difficulty = "story"
	await scene._on_crew_confirmed(crew_ids, 93041)
	for _frame in range(4):
		await process_frame
	if not scene.autobattle_ui.planning_root.visible or scene.turn.encounter_active:
		_fail("A new run did not stop at the narrative planning screen before combat.")
		return
	if scene.ui.hud_root.visible:
		_fail("The manual tactics HUD remained visible during autobattler planning.")
		return
	if scene.autobattle_ui.plans.size() < 3 or scene.autobattle_ui.plans.size() > 4:
		_fail("Boarding did not generate three to four authored plan choices.")
		return
	var safe_count := 0
	var selected_index := -1
	for index in range(scene.autobattle_ui.plans.size()):
		var plan: Dictionary = scene.autobattle_ui.plans[index]
		if bool(plan.get("safe", false)):
			safe_count += 1
		if String(plan.get("id", "")) == "break_the_hands":
			selected_index = index
		if Dictionary(plan.get("deployment_cells", {})).size() != 3:
			_fail("A generated plan did not bind one deployment mark per operative.")
			return
		if not plan.has("risk_unit_name") or not plan.has("opening_hit_chance"):
			_fail("A generated plan omitted its bound risk unit or exact opening chance.")
			return
	if safe_count < 1 or selected_index < 0:
		_fail("The plan set did not include both a safe approach and the authored arms-disable approach.")
		return
	if scene.board.get_node_or_null("PlanDeploymentGhosts") == null:
		_fail("Planning did not render ghosted deployment marks in the carriage.")
		return

	scene.turn.attack_resolved.connect(func(attacker: TacticalUnit, _target: TacticalUnit, zone: Types.BodyZone, _result: Dictionary) -> void:
		if attacker.team == Types.Team.PLAYER:
			player_zones.append(int(zone))
	)
	scene.autobattle_director.timeline_changed.connect(func(entries: Array, _active: int) -> void:
		for raw_entry in entries:
			var entry := Dictionary(raw_entry)
			if int(entry.get("team", -1)) == int(Types.Team.PLAYER): timeline_saw_crew = true
			if int(entry.get("team", -1)) == int(Types.Team.ENEMY): timeline_saw_guard = true
	)
	scene.autobattle_ui._select_plan(selected_index)
	scene.autobattle_ui._select_fallback(1)
	scene.autobattle_ui._confirm_plan()
	await process_frame
	if not scene.autobattle_director.running or not scene.autobattle_ui.combat_root.visible:
		_fail("Confirming a plan did not begin the automatic initiative battle.")
		return
	if scene.board.get_node_or_null("PlanDeploymentGhosts") != null:
		_fail("Deployment ghosts were not cleared when the battle began.")
		return

	scene.autobattle_director.set_paused(true)
	var paused_activation_count: int = scene.autobattle_director.activation_count
	for _frame in range(8):
		await process_frame
	if scene.autobattle_director.activation_count != paused_activation_count:
		_fail("Pause allowed another discrete initiative activation to begin.")
		return
	scene.autobattle_director.set_speed(4.0)
	scene.autobattle_director.set_paused(false)
	var timeout_frames := 5000
	while not scene.autobattle_ui.aftermath_root.visible and timeout_frames > 0:
		timeout_frames -= 1
		await process_frame
	if timeout_frames <= 0:
		_fail("The automatic Boarding encounter did not reach an aftermath screen.")
		return
	if not timeline_saw_crew or not timeline_saw_guard or scene.autobattle_director.activation_count < 2:
		_fail("The initiative timeline did not include automatic crew and guard activations.")
		return
	if Types.BodyZone.ARMS not in player_zones:
		_fail("The selected Break the Trigger Hand plan never aimed at the guard's arms.")
		return
	if scene.run_state.plan_history.size() != 1 or String(scene.run_state.plan_history[0].get("plan_id", "")) != "break_the_hands":
		_fail("The authored plan result was not persisted into the run history.")
		return
	if not scene._pending_autobattle_victory:
		_fail("The story-difficulty Boarding vertical slice did not finish successfully.")
		return
	if scene.autobattle_ui.aftermath_story.text.is_empty() or "REWARD" not in scene.autobattle_ui.aftermath_reward.text:
		_fail("Aftermath omitted its narrative story or reward summary.")
		return

	scene._on_aftermath_continue_requested()
	await process_frame
	if scene.run_state.phase != "intermission" or not scene.campaign_ui.is_frontend_open():
		_fail("Continuing from aftermath did not reach between-car route selection.")
		return
	print("BRASSLINE AUTOBATTLER VERTICAL SLICE: PASS - planning, exact preview, ghost deployment, pause/speed, alternating initiative, called-shot doctrine, persistence, aftermath, and route transition verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER VERTICAL SLICE: FAIL - %s" % message)
	quit(1)

