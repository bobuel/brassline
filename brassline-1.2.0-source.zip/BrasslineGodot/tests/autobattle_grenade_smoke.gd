extends SceneTree

var used_items: Array[String] = []


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 314159)
	scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew"])
	scene.run_state.current_car_id = "armory"
	scene.run_state.phase = "encounter"
	scene.run_state.inventory["clockwork_grenade"] = 1
	await scene._load_run_encounter()
	for _frame in range(4):
		await process_frame

	scene.autobattle_director.consumable_used.connect(func(item_id: String, _unit: TacticalUnit) -> void:
		used_items.append(item_id)
	)
	var selected_index := -1
	for index in range(scene.autobattle_ui.plans.size()):
		if String(scene.autobattle_ui.plans[index].get("gear_item", "")) == "clockwork_grenade":
			selected_index = index
			break
	if selected_index < 0:
		_fail("The Armory plan set did not expose a committed Clockwork Grenade option.")
		return
	scene.autobattle_ui._select_plan(selected_index)
	scene.autobattle_ui._select_fallback(0)
	scene.autobattle_ui._confirm_plan()
	scene.autobattle_director.set_speed(4.0)

	var timeout := 3000
	while "clockwork_grenade" not in used_items and scene.turn.encounter_active and timeout > 0:
		timeout -= 1
		await process_frame
	if "clockwork_grenade" not in used_items:
		_fail("The crew never executed its committed grenade throw before combat ended.")
		return
	if int(scene.run_state.inventory.get("clockwork_grenade", -1)) != 0:
		_fail("The executed grenade was not removed from persistent inventory.")
		return
	if int(scene.turn.encounter_stats.get("grenades", 0)) < 1 or int(scene.run_state.run_stats.get("items_used", 0)) < 1:
		_fail("The grenade throw did not reach combat and inventory telemetry.")
		return

	scene.autobattle_director.stop()
	print("BRASSLINE AUTOBATTLER GRENADE: PASS - authored commitment, approach-to-range, visible throw action, blast damage, inventory decrement, and telemetry verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER GRENADE: FAIL - %s" % message)
	quit(1)
