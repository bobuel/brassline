extends SceneTree

const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var expected_fragments := {
		"dining": "+2 MAX HP PER ZONE",
		"bar": "+4% HIT",
		"crew": "+1 MOVE",
		"armory": "+0.50 DAMAGE",
		"engine": "FINAL OBJECTIVE",
		"observation": "+5% CRITICAL",
		"sleeper": "CHOOSE +6 HEAL",
		"cargo": "+0.25 DAMAGE",
		"casino": "+2% HIT + 3% CRITICAL",
	}
	for car_id in expected_fragments:
		var preview := String(RunState.CAR_CATALOG[car_id].get("buff_preview", ""))
		if String(expected_fragments[car_id]) not in preview:
			_fail("%s does not publish its exact clear reward: %s" % [car_id, preview])
			return

	var bonuses := {
		"damage": 0.75,
		"range": 2,
		"movement": 1,
		"accuracy": 0.06,
		"critical": 0.08,
		"max_zone_hp": 3,
	}
	var summary := RunState.format_bonus_summary(bonuses)
	for fragment in ["DMG +0.75", "RANGE +2", "MOVE +1", "HIT +6%", "CRIT +8%", "ZONE HP +3"]:
		if fragment not in summary:
			_fail("The cumulative buff summary omitted %s: %s" % [fragment, summary])
			return

	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 84103)
	for _frame in range(3):
		await process_frame
	var selected: TacticalUnit = scene.turn.selected_unit
	if not is_instance_valid(selected):
		selected = scene.turn.player_units(true)[0]
		scene.turn.select_unit(selected)
	selected.base_damage += float(bonuses["damage"])
	selected.attack_range += int(bonuses["range"])
	selected.base_movement += int(bonuses["movement"])
	scene.autobattle_ui.current_bonuses = bonuses.duplicate(true)
	scene.autobattle_ui.show_unit_inspector(selected)
	for _frame in range(2):
		await process_frame
	if not scene.autobattle_ui.inspector_panel.visible or "CAR +0.75" not in scene.autobattle_ui.inspector_combat.text:
		_fail("The operative inspector did not show the effective/base/car stat breakdown.")
		return
	for fragment in ["DMG +0.75", "HIT +6%", "ZONE HP +3"]:
		if fragment not in scene.autobattle_ui.inspector_combat.text:
			_fail("The operative inspector omitted cumulative buff %s." % fragment)
			return

	var route_run := RunState.new()
	route_run.start_new_run(crew_ids, 84103)
	route_run.complete_current_car()
	route_run.current_offers.assign(["dining"])
	scene.campaign_ui.show_intermission(route_run, true)
	var route_copy := _collect_text(scene.campaign_ui.front_content)
	if "ON CLEAR" not in route_copy or "+2 maximum health per body zone" not in route_copy or "TRAIN BUFFS / NONE YET" not in route_copy:
		_fail("The route screen does not distinguish the next clear reward from already-earned buffs.")
		return
	if not route_run.prepare_next_car("dining"):
		_fail("The buff UI test could not enter Dining Car preparation.")
		return
	scene.campaign_ui.show_crew_prep(route_run)
	var prep_copy := _collect_text(scene.campaign_ui.front_content)
	if "ON CLEAR: +2 maximum health per body zone" not in prep_copy:
		_fail("Crew preparation does not retain the exact selected destination reward.")
		return
	# An existing order synergy must change the visible offer, not merely its tooltip.
	route_run.phase = "intermission"
	route_run.pending_car_id = ""
	route_run.completed_car_ids.append("bar")
	route_run.current_offers.assign(["dining"])
	scene.campaign_ui.show_intermission(route_run)
	if "+3 maximum health per body zone" not in _collect_text(scene.campaign_ui.front_content):
		_fail("Bar-first Dining synergy is not reflected in the visible reward.")
		return

	print("BRASSLINE CAR BUFF UI SMOKE: PASS - exact clear rewards, cumulative ledger, prep preview, and operative stat breakdown verified.")
	quit(0)


func _collect_text(node: Node) -> String:
	if node is Control and not node.is_visible_in_tree():
		return ""
	var values: Array[String] = []
	if node is Label:
		values.append((node as Label).text)
	elif node is Button:
		values.append((node as Button).text)
	for child in node.get_children():
		values.append(_collect_text(child))
	return "\n".join(values)


func _fail(message: String) -> void:
	push_error("BRASSLINE CAR BUFF UI SMOKE: FAIL - %s" % message)
	quit(1)
