extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const Plans := preload("res://scripts/plan_catalog.gd")

func _initialize() -> void:
	_run.call_deferred()

func _require(ok: bool, message: String) -> bool:
	if not ok:
		push_error("BRASSLINE GAMEPLAY UPLIFT: FAIL - " + message)
		quit(1)
	return ok

func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _i in range(8): await process_frame
	var crew: Array[String] = ["ada", "marlow", "nix"]
	scene.campaign_ui.selected_difficulty = "story"
	await scene._on_crew_confirmed(crew, 45196)
	scene.run_state.current_car_id = "engine"
	scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew", "armory", "observation"])
	await scene._load_run_encounter()
	var director: AutobattleDirector = scene.autobattle_director
	var turn: TurnController = scene.turn
	var plan := {}
	for offered in scene.autobattle_ui.plans:
		if String(offered.id) == "bleed_the_pressure": plan = offered
	if not _require(not plan.is_empty(), "Engine capture offer is missing."): return
	if not _require("+8%" in String(plan.risk_short) and "head" in String(plan.risk_short), "Steam falsely advertises removal of Voss command aim."): return
	if not _require(String(plan.preview_steps[2].action) == "capture_after_disarm" and not String(plan.preview_steps[2].condition).is_empty(), "Follow-through preview promises unconditional capture."): return
	var rifle: Dictionary = plan.orders.ada
	var anchor: Dictionary = plan.orders.marlow
	if not _require(rifle.capture_target and int(rifle.secondary_zone) == Types.BodyZone.LEGS, "Capture follow-through does not target the second mobility capability."): return
	var boss: TacticalUnit
	for enemy in turn.enemy_units(true):
		if enemy.role_id == "boss": boss = enemy
	if not _require(is_instance_valid(boss) and not director.control_advance_ready(anchor), "Anchor rushes the controls before the dangerous gun is disabled."): return
	director.configure(plan, Plans.fallback_data("hold_plan"))
	var marlow: TacticalUnit = turn.player_units(true)[1]
	var anchor_start := marlow.grid_cell
	await director._advance_control_objective(marlow, anchor, director._run_serial)
	if not _require(marlow.grid_cell == anchor_start and director._control_condition_records[0].state == "waiting", "Blocked control advance lacks an actual waiting record."): return
	boss.body_state[Types.BodyZone.ARMS].hp = 0
	boss.body_state[Types.BodyZone.ARMS].disabled = true
	if not _require(director.control_advance_ready(anchor), "Disarming the command guard does not release the control advance."): return
	var ada: TacticalUnit = turn.player_units(true)[0]
	ada.action_points = 2
	boss.body_state[Types.BodyZone.TORSO].hp = 1
	director.configure(plan, Plans.fallback_data("hold_plan"))
	if not _require(director._choose_body_zone(ada, boss, rifle) == Types.BodyZone.LEGS, "Capture priority silently changed to a lethal torso finisher."): return
	turn.board.control_claimed = true
	turn._resolve_surrenders()
	if not _require(boss.is_combat_active(), "Engine capture ignored the mobility requirement."): return
	boss.body_state[Types.BodyZone.LEGS].hp = 0
	boss.body_state[Types.BodyZone.LEGS].disabled = true
	turn.board.control_claimed = false
	if not _require(director.capture_requires_controls(boss, rifle), "Surviving shooter fires into disabled limbs instead of completing an unclaimed capture."): return
	turn.board.control_claimed = true
	turn._resolve_surrenders()
	if not _require(not boss.is_combat_active(), "Crippled arms+legs and claimed controls did not capture Voss."): return
	# In a genuinely safe lane, a leftward coordinate alone must not burn an AP.
	var original_units: Array[TacticalUnit] = turn.units.duplicate()
	for enemy in turn.enemy_units(false): turn.units.erase(enemy)
	if not _require(director.protective_fallback_destination(ada) == ada.grid_cell, "Safe retreat walked left despite no change in exposure."): return
	turn.units = original_units
	print("BRASSLINE GAMEPLAY UPLIFT: PASS - truthful Voss risk, gated control advance, arms-to-legs capture, existing surrender payoff, and stable safe fallback verified.")
	quit(0)
