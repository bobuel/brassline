extends SceneTree

const AudioDirectorScript := preload("res://scripts/audio_director.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var host := Node.new()
	root.add_child(host)
	var director: BrasslineAudioDirector = AudioDirectorScript.new()
	host.add_child(director)
	for _frame in range(3):
		await process_frame
	if director._cues.size() < 25:
		_fail("Only %d production cues loaded." % director._cues.size())
		return
	if director._sfx_pool.size() != 12 or not director._ambience_player.playing:
		_fail("The pooled effects or looping train ambience did not start.")
		return
	director.play_mission_result(false, "The line held")
	if not director._caption_panel.visible or "THE LINE HELD" not in director._caption_label.text:
		_fail("Important combat audio did not produce an accessible caption.")
		return
	director.set_captions_enabled(false)
	if director._caption_panel.visible:
		_fail("Turning sound captions off left the caption visible.")
		return
	director.set_ambience_enabled(false)
	if director._ambience_player.volume_db > -70.0:
		_fail("The ambience accessibility control did not silence the train loop.")
		return
	var button := Button.new()
	button.text = "TEST CONTROL"
	host.add_child(button)
	for _frame in range(2):
		await process_frame
	if not button.has_meta("brassline_audio_hook"):
		_fail("Dynamically created UI controls were not connected to interface audio.")
		return
	print("BRASSLINE AUDIO: PASS - 25+ CC0 cues, pooled playback, generated train ambience, dynamic UI hooks, and optional combat sound captions verified.")
	host.queue_free()
	await process_frame
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE AUDIO: FAIL - %s" % message)
	quit(1)
