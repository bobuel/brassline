extends SceneTree

const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids)
	if scene.run_state == null or scene.run_state.current_car_id != "baggage":
		_fail("Starting a drafted run did not load the guaranteed Boarding Car.")
		return
	if scene.turn.player_units(true).size() != 3 or scene.turn.enemy_units(true).size() != 1:
		_fail("The Boarding Car did not contain the selected squad and exactly one easy guard.")
		return
	var guard_cell: Vector2i = scene.turn.enemy_units(true)[0].grid_cell
	if guard_cell.x < GridBoard.ENEMY_DEPLOYMENT_MIN_X or guard_cell.x >= GridBoard.BOARD_SIZE.x or not scene.board.is_walkable(guard_cell):
		_fail("The easy guard did not take a valid post on the far side of the single Boarding carriage.")
		return
	for crew in scene.turn.player_units(true):
		if scene.board.grid_distance(crew.grid_cell, guard_cell) < GridBoard.MIN_DEPLOYMENT_DISTANCE:
			_fail("The Boarding guard started too close to the crew.")
			return
	if scene.turn.encounter_mode != "secure" or not scene.turn.encounter_active:
		_fail("The first run car was not configured as an active carriage-securing encounter.")
		return

	var ada = scene.turn.player_units(true)[0]
	ada.apply_damage(Types.BodyZone.TORSO, 3)
	var wounded_hp := int(ada.body_state[Types.BodyZone.TORSO]["hp"])
	var marlow = scene.turn.player_units(true)[1]
	var downed_id: String = marlow.roster_id
	marlow.apply_damage(Types.BodyZone.HEAD, 99, true)
	var opening_guard = scene.turn.enemy_units(true)[0]
	opening_guard.apply_damage(Types.BodyZone.TORSO, 99, true)
	for _frame in range(3):
		await process_frame

	if scene.run_state.phase != "intermission" or scene.run_state.completed_car_ids != ["baggage"]:
		_fail("Defeating the opening guard did not advance to the route table.")
		return
	if int(scene.run_state.inventory["medkit"]) != 2 or int(scene.run_state.inventory["limb_brace"]) != 1:
		_fail("The Boarding Car supply cache did not persist into intermission.")
		return
	if not scene.campaign_ui.is_frontend_open() or scene.run_state.current_offers.is_empty():
		_fail("The post-car train diagram and eligible offers were not presented.")
		return

	var heal_result: Dictionary = scene.run_state.use_item("medkit", "ada")
	if not bool(heal_result.get("ok", false)):
		_fail("A Medkit could not be managed between cars.")
		return
	var healed_hp := int(scene.run_state.body_state_for("ada")[Types.BodyZone.TORSO]["hp"])
	if healed_hp <= wounded_hp:
		_fail("Between-car healing did not improve the persistent wound.")
		return
	var chosen_car := ""
	for offered_car in scene.run_state.current_offers:
		if String(scene.run_state.car_data(offered_car).get("kind", "combat")) == "combat":
			chosen_car = offered_car
			break
	if chosen_car.is_empty():
		_fail("The integration seed did not produce a combat route offer.")
		return
	scene._on_car_prep_requested(chosen_car)
	if scene.run_state.phase != "preparation" or scene.run_state.pending_car_id != chosen_car or scene.campaign_ui.crew_preview_stage == null:
		_fail("Choosing a route did not open the checkpointed 3D crew-preparation step.")
		return
	scene._save_path = "user://brassline_prep_restore_test.json"
	scene._clear_run_checkpoint()
	scene._automation_mode = false
	scene._save_run_checkpoint()
	scene._automation_mode = true
	scene.run_state = null
	await scene._on_continue_requested()
	if scene.run_state == null or scene.run_state.phase != "preparation" or scene.run_state.pending_car_id != chosen_car or scene.campaign_ui.crew_preview_stage == null:
		_fail("Continue Run did not restore the chosen car directly into crew preparation.")
		return
	scene._clear_run_checkpoint()
	await scene._on_next_car_chosen(chosen_car)
	if scene.run_state.phase != "encounter" or scene.run_state.current_car_id != chosen_car:
		_fail("Choosing an eligible car did not load the next encounter.")
		return
	if scene.turn.enemy_units(true).size() < 2:
		_fail("The second car did not scale beyond the easy opening guard.")
		return
	var restored_ada = scene.turn.player_units(true)[0]
	if int(restored_ada.body_state[Types.BodyZone.TORSO]["hp"]) != healed_hp:
		_fail("Squad wounds and healing did not survive the car transition.")
		return
	for survivor in scene.turn.player_units(true):
		if survivor.roster_id == downed_id:
			_fail("A downed operative incorrectly resurrected in the next car.")
			return

	var shooter = scene.turn.player_units(true)[0]
	var target = scene.turn.enemy_units(true)[0]
	if not _place_for_clean_combat_item_test(scene, shooter, target):
		_fail("The next-car test could not establish a legal shared shot/grenade lane.")
		return
	scene.turn.select_unit(shooter)
	scene.turn.set_target(target)
	var base_chance: float = scene.turn.attack_chance(shooter, target, Types.BodyZone.TORSO)
	scene.run_state.inventory["focus_tonic"] = 1
	scene.ui.set_combat_inventory(scene.run_state.inventory)
	scene._on_tonic_requested()
	if int(scene.run_state.inventory["focus_tonic"]) != 0 or not shooter.is_focused():
		_fail("A Focus Tonic was not consumed and applied to the selected operative.")
		return
	if scene.turn.attack_chance(shooter, target, Types.BodyZone.TORSO) <= base_chance:
		_fail("Focus Tonic did not increase the selected operative's hit chance.")
		return

	# The controlled clean lane is also inside grenade range; grid movement itself
	# is covered by combat_smoke.gd.
	if not scene.turn.can_use_grenade(target):
		_fail("The next-car test target was not a legal grenade target.")
		return
	var torso_before := int(target.body_state[Types.BodyZone.TORSO]["hp"])
	var ap_before: int = shooter.action_points
	scene.run_state.inventory["clockwork_grenade"] = 1
	scene.ui.set_combat_inventory(scene.run_state.inventory)
	await scene._on_grenade_requested()
	if int(scene.run_state.inventory["clockwork_grenade"]) != 0 or shooter.action_points != ap_before - 1:
		_fail("A Clockwork Grenade did not consume its inventory charge and 1 AP.")
		return
	if int(target.body_state[Types.BodyZone.TORSO]["hp"]) >= torso_before:
		_fail("A Clockwork Grenade did not damage its targeted guard.")
		return

	print("BRASSLINE SEVEN-CAR INTEGRATION SMOKE: PASS - draft, easy opener, route choice, checkpointed 3D preparation restore, boarding, persistent wounds, and combat kit verified.")
	quit(0)


func _place_for_clean_combat_item_test(scene: Node, shooter: TacticalUnit, target: TacticalUnit) -> bool:
	var occupied: Dictionary = scene.turn.occupied_cells(shooter)
	for distance_goal in [6, 5, 4, 3]:
		for y in range(GridBoard.BOARD_SIZE.y):
			for x in range(GridBoard.BOARD_SIZE.x):
				var candidate := Vector2i(x, y)
				if scene.board.grid_distance(candidate, target.grid_cell) != distance_goal:
					continue
				if not scene.board.is_walkable(candidate, occupied) or scene.board.hazard_cells.has(candidate):
					continue
				if not scene.board.has_line_of_sight(candidate, target.grid_cell):
					continue
				shooter.grid_cell = candidate
				shooter.position = scene.board.cell_to_world(candidate) + Vector3(0.0, 0.12, 0.0)
				var chance: float = scene.turn.attack_chance(shooter, target, Types.BodyZone.TORSO)
				if chance > 0.0 and chance < 0.94:
					return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE SEVEN-CAR INTEGRATION SMOKE: FAIL - %s" % message)
	quit(1)
