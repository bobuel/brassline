extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
const Types := preload("res://scripts/game_types.gd")
var failed := false
var output_dir := "res://../../work/trust-pass/ui-captures"

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(output_dir))
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for frame in range(12): await process_frame
	var crew: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew, 661191)
	var route := RunState.new()
	route.start_new_run(crew, 661191)
	route.complete_current_car()
	for resolution in [Vector2i(1280, 720), Vector2i(1280, 800), Vector2i(1920, 1080)]:
		root.content_scale_size = resolution
		root.size = resolution
		for scale in [1.0, 1.3]:
			scene.autobattle_ui.hide_all()
			scene.campaign_ui.text_scale = scale
			scene.autobattle_ui.set_text_scale(scale)
			scene.campaign_ui.show_intro()
			await _capture("title", resolution, scale, [scene.campaign_ui.front_content.get_child(scene.campaign_ui.front_content.get_child_count() - 1)])
			scene.campaign_ui.show_crew_selection()
			await _capture("crew", resolution, scale, [scene.campaign_ui.confirm_button, scene.campaign_ui.cosmetic_button])
			scene.campaign_ui.show_settings()
			await _capture("settings", resolution, scale, [])
			route.phase = "intermission"
			route.pending_car_id = ""
			scene.campaign_ui.show_intermission(route)
			await _capture("route", resolution, scale, [])
			route.prepare_next_car(route.current_offers[0])
			var body := route.body_state_for("ada")
			body[Types.BodyZone.TORSO]["hp"] = 1
			route.record_crew_body_state("ada", body)
			scene.campaign_ui.show_crew_prep(route)
			await _capture("recovery", resolution, scale, [scene.campaign_ui.prep_board_button])
			scene.campaign_ui.front_overlay.visible = false
			scene.autobattle_ui.planning_root.visible = true
			scene.autobattle_ui._select_plan(0)
			await _capture("planning", resolution, scale, [scene.autobattle_ui.confirm_button])
			scene.autobattle_ui.show_inspector("marlow")
			scene.autobattle_ui.inspector_panel._select_tab("gear")
			await _capture("ledger", resolution, scale, [scene.autobattle_ui.inspector_panel.tabs["train"]])
			scene.autobattle_ui.inspector_panel.close()
	print("BRASSLINE UI TRUST CAPTURE: %s - seven UI states at three resolutions and two text scales." % ("FAIL" if failed else "PASS"))
	scene.queue_free()
	for frame in range(3): await process_frame
	quit(1 if failed else 0)

func _capture(screen: String, resolution: Vector2i, scale: float, controls: Array) -> void:
	for frame in range(8): await process_frame
	for control in controls:
		if not Rect2(Vector2.ZERO, resolution).encloses(control.get_global_rect()):
			failed = true
			push_error("UI CAPTURE CLIP %s %s scale%s %s" % [screen, resolution, scale, control.get_global_rect()])
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	if image == null:
		failed = true
		push_error("No rendered UI image for " + screen)
		return
	var path := "%s/%s_%dx%d_%d.png" % [output_dir, screen, resolution.x, resolution.y, roundi(scale * 100)]
	if image.save_png(path) != OK:
		failed = true
		push_error("Could not write UI capture " + path)
