extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 413017)
	var plans: Array[Dictionary] = PlanCatalog.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {}, [], {})
	if plans.size() != 4:
		_fail("Boarding produced %d plans instead of the required quartet." % plans.size())
		return
	var families := {}
	var target_counts := {}
	var body_counts := {}
	var risk_counts := {}
	for plan in plans:
		if not String(plan.get("gear_item", "")).is_empty():
			_fail("An item plan was offered without the required item in inventory.")
			return
		var family := String(plan.get("tactic_family", ""))
		families[family] = true
		_count(target_counts, String(plan.get("primary_target_key", "")))
		_count(body_counts, str(int(plan.get("body_priority", Types.BodyZone.TORSO))))
		_count(risk_counts, String(plan.get("risk_unit_id", "")))
		if Array(plan.get("preview_steps", [])).size() != 3:
			_fail("%s did not expose a three-beat preview." % String(plan.get("id", "plan")))
			return
		var deployment: Dictionary = scene.autobattle_director.build_deployment(plan)
		if not scene.autobattle_director.deployment_is_safe(deployment):
			_fail("%s produced an unsafe deployment: %s" % [String(plan.get("id", "plan")), str(deployment)])
			return
	for family in ["safe_control", "body_disable", "environment_gear", "high_risk"]:
		if not families.has(family):
			_fail("The required %s family was missing: %s" % [family, str(families.keys())])
			return
	for counts in [target_counts, body_counts, risk_counts]:
		for key in Dictionary(counts):
			if int(Dictionary(counts)[key]) > 2:
				_fail("Offer diversity exceeded the two-plan repetition cap for %s (%d)." % [String(key), int(Dictionary(counts)[key])])
				return
	var geared_plans: Array[Dictionary] = PlanCatalog.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {}, [], {"focus_tonic": 1})
	var committed_item := false
	for plan in geared_plans:
		if String(plan.get("gear_item", "")) == "focus_tonic" and "called shot" in String(plan.get("gear_trigger", "")).to_lower():
			committed_item = true
	if not committed_item:
		_fail("A carried Focus Tonic did not appear with its safe called-shot trigger.")
		return
	print("BRASSLINE TEEN-READINESS PLANS: PASS - four tactical families, repetition caps, safe deployments, three-beat previews, and eligible gear verified.")
	quit(0)


func _count(counts: Dictionary, key: String) -> void:
	counts[key] = int(counts.get(key, 0)) + 1


func _fail(message: String) -> void:
	push_error("BRASSLINE TEEN-READINESS PLANS: FAIL - %s" % message)
	quit(1)
