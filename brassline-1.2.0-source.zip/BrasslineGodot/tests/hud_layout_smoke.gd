extends SceneTree


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame
	if int(ProjectSettings.get_setting("display/window/size/viewport_width", 0)) != 1280 or int(ProjectSettings.get_setting("display/window/size/viewport_height", 0)) != 720:
		_fail("The shipping viewport is not the native 1280x720 HUD target.")
		return
	# Headless Godot supplies its own default root size, so force the configured
	# shipping dimensions before measuring anchored control rectangles.
	root.size = Vector2i(1280, 720)
	for _frame in range(2):
		await process_frame

	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 63021)
	for _frame in range(3):
		await process_frame
	if not scene.ui.action_panel.visible or scene.ui.target_panel.visible:
		_fail("The clean combat state should show commands without permanently showing targeting chrome.")
		return
	if scene.ui.help_label != null:
		_fail("The old always-on keyboard instruction strip still occupies the playfield.")
		return
	if scene.ui.selected_label.get_theme_font_size("font_size") < 15 or scene.ui.log_label.get_theme_font_size("normal_font_size") < 14:
		_fail("Primary command or combat-feed text is below the redesigned readability floor.")
		return
	if scene.ui.cover_legend_label == null or scene.ui.cover_legend_label.visible:
		_fail("The contextual cover explanation should stay hidden until a guard is selected.")
		return
	if scene.ui.stats_button == null or scene.ui.stats_button.get_theme_font_size("font_size") < 12 or scene.ui.stats_panel.visible:
		_fail("The compact command bar is missing its optional, closed-by-default Stats inspector.")
		return
	if not scene.campaign_ui.navigator_buttons.is_empty() or scene.campaign_ui.navigator.size.x > 700.0:
		_fail("The old seven-box route strip still occupies the combat view.")
		return
	if scene.campaign_ui.navigator_buff_label == null or "EARNED CAR BUFFS" not in scene.campaign_ui.navigator_buff_label.text:
		_fail("The compact car strip does not summarize earned permanent buffs.")
		return
	if scene.ui.cover_button == null or "TAKE COVER" not in scene.ui.cover_button.text:
		_fail("The command bar is missing the player Take Cover action.")
		return
	var command_bounds: Rect2 = scene.ui.action_panel.get_global_rect()
	for command in [scene.ui.reload_button, scene.ui.overwatch_button, scene.ui.cover_button, scene.ui.ability_button, scene.ui.grenade_button, scene.ui.tonic_button]:
		if command.get_theme_font_size("font_size") < 12:
			_fail("A command button remains below the 12px readability floor.")
			return
		var button_bounds: Rect2 = command.get_global_rect()
		if button_bounds.position.x < command_bounds.position.x or button_bounds.end.x > command_bounds.end.x:
			_fail("A command button overflows the fixed tactical command bar.")
			return

	var target = scene.turn.enemy_units(true)[0]
	scene.turn.set_target(target)
	scene.ui.update_from_turn(scene.turn)
	for _frame in range(2):
		await process_frame
	if not scene.ui.target_panel.visible:
		_fail("Inspecting an enemy did not reveal the contextual called-shot panel.")
		return
	if not scene.ui.cover_legend_label.visible or "TEAL = FULL COVER" not in scene.ui.cover_legend_label.text or scene.board.visible_cover_preview_count() <= 0:
		_fail("Selecting a guard did not explain and reveal contextual move-cover previews.")
		return
	if scene.campaign_ui.navigator.get_global_rect().intersects(scene.ui.target_panel.get_global_rect()):
		_fail("The route strip overlaps the contextual called-shot panel.")
		return
	if scene.ui.action_panel.get_global_rect().intersects(scene.ui.target_panel.get_global_rect()):
		_fail("The command bar %s overlaps the contextual called-shot panel %s." % [scene.ui.action_panel.get_global_rect(), scene.ui.target_panel.get_global_rect()])
		return
	if scene.ui.log_panel.get_global_rect().intersects(scene.ui.action_panel.get_global_rect()):
		_fail("The compact combat feed overlaps the command bar.")
		return

	scene.ui.toggle_stats()
	for _frame in range(2):
		await process_frame
	if not scene.ui.stats_panel.visible or "DAMAGE" not in scene.ui.stats_combat_label.text or "EARNED CAR BUFFS" not in scene.ui.stats_buff_label.text:
		_fail("Opening Stats did not expose the selected operative's combat breakdown and earned car buffs.")
		return
	if scene.ui.stats_panel.get_global_rect().intersects(scene.ui.action_panel.get_global_rect()) or scene.ui.stats_panel.get_global_rect().intersects(scene.campaign_ui.navigator.get_global_rect()):
		_fail("The optional Stats inspector overlaps another persistent HUD region.")
		return
	scene.ui.toggle_stats()
	var selected: TacticalUnit = scene.turn.selected_unit
	selected.grid_cell = Vector2i(5, 1)
	selected.position = scene.board.cell_to_world(selected.grid_cell) + Vector3(0.0, 0.06, 0.0)
	selected.begin_turn()
	if not scene.turn.try_take_cover():
		_fail("The HUD cover-layout scenario could not enter the stance.")
		return
	for _frame in range(2):
		await process_frame
	var top_bar: Control = scene.ui.hud_root.get_child(0)
	if not is_equal_approx(top_bar.get_global_rect().position.y, 12.0) or not is_equal_approx(scene.ui.target_panel.get_global_rect().position.y, 90.0) or scene.ui.action_panel.get_global_rect().end.y > 720.0:
		_fail("Taking cover displaced anchored HUD regions: top=%s target=%s action=%s." % [top_bar.get_global_rect(), scene.ui.target_panel.get_global_rect(), scene.ui.action_panel.get_global_rect()])
		return

	scene.ui.toggle_log()
	for _frame in range(2):
		await process_frame
	if scene.ui.log_panel.get_global_rect().intersects(scene.ui.action_panel.get_global_rect()):
		_fail("The expanded combat feed obscures the command bar.")
		return
	if scene.ui.log_panel.size.x > 250.0:
		_fail("The expanded combat feed is wider than its dedicated left-side column.")
		return

	print("BRASSLINE HUD LAYOUT SMOKE: PASS - simplified car strip, optional Stats inspector, contextual targeting, readable type, and non-overlapping feed verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE HUD LAYOUT SMOKE: FAIL - %s" % message)
	quit(1)
