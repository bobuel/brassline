extends SceneTree

const ArtScript := preload("res://scripts/environment_art.gd")
const CameraScript := preload("res://scripts/camera_rig.gd")
const Types := preload("res://scripts/game_types.gd")
const PreviewScript := preload("res://scripts/crew_preview_stage.gd")
const RunScript := preload("res://scripts/run_state.gd")
const CARS := ["baggage", "dining", "bar", "casino", "crew", "armory", "engine", "observation", "cargo", "sleeper"]
const ROSTER := [
	{"id":"ada", "model":"Casual_2.gltf", "weapon_id":"longshot_rifle"},
	{"id":"marlow", "model":"Adventurer.gltf", "weapon_id":"breach_gun"},
	{"id":"nix", "model":"Punk.gltf", "weapon_id":"coil_pistol"},
]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var capture := "--capture-spatial" in OS.get_cmdline_user_args()
	var stage := Node3D.new(); root.add_child(stage); current_scene = stage
	var world := WorldEnvironment.new(); var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR; environment.background_color = Color("#0c171c")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; environment.ambient_light_color = Color("#bdc7c1"); environment.ambient_light_energy = 0.75
	world.environment = environment; stage.add_child(world)
	var light := DirectionalLight3D.new(); light.light_energy = 1.5; light.rotation_degrees = Vector3(-50, -25, 0); light.shadow_enabled = true; stage.add_child(light)
	var board := GridBoard.new(); stage.add_child(board)
	var art := ArtScript.new(); board.add_child(art); art.setup(board)
	var rig := CameraScript.new(); stage.add_child(rig)
	for car_id in CARS:
		board.prepare_run_encounter(car_id)
		art.set_active_run_car(car_id, 2)
		if not art.decorative_walkable_conflicts().is_empty():
			_fail("Decorative solids intersect walkable actor space in %s." % car_id); return
		for prop in art._tactical_cover_root.get_children():
			var cell := Vector2i(prop.get_meta("grid_cell"))
			if not board.blocked_cells.has(cell) or not prop.position.is_equal_approx(board.cell_to_world(cell)):
				_fail("Functional furniture does not match its blocked cell."); return
			for mesh in prop.find_children("*","MeshInstance3D",true,false):
				for corner in range(8):
					var local:Vector3=prop.global_transform.affine_inverse()*mesh.global_transform*mesh.get_aabb().get_endpoint(corner)
					if absf(local.x)>GridBoard.CELL_SIZE_X*0.49 or absf(local.z)>GridBoard.CELL_SIZE_Z*0.49:
						_fail("Functional furniture intrudes into an adjacent walking cell: %s / %s"%[car_id,mesh.name]);return
	board.prepare_run_encounter("dining"); art.set_active_run_car("dining", 2)
	# These two legal spawn cells were inside the old decorative table layer.
	for cell in [Vector2i(9,1), Vector2i(13,1)]:
		if not board.is_walkable(cell): _fail("Dining regression changed walking topology."); return
	var actors: Array[TacticalUnit] = []
	for index in range(5):
		var unit := TacticalUnit.new(); unit.visual_model_path = "res://assets/characters/quaternius/" + String(ROSTER[mini(index,2)].model if index < 3 else "Worker.gltf")
		stage.add_child(unit)
		var cell: Vector2i = [Vector2i(1,1),Vector2i(2,3),Vector2i(3,2),Vector2i(9,1),Vector2i(13,1)][index]
		unit.setup(["Ada Brass","Marlow Pike","Nix Bell","Dining Bruiser","Dining Railhand"][index], Types.Team.PLAYER if index<3 else Types.Team.ENEMY, cell, board)
		if index < 3: unit.roster_id = ROSTER[index].id; unit.configure_combat_identity(ROSTER[index].weapon_id)
		actors.append(unit)
	var view_count := 0
	for size in [Vector2i(1280,720), Vector2i(1280,800), Vector2i(1920,1080)]:
		root.content_scale_size = size; root.size = size
		for frame in range(4): await process_frame
		rig.frame_active_car()
		if not rig.combat_battlefield_rect().encloses(rig.planning_projected_bounds()):
			_fail("Combat clips the complete car at %s." % size); return
		for unit in actors:
			for offset in [Vector3(-0.6,0,0),Vector3(0.6,2.6,0)]:
				if not rig.combat_battlefield_rect().has_point(rig.camera.unproject_position(unit.global_position+offset)):
					_fail("Combat clips an operative/caption at %s." % size); return
		if capture:
			await _capture("res://preview_spatial_combat_%dx%d.png" % [size.x,size.y])
		rig.set_presentation_subjects([actors[0].global_position, actors[4].global_position], 12.2)
		if not rig.combat_battlefield_rect().encloses(rig.presentation_projected_bounds()):
			_fail("A long-shot cinematic clips either participant at %s." % size); return
		var planning_rect := Rect2(12,58,size.x-24,size.y-224)
		rig.frame_planning_area(planning_rect)
		if not planning_rect.encloses(rig.planning_projected_bounds()):
			_fail("Planning clips complete car at %s." % size); return
		var deployment := {"ada":Vector2i(1,1),"marlow":Vector2i(2,3),"nix":Vector2i(3,2)}
		board.show_deployment_preview(deployment, [actors[0],actors[1],actors[2]], {"risk_unit_id":"marlow","target_instance_id":actors[3].get_instance_id(),"gear_item":"clockwork_grenade","gear_user_id":"nix"}, {"id":"protect_wounded"})
		if not board._deployment_preview_root.find_children("*","Label3D",true,false).is_empty():
			_fail("Redundant world-space prose returned to the plan preview."); return
		if capture: await _capture("res://preview_spatial_planning_%dx%d.png" % [size.x,size.y])
		board.clear_deployment_preview(); view_count += 3
	var environment_cells := [Vector2i(9,1),Vector2i(8,1),Vector2i(10,1)]
	board.show_deployment_preview({"ada":Vector2i(1,1)}, [actors[0]], {
		"environment_preview":{"valid":true,"control_only":false,"impact_cell":Vector2i(9,1),"affected_cells":environment_cells,"victims":[{"instance_id":actors[3].get_instance_id(),"cell":Vector2i(9,1)}]},
		"fallback_destinations":{"ada":Vector2i(0,1)}}, {"id":"protect_wounded"})
	if board._deployment_preview_root.find_children("EnvironmentArea_*","MeshInstance3D",true,false).size() != environment_cells.size():
		_fail("Environment board preview disagrees with the resolver's affected cells."); return
	if not board._deployment_preview_root.has_node("EnvironmentVictim_%s" % str(actors[3].get_instance_id())):
		_fail("Environment preview omits the actual affected opponent."); return
	if Vector2i(board._deployment_preview_root.get_node("ConditionalRetreat_ada").get_meta("destination")) != Vector2i(0,1):
		_fail("Fallback preview ignores its resolved destination."); return
	board.clear_deployment_preview()
	var run := RunScript.new(); var crew_ids: Array[String] = ["ada","marlow","nix"]; run.start_new_run(crew_ids,98520)
	var preview := PreviewScript.new(); root.add_child(preview); preview.setup(run,ROSTER,"ada")
	for member in ROSTER:
		var visual: CharacterVisual = preview.visual_nodes[member.id]
		if String(visual.weapon_root.get_meta("weapon_id")) != String(member.weapon_id):
			_fail("Prep displays a different weapon than the roster."); return
		visual.set_cover_stance(true,false)
		if not is_zero_approx(visual.position.y): _fail("Cover sinks an actor through the deck."); return
	if capture: await _capture("res://preview_spatial_prep.png")
	print("BRASSLINE SPATIAL READABILITY: PASS - 10 cars, legal furniture footprints, %d framing views at 720/800/1080, caption-free plan markers and real prep weapons." % view_count)
	quit(0)


func _capture(path: String) -> void:
	for frame in range(12): await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	if image == null or image.is_empty(): _fail("Renderer produced no image for %s." % path); return
	image.save_png(path)


func _fail(message: String) -> void:
	push_error("BRASSLINE SPATIAL READABILITY: FAIL - " + message)
	quit(1)
