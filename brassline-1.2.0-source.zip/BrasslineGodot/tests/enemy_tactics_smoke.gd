extends SceneTree

const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(6):
		await process_frame

	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 220805)
	for _frame in range(4):
		await process_frame

	if scene.board.get_node_or_null("TacticalCoverEdges") != null:
		_fail("The unexplained always-on blue cover squares still exist.")
		return
	var cover_preview: Node = scene.board.get_node_or_null("ContextualCoverPreview")
	if cover_preview == null or cover_preview.get_child_count() < 12:
		_fail("The active carriage did not build contextual tactical cover previews.")
		return
	if scene.board.visible_cover_preview_count() != 0:
		_fail("Cover previews appeared before the player selected a relevant guard.")
		return

	var crew = scene.turn.player_units(true)
	var enemies = scene.turn.enemy_units(true)
	if crew.is_empty() or enemies.is_empty():
		_fail("A live crew and guard are required for the tactical AI scenario.")
		return
	var shooter: TacticalUnit = crew[0]
	var defender: TacticalUnit = enemies[0]
	var covered_pair := _find_covered_shot(scene.board, shooter.attack_range)
	if covered_pair.is_empty():
		_fail("No legal covered firing lane was found in the carriage layout.")
		return
	_place_unit(scene.board, shooter, covered_pair["attacker"])
	_place_unit(scene.board, defender, covered_pair["defender"])
	scene.board.show_cover_preview(shooter.grid_cell, [defender.grid_cell])
	if scene.board.visible_cover_preview_count() != 1:
		_fail("A covered tile did not reveal exactly one directional teal/brass preview.")
		return
	scene.board.hide_cover_preview()
	defender.set_cover_stance(false, false)
	var standing_chance: float = scene.turn.attack_chance(shooter, defender, Types.BodyZone.TORSO)
	defender.enter_cover_stance()
	var braced_chance: float = scene.turn.attack_chance(shooter, defender, Types.BodyZone.TORSO)
	if not is_equal_approx(standing_chance - braced_chance, 0.10):
		_fail("Taking cover did not add the promised 10% incoming hit penalty.")
		return
	if not defender.is_in_physical_cover() or not defender.get_node("CoverStanceMarker").visible:
		_fail("The defensive stance has no physical-cover state or visible marker.")
		return
	var defender_visual := defender.get_node_or_null("CharacterVisual") as CharacterVisual
	if defender_visual == null or not defender_visual.in_cover_stance:
		_fail("The rigged character did not enter its lowered cover stance.")
		return
	defender.begin_turn()
	if defender.crouched:
		_fail("Cover stance did not expire at the unit's next activation.")
		return

	# Exercise the real player command, its AP economy, and its HUD state.
	scene.turn.phase = Types.Phase.PLAYER
	shooter.begin_turn()
	scene.turn.select_unit(shooter)
	if not scene.turn.try_take_cover() or shooter.action_points != 1 or not shooter.crouched:
		_fail("The player Take Cover command did not spend 1 AP and set the stance.")
		return
	scene.ui.update_from_turn(scene.turn)
	if not scene.ui.cover_button.disabled or "ACTIVE" not in scene.ui.cover_button.text:
		_fail("The command bar did not report the active cover stance.")
		return
	if scene.turn.try_take_cover():
		_fail("The same operative was able to buy the cover bonus twice.")
		return
	if crew.size() < 2:
		_fail("The target-choice cover scenario requires a second operative.")
		return
	var exposed_operative: TacticalUnit = crew[1]
	_place_unit(scene.board, shooter, Vector2i(1, 1))
	_place_unit(scene.board, exposed_operative, Vector2i(1, 3))
	_place_unit(scene.board, defender, Vector2i(8, 2))
	shooter.set_cover_stance(true, false)
	exposed_operative.set_cover_stance(false, false)
	defender.role_id = "railhand"
	scene.turn.units.assign([shooter, exposed_operative, defender])
	if scene.turn._nearest_player(defender) != exposed_operative:
		_fail("A standard guard ignored an equally close exposed target in favor of the ducked operative.")
		return

	# Put one target and one guard on a controlled lane. Distinct combat roles must
	# now value measurably different destinations from identical starting state.
	shooter.set_cover_stance(false, false)
	_place_unit(scene.board, shooter, Vector2i(2, 2))
	_place_unit(scene.board, defender, Vector2i(14, 2))
	scene.turn.units.assign([shooter, defender])
	defender.base_movement = 5
	defender.attack_range = 9
	defender.role_id = "marksman"
	var marksman_destination: Vector2i = scene.turn._best_enemy_destination(defender, shooter)
	defender.attack_range = 5
	defender.role_id = "bruiser"
	var bruiser_destination: Vector2i = scene.turn._best_enemy_destination(defender, shooter)
	var marksman_distance: int = scene.board.grid_distance(marksman_destination, shooter.grid_cell)
	var bruiser_distance: int = scene.board.grid_distance(bruiser_destination, shooter.grid_cell)
	if marksman_destination == bruiser_destination or marksman_distance <= bruiser_distance:
		_fail("Marksman and Bruiser still chose the same rush pattern from identical state.")
		return

	# A guard too far away to shoot receives one move, then braces. It must not
	# spend both AP repeating the same move-to-player action.
	_place_unit(scene.board, shooter, Vector2i(1, 2))
	_place_unit(scene.board, defender, Vector2i(16, 2))
	shooter.begin_turn()
	defender.begin_turn()
	defender.role_id = "railhand"
	defender.attack_range = 4
	defender.base_movement = 4
	scene.turn.encounter_active = true
	scene.turn.encounter_mode = "eliminate"
	scene.turn.phase = Types.Phase.PLAYER
	await scene.turn.end_player_turn()
	if int(scene.turn.encounter_stats.get("ai_moves", 0)) != 1:
		_fail("The controlled guard did not limit itself to one intentional reposition.")
		return
	if int(scene.turn.encounter_stats.get("ai_cover_actions", 0)) != 1 or not defender.crouched:
		_fail("A guard without a shot failed to brace after occupying its firing position.")
		return

	print("BRASSLINE ENEMY TACTICS SMOKE: PASS - contextual cover, player ducking, role-specific destinations, and move-then-brace AI verified.")
	quit(0)


func _find_covered_shot(board: GridBoard, attack_range: int) -> Dictionary:
	for defender_y in range(GridBoard.BOARD_SIZE.y):
		for defender_x in range(GridBoard.BOARD_SIZE.x):
			var defender := Vector2i(defender_x, defender_y)
			if board.blocked_cells.has(defender) or not board.has_adjacent_cover(defender):
				continue
			for attacker_y in range(GridBoard.BOARD_SIZE.y):
				for attacker_x in range(GridBoard.BOARD_SIZE.x):
					var attacker := Vector2i(attacker_x, attacker_y)
					if board.blocked_cells.has(attacker) or attacker == defender:
						continue
					if board.grid_distance(attacker, defender) > attack_range:
						continue
					if board.has_line_of_sight(attacker, defender) and board.cover_level(attacker, defender) > 0:
						return {"attacker": attacker, "defender": defender}
	return {}


func _place_unit(board: GridBoard, unit: TacticalUnit, cell: Vector2i) -> void:
	unit.grid_cell = cell
	unit.position = board.cell_to_world(cell) + Vector3(0.0, 0.06, 0.0)


func _fail(message: String) -> void:
	push_error("BRASSLINE ENEMY TACTICS SMOKE: FAIL - %s" % message)
	quit(1)
