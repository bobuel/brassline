extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")

const ROSTERS: Array[Array] = [
	["ada", "marlow", "nix"],
	["iona", "silas", "rook"],
	["ada", "iona", "silas"],
	["marlow", "nix", "rook"],
]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	for roster_variant in ROSTERS:
		var roster: Array[String] = []
		roster.assign(roster_variant)
		await scene._on_crew_confirmed(roster, 95000 + ROSTERS.find(roster_variant))
		var plans: Array[Dictionary] = scene.autobattle_ui.plans
		if plans.size() < 3 or plans.size() > 4:
			_fail("Roster %s received %d plans instead of 3-4." % [str(roster), plans.size()])
			return
		var has_safe := false
		for plan in plans:
			has_safe = has_safe or bool(plan.get("safe", false))
			var orders: Dictionary = plan.get("orders", {})
			if orders.size() != 3:
				_fail("Roster %s received an incompletely bound plan." % str(roster))
				return
			if "{" in String(plan.get("summary", "")) or "{" in String(plan.get("risk", "")):
				_fail("A materialized plan leaked an unbound prose placeholder.")
				return
			if int(plan.get("confidence_rank", -1)) < 0 or int(plan.get("confidence_rank", -1)) > 3:
				_fail("Plan confidence fell outside its authored range.")
				return
		if not has_safe:
			_fail("Roster %s had no conservative plan option." % str(roster))
			return

	# Injury compatibility must affect the preview rather than being ignored.
	var canonical: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(canonical, 95100)
	var ada: TacticalUnit
	for unit in scene.turn.player_units(true):
		if unit.roster_id == "ada": ada = unit
	var before := PlanCatalog.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {})
	var before_confidence := _confidence_for(before, "break_the_hands")
	ada.apply_damage(Types.BodyZone.ARMS, 999)
	var after := PlanCatalog.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {})
	var after_confidence := _confidence_for(after, "break_the_hands")
	if before_confidence < 0 or after_confidence >= before_confidence:
		_fail("Crippled shooting arms did not lower the called-shot plan's confidence.")
		return
	var lone_crew: Array[TacticalUnit] = [scene.turn.player_units(true)[0]]
	var casualty_plans := PlanCatalog.generate_plans("baggage", lone_crew, scene.turn.enemy_units(true), scene.turn, {})
	if casualty_plans.size() < 3:
		_fail("A lone surviving operative did not receive a reduced-confidence plan set.")
		return
	for plan in casualty_plans:
		if "{" in String(plan.get("summary", "")):
			_fail("Casualty plan prose retained an unfilled assignment placeholder.")
			return

	print("BRASSLINE AUTOBATTLER PLAN PERMUTATIONS: PASS - four rosters, casualty folding, safe-option guarantee, prose binding, confidence bounds, and injury compatibility verified.")
	quit(0)


func _confidence_for(plans: Array[Dictionary], plan_id: String) -> int:
	for plan in plans:
		if String(plan.get("id", "")) == plan_id:
			return int(plan.get("confidence_rank", -1))
	return -1


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER PLAN PERMUTATIONS: FAIL - %s" % message)
	quit(1)
