extends SceneTree

const ASSET_DIRECTORIES := [
	"res://assets/environment/kenney/train",
	"res://assets/environment/kenney/factory",
	"res://assets/environment/kenney/industrial",
]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var asset_count := 0
	for directory_path in ASSET_DIRECTORIES:
		for file_name in DirAccess.get_files_at(directory_path):
			if not file_name.ends_with(".glb"):
				continue
			asset_count += 1
			var path: String = String(directory_path).path_join(String(file_name))
			var packed := load(path) as PackedScene
			if packed == null:
				_fail("Could not load %s" % path)
				return
			var instance := packed.instantiate()
			if instance.find_children("*", "MeshInstance3D", true, false).is_empty():
				_fail("%s contains no visible mesh." % path)
				return
			if not _has_palette_texture(instance):
				_fail("%s is missing its Kenney palette texture." % path)
				return
			instance.free()

	if asset_count != 38:
		_fail("Expected 38 selected environment models, found %d." % asset_count)
		return

	var scene: Node = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(4):
		await process_frame

	var board := scene.get_node_or_null("ClockworkExpress") as GridBoard
	var art: Node = scene.get_node_or_null("ClockworkExpress/ModularTrainArt")
	if board == null or art == null:
		_fail("The modular train presentation was not assembled into the main scene.")
		return
	var active_root := art.get_node_or_null("ActiveRunCarDressing")
	if active_root == null or active_root.get_node_or_null("ActiveCarUnderframe") == null:
		_fail("The finished scene is missing its single active rolling-stock set.")
		return
	if active_root.get_node_or_null("ActiveCarSign") == null or active_root.find_children("PassengerWindow*", "MeshInstance3D", true, false).size() < 7:
		_fail("The active carriage is missing its identity sign or complete window run.")
		return
	for legacy_name in ["CrewCarUnderframe", "WorkshopUnderframe", "VaultUnderframe", "ClockworkLocomotive"]:
		if art.find_child(legacy_name, true, false) != null:
			_fail("Adjacent legacy rolling stock is still present: %s." % legacy_name)
			return
	if board.is_walkable(Vector2i(2, 0)):
		_fail("Replacing graybox cover changed the tactical blocker map.")
		return
	for mesh in board.cover_visuals[Vector2i(2, 0)]:
		if mesh.visible:
			_fail("A procedural cover mesh is still visible beneath modular art.")
			return

	print("BRASSLINE ENVIRONMENT ASSET SMOKE: PASS - 38 CC0 models, textured kits, one active windowed carriage, and blocker masking verified.")
	quit(0)


func _has_palette_texture(instance: Node) -> bool:
	for child in instance.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		for surface in range(mesh_instance.mesh.get_surface_count()):
			var material := mesh_instance.mesh.surface_get_material(surface) as BaseMaterial3D
			if material != null and material.albedo_texture != null:
				return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE ENVIRONMENT ASSET SMOKE: FAIL - %s" % message)
	quit(1)
