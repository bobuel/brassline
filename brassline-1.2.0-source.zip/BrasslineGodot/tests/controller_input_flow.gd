extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	await _frames(10)
	scene._heist_started = false
	scene.ui.set_hud_visible(false)
	scene.campaign_ui.show_intro()
	await _frames(4)
	await _joy(JOY_BUTTON_A)
	if not _require(is_instance_valid(scene.campaign_ui.selection_preview_stage), "A did not activate Start Heist"): return
	var crew_focus := root.gui_get_focus_owner()
	await _joy(JOY_BUTTON_DPAD_RIGHT)
	if not _require(root.gui_get_focus_owner() != crew_focus, "D-pad did not move crew focus"): return
	await _joy(JOY_BUTTON_A)
	if not _require(scene.campaign_ui.selected_crew_ids == ["ada", "marlow", "nix"], "Inspecting a portrait changed the selected crew"): return
	scene.campaign_ui.confirm_button.grab_focus()
	await _joy(JOY_BUTTON_A)
	await _frames(12)
	var ui: AutobattleUI = scene.autobattle_ui
	if not _require(ui.planning_root.visible and not ui.plans.is_empty(), "A did not board into planning"): return
	ui.plan_buttons[0].grab_focus()
	await _joy(JOY_BUTTON_DPAD_RIGHT)
	var plan_focus := root.gui_get_focus_owner()
	if not _require(plan_focus != ui.plan_buttons[0], "D-pad did not move plan focus"): return
	await _joy(JOY_BUTTON_A)
	await _joy(JOY_BUTTON_Y)
	if not _require(ui.inspector_panel.visible, "Y did not open the Ledger"): return
	var ledger_focus := root.gui_get_focus_owner()
	await _joy(JOY_BUTTON_DPAD_DOWN)
	if not _require(root.gui_get_focus_owner() != ledger_focus, "D-pad did not navigate Ledger crew"): return
	await _joy(JOY_BUTTON_A)
	await _joy(JOY_BUTTON_B)
	if not _require(not ui.inspector_panel.visible and root.gui_get_focus_owner() == plan_focus, "B did not close Ledger and restore plan focus"): return
	ui.fallback_button.grab_focus()
	await _joy(JOY_BUTTON_A)
	if not _require(ui.fallback_picker.visible, "A did not open fallback choices"): return
	await _joy(JOY_BUTTON_DPAD_DOWN)
	await _joy(JOY_BUTTON_A)
	if not _require(not ui.fallback_picker.visible, "Fallback selection did not close its picker"): return
	ui.confirm_button.grab_focus()
	await _joy(JOY_BUTTON_A)
	await _joy(JOY_BUTTON_Y)
	if not _require(scene.autobattle_director.inspection_paused, "Y did not pause combat for inspection"): return
	await _joy(JOY_BUTTON_B)
	if not _require(not scene.autobattle_director.inspection_paused, "B did not release the inspection pause"): return
	scene.autobattle_director.stop()
	print("BRASSLINE CONTROLLER INPUT FLOW: PASS - injected A/D-pad/Y/B inputs navigate title, crew, plans, Ledger and fallback picker; focus and pause restore.")
	quit(0)

func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.device = 0
	event.button_index = button
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = InputEventJoypadButton.new()
	event.device = 0
	event.button_index = button
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(2)

func _frames(count: int) -> void:
	for frame in range(count): await process_frame

func _require(condition: bool, message: String) -> bool:
	if not condition:
		push_error("BRASSLINE CONTROLLER INPUT FLOW: FAIL - " + message)
		quit(1)
	return condition
