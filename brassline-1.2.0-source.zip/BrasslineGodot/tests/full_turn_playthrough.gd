extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const PLAYTEST_ROSTERS: Array[Array] = [
	["ada", "marlow", "nix"],
	["iona", "silas", "rook"],
	["ada", "iona", "silas"],
]

var shots_fired := 0
var moves_made := 0
var turns_ended := 0
var grenades_used := 0
var tonics_used := 0
var medkits_used := 0
var braces_used := 0
var reloads_used := 0
var overwatches_used := 0
var abilities_used := 0
var cover_actions_used := 0


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var seed := int(_argument_value("play-seed", "91001"))
	var strategy := int(_argument_value("play-strategy", "0"))
	var roster_index := posmod(int(_argument_value("play-roster", "0")), PLAYTEST_ROSTERS.size())
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	scene._save_path = "user://brassline_full_turn_%d_test.json" % seed
	scene._automation_mode = false
	scene._clear_run_checkpoint()
	var crew_ids: Array[String] = []
	crew_ids.assign(PLAYTEST_ROSTERS[roster_index])
	await scene._on_crew_confirmed(crew_ids, seed)
	var saved_seed: int = scene.run_state.run_seed
	scene.run_state = null
	await scene._on_continue_requested()
	if scene.run_state == null or scene.run_state.run_seed != saved_seed:
		_fail("Continue Run failed before the turn-by-turn playthrough began.")
		return

	var route_trace: Array[String] = []
	var safety_transitions := 0
	while scene.run_state.phase != "complete" and safety_transitions < 20:
		safety_transitions += 1
		if scene.run_state.phase == "encounter":
			var car_data: Dictionary = scene.run_state.car_data(scene.run_state.current_car_id)
			if String(car_data.get("kind", "combat")) == "event":
				scene._on_event_choice_requested("rest" if strategy % 2 == 0 else "scavenge")
			else:
				var combat_result: Dictionary = await _autoplay_combat(scene)
				print("PLAYTEST CAR / %s / rounds=%d / survivors=%d" % [
					String(combat_result.get("car_id", scene.run_state.current_car_id)),
					int(combat_result.get("rounds", 0)),
					scene.turn.player_units(true).size(),
				])
				if not bool(combat_result.get("victory", false)):
					_fail("Combat failed in %s after %d rounds with %d crew alive, %d guards alive, turn phase %d, encounter_active=%s, safety=%d." % [
						scene.run_state.current_car_id,
						int(combat_result.get("rounds", 0)),
						scene.turn.player_units(true).size(),
						int(combat_result.get("enemies", -1)),
						int(combat_result.get("turn_phase", -1)),
						str(combat_result.get("encounter_active", false)),
						int(combat_result.get("safety", -1)),
					])
					print("PLAYTEST FAILURE TELEMETRY / player_cover=%d / ai=%s" % [cover_actions_used, str(scene.turn.encounter_stats)])
					print("PLAYTEST FAILURE LOG / %s" % str(scene.ui._log_lines))
					for unit in scene.turn.units:
						if is_instance_valid(unit) and unit.team == Types.Team.PLAYER:
							print("PLAYTEST FAILURE CREW / %s / alive=%s / body=%s" % [unit.display_name, str(unit.is_alive), str(unit.body_state)])
					return
			for _frame in range(4):
				await process_frame
		elif scene.run_state.phase == "intermission":
			if scene.run_state.has_pending_crew_scene():
				var council_choices: Array = scene.run_state.crew_scene_data().get("choices", [])
				var council_choice := String(Dictionary(council_choices[posmod(strategy, council_choices.size())]).get("id", ""))
				scene._on_crew_scene_choice_requested(council_choice)
				await process_frame
				continue
			if scene.run_state.current_offers.is_empty() or scene.run_state.current_offers.size() > 3:
				_fail("The turn-by-turn run reached an invalid route table.")
				return
			var offer_count: int = scene.run_state.current_offers.size()
			var choice_index := 0
			match posmod(strategy, 3):
				1:
					choice_index = offer_count - 1
				2:
					choice_index = posmod(scene.run_state.completed_car_ids.size(), offer_count)
			var choice: String = scene.run_state.current_offers[choice_index]
			route_trace.append(choice)
			scene._on_crew_review_requested(choice)
			for _frame in range(2):
				await process_frame
			if scene.run_state.phase != "preparation" or scene.campaign_ui.crew_preview_stage == null or scene.campaign_ui.crew_preview_stage.visual_nodes.size() != 3:
				_fail("The real campaign did not enter its staged three-model crew-prep step.")
				return
			_manage_wounds(scene)
			print("PLAYTEST PREP / target=%s / completed=%s / health=%s / inventory=%s" % [
				choice,
				",".join(PackedStringArray(scene.run_state.completed_car_ids)),
				_crew_health_summary(scene),
				str(scene.run_state.inventory),
			])
			await scene._on_next_car_chosen(choice)
			for _frame in range(3):
				await process_frame
		else:
			_fail("The turn-by-turn run stalled in phase %s." % scene.run_state.phase)
			return

	if scene.run_state.phase != "complete" or scene.run_state.completed_car_ids.size() != 7:
		_fail("Turn-by-turn play did not complete all seven cars.")
		return
	for required_id in scene.run_state.REQUIRED_CAR_IDS:
		if required_id not in scene.run_state.completed_car_ids:
			_fail("Turn-by-turn play omitted required car %s." % required_id)
			return
	if FileAccess.file_exists(scene._save_path):
		_fail("Victory left the isolated playthrough checkpoint behind.")
		return
	if shots_fired < 7 or turns_ended < 1 or moves_made < 1 or reloads_used < 1 or abilities_used < 1 or overwatches_used < 1 or cover_actions_used < 1:
		_fail("Turn-by-turn play did not exercise enough real combat actions: shots=%d moves=%d turns=%d reloads=%d overwatches=%d abilities=%d cover=%d." % [shots_fired, moves_made, turns_ended, reloads_used, overwatches_used, abilities_used, cover_actions_used])
		return
	if int(scene.run_state.run_stats.get("cars_cleared", 0)) != 7 or int(scene.run_state.run_stats.get("train_seized", 0)) != 1 or int(scene.run_state.run_stats.get("control_claims", 0)) < 1:
		_fail("The completed playthrough did not record all cars and the final train takeover.")
		return
	if int(scene.run_state.run_stats.get("overwatch_shots", 0)) < 1:
		_fail("The completed playthrough armed Overwatch but never resolved a reaction shot.")
		return

	print("BRASSLINE FULL TURN PLAYTHROUGH: PASS - seed=%d strategy=%d crew=%s route=%s shots=%d moves=%d enemy_turns=%d reloads=%d overwatches=%d cover=%d abilities=%d tonics=%d grenades=%d medkits=%d braces=%d survivors=%d" % [
		seed,
		strategy,
		",".join(PackedStringArray(crew_ids)),
		" > ".join(PackedStringArray(route_trace)),
		shots_fired,
		moves_made,
		turns_ended,
		reloads_used,
		overwatches_used,
		cover_actions_used,
		abilities_used,
		tonics_used,
		grenades_used,
		medkits_used,
		braces_used,
		scene.turn.player_units(true).size(),
	])
	quit(0)


func _autoplay_combat(scene: Node) -> Dictionary:
	var starting_car: String = scene.run_state.current_car_id
	var starting_round: int = scene.turn.round_number
	var safety_actions := 0
	while scene.run_state.phase == "encounter" and scene.turn.encounter_active and safety_actions < 240:
		safety_actions += 1
		if scene.turn.phase == Types.Phase.PLAYER:
			await _play_player_phase(scene)
		elif scene.turn.phase in [Types.Phase.ENEMY, Types.Phase.BUSY]:
			await create_timer(0.05).timeout
		elif scene.turn.phase == Types.Phase.DEFEAT:
			return {
				"victory": false,
				"rounds": scene.turn.round_number - starting_round + 1,
				"car_id": starting_car,
				"enemies": scene.turn.enemy_units(true).size(),
				"turn_phase": scene.turn.phase,
				"encounter_active": scene.turn.encounter_active,
				"safety": safety_actions,
			}
		else:
			await process_frame
	var completed: bool = scene.run_state.phase != "encounter" or scene.run_state.current_car_id != starting_car
	return {
		"victory": completed,
		"rounds": scene.turn.round_number - starting_round + 1,
		"car_id": starting_car,
		"enemies": scene.turn.enemy_units(true).size(),
		"turn_phase": scene.turn.phase,
		"encounter_active": scene.turn.encounter_active,
		"safety": safety_actions,
	}


func _play_player_phase(scene: Node) -> void:
	if scene.turn.encounter_mode == "finale" and scene.turn.enemy_units(true).is_empty():
		await _advance_finale_carrier(scene)
		if scene.run_state.phase != "encounter":
			return
	if int(scene.turn.encounter_stats.get("overwatch_shots", 0)) + int(scene.run_state.run_stats.get("overwatch_shots", 0)) == 0:
		for watcher in scene.turn.player_units(true):
			var covers_a_guard := false
			for guard in scene.turn.enemy_units(true):
				covers_a_guard = covers_a_guard or scene.turn.can_attack(watcher, guard)
			if not covers_a_guard:
				continue
			scene.turn.select_unit(watcher)
			if scene.turn.try_overwatch():
				overwatches_used += 1
				break

	if int(scene.run_state.inventory.get("clockwork_grenade", 0)) > 0:
		var grenade_pair: Array = await _find_or_create_grenade_pair(scene)
		if not grenade_pair.is_empty() and scene.turn.phase == Types.Phase.PLAYER:
			var before := int(scene.run_state.inventory["clockwork_grenade"])
			await scene._on_grenade_requested()
			if int(scene.run_state.inventory["clockwork_grenade"]) == before - 1:
				grenades_used += 1
			if scene.run_state.phase != "encounter":
				return

	var crew: Array = scene.turn.player_units(true).duplicate()
	for shooter in crew:
		if shooter.overwatch_active:
			continue
		var fired_this_turn := false
		while shooter.is_alive and shooter.action_points > 0 and scene.turn.phase == Types.Phase.PLAYER:
			scene.turn.select_unit(shooter)
			# Once an operative has fired from physical cover, preserve the last AP
			# for defense. This mirrors the intended shoot-and-duck player tactic and
			# keeps the full playthrough honest about the new combat economy.
			var finishing_target: TacticalUnit = _best_attackable_target(scene, shooter)
			var can_finish := is_instance_valid(finishing_target) and int(finishing_target.body_state[Types.BodyZone.TORSO]["hp"]) <= roundi(shooter.base_damage * shooter.damage_multiplier())
			if fired_this_turn and not can_finish and shooter.action_points == 1 and shooter.is_in_physical_cover():
				if scene.turn.try_take_cover():
					cover_actions_used += 1
					break
			if not shooter.ability_used and scene.turn.try_signature_ability():
				abilities_used += 1
			if shooter.uses_ammunition and shooter.ammunition <= 0:
				if scene.turn.try_reload():
					reloads_used += 1
					continue
				break
			var target: TacticalUnit = _best_attackable_target(scene, shooter)
			if is_instance_valid(target):
				scene.turn.set_target(target)
				var zone := Types.BodyZone.TORSO
				if shooter.action_points >= 2 and int(target.body_state[Types.BodyZone.HEAD]["hp"]) <= roundi(shooter.base_damage * shooter.damage_multiplier() * float(Types.BODY_ZONE_DAMAGE_MULTIPLIER[Types.BodyZone.HEAD])) and scene.turn.attack_chance(shooter, target, Types.BodyZone.HEAD) >= 0.65:
					zone = Types.BodyZone.HEAD
				scene.turn.set_target_zone(zone)
				if int(scene.run_state.inventory.get("focus_tonic", 0)) > 0 and not shooter.is_focused():
					var before := int(scene.run_state.inventory["focus_tonic"])
					scene._on_tonic_requested()
					if int(scene.run_state.inventory["focus_tonic"]) == before - 1:
						tonics_used += 1
				await scene.turn.try_attack(target)
				shots_fired += 1
				fired_this_turn = true
			else:
				var destination: Vector2i = _best_advance_cell(scene, shooter)
				if destination == shooter.grid_cell:
					if scene.turn.try_overwatch():
						overwatches_used += 1
					break
				await scene.turn.try_move(destination)
				moves_made += 1
			if scene.run_state.phase != "encounter":
				return

	if scene.run_state.phase == "encounter" and scene.turn.phase == Types.Phase.PLAYER:
		turns_ended += 1
		await scene.turn.end_player_turn()


func _advance_finale_carrier(scene: Node) -> void:
	var carrier: TacticalUnit
	for operative in scene.turn.player_units(true):
		if operative.carries_objective:
			carrier = operative
			break
	if not is_instance_valid(carrier):
		var survivors: Array[TacticalUnit] = scene.turn.player_units(true)
		if survivors.is_empty():
			return
		carrier = survivors[0]
	scene.turn.select_unit(carrier)
	while carrier.action_points > 0 and scene.turn.phase == Types.Phase.PLAYER and scene.run_state.phase == "encounter":
		var goal: Vector2i = scene.board.extraction_cell if carrier.carries_objective else scene.board.objective_cell
		if carrier.grid_cell == goal:
			scene.turn._resolve_cell_effects(carrier)
			if scene.run_state.phase != "encounter":
				return
			continue
		var destination := _best_reachable_toward(scene, carrier, goal)
		if destination == carrier.grid_cell:
			await _move_finale_blocker(scene, carrier, goal)
			break
		await scene.turn.try_move(destination)
		moves_made += 1


func _move_finale_blocker(scene: Node, carrier: TacticalUnit, goal: Vector2i) -> bool:
	var ideal_path: Array[Vector2i] = scene.board.find_path(carrier.grid_cell, goal, {}, 999)
	if ideal_path.size() <= 1:
		return false
	var blocker: TacticalUnit
	for path_cell in ideal_path:
		for operative in scene.turn.player_units(true):
			if operative != carrier and operative.grid_cell == path_cell:
				blocker = operative
				break
		if is_instance_valid(blocker):
			break
	if not is_instance_valid(blocker) or blocker.action_points < 1:
		return false
	var reachable: Dictionary = scene.board.get_reachable(
		blocker.grid_cell,
		blocker.movement_range(),
		scene.turn.occupied_cells(blocker)
	)
	var destination := blocker.grid_cell
	for cell_value in reachable:
		var cell: Vector2i = cell_value
		if cell == blocker.grid_cell or cell in ideal_path or scene.board.hazard_cells.has(cell):
			continue
		destination = cell
		break
	if destination == blocker.grid_cell:
		return false
	scene.turn.select_unit(blocker)
	await scene.turn.try_move(destination)
	moves_made += 1
	return true


func _best_reachable_toward(scene: Node, unit: TacticalUnit, goal: Vector2i) -> Vector2i:
	var full_path: Array[Vector2i] = scene.board.find_path(
		unit.grid_cell,
		goal,
		scene.turn.occupied_cells(unit),
		999
	)
	if full_path.size() <= 1:
		return unit.grid_cell
	var step_index := mini(unit.movement_range(), full_path.size() - 1)
	return full_path[step_index]


func _best_attackable_target(scene: Node, shooter: TacticalUnit) -> TacticalUnit:
	var best: TacticalUnit
	var best_hp := 1_000_000
	for target in scene.turn.enemy_units(true):
		if not scene.turn.can_attack(shooter, target):
			continue
		var torso_hp := int(target.body_state[Types.BodyZone.TORSO]["hp"])
		if torso_hp < best_hp:
			best_hp = torso_hp
			best = target
	return best


func _best_advance_cell(scene: Node, shooter: TacticalUnit) -> Vector2i:
	var reachable: Dictionary = scene.board.get_reachable(
		shooter.grid_cell,
		shooter.movement_range(),
		scene.turn.occupied_cells(shooter)
	)
	var best_cell: Vector2i = shooter.grid_cell
	var best_score := 1_000_000.0
	for cell_value in reachable:
		var cell: Vector2i = cell_value
		if cell == shooter.grid_cell:
			continue
		var nearest := 1_000_000
		var firing_position := false
		var defensive_cover := 0.0
		for target in scene.turn.enemy_units(true):
			var distance: int = scene.board.grid_distance(cell, target.grid_cell)
			nearest = mini(nearest, distance)
			if distance <= shooter.attack_range and scene.board.has_line_of_sight(cell, target.grid_cell):
				firing_position = true
			defensive_cover = maxf(defensive_cover, scene.board.cover_penalty(target.grid_cell, cell))
		var score := float(nearest)
		if firing_position:
			# Stay at the longest clean range available instead of charging to
			# point-blank distance merely because it is technically shootable.
			score = -20.0 - float(nearest) * 0.5
		score -= defensive_cover * 8.0
		if scene.board.hazard_cells.has(cell):
			score += 6.0
		if score < best_score:
			best_score = score
			best_cell = cell
	return best_cell


func _find_or_create_grenade_pair(scene: Node) -> Array:
	for shooter in scene.turn.player_units(true):
		scene.turn.select_unit(shooter)
		for target in scene.turn.enemy_units(true):
			scene.turn.set_target(target)
			if scene.turn.can_use_grenade(target):
				return [shooter, target]
	for shooter in scene.turn.player_units(true):
		if shooter.action_points < 2:
			continue
		var reachable: Dictionary = scene.board.get_reachable(
			shooter.grid_cell,
			shooter.movement_range(),
			scene.turn.occupied_cells(shooter)
		)
		for target in scene.turn.enemy_units(true):
			var destination: Vector2i = shooter.grid_cell
			var best_distance := -1
			for cell_value in reachable:
				var cell: Vector2i = cell_value
				var distance: int = scene.board.grid_distance(cell, target.grid_cell)
				if distance <= 6 and distance > 1 and distance > best_distance and cell != shooter.grid_cell and not scene.board.hazard_cells.has(cell):
					best_distance = distance
					destination = cell
			if destination == shooter.grid_cell:
				continue
			scene.turn.select_unit(shooter)
			await scene.turn.try_move(destination)
			moves_made += 1
			if scene.turn.phase != Types.Phase.PLAYER:
				return []
			scene.turn.set_target(target)
			if scene.turn.can_use_grenade(target):
				return [shooter, target]
	return []


func _manage_wounds(scene: Node) -> void:
	for crew_id in scene.run_state.selected_crew_ids:
		if scene.run_state.crew_is_down(crew_id):
			continue
		while int(scene.run_state.inventory.get("medkit", 0)) > 0 and _needs_medkit(scene.run_state.body_state_for(crew_id)):
			var before := int(scene.run_state.inventory["medkit"])
			scene._on_item_requested("medkit", crew_id)
			if int(scene.run_state.inventory["medkit"]) == before:
				break
			medkits_used += 1
		if int(scene.run_state.inventory.get("limb_brace", 0)) > 0 and _has_wounded_limb(scene.run_state.body_state_for(crew_id)):
			var before := int(scene.run_state.inventory["limb_brace"])
			scene._on_item_requested("limb_brace", crew_id)
			if int(scene.run_state.inventory["limb_brace"]) == before - 1:
				braces_used += 1


func _has_wounded_limb(body: Dictionary) -> bool:
	for zone in [Types.BodyZone.ARMS, Types.BodyZone.LEGS]:
		var state: Dictionary = body[zone]
		if not bool(state.get("detached", false)) and int(state["hp"]) < int(state["max_hp"]):
			return true
	return false


func _crew_health_summary(scene: Node) -> String:
	var entries: Array[String] = []
	for crew_id in scene.run_state.selected_crew_ids:
		if scene.run_state.crew_is_down(crew_id):
			entries.append("%s:DOWN" % crew_id)
		else:
			entries.append("%s:%d%%" % [crew_id, roundi(scene.run_state.crew_health_ratio(crew_id) * 100.0)])
	return " ".join(PackedStringArray(entries))


func _needs_medkit(body: Dictionary) -> bool:
	for zone in [Types.BodyZone.HEAD, Types.BodyZone.TORSO]:
		var state: Dictionary = body[zone]
		if float(state["hp"]) / maxf(1.0, float(state["max_hp"])) < 0.75:
			return true
	var hp_total := 0.0
	var max_total := 0.0
	for zone in body:
		hp_total += float(body[zone]["hp"])
		max_total += float(body[zone]["max_hp"])
	return hp_total / maxf(1.0, max_total) < 0.88


func _argument_value(key: String, fallback: String) -> String:
	var prefix := "--%s=" % key
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with(prefix):
			return argument.trim_prefix(prefix)
	return fallback


func _fail(message: String) -> void:
	push_error("BRASSLINE FULL TURN PLAYTHROUGH: FAIL - %s" % message)
	quit(1)
