extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")
const DirectorScript := preload("res://scripts/autobattle_director.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	for car_id in RunState.CAR_CATALOG:
		_assert_budget("%s tagline" % car_id, String(RunState.CAR_CATALOG[car_id].get("tagline", "")), 16)
	for raw_template in PlanCatalog.PLAN_TEMPLATES:
		var template := Dictionary(raw_template)
		_assert_budget("%s title" % String(template.get("id", "plan")), String(template.get("title", "")), 4)
	for plan_id in PlanCatalog.PLAN_SHORT_SUMMARIES:
		_assert_budget("%s summary" % plan_id, String(PlanCatalog.PLAN_SHORT_SUMMARIES[plan_id]), 14)
	for fallback in PlanCatalog.FALLBACKS:
		_assert_budget("fallback", String(Dictionary(fallback).get("short_description", "")), 10)
	var run := RunState.new()
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	run.start_new_run(crew_ids, 46001)
	for scene_id in ["first_cost", "train_answers", "before_redline"]:
		run.pending_crew_scene_id = scene_id
		var scene := run.crew_scene_data()
		_assert_budget("%s council" % scene_id, String(scene.get("prompt", "")), 20)
		for raw_choice in Array(scene.get("choices", [])):
			var choice := Dictionary(raw_choice)
			_assert_budget("council effect", String(choice.get("effect_short", "")), 8)
			_assert_budget("council risk", String(choice.get("risk_short", "")), 8)
	var director: AutobattleDirector = DirectorScript.new()
	for beat_type in ["signature_move", "item", "environment", "cripple", "plan_break", "casualty", "surrender", "victory", "defeat"]:
		_assert_budget("%s bark" % beat_type, director._bark_for_beat(beat_type, null, null, {}), 7)
	var epilogue := run.campaign_epilogue()
	_assert_budget("epilogue thesis", String(epilogue.get("short_thesis", "")), 24)
	print("BRASSLINE CONVERGENCE COPY: PASS - car, plan, council, fallback, bark, and epilogue budgets verified.")
	quit(0)


func _assert_budget(label: String, value: String, budget: int) -> void:
	if value.strip_edges().is_empty() or value.split(" ", false).size() > budget:
		_fail("%s exceeds %d words: %s" % [label, budget, value])


func _fail(message: String) -> void:
	push_error("BRASSLINE CONVERGENCE COPY: FAIL - %s" % message)
	quit(1)
