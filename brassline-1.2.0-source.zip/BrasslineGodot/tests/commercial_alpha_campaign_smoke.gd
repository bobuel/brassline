extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var crew_ids: Array[String] = ["ada", "iona", "rook"]
	var run := RunState.new()
	run.start_new_run(crew_ids, 45012, "story")
	if run.difficulty_id != "story" or run.difficulty_label() != "STORY":
		_fail("A selected difficulty was not stored on the run.")
		return
	# Exercise the two-choice Sleeper event without depending on random offers.
	var body: Dictionary = run.crew_states["ada"]["body"]
	body[Types.BodyZone.ARMS]["hp"] = maxi(1, int(body[Types.BodyZone.ARMS]["hp"]) - 5)
	run.crew_states["ada"]["body"] = body
	run.current_car_id = "sleeper"
	run.phase = "encounter"
	var choice: Dictionary = run.resolve_event_choice("scavenge")
	if not bool(choice.get("ok", false)) or run.pending_event_choice != "scavenge":
		_fail("The Sleeper Car scavenge choice was not accepted.")
		return
	var hp_before := int(body[Types.BodyZone.ARMS]["hp"])
	var completion: Dictionary = run.complete_current_car()
	if not bool(completion.get("ok", false)):
		_fail("The chosen Sleeper event did not complete.")
		return
	if int(run.inventory.get("medkit", 0)) != 2 or int(run.inventory.get("focus_tonic", 0)) != 1:
		_fail("The scavenge choice did not award its advertised supplies.")
		return
	if int(run.last_recovery.get("total", 0)) != 1:
		_fail("The Sleeper transition did not record its separate automatic field-triage point.")
		return
	if int(run.body_state_for("ada")[Types.BodyZone.ARMS]["hp"]) != hp_before + 3:
		_fail("Automatic triage plus the scavenge reward did not apply their advertised healing.")
		return

	run.add_encounter_stats({"shots": 9, "hits": 6, "kills": 3, "reloads": 2, "abilities": 2, "rounds": 4})
	run.record_item_use()
	if int(run.run_stats.get("cars_cleared", 0)) != 1 or int(run.run_stats.get("shots", 0)) != 9 or int(run.run_stats.get("items_used", 0)) != 1:
		_fail("Run telemetry did not accumulate event, combat, and supply activity.")
		return
	var restored := RunState.new()
	if not restored.load_from_save_data(run.to_save_data()):
		_fail("The version-three commercial-alpha checkpoint could not be loaded.")
		return
	if restored.difficulty_id != "story" or int(restored.run_stats.get("hits", 0)) != 6:
		_fail("Difficulty or run telemetry was lost across checkpoint serialization.")
		return

	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame
	scene.campaign_ui.selected_difficulty = "brutal"
	await scene._on_crew_confirmed(crew_ids, 45013)
	if scene.run_state.difficulty_id != "brutal":
		_fail("The front-end difficulty selection was not passed into a new run.")
		return
	if scene._difficulty_enemy_count_bonus() != 1 or not is_equal_approx(scene._difficulty_enemy_damage_multiplier(), 1.18):
		_fail("Brutal mode did not activate its documented enemy modifiers.")
		return

	print("BRASSLINE COMMERCIAL-ALPHA CAMPAIGN SMOKE: PASS - difficulty, event choice, telemetry, and checkpoint persistence verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE COMMERCIAL-ALPHA CAMPAIGN SMOKE: FAIL - %s" % message)
	quit(1)
