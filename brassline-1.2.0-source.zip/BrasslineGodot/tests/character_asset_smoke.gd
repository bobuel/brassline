extends SceneTree

const CHARACTER_PATHS := [
	"res://assets/characters/quaternius/Adventurer.gltf",
	"res://assets/characters/quaternius/Casual_2.gltf",
	"res://assets/characters/quaternius/Punk.gltf",
	"res://assets/characters/quaternius/Suit.gltf",
	"res://assets/characters/quaternius/Swat.gltf",
	"res://assets/characters/quaternius/Worker.gltf",
]

const REQUIRED_ANIMATIONS := ["Idle_Gun", "Run", "Idle_Gun_Shoot", "HitRecieve", "Death"]


func _initialize() -> void:
	for path in CHARACTER_PATHS:
		var packed := load(path) as PackedScene
		if packed == null:
			_fail("Could not load %s" % path)
			return
		var character := packed.instantiate()
		root.add_child(character)
		var skeleton := _find_skeleton(character)
		var player := _find_animation_player(character)
		if skeleton == null or player == null:
			_fail("%s is missing its skeleton or animation player." % path)
			return
		for animation_name in REQUIRED_ANIMATIONS:
			if not player.has_animation(animation_name):
				_fail("%s is missing animation %s." % [path, animation_name])
				return
		for bone_name in ["Head", "UpperArm.L", "UpperArm.R", "UpperLeg.L", "UpperLeg.R", "Wrist.R"]:
			if skeleton.find_bone(bone_name) < 0:
				var available: Array[String] = []
				for bone_index in range(skeleton.get_bone_count()):
					available.append(skeleton.get_bone_name(bone_index))
				_fail("%s is missing required bone %s. Available: %s" % [path, bone_name, available])
				return
		character.queue_free()
	print("BRASSLINE CHARACTER ASSET SMOKE: PASS - 6 rigs, animation sets, and combat bones verified.")
	quit(0)


func _find_skeleton(node: Node) -> Skeleton3D:
	if node is Skeleton3D:
		return node as Skeleton3D
	for child in node.get_children():
		var result := _find_skeleton(child)
		if result != null:
			return result
	return null


func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var result := _find_animation_player(child)
		if result != null:
			return result
	return null


func _fail(message: String) -> void:
	push_error("BRASSLINE CHARACTER ASSET SMOKE: FAIL - %s" % message)
	quit(1)
