extends SceneTree

const COMBAT_CARS: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "engine", "observation"]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	var active_root: Node3D = scene.train_art.get_node_or_null("ActiveRunCarDressing") as Node3D
	if active_root == null:
		_fail("The single-car dressing root was not created.")
		return
	for legacy_name in ["CrewCarUnderframe", "WorkshopUnderframe", "VaultUnderframe", "ClockworkLocomotive"]:
		if scene.train_art.get_node_or_null(legacy_name) != null:
			_fail("Legacy adjacent rolling stock remained visible: %s." % legacy_name)
			return

	var board_span: float = scene.board.cell_to_world(Vector2i(19, 2)).x - scene.board.cell_to_world(Vector2i(0, 2)).x
	if board_span > 21.0:
		_fail("The active carriage still uses the oversized three-room board spacing.")
		return

	var layout_signatures: Dictionary = {}
	var expected_windows := {
		"baggage": ["passenger", "PassengerWindow"],
		"dining": ["passenger", "PassengerWindow"],
		"bar": ["passenger", "PassengerWindow"],
		"crew": ["passenger", "PassengerWindow"],
		"armory": ["armored_slit", "ArmoredWindowSlit"],
		"engine": ["porthole", "EnginePorthole"],
		"observation": ["panorama", "PassengerWindow"],
	}
	for car_index in range(COMBAT_CARS.size()):
		var car_id := COMBAT_CARS[car_index]
		scene.board.prepare_run_encounter(car_id, car_index % 3)
		scene.train_art.set_active_run_car(car_id, car_index + 1)
		for _frame in range(2):
			await process_frame
		if String(active_root.get_meta("active_car_id", "")) != car_id:
			_fail("%s did not become the only active carriage." % car_id)
			return
		if active_root.get_node_or_null("ActiveCarUnderframe") == null:
			_fail("%s lost its single rolling-stock underframe." % car_id)
			return
		var expected: Array = expected_windows[car_id]
		if String(active_root.get_meta("window_style", "")) != String(expected[0]):
			_fail("%s did not expose its expected window architecture." % car_id)
			return
		if active_root.find_children(String(expected[1]) + "*", "MeshInstance3D", true, false).size() < 7:
			_fail("%s did not build a complete visible window run." % car_id)
			return
		var cover_root: Node3D = scene.train_art.get_node_or_null("TacticalCoverProps") as Node3D
		if cover_root == null or cover_root.get_child_count() != scene.board.blocked_cells.size():
			_fail("%s did not place one visible prop on every functional blocker cell." % car_id)
			return
		for cover_prop in cover_root.get_children():
			if not bool(cover_prop.get_meta("functional_cover", false)):
				_fail("%s contains scenery that is not identified as functional cover." % car_id)
				return
			var cover_cell: Vector2i = cover_prop.get_meta("grid_cell")
			if cover_prop.position.distance_to(scene.board.cell_to_world(cover_cell)) > 0.01:
				_fail("%s has a cover prop that does not match its blocker cell." % car_id)
				return
			if cover_prop.get_node_or_null("CoverBadge") == null:
				_fail("%s has functional cover without a visible riveted maker's plate." % car_id)
				return

		var layout_cells: Array[String] = []
		for cell in scene.board.blocked_cells:
			layout_cells.append("%d,%d" % [cell.x, cell.y])
		layout_cells.sort()
		layout_signatures[";".join(layout_cells)] = true
		if scene.board.find_path(Vector2i(1, 2), Vector2i(18, 2)).is_empty():
			_fail("%s blocked the required through-car route." % car_id)
			return

	if layout_signatures.size() != COMBAT_CARS.size():
		_fail("Two or more combat cars still share the same tactical cover plan.")
		return

	scene.camera_rig.frame_active_car()
	if not scene.camera_rig._car_frame_locked or not scene.camera_rig.combat_battlefield_rect().encloses(scene.camera_rig.planning_projected_bounds()):
		_fail("The combat camera did not fit the active carriage and actors inside the visible battlefield.")
		return

	print("BRASSLINE CAR PRESENTATION SMOKE: PASS - seven unique single-car sets, windows, aligned cover props, floor plans, and locked framing verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE CAR PRESENTATION SMOKE: FAIL - %s" % message)
	quit(1)
