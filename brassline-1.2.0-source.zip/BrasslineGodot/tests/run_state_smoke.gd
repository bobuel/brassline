extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	for seed in range(1, 121):
		for strategy in range(3):
			var run := RunState.new()
			var crew_ids: Array[String] = ["ada", "marlow", "nix"]
			run.start_new_run(crew_ids, seed)
			if run.current_car_id != RunState.FIRST_CAR_ID or run.car_number() != 1:
				_fail("Seed %d did not begin in the guaranteed opening car." % seed)
				return
			var opening_result := run.complete_current_car()
			if not bool(opening_result.get("ok", false)) or int(run.inventory["medkit"]) != 2 or int(run.inventory["limb_brace"]) != 1:
				_fail("The opening car did not award its guaranteed supply cache.")
				return

			while run.phase != "complete":
				if run.phase != "intermission" or run.current_offers.is_empty() or run.current_offers.size() > 3:
					_fail("Seed %d produced an invalid inter-car offer state." % seed)
					return
				if run.has_pending_crew_scene():
					var council_choices: Array = run.crew_scene_data().get("choices", [])
					var council_choice := String(Dictionary(council_choices[posmod(strategy, council_choices.size())]).get("id", ""))
					if not bool(run.resolve_crew_scene_choice(council_choice).get("ok", false)):
						_fail("Seed %d could not resolve its required crew council." % seed)
						return
				for offered_id in run.current_offers:
					if not run.is_candidate_eligible(offered_id):
						_fail("Seed %d offered an ineligible %s car." % [seed, offered_id])
						return
				var choice_index := mini(strategy, run.current_offers.size() - 1)
				var choice := run.current_offers[choice_index]
				if not run.choose_next_car(choice):
					_fail("Seed %d rejected an advertised eligible car." % seed)
					return
				run.complete_current_car()

			if run.completed_car_ids.size() != RunState.TOTAL_CARS:
				_fail("Seed %d did not complete exactly seven cars." % seed)
				return
			if run.completed_car_ids[0] != RunState.FIRST_CAR_ID:
				_fail("Seed %d displaced the guaranteed opening car." % seed)
				return
			for required_id in RunState.REQUIRED_CAR_IDS:
				if required_id not in run.completed_car_ids:
					_fail("Seed %d stranded required car %s." % [seed, required_id])
					return
			var optional_count := 0
			for optional_id in RunState.OPTIONAL_CAR_IDS:
				if optional_id in run.completed_car_ids:
					optional_count += 1
			if optional_count != 1:
				_fail("Seed %d completed %d optional cars instead of exactly one." % [seed, optional_count])
				return

	var healing_run := RunState.new()
	var healing_crew: Array[String] = ["ada", "marlow", "nix"]
	healing_run.start_new_run(healing_crew, 8080)
	healing_run.complete_current_car()
	var ada_body := healing_run.body_state_for("ada")
	ada_body[Types.BodyZone.TORSO]["hp"] = 2
	healing_run.record_crew_body_state("ada", ada_body)
	var item_result := healing_run.use_item("medkit", "ada")
	if not bool(item_result.get("ok", false)) or int(healing_run.inventory["medkit"]) != 1:
		_fail("Between-car item management did not consume and apply a Medkit.")
		return
	if int(healing_run.body_state_for("ada")[Types.BodyZone.TORSO]["hp"]) != 4:
		_fail("Medkit healing did not persist in the run state.")
		return

	var takeover_route := RunState.new()
	takeover_route.start_new_run(healing_crew, 9001)
	takeover_route.complete_current_car()
	if takeover_route.is_candidate_eligible("engine") or "engine" in takeover_route.current_offers:
		_fail("The takeover ruleset offered the engine before the finale slot.")
		return
	_force_complete(takeover_route, "crew")
	_force_complete(takeover_route, "armory")
	if not is_equal_approx(float(takeover_route.squad_bonuses["damage"]), 0.75) or int(takeover_route.squad_bonuses["range"]) != 1:
		_fail("Crew-first routing did not apply the advertised Armory damage and range package.")
		return

	var checkpoint_run := RunState.new()
	checkpoint_run.start_new_run(healing_crew, 424242)
	checkpoint_run.complete_current_car()
	var saved_body := checkpoint_run.body_state_for("marlow")
	saved_body[Types.BodyZone.ARMS]["hp"] = 0
	saved_body[Types.BodyZone.ARMS]["disabled"] = true
	checkpoint_run.record_crew_status("marlow", saved_body, false)
	checkpoint_run.inventory["focus_tonic"] = 2
	var prepared_car: String = checkpoint_run.current_offers[0]
	var prepared_offers := checkpoint_run.current_offers.duplicate()
	if not checkpoint_run.prepare_next_car(prepared_car):
		_fail("A legal route choice could not enter crew preparation.")
		return
	var serialized := JSON.stringify(checkpoint_run.to_save_data())
	var parsed = JSON.parse_string(serialized)
	if not parsed is Dictionary:
		_fail("Checkpoint JSON could not be parsed back into a dictionary.")
		return
	var restored_run := RunState.new()
	if not restored_run.load_from_save_data(parsed):
		_fail("A valid checkpoint could not be restored.")
		return
	if restored_run.run_seed != checkpoint_run.run_seed or restored_run.phase != "preparation" or restored_run.pending_car_id != prepared_car:
		_fail("Checkpoint restoration lost the run identity or phase.")
		return
	if restored_run.current_offers != prepared_offers or restored_run.completed_car_ids != checkpoint_run.completed_car_ids:
		_fail("Checkpoint restoration changed the legal route state.")
		return
	if not restored_run.crew_is_down("marlow") or int(restored_run.body_state_for("marlow")[Types.BodyZone.ARMS]["hp"]) != 0:
		_fail("Checkpoint restoration lost a persistent casualty or limb injury.")
		return
	if int(restored_run.inventory["focus_tonic"]) != 2 or restored_run.squad_bonuses != checkpoint_run.squad_bonuses:
		_fail("Checkpoint restoration lost inventory or squad bonuses.")
		return
	var legacy_data: Dictionary = checkpoint_run.to_save_data().duplicate(true)
	legacy_data["version"] = 2
	for crew_id in legacy_data["crew_states"]:
		var current_body: Dictionary = legacy_data["crew_states"][crew_id]["body"]
		legacy_data["crew_states"][crew_id]["body"] = {
			"0": Dictionary(current_body["0"]).duplicate(true),
			"1": Dictionary(current_body["1"]).duplicate(true),
			"2": Dictionary(current_body["2"]).duplicate(true),
			"3": Dictionary(current_body["2"]).duplicate(true),
			"4": Dictionary(current_body["3"]).duplicate(true),
			"5": Dictionary(current_body["3"]).duplicate(true),
		}
	var migrated_run := RunState.new()
	if not migrated_run.load_from_save_data(legacy_data) or migrated_run.body_state_for("marlow").size() != 4:
		_fail("A legacy six-zone checkpoint did not migrate to Head/Torso/Arms/Legs.")
		return
	if migrated_run.ruleset_id != "legacy_blueprint":
		_fail("A pre-v5 checkpoint did not preserve the legacy blueprint contract.")
		return
	if not bool(migrated_run.body_state_for("marlow")[Types.BodyZone.ARMS]["disabled"]):
		_fail("Legacy paired arm damage lost its crippling state during migration.")
		return
	if not restored_run.cancel_preparation() or restored_run.phase != "intermission" or restored_run.current_offers != prepared_offers:
		_fail("Backing out of crew preparation did not preserve the selected route offers.")
		return
	if not restored_run.prepare_next_car(prepared_car) or not restored_run.confirm_prepared_car():
		_fail("The restored preparation state could not be recommitted after returning to the route.")
		return
	if restored_run.phase != "encounter" or restored_run.current_car_id != prepared_car or not restored_run.current_offers.is_empty():
		_fail("Boarding from preparation did not commit exactly one encounter.")
		return

	print("BRASSLINE RUN STATE SMOKE: PASS - 360 adversarial runs preserved route compliance; the engine finale, crew/armory synergy, inventory, prep/back/board state, v7 checkpoints, and legacy migration persisted.")
	quit(0)


func _force_complete(run: RefCounted, car_id: String) -> void:
	run.phase = "encounter"
	run.current_car_id = car_id
	run.available_car_ids.erase(car_id)
	run.complete_current_car()


func _fail(message: String) -> void:
	push_error("BRASSLINE RUN STATE SMOKE: FAIL - %s" % message)
	quit(1)
