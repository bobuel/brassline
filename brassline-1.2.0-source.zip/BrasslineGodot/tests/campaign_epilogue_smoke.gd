extends SceneTree

const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	var run = RunState.new()
	run.start_new_run(crew_ids, 17761, "standard")
	var route: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "observation", "engine"]
	for car_id in route:
		run.current_car_id = car_id
		run.record_plan_result(
			{"id": "counter_%s" % car_id, "title": "Master %s" % car_id, "risk_unit_id": "marlow"},
			{"id": "hold_plan"},
			{
				"plan_status": "on_plan",
				"fallback_triggered": false,
				"rounds": 3,
				"train_events": [{"phase": "impact", "result": {"countered": true}}],
				"doctrine": {"id": "doctrine_%s" % car_id, "name": "Doctrine", "broken": true},
			}
		)
	run.completed_car_ids.assign(route)
	run.current_car_id = ""
	run.phase = "complete"
	for key in run.crew_relationships:
		run.crew_relationships[key]["bond"] = 3
	var chapter: Dictionary = run.campaign_chapter()
	if String(chapter.get("id", "")) != "epilogue":
		_fail("A completed run did not enter the authored epilogue chapter.")
		return
	var metrics: Dictionary = run.campaign_outcome_metrics()
	if int(metrics.get("doctrine_breaks", 0)) != 7 or int(metrics.get("train_counters", 0)) != 7 or int(metrics.get("clean_plans", 0)) != 7:
		_fail("The epilogue did not preserve mastery across all seven plan results.")
		return
	var ending: Dictionary = run.campaign_epilogue()
	if String(ending.get("title", "")) != "THE QUIET LINE" or String(ending.get("grade", "")) != "S" or Array(ending.get("crew_lines", [])).size() != 3:
		_fail("A full-crew mastery run did not produce its distinct named ending and crew epilogues.")
		return
	run.crew_states["marlow"]["down"] = true
	run.crew_states["nix"]["down"] = true
	ending = run.campaign_epilogue()
	if String(ending.get("title", "")) != "THE LAST HAND ON THE THROTTLE" or Array(Dictionary(ending.get("metrics", {})).get("survivors", [])).size() != 1:
		_fail("A one-survivor campaign did not produce the costly last-operative ending.")
		return
	print("BRASSLINE CAMPAIGN EPILOGUE: PASS - act progression, route mastery, named outcomes, grading, survivors, and individual crew epilogues verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE CAMPAIGN EPILOGUE: FAIL - %s" % message)
	quit(1)
