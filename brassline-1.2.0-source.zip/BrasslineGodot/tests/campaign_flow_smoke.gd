extends SceneTree

const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var campaign := CampaignUI.new()
	root.add_child(campaign)
	await process_frame

	if CampaignUI.ROSTER.size() != 6 or campaign.selected_crew_ids.size() != 3:
		_fail("Expected a six-person roster with three operatives preselected.")
		return
	if not campaign.is_frontend_open() or campaign.navigator.visible:
		_fail("The campaign flow did not open on the intro screen.")
		return
	campaign.set_continue_available(true, "CAR 3 / 7 · RUN 4242")
	campaign.show_intro()
	var continue_button := _find_button(campaign.front_content, "CONTINUE RUN")
	if continue_button == null:
		_fail("A valid checkpoint did not expose Continue Run on the title screen.")
		return
	campaign.continue_requested.connect(func() -> void: campaign.set_meta("continue_requested", true))
	continue_button.pressed.emit()
	if not bool(campaign.get_meta("continue_requested", false)):
		_fail("The Continue Run control did not request checkpoint restoration.")
		return

	campaign.show_crew_selection()
	campaign._toggle_crew("ada")
	campaign._toggle_crew("iona")
	if campaign.selected_crew_ids.size() != 3 or "iona" not in campaign.selected_crew_ids or "ada" in campaign.selected_crew_ids:
		_fail("Crew drafting did not swap roster members while preserving the three-person limit.")
		return

	campaign.crew_confirmed.connect(func(ids: Array[String]) -> void: campaign.set_meta("confirmed_ids", ids))
	campaign._confirm_crew()
	await process_frame
	var confirmed_ids: Array = campaign.get_meta("confirmed_ids", [])
	if confirmed_ids.size() != 3 or campaign.is_frontend_open() or not campaign.navigator.visible:
		_fail("Confirming the crew did not transition into the train navigator.")
		return

	var run := RunState.new()
	var run_crew: Array[String] = []
	run_crew.assign(confirmed_ids)
	run.start_new_run(run_crew, 4242)
	run.complete_current_car()
	campaign.show_intermission(run)
	if not campaign.is_frontend_open() or campaign.navigator.visible or run.current_offers.is_empty():
		_fail("Completing a car did not open the dedicated route-selection screen.")
		return
	if campaign.crew_preview_stage != null or not _tree_contains_text(campaign.front_content, "STEP 1 OF 2"):
		_fail("The route screen still mixes crew management into the first decision step.")
		return
	campaign.car_prep_requested.connect(func(car_id: String) -> void: campaign.set_meta("prep_car", car_id))
	campaign._choose_offer(run.current_offers[0])
	if String(campaign.get_meta("prep_car", "")) != run.current_offers[0]:
		_fail("Selecting an eligible offer did not request the crew-prep step.")
		return
	var chosen_offer := run.current_offers[0]
	if not run.prepare_next_car(chosen_offer):
		_fail("The selected route could not enter the checkpointed preparation phase.")
		return
	campaign.show_crew_prep(run)
	await process_frame
	if not _tree_contains_text(campaign.front_content, "STEP 2 OF 2") or campaign.crew_preview_stage == null:
		_fail("Crew preparation did not open as a distinct second screen with a 3D lineup.")
		return
	if campaign.crew_preview_stage.visual_nodes.size() != 3:
		_fail("The prep screen did not stage all three selected character models.")
		return
	for visual in campaign.crew_preview_stage.visual_nodes.values():
		if not is_instance_valid(visual.animation_player) or not visual.animation_player.is_playing():
			_fail("A staged operative is not running its imported idle/death animation.")
			return
		if not visual.scale.is_equal_approx(Vector3.ONE) or not is_zero_approx(visual.position.z):
			_fail("The prep lineup still uses forced-perspective scale or depth instead of a shared floor plane.")
			return
	var initial_crew := campaign._management_crew_id
	campaign._rotate_management_crew(1)
	await process_frame
	if campaign._management_crew_id == initial_crew or campaign.crew_preview_stage.selected_crew_id != campaign._management_crew_id:
		_fail("Previous/next navigation did not rotate the centered operative and readiness panel together.")
		return
	campaign.item_requested.connect(func(item_id: String, crew_id: String) -> void: campaign.set_meta("item_request", "%s:%s" % [item_id, crew_id]))
	campaign._request_item("medkit")
	if String(campaign.get_meta("item_request", "")) != "medkit:%s" % campaign._management_crew_id:
		_fail("Between-car supply controls did not identify the item and crew target.")
		return
	campaign.next_car_chosen.connect(func(car_id: String) -> void: campaign.set_meta("chosen_car", car_id))
	campaign.prep_board_button.pressed.emit()
	if String(campaign.get_meta("chosen_car", "")) != chosen_offer:
		_fail("The crew-prep screen did not reserve encounter commitment for its Board action.")
		return

	print("BRASSLINE CAMPAIGN FLOW SMOKE: PASS - intro, continue, crew draft, route-first selection, three equally scaled animated 3D models, operative rotation, treatment targeting, and final boarding verified.")
	quit(0)


func _find_button(root_node: Node, text: String) -> Button:
	for child in root_node.get_children():
		if child is Button and child.text == text:
			return child
		var nested := _find_button(child, text)
		if nested != null:
			return nested
	return null


func _tree_contains_text(root_node: Node, text_fragment: String) -> bool:
	for child in root_node.get_children():
		if child is Label and text_fragment in child.text:
			return true
		if _tree_contains_text(child, text_fragment):
			return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE CAMPAIGN FLOW SMOKE: FAIL - %s" % message)
	quit(1)
