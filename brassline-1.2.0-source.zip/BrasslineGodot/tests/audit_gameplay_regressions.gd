extends SceneTree

const Types = preload("res://scripts/game_types.gd")
const Plans = preload("res://scripts/plan_catalog.gd")

func _initialize() -> void:
	_run.call_deferred()

func _check(ok: bool, message: String) -> bool:
	if not ok:
		push_error("BRASSLINE AUDIT REGRESSION: FAIL - " + message)
		quit(1)
	return ok

func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for frame in range(8): await process_frame
	var ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(ids, 97501)
	scene.run_state.current_car_id = "dining"
	scene.run_state.completed_car_ids.assign(["baggage"])
	await scene._load_run_encounter()
	var director: AutobattleDirector = scene.autobattle_director
	var turn: TurnController = scene.turn
	var ada: TacticalUnit = turn.player_units(true)[0]
	var enemy: TacticalUnit = turn.enemy_units(true)[0]
	var plan: Dictionary = scene.autobattle_ui.plans[0].duplicate(true)
	plan["safe"] = false
	plan["environment_action"] = ""
	ada.grid_cell = Vector2i(6, 2)
	ada.position = scene.board.cell_to_world(ada.grid_cell)
	enemy.grid_cell = Vector2i(8, 2)
	enemy.position = scene.board.cell_to_world(enemy.grid_cell)
	ada.body_state[Types.BodyZone.TORSO]["hp"] = 2
	var order: Dictionary = plan.orders["ada"]
	order.merge({"body_priority": Types.BodyZone.TORSO, "target_instance_id": enemy.get_instance_id(), "use_ability": false, "objective": "pressure", "gear_item": ""}, true)
	plan.orders["ada"] = order
	director.configure(plan, Plans.fallback_data("protect_wounded"))
	director.running = true
	turn.begin_autobattle_encounter()
	if not _check(turn.can_attack(ada, enemy), "Retreat regression requires a legal shot at start."): return
	var original_danger := director._retreat_position_score(ada, ada.grid_cell)
	await director._run_crew_activation(ada, director._run_serial)
	if not _check(ada.grid_cell != Vector2i(6, 2) and director._retreat_position_score(ada, ada.grid_cell) < original_danger, "Wounded crew fired without seeking safer ground despite a safe path."): return
	if not _check(not director.fallback_actions.is_empty() and "withdrew" in director._fallback_aftermath_text(), "Fallback aftermath must report executed movement."): return
	print("AUDIT retreat: legal shot overridden; actual withdrawal recorded")
	# Inventory UI pauses independently of a player's manual pause selection.
	director.set_speed(4)
	director.set_inspection_paused(true)
	if not _check(is_zero_approx(director.effective_time_scale()) and not director.paused, "Ledger pause changed manual pause state."): return
	director.set_paused(true)
	director.set_inspection_paused(false)
	if not _check(is_zero_approx(director.effective_time_scale()), "Closing Ledger cleared manual pause."): return
	director.set_paused(false)
	if not _check(is_equal_approx(director.effective_time_scale(), 2.0), "Ledger did not restore selected speed."): return
	director.stop()
	# A damaging hazard cannot reach off-footprint enemies.
	var before: Dictionary = {}
	for target in turn.enemy_units(true):
		target.grid_cell = Vector2i(19, 4)
		target.position = scene.board.cell_to_world(target.grid_cell)
		before[target.get_instance_id()] = target.export_body_state()
	var footprint: Dictionary = turn.plan_environment_preview("chandelier", ada)
	if not _check(footprint.victims.is_empty() and Vector2i(19, 4) not in footprint.affected_cells, "Preview included a remote victim."): return
	ada.action_points = 2
	turn.phase = Types.Phase.PLAYER
	var result: Dictionary = await turn.perform_plan_environment_action("chandelier", ada)
	if not _check(result.ok and result.victims.is_empty(), "Chandelier damaged guards outside marked cells."): return
	for target in turn.enemy_units(true):
		if not _check(target.export_body_state() == before[target.get_instance_id()], "Remote guard's body changed."): return
	enemy.grid_cell = Vector2i(9, 2)
	var marked: Dictionary = turn.plan_environment_preview("chandelier", ada)
	if not _check(marked.victims.size() == 1 and int(marked.victims[0].instance_id) == enemy.get_instance_id(), "Preview did not identify the guard actually inside the marked footprint."): return
	ada.action_points = 2
	turn.phase = Types.Phase.PLAYER
	result = await turn.perform_plan_environment_action("chandelier", ada)
	if not _check(result.victims.size() == 1 and String(result.victims[0]) == enemy.display_name, "Hazard victims did not match the marked footprint."): return
	var control: Dictionary = turn.plan_environment_preview("lock_service_cart", ada)
	if not _check(control.control_only and control.primary_damage == 0 and control.secondary_damage == 0, "Control interaction advertised damage."): return
	print("AUDIT environment: exact bounded footprint; control does zero damage")
	# Miss tracer randomness cannot alter subsequent gameplay rolls.
	var rng_state := turn.rng.state
	await turn._play_shot_feedback(ada, enemy, Types.BodyZone.TORSO, false)
	if not _check(turn.rng.state == rng_state, "Miss presentation consumed simulation RNG."): return
	# Unsafe grenade waits; clearing the ally permits the next attempt.
	enemy.grid_cell = Vector2i(8, 2)
	ada.grid_cell = Vector2i(6, 2)
	ada.action_points = 2
	turn.phase = Types.Phase.PLAYER
	turn.select_unit(ada)
	var allies := turn.player_units(true)
	allies[1].grid_cell = Vector2i(8, 3)
	allies[2].grid_cell = Vector2i(1, 3)
	scene.run_state.inventory["clockwork_grenade"] = 1
	director.configure(plan, Plans.fallback_data("hold_plan"), {"clockwork_grenade": 1})
	var gear_order := {"gear_item": "clockwork_grenade", "gear_target_instance_id": enemy.get_instance_id()}
	var used := await director._try_plan_consumable(ada, enemy, Types.BodyZone.TORSO, gear_order)
	if not _check(not used and not bool(director._gear_attempted.get(ada.roster_id, false)), "Unsafe throw permanently cancelled its commitment."): return
	allies[1].grid_cell = Vector2i(1, 1)
	used = await director._try_plan_consumable(ada, enemy, Types.BodyZone.TORSO, gear_order)
	if not _check(used and director._combat_inventory.clockwork_grenade == 0, "Grenade did not execute after blast cleared."): return
	print("AUDIT gear: unsafe throw waits and later consumes exactly one grenade")
	director._crew_damage_events.assign([{"target": "Ada Brass", "attacker": "Officer", "zone": Types.BodyZone.TORSO, "damage": 4, "defeated": true}])
	if not _check("ended the run" not in director._decisive_injury_text(), "An operative casualty falsely ends the run."): return
	# Safe formation requires real cover or a supporting ally.
	var test_plan := {"safe": true}
	ada.grid_cell = Vector2i(0, 2)
	allies[1].grid_cell = Vector2i(19, 0)
	allies[2].grid_cell = Vector2i(19, 4)
	if not ada.is_in_physical_cover():
		if not _check(is_zero_approx(director.formation_resistance(ada, test_plan)), "Isolated exposed operative retained formation protection."): return
	allies[1].grid_cell = Vector2i(1, 2)
	if not _check(is_equal_approx(director.formation_resistance(ada, test_plan), .40), "Supporting ally failed to establish formation protection."): return
	# Real roster and profile sidegrades are gated, not labels on the same offer.
	await scene._on_crew_confirmed(ids, 97501)
	var base := Plans.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn)
	var unlocked := Plans.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {}, [], {}, ["blueprint_crossfire"])
	if not _check(not _has_plan(base, "blueprint_crossfire") and _has_plan(unlocked, "blueprint_crossfire"), "Blueprint unlock does not gate a real offer."): return
	var alternate: Array[String] = ["iona", "silas", "rook"]
	await scene._on_crew_confirmed(alternate, 97501)
	var specialized := Plans.generate_plans("baggage", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn)
	if not _check(_has_plan(specialized, "rook_holds_the_line") or _has_plan(specialized, "silas_double_draw"), "Alternate crew did not produce a specialist tactic."): return
	# A one-person crew must not start with a broken plan solely because its
	# formation has one operative; break state describes losses in this encounter.
	var original_units: Array[TacticalUnit] = scene.turn.units.duplicate()
	var solo: TacticalUnit = scene.turn.player_units(true)[0]
	for unit in scene.turn.player_units(true):
		if unit != solo: scene.turn.units.erase(unit)
	director.configure(specialized[0], Plans.fallback_data("save_crew"))
	director._update_plan_integrity()
	if not _check(director.current_plan_status == "on_plan", "A healthy solo formation began with a broken plan."): return
	scene.turn.units = original_units
	# Unlocks must preserve the car's authored counter choices and rotate when
	# recently used; they may not replace the officer arm counter with leg focus.
	await scene._on_crew_confirmed(ids, 97501)
	scene.run_state.current_car_id = "dining"
	scene.run_state.completed_car_ids.assign(["baggage"])
	await scene._load_run_encounter()
	var known: Array[String] = ["blueprint_crossfire", "blueprint_countermarch", "blueprint_pressure_play"]
	var dining_offers := Plans.generate_plans("dining", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {}, [], {}, known)
	if not _check(_has_plan(dining_offers, "pin_the_command") and _has_plan(dining_offers, "lock_the_service_cart") and not _has_plan(dining_offers, "blueprint_countermarch"), "Unlocked variants replaced the Dining arm/environment counters."): return
	var rotated := Plans.generate_plans("dining", scene.turn.player_units(true), scene.turn.enemy_units(true), scene.turn, {}, ["blueprint_crossfire"], {}, known)
	if not _check(not _has_plan(rotated, "blueprint_crossfire"), "A recently used specialist offer failed to rotate."): return
	var roles := Plans._bind_roles({"scout": "hazard_control", "anchor": "frontline", "shooter": "precision"}, scene.turn.player_units(true))
	if not _check(roles.shooter.roster_id == "ada" and roles.scout.roster_id == "nix", "Unmatched role consumed a required specialist before binding."): return
	# A surrendered medic is alive, but no longer part of combat. It must not
	# heal a disabled boss back into action or remain in automatic initiative.
	turn = scene.turn
	var medic: TacticalUnit = turn.enemy_units(true)[0]
	var patient: TacticalUnit = turn.enemy_units(true)[1]
	medic.role_id = "medic"
	medic.force_surrender()
	patient.body_state[Types.BodyZone.TORSO]["hp"] = 2
	var patient_before := patient.export_body_state()
	medic.action_points = 2
	await turn._try_enemy_support(medic)
	await turn.run_enemy_activation(medic)
	if not _check(patient.export_body_state() == patient_before and medic.action_points == 2, "Surrendered medic healed or spent an action."): return
	if not _check(director._planned_target({"target_instance_id": medic.get_instance_id()}) != medic, "Finish Target retained a surrendered enemy."): return
	if not _check(not turn.can_use_grenade(medic) and not turn.can_target_zone(medic, Types.BodyZone.ARMS), "Surrendered enemy remained a legal item/body target."): return
	director._build_initiative()
	for entry in director.initiative_entries:
		if not _check(entry.unit != medic, "Surrendered guard remained in initiative."): return
	# The actual final blow, including environmental damage, must be recorded
	# before synchronous aftermath creation (including Reduced Motion/headless).
	turn = scene.turn
	solo = turn.player_units(true)[0]
	for unit in turn.player_units(true):
		if unit != solo: turn.units.erase(unit)
	var killer: TacticalUnit = turn.enemy_units(true)[0]
	solo.grid_cell = Vector2i(6, 2)
	killer.grid_cell = Vector2i(8, 2)
	solo.body_state[Types.BodyZone.HEAD]["hp"] = 1
	killer.base_damage = 100
	killer.weapon_accuracy_bonus = 10
	killer.attack_range = 20
	director.configure(dining_offers[0], Plans.fallback_data("hold_plan"))
	director.running = true
	turn.begin_autobattle_encounter()
	turn.phase = Types.Phase.ENEMY
	await turn._perform_attack(killer, solo, Types.BodyZone.HEAD)
	var final_report: Dictionary = scene._pending_autobattle_completion.get("aftermath", {})
	var final_injury := String(Dictionary(final_report.get("failure_analysis", {})).get("decisive_injury", ""))
	if not _check(killer.display_name in final_injury and "head" in final_injury and "fell" in final_injury, "Synchronous aftermath omitted the actual lethal shot."): return
	await scene._on_crew_confirmed(ids, 97501)
	turn = scene.turn
	solo = turn.player_units(true)[0]
	for unit in turn.player_units(true):
		if unit != solo: turn.units.erase(unit)
	director.configure(scene.autobattle_ui.plans[0], Plans.fallback_data("hold_plan"))
	director.running = true
	turn.begin_autobattle_encounter()
	turn.resolve_living_train_event({"id": "audit", "title": "Audit pressure surge", "cells": [solo.grid_cell], "zone": int(Types.BodyZone.TORSO), "damage": 99})
	final_report = scene._pending_autobattle_completion.get("aftermath", {})
	final_injury = String(Dictionary(final_report.get("failure_analysis", {})).get("decisive_injury", ""))
	if not _check("Audit pressure surge" in final_injury and "torso" in final_injury and "fell" in final_injury, "Environmental final injury was missing from aftermath."): return
	print("BRASSLINE AUDIT REGRESSIONS: PASS - retreat, independent inspection pause, environment geometry, RNG isolation, gear retry, casualty truth, formation, and sidegrade eligibility")
	quit(0)

func _has_plan(plans: Array, plan_id: String) -> bool:
	for plan in plans:
		if String(plan.get("id", "")) == plan_id: return true
	return false
