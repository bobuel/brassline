extends SceneTree


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 761901)
	for _frame in range(4):
		await process_frame
	var before: Dictionary = scene._encounter_retry_snapshot.duplicate(true)
	if before.is_empty() or String(before.get("phase", "")) != "encounter":
		_fail("No pre-fight encounter checkpoint was captured.")
		return
	scene.run_state.inventory["clockwork_grenade"] = 99
	scene.run_state.run_stats["items_used"] = 77
	var ada_state: Dictionary = scene.run_state.crew_states["ada"]
	ada_state["down"] = true
	scene.run_state.crew_states["ada"] = ada_state
	scene.campaign_ui.show_run_failed(scene.run_state, "The line held", {
		"crew_consequences": [{"summary": "Ada was cut off from the boarding line."}],
	})
	for _frame in range(2):
		await process_frame
	if not scene.campaign_ui.front_overlay.visible:
		_fail("The dedicated failed-heist recovery screen did not open.")
		return
	var labels := _button_labels(scene.campaign_ui.front_content)
	if "RETRY THIS CAR" not in labels or "ABANDON THIS RUN" not in labels:
		_fail("The failed-heist screen does not offer both recovery choices.")
		return
	await scene._on_retry_requested()
	for _frame in range(4):
		await process_frame
	if int(scene.run_state.inventory.get("clockwork_grenade", -1)) != int(Dictionary(before.get("inventory", {})).get("clockwork_grenade", -2)):
		_fail("Retry did not restore pre-fight supplies.")
		return
	if int(scene.run_state.run_stats.get("items_used", -1)) != int(Dictionary(before.get("run_stats", {})).get("items_used", -2)):
		_fail("Retry duplicated failed-attempt telemetry.")
		return
	if scene.run_state.crew_is_down("ada") != bool(Dictionary(Dictionary(before.get("crew_states", {})).get("ada", {})).get("down", false)):
		_fail("Retry did not restore pre-fight crew condition.")
		return
	if scene.autobattle_ui.plans.is_empty() or not scene.autobattle_ui.planning_root.visible:
		_fail("Retry did not return to a usable planning phase.")
		return
	print("BRASSLINE FAILURE RECOVERY: PASS - defeat screen, retry/abandon choices, and atomic restoration of crew, supplies, telemetry, and planning verified.")
	quit(0)


func _button_labels(node: Node) -> Array[String]:
	var labels: Array[String] = []
	if node is Button:
		labels.append((node as Button).text)
	for child in node.get_children():
		labels.append_array(_button_labels(child))
	return labels


func _fail(message: String) -> void:
	push_error("BRASSLINE FAILURE RECOVERY: FAIL - %s" % message)
	quit(1)
