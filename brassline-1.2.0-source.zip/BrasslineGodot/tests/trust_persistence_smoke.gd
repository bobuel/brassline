extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
const ProfileState := preload("res://scripts/profile_state.gd")
const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var state := RunState.new()
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	state.start_new_run(crew_ids, 880912, "standard")
	state.crew_states["ada"]["body"][Types.BodyZone.TORSO]["hp"] = 1
	assert(state.crew_readiness("ada")["status"] == "CRITICAL", "Lethal-zone danger cannot be averaged away")
	assert(state.crew_readiness("ada")["treatment_recommended"] == "medkit")
	state.crew_states["marlow"]["body"][Types.BodyZone.ARMS]["hp"] = 0
	assert(state.crew_readiness("marlow")["status"] == "CRIPPLED")
	assert(state.crew_readiness("marlow")["treatment_recommended"] == "limb_brace")
	state.crew_states["nix"]["down"] = true
	assert(state.crew_readiness("nix")["status"] == "LOST")
	assert(state.crew_readiness("nix")["health_ratio"] == 0.0)
	assert(int(state.to_save_data()["version"]) == 7)

	var profile := ProfileState.new()
	var legacy_code := profile.build_challenge_code(880912, "standard", crew_ids, "legacy_blueprint")
	assert(profile.parse_challenge_code(legacy_code)["ruleset"] == "legacy_blueprint")
	var duplicate_ids: Array[String] = ["ada", "ada", "nix"]
	assert(not profile.parse_challenge_code(profile.build_challenge_code(880912, "standard", duplicate_ids))["ok"])
	profile.record_daily_result("2026-09-08", "A")
	profile.record_daily_result("2026-09-09", "B")
	profile.record_daily_result("2026-09-08", "C")
	assert(profile.daily_best_grade("2026-09-08") == "A")
	assert(profile.last_daily_date == "2026-09-09")
	var profile_path := "user://trust_profile_%d.json" % OS.get_process_id()
	assert(profile.save_to_disk(profile_path))
	assert(profile.save_to_disk(profile_path), "Atomic save must replace an existing file on Windows")
	var loaded_profile := ProfileState.new()
	assert(loaded_profile.load_from_disk(profile_path))
	assert(loaded_profile.daily_best_grade("2026-09-08") == "A")

	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	await scene._on_crew_confirmed(crew_ids, 880912)
	assert(scene.turn.enemy_units(true)[0].get_meta("inspection_id", "") != "")
	scene.run_state.inventory["clockwork_grenade"] = 1
	scene._encounter_retry_snapshot = scene.run_state.to_save_data().duplicate(true)
	scene._automation_mode = false
	scene._save_path = "user://trust_checkpoint_%d.json" % OS.get_process_id()
	scene._save_run_checkpoint()
	scene._on_autobattle_consumable_used("clockwork_grenade", scene.turn.player_units(true)[0])
	assert(scene.run_state.inventory["clockwork_grenade"] == 0)
	var checkpoint: Dictionary = scene._read_run_checkpoint()
	assert(checkpoint["inventory"]["clockwork_grenade"] == 1, "A refreshed encounter must retain the complete pre-fight item state")
	await scene._on_continue_requested()
	assert(scene.run_state.inventory["clockwork_grenade"] == 1)
	assert(scene.autobattle_ui.planning_root.visible)
	assert(not scene.turn.enemy_units(true).is_empty())

	scene._active_daily_date = "2026-09-08"
	scene._write_daily_context()
	scene._active_daily_date = ""
	await scene._on_continue_requested()
	assert(scene._active_daily_date == "2026-09-08", "Daily must survive restart")
	await scene._on_crew_confirmed(crew_ids, 880913)
	assert(scene._active_daily_date.is_empty(), "Ordinary run must clear daily identity")
	assert(scene._read_daily_context().is_empty())

	var rifle: Dictionary = scene.audio_director.weapon_audio_profile("longshot_rifle")
	var breach: Dictionary = scene.audio_director.weapon_audio_profile("breach_gun")
	assert(rifle != breach)
	var fleeting_button := Button.new()
	scene.add_child(fleeting_button)
	fleeting_button.free()
	for _frame in range(3):
		await process_frame
	scene._clear_run_checkpoint()
	DirAccess.remove_absolute(profile_path)
	scene.queue_free()
	for _frame in range(4):
		await process_frame
	print("BRASSLINE TRUST PERSISTENCE: PASS - lethal-zone advice, challenge validation, daily history/resume isolation, atomic grenade refresh, stable enemy identity, audio lifecycle.")
	quit(0)
