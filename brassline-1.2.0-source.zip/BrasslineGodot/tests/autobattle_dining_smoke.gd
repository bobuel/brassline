extends SceneTree

const Types := preload("res://scripts/game_types.gd")

var environment_fired := false
var environment_victims := 0


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	scene.campaign_ui.selected_difficulty = "story"
	await scene._on_crew_confirmed(crew_ids, 94052)
	scene.run_state.completed_car_ids.clear()
	scene.run_state.completed_car_ids.append("baggage")
	scene.run_state.current_car_id = "dining"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	for _frame in range(4):
		await process_frame

	var roles: Array[String] = []
	for enemy in scene.turn.enemy_units(true):
		roles.append(enemy.role_id)
	if "officer" not in roles or "bruiser" not in roles:
		_fail("The Dining vertical slice did not spawn its authored Officer and Bruiser pair.")
		return
	var hazard_index := -1
	var plan_ids: Array[String] = []
	for index in range(scene.autobattle_ui.plans.size()):
		var plan: Dictionary = scene.autobattle_ui.plans[index]
		plan_ids.append(String(plan.get("id", "")))
		if String(plan.get("id", "")) == "break_the_room":
			hazard_index = index
	if hazard_index < 0 or "pin_the_command" not in plan_ids or "make_them_chase" not in plan_ids:
		_fail("Dining did not offer distinct officer, bruiser, and chandelier plans.")
		return

	scene.turn.environment_resolved.connect(func(_action_id: String, _actor: TacticalUnit, result: Dictionary) -> void:
		environment_fired = true
		environment_victims = Array(result.get("victims", [])).size()
	)
	var legs_before := 0
	for enemy in scene.turn.enemy_units(true):
		legs_before += int(enemy.body_state[Types.BodyZone.LEGS]["hp"])
	scene.autobattle_ui._select_plan(hazard_index)
	scene.autobattle_ui._select_fallback(4)
	scene.autobattle_ui._confirm_plan()
	scene.autobattle_director.set_speed(4.0)
	var timeout_frames := 2400
	while not environment_fired and timeout_frames > 0:
		timeout_frames -= 1
		await process_frame
	if timeout_frames <= 0 or environment_victims < 1:
		_fail("Break the Room never triggered the chandelier against a guard.")
		return
	var legs_after := 0
	for enemy in scene.turn.enemy_units(true):
		legs_after += int(enemy.body_state[Types.BodyZone.LEGS]["hp"])
	if legs_after >= legs_before:
		_fail("The chandelier event did not damage enemy legs as previewed.")
		return
	if not scene.autobattle_director.environment_action_used:
		_fail("The director did not remember that the once-per-plan environment action was spent.")
		return
	print("BRASSLINE AUTOBATTLER DINING: PASS - context tags, Officer/Bruiser composition, three distinct authored plans, and the chandelier leg-damage opening verified.")
	scene.autobattle_director.stop()
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER DINING: FAIL - %s" % message)
	quit(1)
