extends SceneTree

const RunState := preload("res://scripts/run_state.gd")
var failures: Array[String] = []
var capture := false
var output_dir := "res://../../work/ui-lift-20260909/overflow-captures"

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	capture = "--capture-ui-overflow" in OS.get_cmdline_user_args()
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(output_dir))
	root.size = Vector2i(1280, 720); root.content_scale_size = root.size
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--ui-size="):
			var dimensions := argument.trim_prefix("--ui-size=").split("x")
			root.size = Vector2i(int(dimensions[0]), int(dimensions[1])); root.content_scale_size = root.size
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene); current_scene = scene
	for frame in range(10): await process_frame
	var ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(ids, 96001)
	var campaign: CampaignUI = scene.campaign_ui
	var ui: AutobattleUI = scene.autobattle_ui
	var director: AutobattleDirector = scene.autobattle_director
	campaign.text_scale = 1.3; ui.set_text_scale(1.3)
	ui._confirm_plan()
	for frame in range(12): await process_frame
	director.set_paused(true)
	_check(director.running, "Active HUD fixture never entered battle.")
	director.plan_status_changed.emit("on_plan", "Assignments and the opening priority remain viable.")
	director.intent_changed.emit(ui.current_crew[2], "AIMING / DINING BRUISER TORSO 77% shot", "Disable doctrine before advancing; retain cover and avoid the exposed center aisle.", "on_plan")
	ui.presentation_panel.visible = false
	ui.on_train_event_changed({"phase": "warning", "title": "GALLEY PRESSURE / OPEN THE SERVICE VENT BEFORE THE NEXT ACTIVATION", "detail": "Counter the pressure before the next activation.", "counter_action": "vent"}, {})
	ui.on_doctrine_changed({"name": "HEADCOUNTER'S COMMAND", "focus_name": "Marlow Pike", "text": "The commander's squad retains its accuracy bonus while command remains active."})
	await _inspect("combat_active", [ui.combat_root, ui.combat_plan_label, ui.combat_status_label, ui.intent_label, ui.combat_warning_panel])
	_check(ui.combat_status_label.text == "ON PLAN", "Live integrity status leaks explanation into the ribbon.")
	_check(not ui.combat_plan_label.get_global_rect().intersects(ui.combat_status_label.get_global_rect()), "Live integrity label intersects the car title.")
	_check("Disable doctrine" not in ui.intent_label.text and "Disable doctrine" in ui.intent_label.tooltip_text, "Intent does not separate action from its full explanation.")
	director.stop()
	ui.combat_root.visible = false; ui.planning_root.visible = false; ui.presentation_panel.visible = false
	var run := RunState.new(); run.start_new_run(ids, 96001); run.complete_current_car(); run.pending_crew_scene_id = ""
	campaign.show_intermission(run)
	await _inspect("route_early", [campaign.front_panel, campaign.front_content])
	run.completed_car_ids.assign(["baggage", "crew", "armory", "bar"])
	run.current_car_id = ""; run.phase = "intermission"; run.pending_crew_scene_id = ""
	run.current_offers.assign(["dining", "observation", "casino"])
	run.squad_bonuses["damage"] = 0.5; run.squad_bonuses["range"] = 1; run.squad_bonuses["movement"] = 1; run.squad_bonuses["accuracy"] = 0.03
	campaign.show_intermission(run)
	await _inspect("route_late", [campaign.front_panel, campaign.front_content])
	run.prepare_next_car("dining")
	campaign.show_crew_prep(run)
	await _inspect("prep_late", [campaign.front_panel, campaign.front_content, campaign.prep_board_button])
	campaign.front_overlay.visible = false
	var data := {"victory": true, "plan_title": "Vent The Galley", "fallback_title": "Protect the wounded", "fallback_triggered": true, "rounds": 7,
		"injuries": [{"name": "Ada Brass", "changes": ["Head damaged; accuracy reduced", "Torso damaged", "Arms crippled"]}, {"name": "Marlow Pike", "changes": ["Legs crippled; movement reduced", "Torso damaged"]}, {"name": "Nix Bell", "changes": ["Head damaged", "Torso damaged"]}],
		"decisive_beats": [{"type": "environment", "result": {"action_id": "galley_pressure_vent"}}, {"type": "cripple", "actor_name": "Marlow Pike", "target_name": "Dining Bruiser", "result": {"zone": 2}}, {"type": "victory", "result": {"message": "The carriage fell after the crew countered its dangerous pressure system."}}]}
	var reward := "DINING CAR / FIELD KITCHEN\nMAXIMUM BODY HP +2 / BETWEEN-CAR HEALING +1\nORDER SYNERGY / Galley Keys / +1 Medkit\nBLUEPRINT KNOWLEDGE / +5 • TOTAL 16\nFirst clear +2 / Environmental win +1 / New route +1 / Risky victory +1"
	ui.show_aftermath(data, reward)
	await _inspect("aftermath_late", [ui.aftermath_panel, ui.aftermath_continue, ui.aftermath_details])
	_check("MAXIMUM BODY HP +2" in ui.aftermath_reward.text and "TOTAL 16" in ui.aftermath_reward.text, "Compact aftermath lost concrete rewards.")
	_check("First clear +2" not in ui.aftermath_reward.text, "Reward breakdown remains mandatory prose.")
	ui.aftermath_details.pressed.emit()
	await _inspect("aftermath_details", [ui.aftermath_panel, ui.aftermath_continue, ui.aftermath_details])
	_check(ui.aftermath_reward.text == reward, "Reward Details loses the full earned reward breakdown.")
	ui.aftermath_root.visible = false
	run.completed_car_ids.assign(["baggage", "crew", "armory", "dining", "observation", "bar", "engine"])
	run.current_car_id = "engine"; run.phase = "complete"
	campaign.show_run_complete(run)
	await _inspect("run_complete", [campaign.front_panel, campaign.front_content])
	var details := _find_button(campaign.front_content, "DETAILS")
	if details != null:
		details.pressed.emit()
		await _inspect("run_complete_details", [campaign.front_panel, campaign.front_content])
	print("BRASSLINE UI OVERFLOW SMOKE: %s - active signal updates, early/late routes, prep, long aftermath, reward details, and end-card at %dx%d/130%%." % ["PASS" if failures.is_empty() else "FAIL", root.size.x, root.size.y])
	scene.queue_free()
	for frame in range(4): await process_frame
	quit(0 if failures.is_empty() else 1)

func _inspect(label: String, controls: Array) -> void:
	for frame in range(10): await process_frame
	var viewport := Rect2(Vector2.ZERO, root.size)
	for control in controls:
		_check(viewport.encloses(control.get_global_rect()), "%s overflow: %s %s" % [label, control.name, control.get_global_rect()])
	if capture:
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png("%s/%s_%dx%d_130.png" % [output_dir, label, root.size.x, root.size.y])

func _find_button(node: Node, text: String) -> Button:
	for child in node.get_children():
		if child is Button and child.text == text: return child
		var result := _find_button(child, text)
		if result != null: return result
	return null

func _check(condition: bool, message: String) -> void:
	if not condition: failures.append(message); push_error(message)
