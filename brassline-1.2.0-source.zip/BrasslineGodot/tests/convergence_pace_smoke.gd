extends SceneTree

const DirectorScript := preload("res://scripts/autobattle_director.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var director: AutobattleDirector = DirectorScript.new()
	root.add_child(director)
	director.running = true
	for pace in [1.0, 2.0, 4.0]:
		director.set_speed(pace)
		var expected: float = float(pace) * 0.5
		if not is_equal_approx(director.effective_time_scale(), expected) or not is_equal_approx(Engine.time_scale, expected):
			_fail("%dx did not map to %.1f effective scale." % [int(pace), expected])
			return
	director.set_paused(true)
	if not is_zero_approx(director.effective_time_scale()) or not is_zero_approx(Engine.time_scale):
		_fail("Pause did not override the selected pace.")
		return
	director.set_paused(false)
	if not is_equal_approx(director.effective_time_scale(), 2.0):
		_fail("Resume did not restore the selected 4x semantic pace.")
		return
	director.set_inspect_slowdown(true)
	if not is_equal_approx(director.effective_time_scale(), 0.2) or not is_equal_approx(Engine.time_scale, 0.2):
		_fail("Hold-to-inspect did not engage its 0.2 scale.")
		return
	director.set_inspect_slowdown(false)
	if not is_equal_approx(director.effective_time_scale(), 2.0):
		_fail("Releasing inspect did not restore the selected pace.")
		return
	director.stop()
	if not is_equal_approx(Engine.time_scale, 1.0):
		_fail("Leaving combat did not restore normal menu time.")
		return
	print("BRASSLINE CONVERGENCE PACE: PASS - semantic 1/2/4 mapping, pause/resume, inspect slowdown, and menu reset verified.")
	quit(0)


func _fail(message: String) -> void:
	Engine.time_scale = 1.0
	push_error("BRASSLINE CONVERGENCE PACE: FAIL - %s" % message)
	quit(1)
