extends SceneTree

const VisualScript := preload("res://scripts/character_visual.gd")
const ROSTER := [
	["ada","Casual_2.gltf","longshot_rifle"], ["marlow","Adventurer.gltf","breach_gun"],
	["nix","Punk.gltf","coil_pistol"], ["iona","Worker.gltf","rivet_carbine"],
	["silas","Suit.gltf","duelist_revolver"], ["rook","Swat.gltf","hand_cannon"],
]


func _initialize() -> void:
	_render.call_deferred()


func _render() -> void:
	root.size = Vector2i(192,224)
	var stage := Node3D.new(); root.add_child(stage); current_scene = stage
	var world := WorldEnvironment.new(); var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR; environment.background_color = Color("#15383c")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; environment.ambient_light_energy = 0.8; environment.ambient_light_color = Color("#aec5c0")
	world.environment = environment; stage.add_child(world)
	var camera := Camera3D.new(); camera.fov=32; stage.add_child(camera); camera.look_at_from_position(Vector3(0.12,1.43,1.86),Vector3(0,1.40,0),Vector3.UP); camera.current=true
	var key := DirectionalLight3D.new(); key.light_color=Color("#ffe0b4"); key.light_energy=1.5; key.rotation_degrees=Vector3(-35,-30,0); stage.add_child(key)
	var rim := DirectionalLight3D.new(); rim.light_color=Color("#81c2c4"); rim.light_energy=0.7; rim.rotation_degrees=Vector3(-30,135,0); stage.add_child(rim)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://assets/ui/portraits"))
	for member in ROSTER:
		var visual := VisualScript.new(); stage.add_child(visual)
		visual.setup("res://assets/characters/quaternius/"+member[1],0); visual.build_weapon(member[2]); visual.rotation_degrees.y=-12
		# A portrait identifies the face; a rifle stock at rest filled half this crop.
		visual.weapon_root.visible = false
		visual.animation_player.play("Idle_Neutral"); visual.animation_player.advance(0.05); visual.animation_player.pause()
		for frame in range(8): await process_frame
		await RenderingServer.frame_post_draw
		var image := root.get_texture().get_image()
		if image == null or image.is_empty(): push_error("Portrait render failed."); quit(1); return
		image.save_png("res://assets/ui/portraits/"+member[0]+".png")
		visual.queue_free(); await process_frame
	print("BRASSLINE PORTRAITS: PASS - six character busts rendered from the in-game rigs.")
	quit(0)
