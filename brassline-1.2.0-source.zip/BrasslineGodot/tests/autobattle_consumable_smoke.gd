extends SceneTree

var used_items: Array[String] = []


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame

	scene.campaign_ui.selected_difficulty = "story"
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 94117)
	for _frame in range(4):
		await process_frame
	scene.run_state.inventory["focus_tonic"] = 1
	for crew in scene.turn.player_units(true):
		crew.weapon_accuracy_bonus -= 0.25
		crew.base_movement = 20 if crew.roster_id == "ada" else 1
	# Re-author the visible choices after adding the test inventory. Gear is now
	# committed by the player-facing plan instead of consumed opportunistically.
	var car_data: Dictionary = scene.run_state.car_data(scene.run_state.current_car_id).duplicate(true)
	car_data["id"] = scene.run_state.current_car_id
	scene._begin_autobattle_planning(car_data, scene.run_state.squad_bonuses)
	for _frame in range(3):
		await process_frame
	scene.autobattle_director.consumable_used.connect(func(item_id: String, _unit: TacticalUnit) -> void:
		used_items.append(item_id)
	)

	var selected_index := -1
	for index in range(scene.autobattle_ui.plans.size()):
		if String(scene.autobattle_ui.plans[index].get("id", "")) == "break_the_hands":
			selected_index = index
			break
	if selected_index < 0:
		_fail("The Boarding plan set omitted Break the Trigger Hand.")
		return
	# Force this smoke test to exercise gear rather than a signature accuracy buff.
	var plan: Dictionary = scene.autobattle_ui.plans[selected_index]
	var orders: Dictionary = plan.get("orders", {})
	for crew_id in orders.keys():
		var order: Dictionary = orders[crew_id]
		order["use_ability"] = false
		orders[crew_id] = order
	plan["orders"] = orders
	scene.autobattle_ui.plans[selected_index] = plan
	scene.autobattle_ui._select_plan(selected_index)
	scene.autobattle_ui._select_fallback(0)
	scene.autobattle_ui._confirm_plan()
	scene.autobattle_director.set_speed(4.0)

	var timeout := 1800
	while used_items.is_empty() and scene.turn.encounter_active and timeout > 0:
		timeout -= 1
		await process_frame
	if timeout <= 0 or "focus_tonic" not in used_items:
		_fail("The automatic plan never committed the available Focus Tonic to a difficult called shot.")
		return
	if int(scene.run_state.inventory.get("focus_tonic", -1)) != 0:
		_fail("The director used a tonic without removing it from persistent inventory.")
		return
	if int(scene.run_state.run_stats.get("items_used", 0)) < 1:
		_fail("Automatic gear use was not recorded in run statistics.")
		return
	var milestone_found := false
	for milestone in scene.autobattle_director.milestones:
		if "Focus Tonic" in milestone:
			milestone_found = true
	if not milestone_found:
		_fail("Automatic gear use did not produce an explained combat milestone.")
		return

	scene.autobattle_director.stop()
	print("BRASSLINE AUTOBATTLER CONSUMABLES: PASS - plan-aware Focus Tonic use, intent/milestone explanation, persistent inventory decrement, and statistics verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER CONSUMABLES: FAIL - %s" % message)
	quit(1)
