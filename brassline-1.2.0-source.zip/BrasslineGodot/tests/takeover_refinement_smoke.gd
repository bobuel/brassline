extends SceneTree

const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame

	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 271828)
	scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew"])
	scene.run_state.current_car_id = "armory"
	scene.run_state.phase = "encounter"
	scene.run_state.inventory["clockwork_grenade"] = 1
	await scene._load_run_encounter()
	for _frame in range(4):
		await process_frame

	var split_target_plan := false
	var grenade_plan := false
	var families := {}
	for plan in scene.autobattle_ui.plans:
		families[String(plan.get("execution_family", ""))] = true
		var target_ids := {}
		for order_value in Dictionary(plan.get("orders", {})).values():
			var target_id := int(Dictionary(order_value).get("target_instance_id", 0))
			if target_id != 0:
				target_ids[target_id] = true
		if target_ids.size() >= 2:
			split_target_plan = true
		if String(plan.get("gear_item", "")) == "clockwork_grenade":
			grenade_plan = true
	if scene.autobattle_ui.plans.size() < 3 or families.size() < 3 or not split_target_plan:
		_fail("The Armory dossier did not offer at least three materially different plans including divided threat assignments (plans=%d families=%d split=%s enemies=%d)." % [scene.autobattle_ui.plans.size(), families.size(), split_target_plan, scene.turn.enemy_units(true).size()])
		return
	if not grenade_plan:
		_fail("A carried Clockwork Grenade was not explicitly committed by any viable Armory plan.")
		return

	var surrender_candidate: TacticalUnit
	for enemy in scene.turn.enemy_units(true):
		if enemy.role_id not in ["officer", "boss"]:
			surrender_candidate = enemy
			break
	if not is_instance_valid(surrender_candidate):
		_fail("The Armory fixture did not provide an ordinary guard for surrender testing.")
		return
	for enemy in scene.turn.enemy_units(true):
		if enemy.role_id in ["officer", "boss"]:
			enemy.apply_damage(Types.BodyZone.ARMS, 999, true)
	surrender_candidate.apply_damage(Types.BodyZone.ARMS, 999, true)
	scene.turn._resolve_surrenders()
	if not surrender_candidate.has_surrendered or surrender_candidate in scene.turn.enemy_units(true):
		_fail("An isolated guard with crippled arms remained an active combatant.")
		return

	for enemy in scene.turn.enemy_units(true):
		enemy.force_surrender()
	var claimant: TacticalUnit = scene.turn.player_units(true)[0]
	claimant.grid_cell = scene.board.control_cell + Vector2i(-1, 0)
	claimant.position = scene.board.cell_to_world(claimant.grid_cell) + Vector3(0.0, 0.12, 0.0)
	claimant.action_points = 2
	scene.turn.encounter_mode = "takeover_finale"
	scene.turn.encounter_active = true
	scene.turn.phase = Types.Phase.PLAYER
	scene.turn.select_unit(claimant)
	if not scene.turn.try_claim_control() or not scene.board.control_claimed:
		_fail("A cleared engine station could not be claimed by an adjacent operative.")
		return
	if int(scene.turn.encounter_stats.get("train_seized", 0)) != 1 or scene.turn.phase != Types.Phase.VICTORY:
		_fail("Claiming cleared engine controls did not resolve the train-takeover victory.")
		return

	print("BRASSLINE TAKEOVER REFINEMENT: PASS - plan families, split targets, explicit grenade commitment, crippling surrender, control capture, and takeover victory verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE TAKEOVER REFINEMENT: FAIL - %s" % message)
	quit(1)
