extends SceneTree

const ShareCard := preload("res://scripts/heist_share_card.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = ShareCard.CARD_SIZE
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.transparent_bg = false
	root.add_child(viewport)
	var card := ShareCard.new()
	viewport.add_child(card)
	card.setup({
		"grade": "A",
		"route": "Boarding → Dining → Armory → Engine",
		"seed": 424242,
		"difficulty": "STANDARD",
		"survivors": 3,
		"crew": [
			{"name": "Ada Brass", "role": "SHARPSHOOTER", "condition": "SURVIVED / ARMS SCAR", "mastery": 7, "finish": "night_rail"},
			{"name": "Marlow Pike", "role": "VANGUARD", "condition": "SURVIVED", "mastery": 5, "finish": "brassbound"},
			{"name": "Nix Bell", "role": "SABOTEUR", "condition": "SURVIVED / LEGS SCAR", "mastery": 6, "finish": "weathered"},
		],
		"injuries": "ADA: ARMS CRIPPLED  •  NIX: LEGS CRIPPLED",
		"decisive_moment": "Nix turned the pressure valve and Marlow seized the locomotive controls.",
		"run_code": "BR1.424242.N.T.ada+marlow+nix.A1B2C3",
		"blueprint_knowledge": 24,
	})
	for _frame in range(4):
		await process_frame
	if card.size != Vector2(1280, 720):
		_fail("Share card composition was not 1280x720.")
		return
	for required_text in ["HEIST RECORD", "GRADE A", "ADA BRASS", "DECISIVE MOMENT", "CHALLENGE CODE", "BR1.424242"]:
		if not _tree_has_text(card, required_text):
			_fail("Share card omitted required content: %s" % required_text)
			return
	var image: Image
	if DisplayServer.get_name() != "headless":
		var texture := viewport.get_texture()
		image = texture.get_image() if texture != null else null
	if image != null and (image.get_width() != 1280 or image.get_height() != 720):
		_fail("Rendered share card was not 1280x720.")
		return
	if image != null:
		if image.save_png("res://preview_heist_card.png") != OK:
			_fail("Share card PNG could not be saved with an active renderer.")
			return
	print("BRASSLINE HEIST SHARE CARD: PASS - crew, route, grade, injuries, decisive moment, Blueprint Knowledge, challenge code, and 1280x720 export composition verified.")
	quit(0)


func _tree_has_text(node: Node, fragment: String) -> bool:
	if node is Label and fragment in String((node as Label).text):
		return true
	for child in node.get_children():
		if _tree_has_text(child, fragment):
			return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE HEIST SHARE CARD: FAIL - %s" % message)
	quit(1)
