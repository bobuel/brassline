extends SceneTree

const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(4):
		await process_frame

	var crew = scene.turn.player_units(true)
	var enemies = scene.turn.enemy_units(true)
	if crew.size() < 3 or enemies.is_empty():
		_fail("Expected the full crew and enemy roster.")
		return

	var shooter = crew[2]
	var target = enemies[0]
	scene.turn.select_unit(shooter)
	scene.turn.set_target(target)
	scene.turn.set_target_zone(Types.BodyZone.ARMS)
	await scene.turn.try_attack(target)
	if shooter.action_points != 0:
		_fail("A limb called shot did not spend its 2 AP cost.")
		return

	var result: Dictionary = target.apply_damage(Types.BodyZone.LEGS, 99, true)
	if not bool(result["detached"]) or not target.is_zone_detached(Types.BodyZone.LEGS):
		_fail("A destroyed leg was not marked and rendered as detached.")
		return
	if scene.turn.attack_chance(shooter, target, Types.BodyZone.LEGS) != 0.0:
		_fail("A detached limb remained targetable.")
		return
	var character_fragment_found := false
	for child in scene.get_children():
		if child is RigidBody3D and bool(child.get_meta("character_mesh_fragment", false)):
			var fragment_visual := child.get_node_or_null("SkinnedCharacterLimb") as MeshInstance3D
			character_fragment_found = fragment_visual != null and fragment_visual.mesh is ArrayMesh and fragment_visual.mesh.get_surface_count() > 0
			if character_fragment_found:
				break
	if not character_fragment_found:
		_fail("Limb detachment fell back to a primitive proxy instead of character mesh geometry.")
		return

	var mover = crew[0]
	var destination: Vector2i = mover.grid_cell + Vector2i.UP
	var movement_path: Array[Vector2i] = [mover.grid_cell, destination]
	mover.move_along_path(movement_path)
	await process_frame
	if not mover.is_moving:
		_fail("Grid movement did not enter its animated locomotion state.")
		return
	var character_visual := mover.get_node_or_null("CharacterVisual") as CharacterVisual
	if character_visual == null or character_visual.animation_player == null:
		_fail("The moving unit lost its rig or animation player.")
		return
	if character_visual.animation_player.current_animation not in ["Run_Shoot", "Run", "Walk"]:
		_fail("Grid movement did not play a locomotion animation.")
		return
	await mover.movement_finished
	if mover.grid_cell != destination or TacticalUnit.GRID_RUN_SPEED > 5.0:
		_fail("Grid movement skipped its destination or still advances at the old skating speed.")
		return

	var arm_casualty: TacticalUnit = crew[1]
	arm_casualty.ammunition = 0
	arm_casualty.apply_damage(Types.BodyZone.ARMS, 99, true)
	if not arm_casualty.arms_crippled() or arm_casualty.accuracy_penalty() < 0.36 or arm_casualty.damage_multiplier() > 0.50:
		_fail("Destroyed arms did not apply the severe accuracy and weapon-damage penalties.")
		return
	if arm_casualty.can_reload() or arm_casualty.can_overwatch():
		_fail("An operative with destroyed arms could still reload or hold overwatch.")
		return
	mover.apply_damage(Types.BodyZone.LEGS, 99, true)
	if not mover.legs_crippled() or mover.movement_range() != 1 or mover.can_take_cover() or mover.enter_cover_stance():
		_fail("Destroyed legs did not restrict movement to one tile and prevent taking cover.")
		return

	print("BRASSLINE COMBAT SMOKE: PASS - four-zone called shots, paired character-mesh limbs, crippling action penalties, and animated locomotion verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE COMBAT SMOKE: FAIL - %s" % message)
	quit(1)
