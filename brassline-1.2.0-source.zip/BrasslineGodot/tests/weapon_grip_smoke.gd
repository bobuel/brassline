extends SceneTree

const MODELS := ["Casual_2", "Adventurer", "Punk", "Worker", "Suit", "Swat"]
const WEAPONS := ["longshot_rifle", "breach_gun", "coil_pistol", "rivet_carbine", "duelist_revolver", "hand_cannon"]

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var capture := "--capture-weapons" in OS.get_cmdline_user_args()
	var stage := Node3D.new(); root.add_child(stage); current_scene = stage
	if capture:
		root.size = Vector2i(1600,900)
		var world := WorldEnvironment.new(); var environment := Environment.new()
		environment.background_mode = Environment.BG_COLOR; environment.background_color = Color("#152a2e")
		environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR; environment.ambient_light_energy = 0.8
		world.environment = environment; stage.add_child(world)
		var key := DirectionalLight3D.new(); key.rotation_degrees = Vector3(-35,-30,0); key.light_energy = 1.8; stage.add_child(key)
		var camera := Camera3D.new(); camera.fov=35; stage.add_child(camera)
		camera.look_at_from_position(Vector3(3.4,2.3,5.0),Vector3(0,1.0,0.2),Vector3.UP); camera.current=true
	for index in range(MODELS.size()):
		var visual := CharacterVisual.new(); stage.add_child(visual)
		visual.setup("res://assets/characters/quaternius/%s.gltf" % MODELS[index], 0)
		visual.build_weapon(WEAPONS[index])
		for clip in ["Idle_Gun_Pointing", "Idle_Gun_Shoot"]:
			visual.animation_player.play(clip); visual.animation_player.advance(0.12); visual.animation_player.pause()
			for frame in range(3): await process_frame
			var direction := visual.weapon_root.global_basis.z.normalized()
			if direction.dot(Vector3.BACK) < 0.90:
				push_error("Weapon points away from the animation's aim: %s / %s / %s" % [MODELS[index], clip, direction]); quit(1); return
			if visual.weapon_root.global_basis.y.normalized().dot(Vector3.UP) < 0.80:
				push_error("Weapon is upside down: %s / %s" % [MODELS[index], clip]); quit(1); return
			if visual.weapon_root.global_position.y < 0.9:
				push_error("Weapon mount stayed below the hand: %s / %s" % [MODELS[index],clip]); quit(1); return
			if is_instance_valid(visual._support_pose) and float(visual._support_pose.get("last_hand_error")) > 0.035:
				push_error("Support hand missed its grip: %s / %.3f" % [MODELS[index],float(visual._support_pose.get("last_hand_error"))]); quit(1); return
		if capture and index < 3:
			visual.position.x = (index-1)*1.6
		else: visual.free()
	if capture:
		for frame in range(12): await process_frame
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png("res://preview_weapon_grips.png")
	print("BRASSLINE WEAPON GRIP: PASS - all six characters aim equipped weapons forward and upright in pointing/shoot clips.")
	quit(0)
