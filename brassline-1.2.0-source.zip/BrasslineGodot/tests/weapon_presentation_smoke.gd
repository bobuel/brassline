extends SceneTree

const ROSTER := [["Casual_2","longshot_rifle"],["Adventurer","breach_gun"],["Punk","coil_pistol"],["Worker","rivet_carbine"],["Suit","duelist_revolver"],["Swat","hand_cannon"]]

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var stage:=Node3D.new();root.add_child(stage);current_scene=stage
	for member in ROSTER:
		var visual:=CharacterVisual.new();stage.add_child(visual)
		visual.setup("res://assets/characters/quaternius/%s.gltf"%member[0],0);visual.build_weapon(member[1])
		visual.animation_player.play("Idle_Gun_Pointing");visual.animation_player.advance(0.12)
		for frame in range(4):await process_frame
		if visual.weapon_root.get_meta("silhouette_version",0)!=2:_fail("Old weapon silhouette: "+member[1]);return
		if visual.muzzle_socket.position.z<0.25:_fail("Muzzle is not at the barrel tip.");return
		var before:=visual.weapon_root.position
		visual._play_weapon_recoil()
		if not visual._muzzle_flash.visible or not visual._muzzle_light.visible:_fail("Firing has no flash.");return
		await create_timer(0.026).timeout
		var recoil:=visual.weapon_root.position-before
		var expected:=Vector3.FORWARD if is_instance_valid(visual._weapon_mount) else Vector3.DOWN
		if recoil.dot(expected)<0.004:_fail("Recoil is not backward along the bore.");return
		await create_timer(0.30).timeout
		if visual._muzzle_flash.visible or visual.weapon_root.position.distance_to(before)>0.003:_fail("Recoil does not settle.");return
		visual.play_death()
		if is_instance_valid(visual._support_pose):
			if visual._support_pose.arms_available or visual.weapon_root.get_parent()!=visual.weapon_attachment:_fail("Dead long gun floats outside the wrist rig.");return
		visual.free()
	# Recovery constructs dead preview models before attaching its viewport.
	var detached:=CharacterVisual.new()
	detached.setup("res://assets/characters/quaternius/Casual_2.gltf",0);detached.build_weapon("longshot_rifle");detached.play_death()
	if detached.weapon_root.get_parent()!=detached.weapon_attachment:_fail("Off-tree death does not attach its weapon.");return
	detached.free()
	print("BRASSLINE WEAPON PRESENTATION: PASS - six silhouettes, muzzle placement, visible flash, axial recoil/settle and death attachment.")
	quit(0)

func _fail(message:String)->void:
	push_error("BRASSLINE WEAPON PRESENTATION: FAIL - "+message);quit(1)
