extends SceneTree

const SIZES := [Vector2i(1280, 720), Vector2i(1280, 800), Vector2i(1920, 1080)]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	for capture_size in SIZES:
		root.content_scale_size = capture_size
		root.size = capture_size
		var scene = load("res://scenes/main.tscn").instantiate()
		root.add_child(scene)
		current_scene = scene
		for _frame in range(10):
			await process_frame
		scene.campaign_ui.show_crew_selection()
		for _frame in range(18):
			await process_frame
		if not _save_frame("crew", capture_size):
			return
		var crew_ids: Array[String] = ["ada", "marlow", "nix"]
		await scene._on_crew_confirmed(crew_ids, 630000 + capture_size.y)
		for _frame in range(12):
			await process_frame
		if not _assert_inside(scene.autobattle_ui.confirm_button, capture_size, "planning commit") or not _save_frame("planning", capture_size):
			return
		scene.autobattle_ui.set_text_scale(1.30)
		scene.autobattle_ui._toggle_fallback_picker()
		await process_frame
		if not _assert_inside(scene.autobattle_ui.fallback_picker, capture_size, "130% fallback picker"):
			return
		for button in scene.autobattle_ui.fallback_buttons:
			if not _assert_inside(button, capture_size, "fallback choice"):
				return
		scene.autobattle_ui.fallback_picker.visible = false
		scene.autobattle_ui.toggle_inspector("ada")
		for _frame in range(4): await process_frame
		if not _assert_inside(scene.autobattle_ui.inspector_panel, capture_size, "Crew Ledger") or not _save_frame("ledger", capture_size):
			return
		scene.autobattle_ui.inspector_panel.visible = false
		scene.autobattle_ui.set_text_scale(1.0)
		scene.autobattle_ui._select_plan(1)
		scene.autobattle_ui._select_fallback(1)
		scene.autobattle_ui._confirm_plan()
		scene.autobattle_director.set_speed(2.0)
		var combat_timeout := 900
		while scene.autobattle_director.activation_count < 1 and combat_timeout > 0:
			combat_timeout -= 1
			await process_frame
		if combat_timeout <= 0:
			_fail("Combat did not begin at %s." % str(capture_size))
			return
		scene.autobattle_director.set_paused(true)
		for _frame in range(10):
			await process_frame
		if not _assert_inside(scene.autobattle_ui.pause_button, capture_size, "combat controls") or not _save_frame("combat", capture_size):
			return
		scene.autobattle_director.set_paused(false)
		scene.autobattle_director.set_speed(4.0)
		for enemy in scene.turn.enemy_units(true):
			enemy.apply_damage(1, 999, true)
		var aftermath_timeout := 1800
		while not scene.autobattle_ui.aftermath_root.visible and aftermath_timeout > 0:
			aftermath_timeout -= 1
			await process_frame
		if aftermath_timeout <= 0:
			_fail("Aftermath did not appear at %s." % str(capture_size))
			return
		for _frame in range(10):
			await process_frame
		if not _assert_inside(scene.autobattle_ui.aftermath_continue, capture_size, "aftermath continue") or not _save_frame("aftermath", capture_size):
			return
		scene._on_aftermath_continue_requested()
		for _frame in range(4): await process_frame
		if scene.run_state.phase == "intermission" and not scene.run_state.current_offers.is_empty():
			scene._on_car_prep_requested(String(scene.run_state.current_offers[0]))
			for _frame in range(8): await process_frame
			if not _assert_inside(scene.campaign_ui.prep_board_button, capture_size, "recovery board") or not _save_frame("recovery", capture_size):
				return
		scene.queue_free()
		await process_frame
	print("BRASSLINE TEEN-READINESS VISUAL CAPTURE: PASS - crew, planning, 130% fallback, Ledger, combat, recovery, and aftermath rendered at 1280x720, 1280x800, and 1920x1080.")
	quit(0)


func _save_frame(stage: String, capture_size: Vector2i) -> bool:
	var texture := root.get_texture()
	if texture == null:
		_fail("No render texture was available for %s at %s." % [stage, str(capture_size)])
		return false
	var image := texture.get_image()
	if image == null:
		_fail("No rendered image was available for %s at %s." % [stage, str(capture_size)])
		return false
	var path := "res://preview_teen_%s_%dx%d.png" % [stage, capture_size.x, capture_size.y]
	if image.save_png(path) != OK:
		_fail("Could not save %s." % path)
		return false
	return true


func _assert_inside(control: Control, capture_size: Vector2i, label: String) -> bool:
	var rect := control.get_global_rect()
	if rect.position.x < -0.5 or rect.position.y < -0.5 or rect.end.x > float(capture_size.x) + 0.5 or rect.end.y > float(capture_size.y) + 0.5:
		_fail("%s is clipped at %s: %s" % [label, str(capture_size), str(rect)])
		return false
	return true


func _fail(message: String) -> void:
	push_error("BRASSLINE TEEN-READINESS VISUAL CAPTURE: FAIL - %s" % message)
	quit(1)
