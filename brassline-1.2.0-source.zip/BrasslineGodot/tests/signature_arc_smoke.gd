extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")
const RunState := preload("res://scripts/run_state.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	scene.campaign_ui.selected_difficulty = "story"
	await scene._on_crew_confirmed(crew_ids, 731993)
	for _frame in range(4):
		await process_frame

	if not _has_plan(scene.autobattle_ui.plans, "lash_the_freight") or not _has_plan(scene.autobattle_ui.plans, "break_the_hands"):
		var offered: Array[String] = []
		for plan in scene.autobattle_ui.plans: offered.append(String(plan.get("id", "")))
		_fail("Boarding did not offer both its moving-train counter and anatomical doctrine counter. Offered: %s / phase=%s planning=%s encounter=%s car=%s units=%d" % [", ".join(offered), scene.run_state.phase, scene.autobattle_ui.planning_root.visible, scene.turn.encounter_active, scene.run_state.current_car_id, scene.turn.units.size()])
		return
	# The compact header shows the hazard; exact counter copy is in optional Details,
	# while the enemy's on-board caption identifies its tactical threat/body counter.
	if not scene.autobattle_ui.scene_report_label.is_visible_in_tree() or "LOOSE FREIGHT" not in scene.autobattle_ui.scene_report_label.text:
		_fail("Boarding planning did not visibly identify the living-train hazard.")
		return
	scene.autobattle_ui.toggle_plan_details()
	await process_frame
	var boarding_profile := SignatureArc.car_profile("baggage")
	if not scene.autobattle_ui.plan_detail_body.is_visible_in_tree() or "LOOSE FREIGHT" not in scene.autobattle_ui.plan_detail_body.text or String(boarding_profile.get("counter_text", "missing counter")) not in scene.autobattle_ui.plan_detail_body.text:
		_fail("Opened Plan Details omitted the living-train hazard or its exact counter.")
		return
	if "CHAIN OF CUSTODY" not in scene.autobattle_ui.plan_detail_body.text or String(boarding_profile.get("doctrine_text", "missing doctrine")) not in scene.autobattle_ui.plan_detail_body.text:
		_fail("Opened Plan Details omitted the exact enemy doctrine and anatomical counter.")
		return
	scene.autobattle_ui.toggle_plan_details()
	var boarding_guard: TacticalUnit = scene.turn.enemy_units(true)[0]
	if not boarding_guard._status_label.is_visible_in_tree() or boarding_guard._status_label.text != scene._enemy_threat_summary(boarding_guard) or "ARMS" not in boarding_guard._status_label.text:
		_fail("The on-board guard caption omitted its tactical threat and anatomical counter.")
		return
	var warning := SignatureArc.event_for_round("baggage", 1)
	var impact := SignatureArc.event_for_round("baggage", 2)
	if String(warning.get("phase", "")) != "warning" or String(impact.get("phase", "")) != "impact":
		_fail("Boarding train event did not telegraph one round before impact.")
		return
	scene.train_art.set_living_train_event(warning, {})
	if scene.train_art._train_event_root.get_child_count() != Array(warning.get("cells", [])).size():
		_fail("The carriage floor did not render one purposeful hazard mark for every telegraphed cell.")
		return
	var exposed: TacticalUnit = scene.turn.player_units(true)[0]
	exposed.grid_cell = Vector2i(3, 1)
	var legs_before := int(exposed.body_state[Types.BodyZone.LEGS]["hp"])
	var hazard_result: Dictionary = scene.turn.resolve_living_train_event(impact, false)
	if int(exposed.body_state[Types.BodyZone.LEGS]["hp"]) >= legs_before or not bool(exposed.get_meta("train_staggered", false)) or exposed.display_name not in Array(hazard_result.get("crew_victims", [])):
		_fail("Loose Freight did not damage legs, stagger the exposed operative, and report the victim.")
		return
	var countered_result: Dictionary = scene.turn.resolve_living_train_event(impact, true)
	if not bool(countered_result.get("countered", false)):
		_fail("The authored freight counter did not neutralize the train event.")
		return
	var boarding_doctrine: Dictionary = scene.turn.apply_enemy_doctrine_round()
	if bool(boarding_doctrine.get("broken", true)) or String(boarding_doctrine.get("focus_name", "")).is_empty():
		_fail("Chain of Custody did not visibly select a concentrated-fire target.")
		return

	# Crew campaign state must create both story and combat consequences and survive save/load.
	var campaign = RunState.new()
	campaign.start_new_run(crew_ids, 4451, "standard")
	var consequences := campaign.resolve_crew_consequences(
		{"id": "trust_test", "title": "Trust the crossing", "risk_unit_id": "marlow", "assignments": {"anchor": "marlow", "shooter": "ada", "scout": "nix"}},
		{"id": "protect_wounded"},
		{"victory": true, "fallback_triggered": true, "injuries": [{"roster_id": "marlow", "name": "Marlow Pike", "down": false, "changes": ["Legs 4/7"]}]}
	)
	if consequences.is_empty() or int(campaign.crew_relationships.get("ada|marlow", {}).get("bond", 0)) < 2:
		_fail("Protecting the risk carrier did not create a persistent trust event.")
		return
	var saved: Dictionary = campaign.to_save_data()
	if int(saved.get("version", 0)) != 7:
		_fail("The crew-campaign schema was not written as save version 7.")
		return
	var loaded = RunState.new()
	if not loaded.load_from_save_data(saved) or int(loaded.crew_relationships.get("ada|marlow", {}).get("bond", 0)) < 2:
		_fail("Crew trust and memories did not survive checkpoint serialization.")
		return

	# Dining: the officer's body state must directly control the whole doctrine.
	scene.autobattle_director.stop()
	scene.run_state.completed_car_ids.assign(["baggage"])
	scene.run_state.current_car_id = "dining"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	for _frame in range(4): await process_frame
	if not _has_plan(scene.autobattle_ui.plans, "lock_the_service_cart") or "HARD CURVE" not in scene.autobattle_ui.scene_report_label.text:
		_fail("Dining did not offer its cart brace or identify the hard curve.")
		return
	var dining_doctrine: Dictionary = scene.turn.apply_enemy_doctrine_round()
	var officer: TacticalUnit
	for enemy in scene.turn.enemy_units(true):
		if enemy.role_id == "officer": officer = enemy
	if not is_instance_valid(officer) or bool(dining_doctrine.get("broken", true)):
		_fail("Dining did not spawn an active officer doctrine.")
		return
	officer.apply_damage(Types.BodyZone.ARMS, 999, true)
	dining_doctrine = scene.turn.apply_enemy_doctrine_round()
	if not bool(dining_doctrine.get("broken", false)):
		_fail("Crippling the Dining officer's arms did not dismantle the doctrine.")
		return

	# Engine: Voss owns a different doctrine with a different anatomical counter.
	scene.autobattle_director.stop()
	scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew", "armory", "observation"])
	scene.run_state.current_car_id = "engine"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	for _frame in range(4): await process_frame
	if not _has_plan(scene.autobattle_ui.plans, "break_voss_timing") or not _has_plan(scene.autobattle_ui.plans, "bleed_the_pressure"):
		_fail("Engine did not offer both the Voss called-shot counter and pressure-valve plan.")
		return
	var engine_doctrine: Dictionary = scene.turn.apply_enemy_doctrine_round()
	var boss: TacticalUnit
	for enemy in scene.turn.enemy_units(true):
		if enemy.role_id == "boss": boss = enemy
	if not is_instance_valid(boss) or bool(engine_doctrine.get("broken", true)) or absf(boss.signature_accuracy_bonus - 0.08) > 0.001:
		_fail("Voss's Redline did not grant its exact +8% aim doctrine.")
		return
	boss.apply_damage(Types.BodyZone.HEAD, 999, true)
	engine_doctrine = scene.turn.apply_enemy_doctrine_round()
	if not bool(engine_doctrine.get("broken", false)):
		_fail("Crippling Voss's head did not end Redline timing.")
		return

	print("BRASSLINE SIGNATURE ARC: PASS - three authored cars, telegraphed train hazards, physical floor marks, distinct body-countered enemy doctrines, persistent trust, nerve, memories, and save migration verified.")
	quit(0)


func _has_plan(plans: Array[Dictionary], plan_id: String) -> bool:
	for plan in plans:
		if String(plan.get("id", "")) == plan_id:
			return true
	return false


func _fail(message: String) -> void:
	push_error("BRASSLINE SIGNATURE ARC: FAIL - %s" % message)
	quit(1)
