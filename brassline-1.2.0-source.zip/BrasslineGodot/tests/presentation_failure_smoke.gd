extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 918273)
	var plan: Dictionary = scene.autobattle_ui.plans[0].duplicate(true)
	var fallback := PlanCatalog.fallback_data("protect_wounded")
	scene.autobattle_director.configure(plan, fallback, {})
	var event_types: Array[String] = []
	scene.autobattle_director.presentation_beat.connect(func(beat: Dictionary) -> void: event_types.append(String(beat.get("type", ""))))
	var crew: Array[TacticalUnit] = scene.turn.player_units(true)
	var enemies: Array[TacticalUnit] = scene.turn.enemy_units(true)
	var risk_target := crew[0]
	for candidate in crew:
		if candidate.roster_id == String(plan.get("risk_unit_id", "")):
			risk_target = candidate
	# Record a real protection trigger before the synthetic decisive sequence;
	# aftermath may describe a defense that was applied, but not invented moves.
	risk_target.body_state[Types.BodyZone.TORSO]["hp"] = 2
	scene.autobattle_director._apply_plan_guard_to_crew()
	if not is_equal_approx(risk_target.damage_resistance, 0.46):
		_fail("The critically wounded risk carrier did not receive actual fallback protection.")
		return
	scene.autobattle_director._on_environment_resolved("test_valve", crew[0], {"ok": true, "victims": []})
	scene.autobattle_director._on_attack_resolved(crew[0], enemies[0], Types.BodyZone.ARMS, {"hit": true, "damage": 4, "disabled": true, "detached": false, "defeated": false})
	scene.autobattle_director._on_attack_resolved(enemies[0], risk_target, Types.BodyZone.TORSO, {"hit": true, "damage": 8, "disabled": false, "detached": false, "defeated": true})
	crew[1].apply_damage(Types.BodyZone.TORSO, 999, true)
	crew[2].apply_damage(Types.BodyZone.TORSO, 999, true)
	scene.autobattle_director._update_plan_integrity()
	scene.autobattle_director.record_mission_result(false, "THE CREW IS DOWN")
	var expected_order := ["environment", "cripple", "casualty", "plan_break", "defeat"]
	if event_types != expected_order:
		_fail("Presentation events were out of order: %s" % str(event_types))
		return
	var aftermath: Dictionary = scene.autobattle_director.build_aftermath(false)
	if Array(aftermath.get("decisive_beats", [])).size() != expected_order.size():
		_fail("Consequential beats were not preserved for the aftermath.")
		return
	var analysis: Dictionary = aftermath.get("failure_analysis", {})
	for required_key in ["why_plan_broke", "fallback_effect", "decisive_injury", "suggested_adjustment"]:
		if String(analysis.get(required_key, "")).is_empty():
			_fail("Failure analysis omitted %s." % required_key)
			return
	if "46%" not in String(analysis.get("fallback_effect", "")):
		_fail("Protect the Wounded did not report its exact protection.")
		return
	if not Dictionary(analysis.get("fallback_protection", {})).has(risk_target.display_name) or not Array(analysis.get("fallback_actions", [])).is_empty() or "No protective movement" not in String(analysis.get("fallback_effect", "")):
		_fail("Aftermath did not distinguish applied protection from unexecuted movement.")
		return
	if String(analysis.get("risk_carrier", "")).is_empty() or int(analysis.get("risk_exposures", 0)) < 1:
		_fail("Risk-carrier exposure was not recorded.")
		return
	var sequences: Array[int] = []
	scene.autobattle_director.presentation_beat.connect(func(beat: Dictionary) -> void: sequences.append(int(beat.get("sequence", 0))))
	for index in range(20):
		scene.autobattle_director._emit_presentation_beat("environment", null, null, {"countered": false})
	for index in range(1, sequences.size()):
		if sequences[index] <= sequences[index - 1]:
			_fail("Presentation sequence repeated after the twelve-highlight buffer filled.")
			return
	if scene.autobattle_director._bark_for_beat("casualty", crew[0], enemies[0], {}).begins_with("Crew down") or scene.autobattle_director._bark_for_beat("environment", null, null, {"countered": false}) == "The train works for us now.":
		_fail("Presentation barks misidentified an enemy casualty or uncountered hazard.")
		return
	print("BRASSLINE PRESENTATION/FAILURE: PASS - ordered presentation beats, three-highlight source data, plan-break cause, risk exposure, decisive injury, exact fallback protection, and adjustment guidance verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE PRESENTATION/FAILURE: FAIL - %s" % message)
	quit(1)
