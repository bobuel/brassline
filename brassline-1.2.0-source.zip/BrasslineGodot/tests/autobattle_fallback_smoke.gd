extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8): await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 97501)
	scene.run_state.completed_car_ids.append("baggage")
	scene.run_state.current_car_id = "dining"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	var plan: Dictionary
	for candidate in scene.autobattle_ui.plans:
		if String(candidate.get("id", "")) == "pin_the_command":
			plan = candidate
	if plan.is_empty():
		_fail("Dining did not provide the officer-priority plan needed for fallback checks.")
		return
	var director: AutobattleDirector = scene.autobattle_director
	var ada := _crew(scene, "ada")
	var marlow := _crew(scene, "marlow")
	var nix := _crew(scene, "nix")
	var officer := _enemy(scene, "officer")
	var bruiser := _enemy(scene, "bruiser")

	# Finish Target must preserve the authored Officer even when the Bruiser is an
	# easier torso kill.
	var bruiser_torso: Dictionary = bruiser.body_state[Types.BodyZone.TORSO]
	bruiser_torso["hp"] = 1
	bruiser.body_state[Types.BodyZone.TORSO] = bruiser_torso
	director.configure(plan, PlanCatalog.fallback_data("finish_target"))
	var ada_order: Dictionary = Dictionary(plan.get("orders", {})).get("ada", {})
	if director._choose_target(ada, ada_order) != officer:
		_fail("Finish Target abandoned the authored Officer for the easier guard.")
		return

	# Protect Wounded adds a stronger defensive layer once torso health is critical.
	var ada_torso: Dictionary = ada.body_state[Types.BodyZone.TORSO]
	ada_torso["hp"] = 3
	ada.body_state[Types.BodyZone.TORSO] = ada_torso
	director.configure(plan, PlanCatalog.fallback_data("protect_wounded"))
	director._update_plan_integrity()
	if director.current_plan_status != "adapting" or director._plan_resistance(ada) < 0.46:
		_fail("Protect Wounded did not detect and defend a critical torso injury.")
		return

	# Save Crew activates only after the opening genuinely breaks under multiple
	# crippling injuries.
	for unit in [ada, marlow]:
		var legs: Dictionary = unit.body_state[Types.BodyZone.LEGS]
		legs["hp"] = 0
		legs["disabled"] = true
		unit.body_state[Types.BodyZone.LEGS] = legs
	director.configure(plan, PlanCatalog.fallback_data("save_crew"))
	director._update_plan_integrity()
	if director.current_plan_status != "broken" or director._plan_resistance(marlow) < 0.46:
		_fail("Save Crew did not take control after two operatives were crippled.")
		return

	# Improvise replaces the authored arm priority with each operative's instinct;
	# Nix attacks legs while Ada remains an arm breaker.
	director.configure(plan, PlanCatalog.fallback_data("improvise"))
	director.current_plan_status = "adapting"
	nix.action_points = 2
	ada.action_points = 2
	if director._choose_body_zone(nix, officer, Dictionary(plan.get("orders", {})).get("nix", {})) != Types.BodyZone.LEGS:
		_fail("Improvise did not switch Nix to her personal leg-disabling instinct.")
		return
	if director._choose_body_zone(ada, officer, ada_order) != Types.BodyZone.ARMS:
		_fail("Improvise did not preserve Ada's personal arm-breaking instinct.")
		return

	print("BRASSLINE AUTOBATTLER FALLBACKS: PASS - Finish Target, Protect Wounded, Save Crew, and role-specific Improvise behavior verified.")
	quit(0)


func _crew(scene: Node, roster_id: String) -> TacticalUnit:
	for unit in scene.turn.player_units(true):
		if unit.roster_id == roster_id: return unit
	return null


func _enemy(scene: Node, role_id: String) -> TacticalUnit:
	for unit in scene.turn.enemy_units(true):
		if unit.role_id == role_id: return unit
	return null


func _fail(message: String) -> void:
	push_error("BRASSLINE AUTOBATTLER FALLBACKS: FAIL - %s" % message)
	quit(1)
