extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const CombatCatalog := preload("res://scripts/combat_catalog.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	var crew_ids: Array[String] = ["ada", "iona", "rook"]
	await scene._on_crew_confirmed(crew_ids, 91021)
	var ada = _operative(scene, "ada")
	var iona = _operative(scene, "iona")
	var rook = _operative(scene, "rook")
	if not is_instance_valid(ada) or not is_instance_valid(iona) or not is_instance_valid(rook):
		_fail("The requested commercial-alpha crew was not spawned.")
		return
	if ada.weapon_id != "longshot_rifle" or ada.weapon_name != "Longshot Rifle" or ada.magazine_size != 4:
		_fail("Ada's weapon identity and magazine were not configured from the combat catalog.")
		return
	if iona.ability_id != "field_repair" or rook.ability_id != "iron_stance":
		_fail("Operative signature abilities were not assigned from the roster.")
		return
	if CombatCatalog.enemy_role("boss").get("label", "") != "BOSS":
		_fail("The elite enemy-role catalog is unavailable.")
		return

	var target = scene.turn.enemy_units(true)[0]
	# Keep this isolated weapon/API fixture alive across several actions; the real
	# one-guard opener is now deliberately short and may otherwise resolve at once.
	target.body_state[Types.BodyZone.TORSO]["hp"] = 99
	target.body_state[Types.BodyZone.TORSO]["max_hp"] = 99
	scene.turn.select_unit(ada)
	scene.turn.set_target(target)
	var base_chance: float = scene.turn.attack_chance(ada, target, Types.BodyZone.TORSO)
	if not scene.turn.try_signature_ability():
		_fail("Deadeye could not be activated on Ada's turn.")
		return
	if scene.turn.attack_chance(ada, target, Types.BodyZone.TORSO) <= base_chance:
		_fail("Deadeye did not improve Ada's next-shot hit chance.")
		return
	var ammo_before: int = ada.ammunition
	await scene.turn.try_attack(target)
	if ada.ammunition != ammo_before - 1 or int(scene.turn.encounter_stats.get("shots", 0)) != 1:
		_fail("A fired weapon did not consume one round and record the shot.")
		return
	if ada.focus_accuracy_bonus > 0.0 or ada.signature_accuracy_bonus > 0.0:
		_fail("Next-shot ability bonuses persisted after Ada fired.")
		return
	ada.ammunition = 0
	ada.action_points = 1
	if not scene.turn.try_reload() or ada.ammunition != ada.magazine_size or ada.action_points != 0:
		_fail("Reload did not spend 1 AP and restore the full magazine.")
		return

	var arm_before: int = int(iona.body_state[Types.BodyZone.ARMS]["hp"])
	iona.apply_damage(Types.BodyZone.ARMS, 3)
	var wounded_arm: int = int(iona.body_state[Types.BodyZone.ARMS]["hp"])
	scene.turn.select_unit(iona)
	if not scene.turn.try_signature_ability():
		_fail("Field Repair could not be used on a damaged body zone.")
		return
	if int(iona.body_state[Types.BodyZone.ARMS]["hp"]) <= wounded_arm or int(iona.body_state[Types.BodyZone.ARMS]["hp"]) > arm_before:
		_fail("Field Repair did not restore the damaged body zone correctly.")
		return

	scene.turn.select_unit(rook)
	if not scene.turn.try_signature_ability():
		_fail("Iron Stance could not be activated.")
		return
	var resisted: Dictionary = rook.apply_damage(Types.BodyZone.TORSO, 5)
	if int(resisted.get("damage", 0)) != 3:
		_fail("Iron Stance did not reduce five incoming damage to three.")
		return
	var overwatch_ammo: int = rook.ammunition
	if not scene.turn.try_overwatch() or not rook.overwatch_active:
		_fail("Overwatch could not be armed for 1 AP.")
		return
	# Spawns are deliberately outside the boarding crew's close-range weapons now.
	# Exercise a guard entering the lane, not an assumption that it starts there.
	target.grid_cell = rook.grid_cell + Vector2i(3, 0)
	target.position = scene.board.cell_to_world(target.grid_cell) + Vector3(0, 0.12, 0)
	if not scene.turn.can_attack(rook, target):
		_fail("The overwatch fixture did not place the approaching guard in a clear firing lane.")
		return
	await scene.turn._resolve_overwatch(target)
	if rook.overwatch_active or rook.ammunition != overwatch_ammo - 1:
		_fail("Overwatch did not interrupt a visible enemy and consume one round.")
		return
	if int(scene.turn.encounter_stats.get("overwatch_shots", 0)) != 1:
		_fail("The overwatch reaction was not recorded in encounter telemetry.")
		return

	print("BRASSLINE COMMERCIAL-ALPHA COMBAT SMOKE: PASS - weapons, magazines, reloads, signatures, resistance, roles, and overwatch verified.")
	quit(0)


func _operative(scene, roster_id: String):
	for unit in scene.turn.player_units(true):
		if unit.roster_id == roster_id:
			return unit
	return null


func _fail(message: String) -> void:
	push_error("BRASSLINE COMMERCIAL-ALPHA COMBAT SMOKE: FAIL - %s" % message)
	quit(1)
