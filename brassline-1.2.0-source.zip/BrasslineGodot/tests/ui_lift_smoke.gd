extends SceneTree

const Types := preload("res://scripts/game_types.gd")
var failures: Array[String] = []

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	root.size = Vector2i(1280, 720)
	root.content_scale_size = root.size
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene); current_scene = scene
	for frame in range(8): await process_frame
	var crew: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew, 882601)
	var ui: AutobattleUI = scene.autobattle_ui
	var campaign: CampaignUI = scene.campaign_ui
	var director: AutobattleDirector = scene.autobattle_director
	ui.toggle_plan_details()
	_check("CHAIN OF CUSTODY" in ui.plan_detail_body.text and "ARMS" in ui.plan_detail_body.text, "Planning Details hides the enemy doctrine/anatomical counter.")
	ui.toggle_plan_details()
	ui.current_inventory = {"clockwork_grenade": 1, "focus_tonic": 1, "medkit": 2, "limb_brace": 1}
	ui.plans[0]["gear_item"] = "clockwork_grenade"
	ui.plans[0]["gear_user_name"] = "Nix Bell"
	ui.plans[0]["gear_trigger"] = "Wait for a safe legal blast."
	ui.selected_plan_index = 0
	ui.show_inspector("nix")
	var ledger: CrewLedgerUI = ui.inspector_panel
	ledger._select_tab("gear")
	ui.set_text_scale(1.3)
	for frame in range(3): await process_frame
	_check(ledger.item_grid.visible and ledger.item_buttons.size() == 4, "Gear lacks visual supply cards.")
	_check("COMMITTED" in ledger.item_buttons["clockwork_grenade"].text and "Nix Bell" in ledger.detail_body.text, "Gear does not identify its committed operative.")
	scene.run_state.inventory = ui.current_inventory.duplicate(true)
	scene._on_autobattle_consumable_used("clockwork_grenade", ledger._selected_unit())
	_check(int(ui.current_inventory.get("clockwork_grenade", -1)) == 0 and "USED THIS CAR" in ledger.item_buttons["clockwork_grenade"].text, "Actual 1-to-0 consumption did not update the Ledger.")
	scene.run_state.inventory["clockwork_grenade"] = 2
	ui.current_inventory = scene.run_state.inventory.duplicate(true)
	ui.gear_outcomes.clear()
	scene._on_autobattle_consumable_used("clockwork_grenade", ledger._selected_unit())
	_check(int(ui.current_inventory.get("clockwork_grenade", -1)) == 1 and "USED THIS CAR" in ledger.item_buttons["clockwork_grenade"].text and "1 remaining" in ledger.detail_body.text, "Actual 2-to-1 consumption wrongly marks the spare item committed again.")
	ui.gear_outcomes.clear(); ui.refresh_combat_crew()
	(ledger.tabs["gear"] as Button).grab_focus()
	await _action("ui_right")
	_check(root.gui_get_focus_owner() == ledger.tabs["injuries"], "Directional focus cannot move from Gear to Injuries.")
	await _action("ui_accept")
	_check(ledger.selected_tab == "injuries", "Controller confirm does not open the focused Ledger tab.")
	ledger._select_tab("gear")
	for button in ledger.item_buttons.values():
		var icon := button.get_node("ItemIcon") as TextureRect
		_check(icon.texture != null and icon.size.x >= 36 and icon.position.x + icon.size.x < button.get_theme_stylebox("normal").content_margin_left, "Supply icon missing or overlapping its label.")
		var atlas := icon.texture as AtlasTexture
		_check(atlas != null and atlas.region.size == atlas.atlas.get_size() * 0.5, "Supply atlas uses stale hard-coded quadrant dimensions.")
	var campaign_icon := campaign._item_icon("focus_tonic")
	_check(campaign_icon.region.position == campaign_icon.atlas.get_size() * 0.5 and campaign_icon.region.size == campaign_icon.atlas.get_size() * 0.5, "Campaign tonic crop does not match the actual atlas size.")
	var operative := ledger._selected_unit()
	operative.body_state[Types.BodyZone.HEAD]["hp"] = 2
	(ledger._body_buttons[Types.BodyZone.HEAD] as Button).pressed.emit()
	_check(ledger.selected_tab == "injuries" and "ACTIVE / -8% aim" in ledger.detail_body.text and "At zero: lost" in ledger.detail_body.text, "Head-zone inspection omits current aim loss or fatal threshold.")
	ledger._select_tab("gear")
	director.running = true; director.paused = false; director.set_speed(2.0)
	ledger.settings_button.grab_focus()
	var prior_visual := ledger.stage.active_visual
	var prior_front := campaign.front_content
	var prior_phase := String(scene.run_state.phase)
	var prior_difficulty := campaign.selected_difficulty
	ledger.settings_button.pressed.emit()
	for frame in range(3): await process_frame
	_check(campaign.in_run_settings_open(), "Ledger cannot reach in-run settings.")
	_check(director.inspection_paused and is_zero_approx(director.effective_time_scale()), "Settings failed to retain inspection pause.")
	campaign._select_difficulty("brutal")
	_check(campaign.selected_difficulty == prior_difficulty, "Mid-run settings changed locked difficulty.")
	_check(ledger.visible and ledger.selected_roster_id == "nix" and ledger.selected_tab == "gear" and ledger.stage.active_visual == prior_visual, "Settings replaced the underlying actor/tab/model.")
	await _action("ui_cancel")
	for frame in range(3): await process_frame
	_check(not campaign.in_run_settings_open() and campaign.front_content == prior_front and scene.run_state.phase == prior_phase, "Closing settings changed the underlying screen or run phase.")
	_check(root.gui_get_focus_owner() == ledger.settings_button, "Settings failed to restore invoking controller focus.")
	_check(director.inspection_paused, "Closing settings resumed combat beneath the still-open Ledger.")
	ledger.close()
	_check(not director.inspection_paused and is_equal_approx(director.effective_time_scale(), 1.0), "Closing all overlays failed to restore the selected pace.")
	director.set_paused(true)
	ui.settings_requested.emit()
	await process_frame
	campaign._save_settings_and_return()
	_check(director.paused, "Settings erased the player's original pause.")
	director.stop()
	for resolution in [Vector2i(1280, 720), Vector2i(1280, 800), Vector2i(1920, 1080)]:
		root.size = resolution; root.content_scale_size = resolution
		ui.show_inspector("nix"); ledger._select_tab("gear")
		for frame in range(3): await process_frame
		for control in [ledger.settings_button, ledger.item_grid, ledger.tabs["train"]]:
			_check(Rect2(Vector2.ZERO, resolution).encloses(control.get_global_rect()), "Ledger controls overflow at %s/130%%." % resolution)
		ledger.close()
	if failures.is_empty(): print("BRASSLINE UI LIFT: PASS - in-run settings/pause/focus, locked rules, character persistence, item cards/commitment, Head effects, doctrine discovery and 130% layouts.")
	else:
		for failure in failures: push_error("BRASSLINE UI LIFT: FAIL - " + failure)
	quit(0 if failures.is_empty() else 1)

func _check(condition: bool, message: String) -> void:
	if not condition: failures.append(message)

func _action(action_name: String) -> void:
	var event := InputEventAction.new()
	event.action = action_name; event.pressed = true
	Input.parse_input_event(event)
	await process_frame
	event = InputEventAction.new(); event.action = action_name; event.pressed = false
	Input.parse_input_event(event)
	await process_frame
