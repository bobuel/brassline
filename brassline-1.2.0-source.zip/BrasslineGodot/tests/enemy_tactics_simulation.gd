extends SceneTree

const CAR_IDS: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "engine", "observation"]
const ROLE_RANGES := {
	"railhand": 7,
	"marksman": 10,
	"duelist": 7,
	"bruiser": 5,
	"medic": 7,
	"officer": 8,
}


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(6):
		await process_frame
	var crew = scene.turn.player_units(true)
	var guards = scene.turn.enemy_units(true)
	if crew.is_empty() or guards.is_empty():
		_fail("The simulation could not acquire a player and a guard.")
		return
	var player: TacticalUnit = crew[0]
	var guard: TacticalUnit = guards[0]
	scene.turn.units.assign([player, guard])
	guard.base_movement = 5

	var decisions := 0
	var covered_destinations := 0
	var role_divergent_scenarios := 0
	var marksman_farther_scenarios := 0
	var seed_destinations: Dictionary = {}
	for car_id in CAR_IDS:
		scene.board.prepare_run_encounter(car_id, 0)
		_place_unit(scene.board, player, Vector2i(2, 2))
		_place_unit(scene.board, guard, Vector2i(11, 2))
		for seed_offset in range(18):
			scene.turn.set_encounter_seed(43000 + seed_offset * 211 + int(hash(car_id)))
			var destinations_this_scenario: Dictionary = {}
			for role_id in ROLE_RANGES:
				guard.role_id = role_id
				guard.attack_range = int(ROLE_RANGES[role_id])
				var destination: Vector2i = scene.turn._best_enemy_destination(guard, player)
				destinations_this_scenario[str(destination)] = true
				var key := "%s/%s" % [car_id, role_id]
				if not seed_destinations.has(key):
					seed_destinations[key] = {}
				seed_destinations[key][str(destination)] = true
				decisions += 1
				if scene.board.cover_penalty(player.grid_cell, destination) > 0.0:
					covered_destinations += 1
			if destinations_this_scenario.size() >= 2:
				role_divergent_scenarios += 1
			guard.role_id = "marksman"
			guard.attack_range = int(ROLE_RANGES["marksman"])
			var marksman_cell: Vector2i = scene.turn._best_enemy_destination(guard, player)
			guard.role_id = "bruiser"
			guard.attack_range = int(ROLE_RANGES["bruiser"])
			var bruiser_cell: Vector2i = scene.turn._best_enemy_destination(guard, player)
			if scene.board.grid_distance(marksman_cell, player.grid_cell) > scene.board.grid_distance(bruiser_cell, player.grid_cell):
				marksman_farther_scenarios += 1

	var seed_varied_role_car_pairs := 0
	for destinations in seed_destinations.values():
		if destinations.size() > 1:
			seed_varied_role_car_pairs += 1
	var total_scenarios := CAR_IDS.size() * 18
	var cover_rate := float(covered_destinations) / maxf(1.0, float(decisions))
	if role_divergent_scenarios < roundi(float(total_scenarios) * 0.70):
		_fail("Role choices converged too often across the carriage matrix (%d/%d divergent)." % [role_divergent_scenarios, total_scenarios])
		return
	if marksman_farther_scenarios < roundi(float(total_scenarios) * 0.60):
		_fail("Marksmen did not preserve more range than Bruisers often enough (%d/%d)." % [marksman_farther_scenarios, total_scenarios])
		return
	if seed_varied_role_car_pairs < 10:
		_fail("Seeded tie-breaking varied only %d role/car decision sets." % seed_varied_role_car_pairs)
		return
	if cover_rate < 0.18:
		_fail("Only %.1f%% of evaluated destinations used physical cover." % (cover_rate * 100.0))
		return

	print("BRASSLINE ENEMY TACTICS SIMULATION: PASS - decisions=%d cars=%d seeds=18 role_divergence=%d/%d marksman_farther=%d/%d seed_varied_sets=%d cover_rate=%.1f%%" % [
		decisions,
		CAR_IDS.size(),
		role_divergent_scenarios,
		total_scenarios,
		marksman_farther_scenarios,
		total_scenarios,
		seed_varied_role_car_pairs,
		cover_rate * 100.0,
	])
	quit(0)


func _place_unit(board: GridBoard, unit: TacticalUnit, cell: Vector2i) -> void:
	unit.grid_cell = cell
	unit.position = board.cell_to_world(cell) + Vector3(0.0, 0.06, 0.0)


func _fail(message: String) -> void:
	push_error("BRASSLINE ENEMY TACTICS SIMULATION: FAIL - %s" % message)
	quit(1)
