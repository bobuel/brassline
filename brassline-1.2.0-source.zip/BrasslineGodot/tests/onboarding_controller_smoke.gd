extends SceneTree


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	root.size = Vector2i(1280, 720)
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(8):
		await process_frame
	var start_button := _find_button(scene.campaign_ui.front_content, "START HEIST")
	if not is_instance_valid(start_button):
		_fail("The primary title action is not Start Heist.")
		return
	scene.campaign_ui.show_crew_selection()
	await process_frame
	if scene.campaign_ui.selected_crew_ids != ["ada", "marlow", "nix"]:
		_fail("The default trio was not preselected.")
		return
	if not is_instance_valid(scene.campaign_ui.selection_preview_stage) or not is_instance_valid(scene.campaign_ui.selection_preview_stage.active_visual) or scene.campaign_ui.selection_preview_stage.active_member_id.is_empty():
		_fail("Crew selection did not display an animated 3D operative.")
		return
	# The onboarding assertion must not depend on the developer profile left by a
	# previous local or Web run.
	scene.profile_state.tutorial_complete = false
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 556677)
	if not scene.autobattle_ui.training_mode or scene.autobattle_ui.training_step != 1 or not scene.autobattle_ui.training_banner.visible:
		_fail("First-run contextual training did not begin at Choose an Approach.")
		return
	if scene.autobattle_ui.plans.size() != 4:
		_fail("First-run planning did not expose the required four approaches.")
		return
	scene.autobattle_ui._select_plan(1)
	if scene.autobattle_ui.training_step != 2:
		_fail("Selecting a plan did not advance to ghost inspection.")
		return
	scene.autobattle_ui._select_fallback(1)
	if scene.autobattle_ui.training_step != 3:
		_fail("Selecting a fallback did not advance the contextual training.")
		return
	var preview_root = scene.board._deployment_preview_root
	if not is_instance_valid(preview_root) or int(preview_root.get_meta("preview_beat_count", 0)) != 3 or String(preview_root.get_meta("fallback_id", "")) != "protect_wounded":
		_fail("Fallback selection did not redraw the board's three-beat preview.")
		return
	scene.campaign_ui.set_controller_mode(true)
	scene.autobattle_ui.set_controller_mode(true)
	scene.autobattle_ui._refresh_plan_detail()
	if "[A]" not in scene.autobattle_ui.training_label.text:
		_fail("Input-sensitive controller prompts did not replace the mouse legend.")
		return
	scene.autobattle_ui.set_text_scale(1.30)
	if scene.autobattle_ui.plan_buttons[0].get_theme_font_size("font_size") < 14:
		_fail("130% scalable text was not applied to dynamic plan cards.")
		return
	scene.autobattle_ui.plan_buttons[0].grab_focus()
	await process_frame
	if root.gui_get_focus_owner() not in scene.autobattle_ui.plan_buttons:
		_fail("Directional/controller focus could not enter the plan offer.")
		return
	print("BRASSLINE ONBOARDING/CONTROLLER: PASS - Start Heist, default animated trio, four contextual prompts, fallback redraw, controller legends/focus, 1280x720 layout root, and 130% text verified.")
	quit(0)


func _find_button(node: Node, exact_text: String) -> Button:
	if node is Button and String((node as Button).text) == exact_text:
		return node as Button
	for child in node.get_children():
		var found := _find_button(child, exact_text)
		if is_instance_valid(found):
			return found
	return null


func _fail(message: String) -> void:
	push_error("BRASSLINE ONBOARDING/CONTROLLER: FAIL - %s" % message)
	quit(1)
