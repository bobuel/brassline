extends SceneTree

const Types := preload("res://scripts/game_types.gd")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 74007)
	# Load a deterministic seventh-car state while preserving the real crew body data.
	scene.run_state.completed_car_ids.assign(["baggage", "dining", "bar", "crew", "armory", "observation"])
	scene.run_state.run_stats["cars_cleared"] = 6
	scene.run_state.current_car_id = "engine"
	scene.run_state.phase = "encounter"
	await scene._load_run_encounter()
	if scene.turn.encounter_mode != "takeover_finale" or scene.turn.enemy_units(true).size() < 2:
		_fail("The seventh car did not load as a guarded engine-takeover encounter.")
		return
	# Keep this fixture on the explicit objective path even though it is launched
	# through the retained manual-combat harness.
	scene.turn.autobattle_enabled = true
	var boss = null
	for enemy in scene.turn.enemy_units(true):
		if enemy.role_id == "boss":
			boss = enemy
			break
	if not is_instance_valid(boss) or boss.display_name != "Chief Engineer Voss":
		_fail("The Engine finale did not spawn its named boss.")
		return
	boss.apply_damage(Types.BodyZone.HEAD, 99, true)
	for _frame in range(3):
		await process_frame
	if int(scene.turn.encounter_stats.get("boss_kills", 0)) != 1:
		_fail("The finale boss defeat was not recorded.")
		return
	for enemy in scene.turn.enemy_units(true):
		enemy.apply_damage(Types.BodyZone.TORSO, 99, true)
	for _frame in range(3):
		await process_frame
	if scene.turn.phase == Types.Phase.VICTORY:
		_fail("The finale ended after elimination without seizing the engine controls.")
		return

	var carrier: TacticalUnit = scene.turn.player_units(true)[0]
	carrier.grid_cell = scene.board.control_cell + Vector2i(-1, 0)
	carrier.position = scene.board.cell_to_world(carrier.grid_cell) + Vector3(0.0, 0.12, 0.0)
	carrier.action_points = 1
	scene.turn.phase = Types.Phase.PLAYER
	scene.turn.select_unit(carrier)
	if not scene.turn.try_claim_control():
		_fail("An adjacent operative could not seize the cleared engine station.")
		return
	for _frame in range(3):
		await process_frame
	if scene.run_state.phase != "complete" or int(scene.turn.encounter_stats.get("train_seized", 0)) != 1:
		_fail("Seizing the engine controls did not complete the seven-car run.")
		return
	if int(scene.run_state.run_stats.get("train_seized", 0)) != 1 or int(scene.run_state.run_stats.get("control_claims", 0)) != 1 or int(scene.run_state.run_stats.get("cars_cleared", 0)) != 7:
		_fail("The final takeover was not included in the completed run report.")
		return

	print("BRASSLINE COMMERCIAL-ALPHA FINALE SMOKE: PASS - Voss defeat, guarded engine controls, explicit takeover, and completed-run telemetry verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE COMMERCIAL-ALPHA FINALE SMOKE: FAIL - %s" % message)
	quit(1)
