extends SceneTree

const COMBAT_CARS: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "engine", "observation"]
const TEST_ROLES: Array[String] = ["bruiser", "marksman", "medic", "officer", "railhand"]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame
	var crew_ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(crew_ids, 481516)
	for _frame in range(3):
		await process_frame

	scene.board.prepare_run_encounter("baggage", 0)
	if scene._logical_enemy_spawn_cell("baggage", "railhand", 0, {}) != Vector2i(9, 2):
		_fail("The tutorial guard no longer holds the visible boarding checkpoint.")
		return

	var signatures := {}
	for car_index in range(COMBAT_CARS.size()):
		var car_id := COMBAT_CARS[car_index]
		scene.board.prepare_run_encounter(car_id, car_index % 3)
		var occupied := {}
		for crew in scene.turn.player_units(true):
			occupied[crew.grid_cell] = crew
		var covered_posts := 0
		var cells: Array[String] = []
		for role_index in range(TEST_ROLES.size()):
			var role_id := TEST_ROLES[role_index]
			# Index zero is reserved for the baggage tutorial checkpoint; regular
			# deployment logic is audited here for every car and role.
			var cell: Vector2i = scene._logical_enemy_spawn_cell(car_id, role_id, role_index + 1, occupied)
			if not scene.board.is_walkable(cell, occupied) or scene.board.hazard_cells.has(cell):
				_fail("%s placed its %s on blocked, occupied, or hazardous ground." % [car_id, role_id])
				return
			if role_id == "marksman" and cell.x < 13:
				_fail("%s marksman abandoned the rear/window firing line: %s." % [car_id, cell])
				return
			if role_id == "bruiser" and cell.x > 12:
				_fail("%s bruiser did not hold the forward boarding choke: %s." % [car_id, cell])
				return
			if role_id in ["medic", "officer"] and cell.x < 12:
				_fail("%s support guard started ahead of the fighting line: %s." % [car_id, cell])
				return
			if role_id in ["marksman", "medic", "officer"] and not scene.board.has_adjacent_cover(cell):
				_fail("%s %s abandoned its protected tactical post: %s." % [car_id, role_id, cell])
				return
			if scene.board.has_adjacent_cover(cell):
				covered_posts += 1
			if scene._enemy_spawn_post_label(car_id, role_id).is_empty():
				_fail("%s %s has no authored guard-post identity." % [car_id, role_id])
				return
			occupied[cell] = true
			cells.append("%d,%d" % [cell.x, cell.y])
		if covered_posts < 3:
			_fail("%s failed to protect its marksman and support line with real cover." % car_id)
			return
		signatures[";".join(cells)] = true

	if signatures.size() < 5:
		_fail("Guard deployment still collapses into generic formations across the seven cars.")
		return

	print("BRASSLINE LOGICAL SPAWN SMOKE: PASS - seven car-aware deployments, role depth, hazards, uniqueness, and physical-cover posts verified.")
	quit(0)


func _fail(message: String) -> void:
	push_error("BRASSLINE LOGICAL SPAWN SMOKE: FAIL - %s" % message)
	quit(1)
