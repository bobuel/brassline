extends SceneTree

const Types := preload("res://scripts/game_types.gd")
var errors: Array[String] = []

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for frame in range(8): await process_frame
	var ids: Array[String] = ["ada", "marlow", "nix"]
	await scene._on_crew_confirmed(ids, 120091)
	# Explicit completed-run render fixture, not a gameplay completion claim.
	scene.autobattle_director.stop()
	scene.run_state.phase = "complete"
	scene.run_state.completed_car_ids.assign(["baggage", "sleeper", "crew", "dining", "armory", "bar", "engine"])
	scene.run_state.current_car_id = "engine"
	scene.run_state.run_stats["train_seized"] = 1
	scene.profile_state.crew_scars["ada"] = ["OLD HISTORY THAT MUST NOT BECOME A CURRENT INJURY"]
	var body: Dictionary = scene.run_state.body_state_for("nix")
	body[Types.BodyZone.ARMS]["hp"] = 0
	body[Types.BodyZone.ARMS]["disabled"] = true
	scene.run_state.crew_states["nix"]["body"] = body
	scene.run_state.crew_states["marlow"]["down"] = true
	var data: Dictionary = scene._build_share_card_data()
	_check(data["survivors"] == 2, "Card survivor count differs from current run.")
	_check("Nix Bell: ARMS CRIPPLED" in data["injuries"] and "Marlow Pike: FALLEN" in data["injuries"], "Card omits actual current injury or casualty.")
	_check("OLD HISTORY" not in str(data), "Historical profile scar became a current-run wound.")
	_check(data["crew"][0]["id"] == "ada" and data["crew"][2]["id"] == "nix", "Card omitted portrait identity.")
	var parsed: Dictionary = scene.profile_state.parse_challenge_code(data["run_code"])
	_check(parsed.get("ok", false) and parsed["seed"] == 120091, "Card challenge identity cannot be imported.")
	if DisplayServer.get_name() != "headless":
		scene._show_run_complete()
		for frame in range(16): await process_frame
		_check(not scene._share_card_png.is_empty(), "Completed screen did not pre-render a PNG before Save.")
		_check(scene._share_card_cache_code == data["run_code"], "Cached PNG belongs to another run.")
		var before: PackedByteArray = scene._share_card_png.duplicate()
		await scene._on_share_card_requested()
		_check(scene._share_card_png == before, "Save rerendered rather than using the ready cache.")
		var image := Image.new()
		_check(image.load_png_from_buffer(before) == OK and image.get_size() == Vector2i(1280, 720), "Cached card is not a valid 1280x720 PNG.")
		if not OS.has_feature("web"):
			_check(FileAccess.file_exists("user://heist_cards/brassline_heist_120091.png"), "Native Save did not write the cached PNG.")
		image.save_png("res://preview_share_pipeline.png")
	if not errors.is_empty():
		for error in errors: push_error(error)
		quit(1)
		return
	print("BRASSLINE SHARE PIPELINE: PASS - current-run injuries, casualties, portraits, valid challenge identity%s." % (", active-renderer pre-cache and native PNG receipt" if DisplayServer.get_name() != "headless" else "; rendering deliberately skipped headless"))
	scene.queue_free()
	await process_frame
	quit(0)

func _check(condition: bool, reason: String) -> void:
	if not condition: errors.append(reason)
