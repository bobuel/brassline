extends SceneTree

const Types := preload("res://scripts/game_types.gd")
const PLAYTEST_ROSTERS: Array[Array] = [
	["ada", "marlow", "nix"],
	["iona", "silas", "rook"],
	["ada", "iona", "silas"],
]


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var seed := int(_argument_value("soak-seed", "71001"))
	var strategy := int(_argument_value("soak-strategy", "0"))
	var roster_index := posmod(int(_argument_value("soak-roster", "0")), PLAYTEST_ROSTERS.size())
	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	current_scene = scene
	for _frame in range(5):
		await process_frame

	scene._save_path = "user://brassline_run_soak_%d_test.json" % seed
	scene._automation_mode = false
	scene._clear_run_checkpoint()
	var crew_ids: Array[String] = []
	crew_ids.assign(PLAYTEST_ROSTERS[roster_index])
	await scene._on_crew_confirmed(crew_ids, seed)
	if scene._read_run_checkpoint().is_empty():
		_fail("Starting a real run did not write its checkpoint.")
		return
	var checkpoint_seed: int = scene.run_state.run_seed
	scene.run_state = null
	await scene._on_continue_requested()
	if scene.run_state == null or scene.run_state.run_seed != checkpoint_seed or scene.run_state.current_car_id != "baggage":
		_fail("Continue Run did not restore the live encounter checkpoint.")
		return
	var transition_count := 0
	var route_trace: Array[String] = []
	var real_shots := 0
	var grenades_used := 0
	var tonics_used := 0
	var medkits_used := 0
	while scene.run_state.phase != "complete" and transition_count < 20:
		transition_count += 1
		match scene.run_state.phase:
			"encounter":
				var car_data: Dictionary = scene.run_state.car_data(scene.run_state.current_car_id)
				if String(car_data.get("kind", "combat")) == "event":
					scene._on_event_resolved()
				else:
					var enemies: Array = scene.turn.enemy_units(true).duplicate()
					if enemies.is_empty():
						if scene.turn.encounter_mode == "finale":
							_force_finale_extraction(scene)
							for _frame in range(4):
								await process_frame
							continue
						else:
							_fail("Combat car %s loaded without a rail guard." % scene.run_state.current_car_id)
							return
					var grenade_was_used := false
					if int(scene.run_state.inventory.get("clockwork_grenade", 0)) > 0:
						var grenade_pair: Array = await _find_or_create_grenade_pair(scene)
						if not grenade_pair.is_empty():
							var grenades_before := int(scene.run_state.inventory["clockwork_grenade"])
							await scene._on_grenade_requested()
							if int(scene.run_state.inventory["clockwork_grenade"]) == grenades_before - 1:
								grenades_used += 1
								grenade_was_used = true
					var action_pair: Array = await _find_or_create_action_pair(scene)
					if not grenade_was_used and not action_pair.is_empty():
						var shooter: TacticalUnit = action_pair[0]
						var target: TacticalUnit = action_pair[1]
						scene.turn.select_unit(shooter)
						scene.turn.set_target(target)
						scene.turn.set_target_zone(Types.BodyZone.TORSO)
						if int(scene.run_state.inventory.get("focus_tonic", 0)) > 0 and not shooter.is_focused():
							var tonics_before := int(scene.run_state.inventory["focus_tonic"])
							scene._on_tonic_requested()
							if int(scene.run_state.inventory["focus_tonic"]) == tonics_before - 1:
								tonics_used += 1
						if scene.run_state.phase == "encounter" and scene.turn.phase == Types.Phase.PLAYER and target.is_alive:
							await scene.turn.try_attack(target)
							real_shots += 1
					for enemy in enemies:
						if scene.run_state.phase == "encounter" and enemy.is_alive:
							enemy.apply_damage(Types.BodyZone.TORSO, 999, true)
					if scene.run_state.phase == "encounter" and scene.turn.encounter_mode == "finale" and scene.turn.enemy_units(true).is_empty():
						_force_finale_extraction(scene)
				for _frame in range(4):
					await process_frame
			"intermission":
				if scene.run_state.has_pending_crew_scene():
					var council_choices: Array = scene.run_state.crew_scene_data().get("choices", [])
					var council_choice := String(Dictionary(council_choices[posmod(strategy, council_choices.size())]).get("id", ""))
					scene._on_crew_scene_choice_requested(council_choice)
					await process_frame
					continue
				if scene.run_state.current_offers.is_empty() or scene.run_state.current_offers.size() > 3:
					_fail("The real scene produced an invalid route table during the soak run.")
					return
				var offer_count: int = scene.run_state.current_offers.size()
				var choice_index := 0
				match posmod(strategy, 3):
					1:
						choice_index = offer_count - 1
					2:
						choice_index = posmod(scene.run_state.completed_car_ids.size(), offer_count)
				var choice: String = scene.run_state.current_offers[choice_index]
				route_trace.append(choice)
				# Explicit crew review remains available even when healthy crews can
				# board immediately. This soak must exercise management and treatment.
				scene._on_crew_review_requested(choice)
				for _frame in range(2):
					await process_frame
				if scene.run_state.phase != "preparation" or scene.campaign_ui.crew_preview_stage == null:
					_fail("Explicit crew review skipped the route-to-crew-preparation transition.")
					return
				if scene.run_state.completed_car_ids.size() == 1 and medkits_used == 0:
					var member_id: String = crew_ids[0]
					var saved_body: Dictionary = scene.run_state.body_state_for(member_id)
					saved_body[Types.BodyZone.TORSO]["hp"] = maxi(1, int(saved_body[Types.BodyZone.TORSO]["hp"]) - 2)
					scene.run_state.record_crew_body_state(member_id, saved_body)
					var medkits_before := int(scene.run_state.inventory.get("medkit", 0))
					scene._on_item_requested("medkit", member_id)
					if int(scene.run_state.inventory.get("medkit", 0)) == medkits_before - 1:
						medkits_used += 1
				await scene._on_next_car_chosen(choice)
				for _frame in range(3):
					await process_frame
			_:
				_fail("The full run entered an unknown phase: %s" % scene.run_state.phase)
				return

	if scene.run_state.phase != "complete" or transition_count >= 20:
		_fail("The seven-car scene loop failed to reach completion.")
		return
	if scene.run_state.completed_car_ids.size() != 7 or scene.run_state.completed_car_ids[0] != "baggage":
		_fail("The completed scene run did not contain the fixed seven-car sequence.")
		return
	for required_id in scene.run_state.REQUIRED_CAR_IDS:
		if required_id not in scene.run_state.completed_car_ids:
			_fail("The completed scene run omitted required car %s." % required_id)
			return
	var optional_count := 0
	for optional_id in scene.run_state.OPTIONAL_CAR_IDS:
		if optional_id in scene.run_state.completed_car_ids:
			optional_count += 1
	if optional_count != 1:
		_fail("The completed scene run contained %d optional cars instead of one." % optional_count)
		return
	if not scene.campaign_ui.is_frontend_open():
		_fail("Completing all seven cars did not open the run result screen.")
		return
	if FileAccess.file_exists(scene._save_path):
		_fail("The finished run left a stale Continue Run checkpoint behind.")
		return
	if real_shots < 1 or medkits_used != 1:
		_fail("The soak run did not exercise a real attack and between-car healing.")
		return
	var armory_index: int = scene.run_state.completed_car_ids.find("armory")
	if armory_index < 6 and grenades_used < 1:
		_fail("The run earned a grenade before its last car but never completed a legal move-and-throw action.")
		return
	var bar_index: int = scene.run_state.completed_car_ids.find("bar")
	if bar_index < 6 and tonics_used < 1:
		_fail("The run earned a Focus Tonic before its last car but never used it on a real shot.")
		return

	print("BRASSLINE FULL RUN SOAK: PASS - seed=%d strategy=%d crew=%s route=%s shots=%d tonics=%d grenades=%d medkits=%d" % [
		seed,
		strategy,
		",".join(PackedStringArray(crew_ids)),
		" > ".join(PackedStringArray(route_trace)),
		real_shots,
		tonics_used,
		grenades_used,
		medkits_used,
	])
	quit(0)


func _find_action_pair(scene: Node) -> Array:
	for shooter in scene.turn.player_units(true):
		for target in scene.turn.enemy_units(true):
			if scene.turn.can_attack(shooter, target):
				return [shooter, target]
	return []


func _find_or_create_action_pair(scene: Node) -> Array:
	var standing_pair := _find_action_pair(scene)
	if not standing_pair.is_empty():
		return standing_pair
	# Car-logical guard posts deliberately begin deeper than the old generic
	# formations. Exercise one real move before the real shot when nobody starts
	# with a legal line, matching the actual player loop.
	for shooter in scene.turn.player_units(true):
		if shooter.action_points < 2:
			continue
		var reachable: Dictionary = scene.board.get_reachable(
			shooter.grid_cell,
			shooter.movement_range(),
			scene.turn.occupied_cells(shooter)
		)
		for target in scene.turn.enemy_units(true):
			var destination: Vector2i = shooter.grid_cell
			var best_distance: int = 1_000_000
			for cell in reachable:
				var candidate: Vector2i = cell
				var distance: int = scene.board.grid_distance(candidate, target.grid_cell)
				if distance > shooter.attack_range or not scene.board.has_line_of_sight(candidate, target.grid_cell):
					continue
				if distance < best_distance and candidate != shooter.grid_cell:
					best_distance = distance
					destination = candidate
			if destination == shooter.grid_cell:
				continue
			scene.turn.select_unit(shooter)
			await scene.turn.try_move(destination)
			if scene.run_state.phase != "encounter" or scene.turn.phase != Types.Phase.PLAYER:
				return []
			if scene.turn.can_attack(shooter, target):
				return [shooter, target]
	return []


func _force_finale_extraction(scene: Node) -> void:
	var survivors: Array[TacticalUnit] = scene.turn.player_units(true)
	if survivors.is_empty() or not scene.board.objective_marker.visible:
		return
	var carrier: TacticalUnit = survivors[0]
	carrier.grid_cell = scene.board.objective_cell
	carrier.position = scene.board.cell_to_world(carrier.grid_cell) + Vector3(0.0, 0.12, 0.0)
	scene.turn._resolve_cell_effects(carrier)
	carrier.grid_cell = scene.board.extraction_cell
	carrier.position = scene.board.cell_to_world(carrier.grid_cell) + Vector3(0.0, 0.12, 0.0)
	scene.turn._resolve_cell_effects(carrier)


func _find_or_create_grenade_pair(scene: Node) -> Array:
	for shooter in scene.turn.player_units(true):
		scene.turn.select_unit(shooter)
		for target in scene.turn.enemy_units(true):
			scene.turn.set_target(target)
			if scene.turn.can_use_grenade(target):
				return [shooter, target]
	for shooter in scene.turn.player_units(true):
		if shooter.action_points < 2:
			continue
		var reachable: Dictionary = scene.board.get_reachable(
			shooter.grid_cell,
			shooter.movement_range(),
			scene.turn.occupied_cells(shooter)
		)
		for target in scene.turn.enemy_units(true):
			var destination: Vector2i = shooter.grid_cell
			var best_distance: int = 1_000_000
			for cell in reachable:
				var candidate_cell: Vector2i = cell
				var distance: int = scene.board.grid_distance(candidate_cell, target.grid_cell)
				if distance <= 6 and distance < best_distance and candidate_cell != shooter.grid_cell:
					best_distance = distance
					destination = candidate_cell
			if destination == shooter.grid_cell:
				continue
			scene.turn.select_unit(shooter)
			await scene.turn.try_move(destination)
			if scene.run_state.phase != "encounter" or scene.turn.phase != Types.Phase.PLAYER:
				return []
			scene.turn.set_target(target)
			if scene.turn.can_use_grenade(target):
				return [shooter, target]
	return []


func _argument_value(key: String, fallback: String) -> String:
	var prefix := "--%s=" % key
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with(prefix):
			return argument.trim_prefix(prefix)
	return fallback


func _fail(message: String) -> void:
	push_error("BRASSLINE FULL RUN SOAK: FAIL - %s" % message)
	quit(1)
