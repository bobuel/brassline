class_name TurnController
extends Node

signal state_changed
signal selection_changed(unit: TacticalUnit, target: TacticalUnit)
signal log_entry(message: String)
signal mission_finished(victory: bool, message: String)
signal attack_resolved(attacker: TacticalUnit, target: TacticalUnit, zone: BrasslineTypes.BodyZone, result: Dictionary)
signal unit_surrendered(unit: TacticalUnit)
signal environment_resolved(action_id: String, actor: TacticalUnit, result: Dictionary)
signal environment_injury_resolved(source_name: String, unit: TacticalUnit, zone: BrasslineTypes.BodyZone, result: Dictionary)

const Types := preload("res://scripts/game_types.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")

var board: GridBoard
var units: Array[TacticalUnit] = []
var phase: Types.Phase = Types.Phase.BUSY
var round_number := 0
var selected_unit: TacticalUnit
var current_target: TacticalUnit
var target_zone: Types.BodyZone = Types.BodyZone.TORSO
var rng := RandomNumberGenerator.new()
var presentation_rng := RandomNumberGenerator.new()
var encounter_active := false
var encounter_mode := "blueprint"
var encounter_title := "BLUEPRINT HEIST"
var objective_text := "Seize the violet blueprint case, then return to extraction."
var squad_accuracy_bonus := 0.0
var squad_critical_bonus := 0.0
var encounter_stats: Dictionary = {}
var encounter_ai_seed := 8675309
var autobattle_enabled := false
var active_car_id := ""
var active_enemy_doctrine: Dictionary = {}
var _doctrine_focus_id := 0
var _resolving_damage := false


func setup(grid_board: GridBoard) -> void:
	board = grid_board
	rng.seed = encounter_ai_seed
	presentation_rng.seed = encounter_ai_seed ^ 0x4b524153


func set_encounter_seed(value: int) -> void:
	encounter_ai_seed = value if value != 0 else 8675309
	rng.seed = encounter_ai_seed
	presentation_rng.seed = encounter_ai_seed ^ 0x4b524153


func register_unit(unit: TacticalUnit) -> void:
	units.append(unit)
	unit.defeated.connect(_on_unit_defeated)
	unit.surrendered_unit.connect(_on_unit_surrendered)


func unregister_unit(unit: TacticalUnit) -> void:
	if not is_instance_valid(unit):
		return
	units.erase(unit)
	if selected_unit == unit:
		selected_unit = null
	if current_target == unit:
		current_target = null


func reset_encounter() -> void:
	encounter_active = false
	phase = Types.Phase.BUSY
	round_number = 0
	clear_selection_highlights()
	selected_unit = null
	current_target = null
	target_zone = Types.BodyZone.TORSO
	autobattle_enabled = false
	active_car_id = ""
	active_enemy_doctrine.clear()
	_doctrine_focus_id = 0
	units.clear()
	encounter_stats = {
		"shots": 0,
		"hits": 0,
		"kills": 0,
		"moves": 0,
		"reloads": 0,
		"overwatch_shots": 0,
		"abilities": 0,
		"grenades": 0,
		"rounds": 0,
		"boss_kills": 0,
		"surrenders": 0,
		"control_claims": 0,
		"train_seized": 0,
		"finale_escapes": 0,
		"ai_moves": 0,
		"ai_cover_moves": 0,
		"ai_cover_actions": 0,
		"ai_flanks": 0,
		"ai_shots": 0,
	}


func configure_run_encounter(car_data: Dictionary, car_number: int, bonuses: Dictionary) -> void:
	active_car_id = String(car_data.get("id", ""))
	active_enemy_doctrine = SignatureArc.car_profile(active_car_id)
	_doctrine_focus_id = 0
	var legacy_rules := String(car_data.get("ruleset_id", "train_takeover")) == "legacy_blueprint"
	encounter_mode = ("finale" if legacy_rules else "takeover_finale") if bool(car_data.get("is_finale", false)) else "secure"
	encounter_title = "CAR %02d / %s" % [car_number, String(car_data.get("name", "Unknown Car")).to_upper()]
	if encounter_mode == "finale":
		objective_text = "Defeat Voss, take the case, and return to the green hatch."
	elif encounter_mode == "takeover_finale":
		objective_text = "Break Voss's command and seize the engine controls."
	else:
		objective_text = "Break the guard line and secure this carriage."
	squad_accuracy_bonus = float(bonuses.get("accuracy", 0.0))
	squad_critical_bonus = float(bonuses.get("critical", 0.0))


func apply_enemy_doctrine_round() -> Dictionary:
	for enemy in enemy_units(true):
		enemy.signature_accuracy_bonus = 0.0
		enemy.signature_critical_bonus = 0.0
		enemy.signature_damage_bonus = 0.0
		enemy.set_meta("doctrine_resistance", 0.0)
		enemy.damage_resistance = 0.0
	_doctrine_focus_id = 0
	if active_enemy_doctrine.is_empty():
		return {}
	var doctrine_id := String(active_enemy_doctrine.get("doctrine_id", ""))
	var break_role := String(active_enemy_doctrine.get("break_role", ""))
	var break_zone: Types.BodyZone = int(active_enemy_doctrine.get("break_zone", Types.BodyZone.ARMS))
	var counter_units: Array[TacticalUnit] = []
	for enemy in enemy_units(true):
		if enemy.role_id == break_role:
			counter_units.append(enemy)
	var suppressed := bool(active_enemy_doctrine.get("suppressed", false))
	var broken := not counter_units.is_empty()
	for counter in counter_units:
		if not counter.is_zone_detached(break_zone) and not bool(counter.body_state[break_zone].get("disabled", false)):
			broken = false
	if counter_units.is_empty():
		broken = true
	if suppressed:
		broken = true
	var result := {
		"id": doctrine_id,
		"name": String(active_enemy_doctrine.get("doctrine_name", "GUARD DOCTRINE")),
		"text": String(active_enemy_doctrine.get("doctrine_text", "")),
		"break_zone": int(break_zone),
		"break_role": break_role,
		"broken": broken,
		"status": "broken" if broken else "active",
	}
	if broken:
		result["round_effect"] = "The chandelier scattered the command table." if suppressed else "The anatomical counter has dismantled this doctrine."
		return result
	match doctrine_id:
		"chain_of_custody":
			var forward: TacticalUnit
			for crew in player_units(true):
				if not is_instance_valid(forward) or crew.grid_cell.x > forward.grid_cell.x:
					forward = crew
			if is_instance_valid(forward):
				_doctrine_focus_id = forward.get_instance_id()
				result["focus_name"] = forward.display_name
				result["round_effect"] = "Every railhand is concentrating fire on %s." % forward.display_name
		"officers_table":
			for enemy in enemy_units(true):
				if enemy.role_id != "officer":
					enemy.signature_accuracy_bonus = 0.05
					enemy.set_meta("doctrine_resistance", 0.12)
					enemy.damage_resistance = 0.12
			result["round_effect"] = "The officer grants the guard line +5% aim and 12% damage resistance."
		"pistols_at_ten":
			for enemy in enemy_units(true):
				if enemy.role_id == "duelist":
					enemy.signature_critical_bonus = 0.12
			result["round_effect"] = "The duelists share the carriage count: each gains +12% critical chance."
		"relief_rotation":
			var weakest: TacticalUnit
			var weakest_ratio := 2.0
			for enemy in enemy_units(true):
				var current_hp := 0
				var maximum_hp := 0
				for zone in [Types.BodyZone.HEAD, Types.BodyZone.TORSO, Types.BodyZone.ARMS, Types.BodyZone.LEGS]:
					var zone_state: Dictionary = enemy.body_state[zone]
					current_hp += int(zone_state.get("hp", 0))
					maximum_hp += int(zone_state.get("max_hp", 1))
				var health_ratio := float(current_hp) / maxf(1.0, float(maximum_hp))
				if health_ratio < weakest_ratio:
					weakest_ratio = health_ratio
					weakest = enemy
			if is_instance_valid(weakest) and weakest.heal_weakest_body_zone(1):
				result["healed_name"] = weakest.display_name
				result["round_effect"] = "The relief medic restores 1 body health to %s." % weakest.display_name
			else:
				result["round_effect"] = "The relief medic is ready to restore the first wounded guard."
		"cage_line":
			for enemy in enemy_units(true):
				enemy.set_meta("doctrine_resistance", 0.15)
				enemy.damage_resistance = 0.15
			result["round_effect"] = "The cage formation grants every guard 15% damage resistance."
		"spotter_glass":
			for enemy in enemy_units(true):
				if enemy.role_id == "marksman":
					enemy.signature_accuracy_bonus = 0.12
			result["round_effect"] = "Reflected range marks grant every marksman +12% aim."
		"loader_screen":
			for enemy in enemy_units(true):
				if enemy.role_id == "railhand":
					enemy.signature_damage_bonus = 0.35
			result["round_effect"] = "The heavy loader feeds each railhand +0.35 weapon damage."
		"house_edge":
			for enemy in enemy_units(true):
				if enemy.role_id == "duelist":
					enemy.signature_critical_bonus = 0.15
			result["round_effect"] = "House timing grants every duelist +15% critical chance."
		"voss_redline":
			for enemy in enemy_units(true):
				enemy.signature_accuracy_bonus = 0.08
			result["round_effect"] = "Voss reads the boiler rhythm: every guard gains +8% aim."
	return result


func resolve_living_train_event(event: Dictionary, countered: bool = false) -> Dictionary:
	var result := {
		"ok": not event.is_empty(),
		"id": String(event.get("id", "")),
		"title": String(event.get("title", "TRAIN EVENT")),
		"countered": countered,
		"crew_victims": [],
		"enemy_victims": [],
	}
	if event.is_empty():
		return result
	var affected_cells: Array = event.get("cells", [])
	var zone: Types.BodyZone = int(event.get("zone", Types.BodyZone.LEGS))
	var damage := int(event.get("damage", 1))
	if countered:
		# Engine pressure is redirected into the redline guard; the other two
		# counter-actions secure the moving scenery without inventing free damage.
		if active_car_id == "engine":
			for enemy in enemy_units(true):
				if enemy.grid_cell in affected_cells:
					enemy.apply_damage(zone, damage)
					result["enemy_victims"].append(enemy.display_name)
					if result["enemy_victims"].size() >= 2:
						break
		_log("LIVING TRAIN / %s — the crew's counter holds%s." % [
			String(event.get("title", "HAZARD")),
			" and redirects steam into %d guard%s" % [result["enemy_victims"].size(), "" if result["enemy_victims"].size() == 1 else "s"] if not result["enemy_victims"].is_empty() else "",
		])
		_resolve_surrenders()
		return result
	_resolving_damage = true
	for unit in units:
		if not is_instance_valid(unit) or not unit.is_alive or unit.grid_cell not in affected_cells:
			continue
		var injury := unit.apply_damage(zone, damage)
		environment_injury_resolved.emit(String(event.get("title", "Train hazard")), unit, zone, injury)
		if bool(event.get("stagger", false)):
			unit.set_meta("train_staggered", true)
		if bool(event.get("strips_cover", false)):
			unit.set_cover_stance(false)
		var key := "crew_victims" if unit.team == Types.Team.PLAYER else "enemy_victims"
		result[key].append(unit.display_name)
	_log("LIVING TRAIN / %s — %d crew and %d guards caught." % [
		String(event.get("title", "HAZARD")), result["crew_victims"].size(), result["enemy_victims"].size(),
	])
	_resolve_surrenders()
	_resolving_damage = false
	_check_terminal_state()
	return result


func start_battle() -> void:
	encounter_active = true
	round_number = 1
	encounter_stats["rounds"] = 1
	_log("%s — %s" % [encounter_title, objective_text])
	_begin_player_turn()


func _begin_player_turn() -> void:
	if _check_terminal_state():
		return
	phase = Types.Phase.PLAYER
	for unit in player_units(true):
		unit.begin_turn()
	_log("ROUND %d — crew turn." % round_number)
	if not is_instance_valid(selected_unit) or not selected_unit.is_alive:
		var available := player_units(true)
		if not available.is_empty():
			select_unit(available[0])
	state_changed.emit()


func end_player_turn() -> void:
	if phase != Types.Phase.PLAYER:
		return
	clear_selection_highlights()
	phase = Types.Phase.ENEMY
	state_changed.emit()
	_log("Rail guards respond.")
	await _run_enemy_turn()


func _run_enemy_turn() -> void:
	var target_pressure := {}
	for enemy in enemy_units(true):
		if _check_terminal_state():
			return
		await run_enemy_activation(enemy, target_pressure)

	if _check_terminal_state():
		return
	round_number += 1
	encounter_stats["rounds"] = round_number
	_begin_player_turn()


func begin_autobattle_encounter() -> void:
	autobattle_enabled = true
	encounter_active = true
	round_number = 0
	encounter_stats["rounds"] = 0
	phase = Types.Phase.BUSY
	clear_selection_highlights()
	_log("%s — %s" % [encounter_title, objective_text])
	state_changed.emit()


func run_enemy_activation(enemy: TacticalUnit, target_pressure: Dictionary = {}) -> void:
	if not is_instance_valid(enemy) or not enemy.is_combat_active() or _check_terminal_state():
		return
	enemy.begin_turn()
	await _resolve_overwatch(enemy)
	if not enemy.is_combat_active() or _check_terminal_state():
		return
	await _try_enemy_support(enemy)
	var movement_actions := 0
	var shots_taken := 0
	var shot_limit := 2 if enemy.role_id == "boss" else 1
	while enemy.action_points > 0 and enemy.is_combat_active():
		var target := _nearest_player(enemy, target_pressure)
		if not is_instance_valid(target):
			break
		var destination := _best_enemy_destination(enemy, target)
		if (
			shots_taken == 0
			and movement_actions == 0
			and enemy.action_points >= 2
			and destination != enemy.grid_cell
			and _should_enemy_reposition(enemy, target, destination)
		):
			if await _move_enemy(enemy, destination, target):
				movement_actions += 1
				continue

		if shots_taken < shot_limit and can_attack(enemy, target):
			target_pressure[target] = int(target_pressure.get(target, 0)) + 1
			var zone := _choose_enemy_zone(target, enemy.action_points)
			var shot_cost := Types.zone_ap_cost(zone)
			if not enemy.spend_action_point(shot_cost):
				zone = Types.BodyZone.TORSO
				enemy.spend_action_point(1)
			await _perform_attack(enemy, target, zone)
			shots_taken += 1
			encounter_stats["ai_shots"] = int(encounter_stats.get("ai_shots", 0)) + 1
			if enemy.role_id != "boss":
				await _enemy_post_shot_action(enemy, target)
				break
			continue

		if movement_actions == 0 and destination != enemy.grid_cell:
			if await _move_enemy(enemy, destination, target):
				movement_actions += 1
				continue

		_enemy_take_cover_action(enemy)
		break


func plan_environment_preview(action_id: String, actor: TacticalUnit = null) -> Dictionary:
	# Authored rigging/valves are remote openings prepared before boarding. The
	# impacted cells, rather than proximity ranking, govern every damage result.
	var preview := {"valid": false, "action_id": action_id, "remote_trigger": true, "affected_cells": [], "victims": []}
	if action_id not in [
		"chandelier", "bottle_fire", "steam_valve", "lash_freight", "lock_service_cart",
		"dog_the_lockers", "jam_the_press", "drop_storm_shutters", "set_cargo_brake", "lock_the_tables",
	]:
		return preview
	var impact_cell := Vector2i(9, 2)
	var action_label := "drops the Dining Car chandelier"
	var primary_zone := Types.BodyZone.LEGS
	var primary_damage := 2
	var secondary_damage := 1
	var control_only := false
	match action_id:
		"lash_freight":
			impact_cell = Vector2i(7, 1)
			action_label = "lashes the Boarding Car freight to the deck rings"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"lock_service_cart":
			impact_cell = Vector2i(9, 2)
			action_label = "locks the Dining Car service cart across the brace rail"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"dog_the_lockers":
			impact_cell = Vector2i(8, 4)
			action_label = "dogs every Crew Car locker latch"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"jam_the_press":
			impact_cell = Vector2i(11, 2)
			action_label = "jams the Armory ammunition press clutch"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"drop_storm_shutters":
			impact_cell = Vector2i(10, 0)
			action_label = "drops the Observation Car storm shutters"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"set_cargo_brake":
			impact_cell = Vector2i(7, 2)
			action_label = "sets the Cargo Car independent brake"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"lock_the_tables":
			impact_cell = Vector2i(9, 2)
			action_label = "locks the Casino gaming tables to their floor catches"
			primary_damage = 0
			secondary_damage = 0
			control_only = true
		"bottle_fire":
			impact_cell = Vector2i(13, 1)
			action_label = "ignites the Bar Car backbar"
			primary_zone = Types.BodyZone.TORSO
			primary_damage = 3
			secondary_damage = 1
		"steam_valve":
			impact_cell = Vector2i(15, 3)
			action_label = "bleeds the Engine Car pressure valve"
			primary_zone = Types.BodyZone.ARMS
			primary_damage = 2
			secondary_damage = 2
	var affected: Array[Vector2i] = []
	for x in range(maxi(0, impact_cell.x - 2), mini(board.BOARD_SIZE.x, impact_cell.x + 3)):
		for y in range(maxi(0, impact_cell.y - 2), mini(board.BOARD_SIZE.y, impact_cell.y + 3)):
			var cell := Vector2i(x, y)
			if cell == impact_cell or (not control_only and board.grid_distance(cell, impact_cell) <= 2):
				affected.append(cell)
	var victims: Array[Dictionary] = []
	if not control_only:
		for enemy in enemy_units(true):
			if enemy.grid_cell in affected:
				victims.append({"instance_id": enemy.get_instance_id(), "name": enemy.display_name, "cell": enemy.grid_cell})
	preview.merge({"valid": true, "impact_cell": impact_cell, "affected_cells": affected, "victims": victims, "control_only": control_only,
		"primary_zone": int(primary_zone), "primary_damage": primary_damage, "secondary_damage": secondary_damage,
		"action_label": action_label, "actor_name": actor.display_name if is_instance_valid(actor) else ""}, true)
	return preview


func perform_plan_environment_action(action_id: String, actor: TacticalUnit) -> Dictionary:
	var result := {"ok": false, "action_id": action_id, "victims": [], "risk_hit": ""}
	if not autobattle_enabled or phase != Types.Phase.PLAYER or not is_instance_valid(actor) or actor.action_points < 1:
		return result
	var preview := plan_environment_preview(action_id, actor)
	if not bool(preview.get("valid", false)):
		return result
	var impact_cell: Vector2i = preview["impact_cell"]
	var control_only := bool(preview["control_only"])
	var primary_zone: Types.BodyZone = int(preview["primary_zone"])
	actor.spend_action_point(1)
	phase = Types.Phase.BUSY
	state_changed.emit()
	actor.play_throw_animation()
	await _play_grenade_feedback(board.cell_to_world(impact_cell) + Vector3(0.0, 0.85, 0.0), actor.shot_origin(), false, action_id)
	_resolving_damage = true
	if not control_only:
		for victim in enemy_units(true):
			if victim.grid_cell not in Array(preview["affected_cells"]):
				continue
			victim.apply_damage(primary_zone, int(preview["primary_damage"]))
			if victim.is_alive:
				var secondary_zone := Types.BodyZone.LEGS if primary_zone != Types.BodyZone.LEGS else Types.BodyZone.TORSO
				victim.apply_damage(secondary_zone, int(preview["secondary_damage"]))
			result["victims"].append(victim.display_name)
	var exposed_crew: TacticalUnit
	var closest := 999
	for crew in player_units(true):
		var distance := board.grid_distance(crew.grid_cell, impact_cell)
		if distance < closest:
			closest = distance
			exposed_crew = crew
	if not control_only and is_instance_valid(exposed_crew) and exposed_crew.grid_cell in Array(preview["affected_cells"]) and rng.randf() < 0.18:
		var injury := exposed_crew.apply_damage(Types.BodyZone.LEGS, 1)
		environment_injury_resolved.emit(action_id.replace("_", " "), exposed_crew, Types.BodyZone.LEGS, injury)
		result["risk_hit"] = exposed_crew.display_name
	_resolve_surrenders()
	result["ok"] = true
	result["control_only"] = control_only
	result["affected_cells"] = preview["affected_cells"]
	result["train_counter"] = control_only or action_id == String(active_enemy_doctrine.get("counter_action", ""))
	if action_id == "chandelier" and active_car_id == "dining":
		active_enemy_doctrine["suppressed"] = true
	_log("%s %s — %d guard%s caught in the hazard.%s" % [
		actor.display_name,
		String(preview["action_label"]),
		result["victims"].size(),
		"" if result["victims"].size() == 1 else "s",
		" %s is clipped in the legs." % result["risk_hit"] if not String(result["risk_hit"]).is_empty() else "",
	])
	environment_resolved.emit(action_id, actor, result)
	_resolving_damage = false
	if not _check_terminal_state():
		phase = Types.Phase.PLAYER
		state_changed.emit()
	return result


func _move_enemy(enemy: TacticalUnit, destination: Vector2i, target: TacticalUnit) -> bool:
	if destination == enemy.grid_cell or enemy.action_points < 1:
		return false
	var path := board.find_path(
		enemy.grid_cell,
		destination,
		occupied_cells(enemy),
		enemy.movement_range()
	)
	if path.is_empty() or not enemy.spend_action_point(1):
		return false
	var old_target_cover := board.cover_penalty(enemy.grid_cell, target.grid_cell)
	var new_target_cover := board.cover_penalty(destination, target.grid_cell)
	var destination_cover := board.cover_penalty(target.grid_cell, destination)
	_log("%s %s to %s." % [enemy.display_name, _enemy_move_verb(enemy.role_id), board.cover_name(target.grid_cell, destination).to_lower()])
	encounter_stats["ai_moves"] = int(encounter_stats.get("ai_moves", 0)) + 1
	if destination_cover > 0.0:
		encounter_stats["ai_cover_moves"] = int(encounter_stats.get("ai_cover_moves", 0)) + 1
	if new_target_cover + 0.01 < old_target_cover:
		encounter_stats["ai_flanks"] = int(encounter_stats.get("ai_flanks", 0)) + 1
	await enemy.move_along_path(path)
	await get_tree().create_timer(0.18).timeout
	_resolve_cell_effects(enemy)
	await _resolve_overwatch(enemy)
	return enemy.is_alive and not _check_terminal_state()


func _enemy_move_verb(role_id: String) -> String:
	match role_id:
		"marksman":
			return "withdraws"
		"duelist":
			return "flanks"
		"bruiser":
			return "presses forward"
		"medic":
			return "shifts behind the line"
		"officer":
			return "takes command position"
		"boss":
			return "repositions"
	return "moves"


func _enemy_take_cover_action(enemy: TacticalUnit) -> bool:
	if enemy.action_points < 1 or enemy.crouched or not enemy.can_take_cover():
		return false
	if not enemy.spend_action_point(1) or not enemy.enter_cover_stance():
		return false
	encounter_stats["ai_cover_actions"] = int(encounter_stats.get("ai_cover_actions", 0)) + 1
	_log("%s %s (-%d%% incoming hit)." % [
		enemy.display_name,
		"hunkers behind cover" if enemy.is_in_physical_cover() else "ducks low",
		roundi(enemy.cover_defense_bonus() * 100.0),
	])
	return true


func _enemy_post_shot_action(enemy: TacticalUnit, target: TacticalUnit) -> void:
	if enemy.action_points < 1 or not enemy.is_alive:
		return
	if enemy.role_id in ["bruiser", "duelist"]:
		var destination := _best_enemy_destination(enemy, target)
		if destination != enemy.grid_cell and await _move_enemy(enemy, destination, target):
			return
	_enemy_take_cover_action(enemy)


func _resolve_overwatch(enemy: TacticalUnit) -> void:
	if not is_instance_valid(enemy) or not enemy.is_alive:
		return
	for watcher in player_units(true):
		if not watcher.overwatch_active:
			continue
		if watcher.uses_ammunition and watcher.ammunition <= 0:
			watcher.overwatch_active = false
			watcher._update_labels()
			continue
		if not can_attack(watcher, enemy):
			continue
		watcher.overwatch_active = false
		if not watcher.consume_round():
			continue
		encounter_stats["shots"] = int(encounter_stats.get("shots", 0)) + 1
		encounter_stats["overwatch_shots"] = int(encounter_stats.get("overwatch_shots", 0)) + 1
		_log("OVERWATCH — %s interrupts %s." % [watcher.display_name, enemy.display_name])
		await _perform_attack(watcher, enemy, Types.BodyZone.TORSO)
		if not enemy.is_alive:
			return


func _try_enemy_support(enemy: TacticalUnit) -> void:
	if not enemy.is_combat_active() or enemy.role_id != "medic" or enemy.action_points < 1:
		return
	var patient: TacticalUnit
	var lowest_ratio := 1.0
	for ally in enemy_units(true):
		if ally == enemy:
			continue
		var torso: Dictionary = ally.body_state[Types.BodyZone.TORSO]
		var ratio := float(torso["hp"]) / maxf(1.0, float(torso["max_hp"]))
		if ratio < lowest_ratio:
			lowest_ratio = ratio
			patient = ally
	if not is_instance_valid(patient) or not patient.heal_weakest_body_zone(2):
		return
	enemy.spend_action_point()
	_log("%s patches %s for 2 body-zone health." % [enemy.display_name, patient.display_name])
	await get_tree().create_timer(0.18).timeout


func select_unit(unit: TacticalUnit) -> void:
	if phase != Types.Phase.PLAYER or not is_instance_valid(unit):
		return
	if not unit.is_alive or unit.team != Types.Team.PLAYER:
		return
	if is_instance_valid(selected_unit):
		selected_unit.set_selected(false)
	selected_unit = unit
	selected_unit.set_selected(true)
	_show_reachable_cells()
	selection_changed.emit(selected_unit, current_target)
	state_changed.emit()


func set_target(unit: TacticalUnit) -> void:
	if not is_instance_valid(unit) or not unit.is_alive or unit.team != Types.Team.ENEMY:
		return
	if is_instance_valid(current_target):
		current_target.set_targeted(false)
	current_target = unit
	current_target.set_targeted(true)
	current_target.set_called_shot_zone(target_zone)
	_show_reachable_cells()
	selection_changed.emit(selected_unit, current_target)
	state_changed.emit()


func set_target_zone(zone: Types.BodyZone) -> void:
	if is_instance_valid(current_target) and current_target.is_zone_detached(zone):
		_log("%s's %s is already gone; choose another target zone." % [current_target.display_name, Types.zone_name(zone)])
		return
	target_zone = zone
	if is_instance_valid(current_target):
		current_target.set_called_shot_zone(zone)
	state_changed.emit()


func try_move(destination: Vector2i) -> void:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit):
		return
	if selected_unit.action_points <= 0 or selected_unit.is_moving:
		_log("%s has no action points remaining." % selected_unit.display_name)
		return
	var path := board.find_path(
		selected_unit.grid_cell,
		destination,
		occupied_cells(selected_unit),
		selected_unit.movement_range()
	)
	if path.size() <= 1:
		_log("That tile is blocked or outside %s's movement range." % selected_unit.display_name)
		return
	selected_unit.spend_action_point()
	encounter_stats["moves"] = int(encounter_stats.get("moves", 0)) + 1
	phase = Types.Phase.BUSY
	board.set_highlights([], path)
	state_changed.emit()
	await selected_unit.move_along_path(path)
	_resolve_cell_effects(selected_unit)
	if _check_terminal_state():
		return
	phase = Types.Phase.PLAYER
	_show_reachable_cells()
	state_changed.emit()
	_auto_end_if_spent()


func try_claim_control() -> bool:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit) or selected_unit.action_points < 1 or board.control_claimed:
		return false
	if board.grid_distance(selected_unit.grid_cell, board.control_cell) > 1:
		return false
	for enemy in enemy_units(true):
		if board.grid_distance(enemy.grid_cell, board.control_cell) <= 1:
			_log("%s cannot seize the controls while %s contests the station." % [selected_unit.display_name, enemy.display_name])
			return false
	selected_unit.spend_action_point()
	board.claim_control()
	encounter_stats["control_claims"] = int(encounter_stats.get("control_claims", 0)) + 1
	_log("%s seizes the carriage controls." % selected_unit.display_name)
	_resolve_surrenders()
	_check_terminal_state()
	state_changed.emit()
	return true


func try_attack(target: TacticalUnit = null) -> void:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit):
		return
	if not is_instance_valid(target):
		target = current_target
	if not is_instance_valid(target) or not target.is_alive:
		_log("Select a living rail guard first.")
		return
	if not can_target_zone(target, target_zone):
		_log("That body part can no longer be targeted.")
		return
	var shot_cost := Types.zone_ap_cost(target_zone)
	if selected_unit.action_points < shot_cost:
		_log("%s needs %d AP for that called shot." % [selected_unit.display_name, shot_cost])
		return
	if selected_unit.uses_ammunition and selected_unit.ammunition <= 0:
		_log("%s's %s is empty. Reload for 1 AP." % [selected_unit.display_name, selected_unit.weapon_name])
		return
	if not can_attack(selected_unit, target):
		var distance := board.grid_distance(selected_unit.grid_cell, target.grid_cell)
		_log("No clean shot: range %d, or the train interior blocks line of sight." % distance)
		return
	selected_unit.spend_action_point(shot_cost)
	if not selected_unit.consume_round():
		return
	encounter_stats["shots"] = int(encounter_stats.get("shots", 0)) + 1
	phase = Types.Phase.BUSY
	clear_selection_highlights()
	state_changed.emit()
	await _perform_attack(selected_unit, target, target_zone)
	if _check_terminal_state():
		return
	phase = Types.Phase.PLAYER
	_show_reachable_cells()
	state_changed.emit()
	_auto_end_if_spent()


func try_reload() -> bool:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit):
		return false
	if selected_unit.action_points < 1:
		_log("%s has no AP left to reload." % selected_unit.display_name)
		return false
	if not selected_unit.can_reload():
		_log("%s cannot reload with crippled arms." % selected_unit.display_name if selected_unit.arms_crippled() else "%s's %s is already loaded." % [selected_unit.display_name, selected_unit.weapon_name])
		return false
	selected_unit.spend_action_point()
	selected_unit.reload_weapon()
	encounter_stats["reloads"] = int(encounter_stats.get("reloads", 0)) + 1
	_log("%s reloads %s — %d rounds ready." % [selected_unit.display_name, selected_unit.weapon_name, selected_unit.ammunition])
	state_changed.emit()
	_auto_end_if_spent()
	return true


func try_overwatch() -> bool:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit):
		return false
	if selected_unit.action_points < 1:
		_log("%s has no AP left for overwatch." % selected_unit.display_name)
		return false
	if not selected_unit.can_overwatch():
		_log("%s cannot hold overwatch with crippled arms." % selected_unit.display_name)
		return false
	if selected_unit.uses_ammunition and selected_unit.ammunition <= 0:
		_log("Reload before setting overwatch.")
		return false
	selected_unit.spend_action_point()
	selected_unit.overwatch_active = true
	selected_unit._update_labels()
	_log("%s watches the carriage with %s." % [selected_unit.display_name, selected_unit.weapon_name])
	state_changed.emit()
	_auto_end_if_spent()
	return true


func try_take_cover() -> bool:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit) or not selected_unit.is_alive:
		return false
	if selected_unit.crouched:
		_log("%s is already in a defensive stance." % selected_unit.display_name)
		return false
	if not selected_unit.can_take_cover():
		_log("%s cannot take cover with crippled legs." % selected_unit.display_name)
		return false
	if not selected_unit.spend_action_point(1):
		_log("%s has no AP left to take cover." % selected_unit.display_name)
		return false
	selected_unit.enter_cover_stance()
	var defense := roundi(selected_unit.cover_defense_bonus() * 100.0)
	_log("%s %s: incoming shots suffer -%d%% hit." % [
		selected_unit.display_name,
		"hunkers behind cover" if selected_unit.is_in_physical_cover() else "ducks low",
		defense,
	])
	_show_reachable_cells()
	state_changed.emit()
	_auto_end_if_spent()
	return true


func try_signature_ability() -> bool:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit):
		return false
	if selected_unit.ability_id.is_empty() or selected_unit.ability_used:
		_log("%s has already used their signature ability this car." % selected_unit.display_name)
		return false
	var applied := true
	match selected_unit.ability_id:
		"deadeye":
			selected_unit.apply_focus_bonus(0.25, 0.20)
		"breach_charge":
			selected_unit.signature_damage_bonus = 0.55
			selected_unit.signature_accuracy_bonus = 0.10
		"overclock":
			selected_unit.action_points += 1
			selected_unit.bonus_movement_this_turn += 2
		"field_repair":
			applied = selected_unit.heal_weakest_body_zone(4)
			if not applied:
				_log("Iona has no damaged body zone to repair.")
		"quickdraw":
			selected_unit.action_points += 1
			selected_unit.signature_critical_bonus = 0.12
		"iron_stance":
			selected_unit.damage_resistance = 0.40
			selected_unit.set_meta("signature_guard", 0.40)
		_:
			applied = false
	if not applied:
		return false
	selected_unit.ability_used = true
	selected_unit._update_labels()
	encounter_stats["abilities"] = int(encounter_stats.get("abilities", 0)) + 1
	_log("%s uses %s — %s" % [selected_unit.display_name, selected_unit.ability_name, selected_unit.ability_description])
	_show_reachable_cells()
	state_changed.emit()
	return true


func can_use_grenade(target: TacticalUnit = null) -> bool:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit) or selected_unit.action_points < 1:
		return false
	if not is_instance_valid(target):
		target = current_target
	if not is_instance_valid(target) or not target.is_combat_active():
		return false
	return board.grid_distance(selected_unit.grid_cell, target.grid_cell) <= 6


func try_grenade(target: TacticalUnit = null) -> bool:
	if not is_instance_valid(target):
		target = current_target
	if not can_use_grenade(target):
		_log("Grenade needs a living target within six tiles and 1 AP.")
		return false
	selected_unit.spend_action_point()
	encounter_stats["grenades"] = int(encounter_stats.get("grenades", 0)) + 1
	phase = Types.Phase.BUSY
	clear_selection_highlights()
	state_changed.emit()
	selected_unit.play_throw_animation()
	await _play_grenade_feedback(target.zone_world_position(Types.BodyZone.TORSO), selected_unit.shot_origin(), true, "grenade")
	var blast_cell := target.grid_cell
	var victims: Array[TacticalUnit] = []
	_resolving_damage = true
	for enemy in enemy_units(true):
		if board.grid_distance(enemy.grid_cell, blast_cell) <= 1:
			victims.append(enemy)
	for victim in victims:
		if victim == target and victim.is_alive:
			var extremities: Array[Types.BodyZone] = [Types.BodyZone.ARMS, Types.BodyZone.LEGS]
			var limb := extremities[rng.randi_range(0, extremities.size() - 1)]
			if not victim.is_zone_detached(limb):
				victim.apply_damage(limb, 2)
		if victim.is_alive:
			victim.apply_damage(Types.BodyZone.TORSO, 4 if victim == target else 3)
	_resolve_surrenders()
	_log("%s detonates a Clockwork Grenade — %d guard%s caught in the blast." % [selected_unit.display_name, victims.size(), "" if victims.size() == 1 else "s"])
	_resolving_damage = false
	if not autobattle_enabled and _check_terminal_state():
		return true
	phase = Types.Phase.PLAYER
	_show_reachable_cells()
	state_changed.emit()
	_auto_end_if_spent()
	if autobattle_enabled:
		# Let the director record the consumed item before a grenade victory builds
		# its aftermath. There is no subsequent initiative action in this frame.
		_check_terminal_state.call_deferred()
	return true


func _perform_attack(
		attacker: TacticalUnit,
		target: TacticalUnit,
		zone: Types.BodyZone
	) -> void:
	if not attacker.is_alive or not target.is_alive:
		return
	var target_position := target.global_position
	target_position.y = attacker.global_position.y
	attacker.look_at(target_position, Vector3.UP, true)
	var chance := attack_chance(attacker, target, zone)
	var rolled_critical_chance := critical_chance(attacker, target, zone)
	var shot_damage_multiplier := attacker.damage_multiplier()
	var roll := rng.randf()
	var hit := roll <= chance
	attacker.play_shoot_animation()
	await _play_shot_feedback(attacker, target, zone, hit)
	if attacker.team == Types.Team.PLAYER:
		attacker.clear_shot_bonuses()
	if roll > chance:
		_log(
			"%s misses %s's %s - %d%% shot."
			% [attacker.display_name, target.display_name, Types.zone_name(zone), roundi(chance * 100.0)]
		)
		attack_resolved.emit(attacker, target, zone, {"hit": false, "critical": false, "damage": 0, "defeated": false, "disabled": false, "detached": false, "chance": chance})
		return

	var critical := rng.randf() <= rolled_critical_chance
	var raw_damage := attacker.base_damage * shot_damage_multiplier
	if critical:
		raw_damage = raw_damage * 1.45 + 1.0
	var damage := maxi(1, roundi(raw_damage * float(Types.BODY_ZONE_DAMAGE_MULTIPLIER[zone])))
	_resolving_damage = true
	var result := target.apply_damage(zone, damage, critical)
	_resolve_surrenders()
	if attacker.team == Types.Team.PLAYER:
		encounter_stats["hits"] = int(encounter_stats.get("hits", 0)) + 1
		if bool(result["defeated"]):
			encounter_stats["kills"] = int(encounter_stats.get("kills", 0)) + 1
	var consequence := ""
	if bool(result["detached"]):
		consequence = " %s severed." % Types.zone_name(zone)
	elif bool(result["disabled"]):
		consequence = " %s disabled." % Types.zone_name(zone)
	if bool(result["defeated"]):
		consequence = " Target down."
	var critical_text := " CRITICAL." if critical else ""
	_log(
		"%s hits %s's %s for %d - %d%% shot.%s%s"
		% [
			attacker.display_name,
			target.display_name,
			Types.zone_name(zone),
			int(result.get("damage", damage)),
			roundi(chance * 100.0),
			critical_text,
			consequence,
		]
	)
	var resolved_result := result.duplicate(true)
	resolved_result["hit"] = true
	resolved_result["chance"] = chance
	attack_resolved.emit(attacker, target, zone, resolved_result)
	_resolving_damage = false
	_check_terminal_state()
	await get_tree().create_timer(0.16).timeout


func can_attack(attacker: TacticalUnit, target: TacticalUnit) -> bool:
	if not attacker.is_combat_active() or not target.is_combat_active():
		return false
	var distance := board.grid_distance(attacker.grid_cell, target.grid_cell)
	return distance <= attacker.attack_range and board.has_line_of_sight(attacker.grid_cell, target.grid_cell)


func can_target_zone(target: TacticalUnit, zone: Types.BodyZone) -> bool:
	return is_instance_valid(target) and target.is_combat_active() and not target.is_zone_detached(zone)


func attack_chance(
		attacker: TacticalUnit,
		target: TacticalUnit,
		zone: Types.BodyZone = target_zone
	) -> float:
	if not can_attack(attacker, target):
		return 0.0
	if not can_target_zone(target, zone):
		return 0.0
	var distance := board.grid_distance(attacker.grid_cell, target.grid_cell)
	var chance := 0.88
	chance -= maxf(0.0, float(distance - 2)) * 0.035
	chance -= board.cover_penalty(attacker.grid_cell, target.grid_cell)
	chance -= target.cover_defense_bonus()
	chance -= float(Types.BODY_ZONE_AIM_PENALTY[zone])
	chance -= attacker.accuracy_penalty()
	chance += attacker.weapon_accuracy_bonus
	if attacker.team == Types.Team.PLAYER:
		chance += squad_accuracy_bonus
	chance = clampf(chance, 0.10, 0.95)
	chance += attacker.signature_accuracy_bonus
	if attacker.team == Types.Team.PLAYER:
		chance += attacker.focus_accuracy_bonus
	return clampf(chance, 0.10, 0.99)


func target_defense_text(attacker: TacticalUnit, target: TacticalUnit) -> String:
	if not is_instance_valid(attacker) or not is_instance_valid(target):
		return ""
	var pieces: Array[String] = []
	var level := board.cover_level(attacker.grid_cell, target.grid_cell)
	if level > 0:
		pieces.append("%s -%d%%" % [board.cover_name(attacker.grid_cell, target.grid_cell), 28 if level == 2 else 14])
	if target.crouched:
		pieces.append("%s -%d%%" % [target.cover_stance_name(), roundi(target.cover_defense_bonus() * 100.0)])
	return " / ".join(pieces) if not pieces.is_empty() else "EXPOSED"


func critical_chance(
		attacker: TacticalUnit,
		_target: TacticalUnit,
		zone: Types.BodyZone
	) -> float:
	var result := 0.08
	match zone:
		Types.BodyZone.HEAD:
			result = 0.24
		Types.BodyZone.ARMS:
			result = 0.14
		Types.BodyZone.LEGS:
			result = 0.12
	result += attacker.weapon_critical_bonus + attacker.signature_critical_bonus
	if attacker.team == Types.Team.PLAYER:
		result += squad_critical_bonus + attacker.focus_critical_bonus
	return clampf(result, 0.0, 0.75)


func _play_grenade_feedback(destination: Vector3, origin: Vector3 = Vector3.ZERO, show_projectile: bool = false, effect_id: String = "grenade") -> void:
	if show_projectile:
		var projectile := Node3D.new()
		projectile.name = "ClockworkGrenadeProjectile"
		get_tree().current_scene.add_child(projectile)
		projectile.global_position = origin
		var grenade_body := MeshInstance3D.new()
		var grenade_mesh := SphereMesh.new()
		grenade_mesh.radius = 0.11
		grenade_mesh.height = 0.22
		grenade_body.mesh = grenade_mesh
		var grenade_material := StandardMaterial3D.new()
		grenade_material.albedo_color = Color("#2a302f")
		grenade_material.metallic = 0.82
		grenade_material.roughness = 0.34
		grenade_body.material_override = grenade_material
		projectile.add_child(grenade_body)
		var grenade_band := MeshInstance3D.new()
		var band_mesh := TorusMesh.new()
		band_mesh.inner_radius = 0.095
		band_mesh.outer_radius = 0.122
		grenade_band.mesh = band_mesh
		grenade_band.rotation_degrees.x = 90.0
		var band_material := StandardMaterial3D.new()
		band_material.albedo_color = Color("#b27a32")
		band_material.metallic = 0.92
		band_material.roughness = 0.28
		grenade_band.material_override = band_material
		projectile.add_child(grenade_band)
		var midpoint := (origin + destination) * 0.5 + Vector3(0.0, 2.0, 0.0)
		var throw_tween := projectile.create_tween()
		throw_tween.set_trans(Tween.TRANS_QUAD)
		throw_tween.set_ease(Tween.EASE_OUT)
		throw_tween.tween_property(projectile, "global_position", midpoint, 0.16)
		throw_tween.parallel().tween_property(projectile, "rotation_degrees", Vector3(260.0, 160.0, 90.0), 0.32)
		throw_tween.tween_property(projectile, "global_position", destination, 0.16).set_ease(Tween.EASE_IN)
		await throw_tween.finished
		projectile.queue_free()
	var blast := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.18
	mesh.height = 0.36
	blast.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#d9eff0") if effect_id == "steam_valve" else Color("#ffcf70")
	material.emission_enabled = true
	material.emission = Color("#b8ffff") if effect_id == "steam_valve" else Color("#ff5b2e")
	material.emission_energy_multiplier = 4.0 if effect_id == "steam_valve" else 8.0
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	blast.material_override = material
	get_tree().current_scene.add_child(blast)
	blast.global_position = destination
	var tween := blast.create_tween()
	tween.set_parallel(true)
	var blast_scale := Vector3(4.0, 8.0, 4.0) if effect_id == "steam_valve" else Vector3(7.0, 7.0, 7.0)
	tween.tween_property(blast, "scale", blast_scale, 0.28).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tween.tween_property(material, "albedo_color:a", 0.0, 0.28)
	await tween.finished
	blast.queue_free()


func _play_shot_feedback(
		attacker: TacticalUnit,
		target: TacticalUnit,
		zone: Types.BodyZone,
		hit: bool
	) -> void:
	var tracer := MeshInstance3D.new()
	var tracer_mesh := SphereMesh.new()
	tracer_mesh.radius = 0.055
	tracer_mesh.height = 0.11
	tracer.mesh = tracer_mesh
	var tracer_material := StandardMaterial3D.new()
	tracer_material.albedo_color = Color("#ffe2a1")
	tracer_material.emission_enabled = true
	tracer_material.emission = Color("#ff9f35")
	tracer_material.emission_energy_multiplier = 6.0
	tracer.material_override = tracer_material
	tracer.scale = Vector3(0.72, 0.72, 2.8)
	get_tree().current_scene.add_child(tracer)
	tracer.global_position = attacker.shot_origin()
	var destination := target.zone_world_position(zone)
	if not hit:
		destination += Vector3(
			presentation_rng.randf_range(-0.65, 0.65),
			presentation_rng.randf_range(0.25, 0.75),
			presentation_rng.randf_range(-0.65, 0.65)
		)
	tracer.look_at(destination, Vector3.UP)
	var tween := tracer.create_tween()
	tween.set_trans(Tween.TRANS_EXPO)
	tween.set_ease(Tween.EASE_IN)
	tween.tween_property(tracer, "global_position", destination, 0.13)
	await tween.finished
	tracer.queue_free()
	_spawn_impact_feedback(destination, hit)


func _spawn_impact_feedback(destination: Vector3, hit: bool) -> void:
	var impact := MeshInstance3D.new()
	impact.name = "BodyImpactSpark" if hit else "RicochetSpark"
	var mesh := SphereMesh.new()
	mesh.radius = 0.075 if hit else 0.052
	mesh.height = 0.15 if hit else 0.10
	impact.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#ffd47a") if hit else Color("#8ad4dc")
	material.emission_enabled = true
	material.emission = Color("#ff682f") if hit else Color("#54c6d0")
	material.emission_energy_multiplier = 8.0 if hit else 5.0
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	impact.material_override = material
	impact.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_tree().current_scene.add_child(impact)
	impact.global_position = destination
	var light := OmniLight3D.new()
	light.light_color = material.emission
	light.light_energy = 2.6 if hit else 1.4
	light.omni_range = 2.2
	light.shadow_enabled = false
	impact.add_child(light)
	var tween := impact.create_tween()
	tween.set_parallel(true)
	tween.tween_property(impact, "scale", Vector3(3.6, 3.6, 3.6) if hit else Vector3(2.2, 2.2, 2.2), 0.17).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tween.tween_property(material, "albedo_color:a", 0.0, 0.17)
	tween.tween_property(light, "light_energy", 0.0, 0.15)
	tween.chain().tween_callback(impact.queue_free)


func occupied_cells(except_unit: TacticalUnit = null) -> Dictionary:
	var occupied := {}
	for unit in units:
		if unit != except_unit and unit.is_combat_active():
			occupied[unit.grid_cell] = unit
	return occupied


func _show_reachable_cells() -> void:
	if phase != Types.Phase.PLAYER or not is_instance_valid(selected_unit):
		board.clear_highlights()
		return
	if selected_unit.action_points <= 0:
		board.clear_highlights()
		return
	var reachable := board.get_reachable(
		selected_unit.grid_cell,
		selected_unit.movement_range(),
		occupied_cells(selected_unit)
	)
	var cells: Array = reachable.keys()
	cells.erase(selected_unit.grid_cell)
	board.set_highlights(cells)
	if is_instance_valid(current_target) and current_target.is_alive:
		var preview_cells := cells.duplicate()
		preview_cells.append(selected_unit.grid_cell)
		board.show_cover_preview(current_target.grid_cell, preview_cells)
	else:
		board.hide_cover_preview()


func clear_selection_highlights() -> void:
	board.clear_highlights()


func _resolve_cell_effects(unit: TacticalUnit) -> void:
	if not unit.is_alive:
		return
	if board.hazard_cells.has(unit.grid_cell):
		var zone := Types.BodyZone.LEGS
		var result := unit.apply_damage(zone, 2)
		_log("A steam vent scorches %s's %s for 2.%s" % [
			unit.display_name,
			Types.zone_name(zone),
			" Legs crippled." if bool(result["disabled"]) else "",
		])

	if encounter_mode in ["blueprint", "finale"] and unit.team == Types.Team.PLAYER and not board.objective_collected and unit.grid_cell == board.objective_cell:
		board.collect_objective()
		unit.set_objective_carrier(true)
		_log("%s seizes the stolen locomotive blueprints. Get back to extraction!" % unit.display_name)

	if encounter_mode in ["blueprint", "finale"] and unit.team == Types.Team.PLAYER and unit.carries_objective and unit.grid_cell == board.extraction_cell:
		phase = Types.Phase.VICTORY
		encounter_active = false
		if encounter_mode == "finale":
			encounter_stats["finale_escapes"] = int(encounter_stats.get("finale_escapes", 0)) + 1
		clear_selection_highlights()
		_log("HEIST COMPLETE — the crew escapes with the blueprints.")
		mission_finished.emit(true, "BLUEPRINTS SECURED")
		state_changed.emit()


func _on_unit_defeated(unit: TacticalUnit) -> void:
	if encounter_mode == "finale" and unit.team == Types.Team.ENEMY and unit.role_id == "boss":
		board.reveal_finale_objective(unit.grid_cell)
		encounter_stats["boss_kills"] = int(encounter_stats.get("boss_kills", 0)) + 1
		_log("VOSS IS DOWN — seize the blueprint case and return to the green hatch!")
	elif encounter_mode == "takeover_finale" and unit.team == Types.Team.ENEMY and unit.role_id == "boss":
		encounter_stats["boss_kills"] = int(encounter_stats.get("boss_kills", 0)) + 1
		_log("VOSS IS DOWN — the engine controls are exposed.")
	if unit.carries_objective:
		unit.set_objective_carrier(false)
		board.drop_objective(unit.grid_cell)
		_log("The blueprint case drops onto the carriage floor.")
	if unit == current_target:
		current_target = null
		_show_reachable_cells()
	if unit == selected_unit:
		selected_unit = null
	_check_terminal_state()
	state_changed.emit()


func _on_unit_surrendered(unit: TacticalUnit) -> void:
	encounter_stats["surrenders"] = int(encounter_stats.get("surrenders", 0)) + 1
	_log("%s drops their weapon and surrenders." % unit.display_name)
	unit_surrendered.emit(unit)
	if unit == current_target:
		current_target = null
	_check_terminal_state()
	state_changed.emit()


func _resolve_surrenders() -> void:
	var command_active := false
	for enemy in enemy_units(true):
		if enemy.role_id in ["officer", "boss"] and not enemy.arms_crippled():
			command_active = true
	for enemy in enemy_units(true):
		if not enemy.arms_crippled():
			continue
		if enemy.role_id == "boss":
			if enemy.legs_crippled() and board.control_claimed:
				enemy.force_surrender()
		elif enemy.legs_crippled() or not command_active or board.control_claimed:
			enemy.force_surrender()


func _check_terminal_state() -> bool:
	if _resolving_damage:
		return false
	if phase == Types.Phase.VICTORY or phase == Types.Phase.DEFEAT:
		return true
	if player_units(true).is_empty():
		phase = Types.Phase.DEFEAT
		clear_selection_highlights()
		_log("HEIST FAILED — the crew is down.")
		mission_finished.emit(false, "THE CREW IS DOWN")
		state_changed.emit()
		return true
	if encounter_active and encounter_mode == "secure" and enemy_units(true).is_empty():
		encounter_active = false
		phase = Types.Phase.VICTORY
		clear_selection_highlights()
		_log("CAR SECURED — the route table is ready.")
		mission_finished.emit(true, "CAR SECURED")
		state_changed.emit()
		return true
	# The retained direct-control compatibility mode has no dedicated "seize"
	# button. Once its player has manually cleared the engine, hand over the empty
	# station automatically; the shipping autobattler still advances to and claims
	# the controls as an explicit authored objective.
	if encounter_active and encounter_mode == "takeover_finale" and enemy_units(true).is_empty() and not board.control_claimed and not autobattle_enabled:
		board.claim_control()
		encounter_stats["control_claims"] = int(encounter_stats.get("control_claims", 0)) + 1
		_log("The cleared engine station falls under crew control.")
	if encounter_active and encounter_mode == "takeover_finale" and enemy_units(true).is_empty() and board.control_claimed:
		encounter_active = false
		phase = Types.Phase.VICTORY
		clear_selection_highlights()
		_log("TRAIN SECURED — the engine answers to the crew.")
		encounter_stats["train_seized"] = 1
		mission_finished.emit(true, "THE TRAIN IS YOURS")
		state_changed.emit()
		return true
	return false


func _nearest_player(enemy: TacticalUnit, target_pressure: Dictionary = {}) -> TacticalUnit:
	var candidates := player_units(true)
	if _doctrine_focus_id != 0 and enemy.role_id == "railhand":
		var doctrine_target := instance_from_id(_doctrine_focus_id) as TacticalUnit
		if is_instance_valid(doctrine_target) and doctrine_target.is_alive:
			return doctrine_target
	var nearest: TacticalUnit
	var nearest_score := 1_000_000.0
	for candidate in candidates:
		var distance := float(board.grid_distance(enemy.grid_cell, candidate.grid_cell))
		var score := distance
		# Standard guards spread their fire across the crew. This prevents a
		# four-guard activation from deleting one full-health operative before
		# the player can respond, while distance still matters tactically.
		score += float(target_pressure.get(candidate, 0)) * 3.0
		if candidate.carries_objective:
			score -= 4.0
		match enemy.role_id:
			"marksman":
				# Marksmen care more about a clean exposed shot than raw proximity.
				score = distance * 0.32 + board.cover_penalty(enemy.grid_cell, candidate.grid_cell) * 8.0
				score += float(target_pressure.get(candidate, 0)) * 2.2
			"duelist":
				score -= (1.0 - _unit_health_ratio(candidate)) * 5.0
				score += board.cover_penalty(enemy.grid_cell, candidate.grid_cell) * 5.0
			"bruiser":
				score = distance * 0.72 + float(target_pressure.get(candidate, 0)) * 2.0
			"officer", "boss":
				if candidate.carries_objective:
					score -= 3.0
		# Defensive play changes enemy intent as well as the raw dice. Most guards
		# prefer a similarly placed exposed target; Duelists and Marksmen already
		# account for physical cover more aggressively in their role rules above.
		score += candidate.cover_defense_bonus() * 6.0
		if enemy.role_id not in ["marksman", "duelist"]:
			score += board.cover_penalty(enemy.grid_cell, candidate.grid_cell) * 4.0
		if score < nearest_score:
			nearest_score = score
			nearest = candidate
	return nearest


func _best_enemy_destination(enemy: TacticalUnit, target: TacticalUnit) -> Vector2i:
	var reachable := board.get_reachable(
		enemy.grid_cell,
		enemy.movement_range(),
		occupied_cells(enemy)
	)
	var best := enemy.grid_cell
	var best_score := 1_000_000.0
	for cell in reachable:
		var score := _enemy_position_score(enemy, target, cell)
		if score < best_score:
			best_score = score
			best = cell
	return best


func _should_enemy_reposition(enemy: TacticalUnit, target: TacticalUnit, destination: Vector2i) -> bool:
	if destination == enemy.grid_cell or enemy.action_points < 2:
		return false
	var current_score := _enemy_position_score(enemy, target, enemy.grid_cell)
	var destination_score := _enemy_position_score(enemy, target, destination)
	var threshold := 1.35
	match enemy.role_id:
		"marksman":
			threshold = 0.45
		"duelist":
			threshold = 0.65
		"bruiser":
			threshold = 0.80
		"medic", "officer":
			threshold = 0.75
		"boss":
			threshold = 0.55
	return destination_score + threshold < current_score


func _enemy_position_score(enemy: TacticalUnit, target: TacticalUnit, cell: Vector2i) -> float:
	var distance := board.grid_distance(cell, target.grid_cell)
	var has_sight := board.has_line_of_sight(cell, target.grid_cell)
	var preferred_range := 4
	match enemy.role_id:
		"marksman":
			preferred_range = mini(8, maxi(6, enemy.attack_range - 1))
		"duelist":
			preferred_range = 3
		"bruiser":
			preferred_range = 2
		"medic":
			preferred_range = 6
		"officer":
			preferred_range = 5
		"boss":
			preferred_range = 4

	var score := absf(float(distance - preferred_range)) * 1.18
	score += -3.8 if has_sight and distance <= enemy.attack_range else 4.6
	var defensive_cover := board.cover_penalty(target.grid_cell, cell)
	var target_cover := board.cover_penalty(cell, target.grid_cell)
	var cover_weight := 12.0
	if enemy.role_id in ["marksman", "medic", "officer"]:
		cover_weight = 16.0
	elif enemy.role_id == "bruiser":
		cover_weight = 6.0
	score -= defensive_cover * cover_weight
	# A firing position that removes the player's cover is a flank, and duelists
	# value it more than simply shortening the range.
	score += target_cover * (15.0 if enemy.role_id == "duelist" else 8.0)
	if board.hazard_cells.has(cell):
		score += 12.0
	for ally in enemy_units(true):
		if ally == enemy:
			continue
		var ally_distance := board.grid_distance(cell, ally.grid_cell)
		if ally_distance == 0:
			score += 20.0
		elif ally_distance == 1:
			score += 1.35
	if enemy.role_id == "medic":
		var patient := _most_wounded_enemy(enemy)
		if is_instance_valid(patient):
			score += float(board.grid_distance(cell, patient.grid_cell)) * 0.22
	elif enemy.role_id == "officer":
		var nearest_ally_distance := 99
		for ally in enemy_units(true):
			if ally != enemy:
				nearest_ally_distance = mini(nearest_ally_distance, board.grid_distance(cell, ally.grid_cell))
		if nearest_ally_distance < 99:
			score += absf(float(nearest_ally_distance - 3)) * 0.18
	# Seeded, stable tie breaking prevents every run and every same-role guard from
	# resolving equal-scored cells in the same direction.
	score += _enemy_cell_tiebreak(enemy, cell)
	return score


func _enemy_cell_tiebreak(enemy: TacticalUnit, cell: Vector2i) -> float:
	# Hash the full encounter/unit/cell tuple so changing the run seed reshuffles
	# close tactical alternatives instead of merely shifting every cell together.
	# The amplitude can choose between adjacent acceptable lanes but cannot outweigh
	# hazards, firing access, or the large half/full-cover terms.
	var stable := int(hash("%d:%s:%d:%d" % [encounter_ai_seed, enemy.display_name, cell.x, cell.y]))
	return float(posmod(stable, 1009)) / 917.0


func _unit_health_ratio(unit: TacticalUnit) -> float:
	var total := 0.0
	var maximum := 0.0
	for zone in unit.body_state:
		total += float(unit.body_state[zone]["hp"])
		maximum += float(unit.body_state[zone]["max_hp"])
	return total / maxf(1.0, maximum)


func _most_wounded_enemy(except_enemy: TacticalUnit = null) -> TacticalUnit:
	var result: TacticalUnit
	var lowest := 1.01
	for ally in enemy_units(true):
		if ally == except_enemy:
			continue
		var ratio := _unit_health_ratio(ally)
		if ratio < lowest:
			lowest = ratio
			result = ally
	return result


func _choose_enemy_zone(target: TacticalUnit, available_ap: int) -> Types.BodyZone:
	# Guards pressure weakened limbs but favor a reliable torso shot.
	var options: Array[Types.BodyZone] = [
		Types.BodyZone.TORSO,
		Types.BodyZone.TORSO,
		Types.BodyZone.ARMS,
		Types.BodyZone.LEGS,
		Types.BodyZone.LEGS,
		Types.BodyZone.LEGS,
	]
	var weakest := Types.BodyZone.TORSO
	var weakest_ratio := 2.0
	for zone in target.body_state:
		var state: Dictionary = target.body_state[zone]
		if bool(state["disabled"]) or target.is_zone_detached(zone) or Types.zone_ap_cost(zone) > available_ap:
			continue
		var ratio := float(state["hp"]) / float(state["max_hp"])
		if ratio < weakest_ratio:
			weakest_ratio = ratio
			weakest = zone
	if weakest_ratio < 0.55 and rng.randf() < 0.5 and Types.zone_ap_cost(weakest) <= available_ap:
		return weakest
	var legal_options: Array[Types.BodyZone] = []
	for zone in options:
		if Types.zone_ap_cost(zone) <= available_ap and not target.is_zone_detached(zone):
			legal_options.append(zone)
	if legal_options.is_empty():
		return Types.BodyZone.TORSO
	return legal_options[rng.randi_range(0, legal_options.size() - 1)]


func _auto_end_if_spent() -> void:
	if autobattle_enabled:
		return
	if phase != Types.Phase.PLAYER:
		return
	for unit in player_units(true):
		if unit.action_points > 0:
			return
	end_player_turn.call_deferred()


func player_units(alive_only: bool = false) -> Array[TacticalUnit]:
	var result: Array[TacticalUnit] = []
	for unit in units:
		if unit.team == Types.Team.PLAYER and (not alive_only or unit.is_combat_active()):
			result.append(unit)
	return result


func enemy_units(alive_only: bool = false) -> Array[TacticalUnit]:
	var result: Array[TacticalUnit] = []
	for unit in units:
		if unit.team == Types.Team.ENEMY and (not alive_only or unit.is_combat_active()):
			result.append(unit)
	return result


func phase_name() -> String:
	match phase:
		Types.Phase.PLAYER:
			return "CREW TURN"
		Types.Phase.ENEMY:
			return "RAIL GUARD TURN"
		Types.Phase.BUSY:
			return "ACTION RESOLVING"
		Types.Phase.VICTORY:
			return "HEIST COMPLETE"
		Types.Phase.DEFEAT:
			return "HEIST FAILED"
	return "UNKNOWN"


func _log(message: String) -> void:
	log_entry.emit(message)
