class_name BrasslineWeaponModel
extends RefCounted

# Original mesh geometry, in metres. +Z is the bore axis; grips are centred
# around the wrist rather than inflated to make a tactical thumbnail readable.
static func build(parent: Node3D, weapon_id: String, materials: Dictionary) -> Dictionary:
	var iron: Material = materials.iron
	var brass: Material = materials.brass
	var wood: Material = materials.wood
	var dark: Material = materials.dark
	var muzzle := Vector3(0,0.075,0.30)
	var support := Vector3(0.025,-0.045,0.17)
	match weapon_id:
		"longshot_rifle":
			_stock(parent,0.37,wood,iron)
			_profile(parent,"MachinedReceiver",[Vector2(-0.13,0.045),Vector2(-0.13,0.12),Vector2(0.18,0.12),Vector2(0.22,0.082),Vector2(0.18,0.04)],0.066,iron)
			_profile(parent,"ForeStock",[Vector2(0.10,0.055),Vector2(0.31,0.052),Vector2(0.34,0.015),Vector2(0.14,0.004)],0.060,wood)
			_barrel(parent,"RifledBarrel",0.022,0.18,0.68,0.086,iron,dark)
			for z in [0.20,0.32,0.61]: _ring(parent,"BarrelBand",0.028,0.025,Vector3(0,0.086,z),brass)
			_barrel(parent,"OpticalScope",0.034,-0.085,0.20,0.208,brass,dark)
			for z in [-0.035,0.12]: _strut(parent,"ScopeMount",Vector3(0,0.13,z),Vector3(0,0.19,z),0.012,iron)
			_bolt(parent,Vector3(0.060,0.105,-0.015),brass)
			_sight(parent,0.62,0.115,iron)
			muzzle=Vector3(0,0.086,0.684)
		"breach_gun":
			_stock(parent,0.31,wood,iron)
			_profile(parent,"BreakAction",[Vector2(-0.12,0.03),Vector2(-0.12,0.12),Vector2(0.14,0.115),Vector2(0.19,0.07),Vector2(0.12,0.012)],0.12,iron)
			for x in [-0.033,0.033]:
				var barrel := Node3D.new(); barrel.position.x=x; parent.add_child(barrel)
				_barrel(barrel,"TwinBore",0.031,0.09,0.50,0.082,iron,dark)
			_profile(parent,"PumpForeEnd",[Vector2(0.13,0.04),Vector2(0.32,0.04),Vector2(0.32,-0.01),Vector2(0.15,-0.018)],0.105,wood)
			for z in [0.17,0.21,0.25,0.29]: _strut(parent,"ForeEndGroove",Vector3(-0.055,0.02,z),Vector3(0.055,0.02,z),0.003,dark)
			_bolt(parent,Vector3(0.075,0.08,-0.04),brass)
			_sight(parent,0.45,0.122,brass)
			muzzle=Vector3(0,0.082,0.504)
		"rivet_carbine":
			_stock(parent,0.27,wood,iron)
			_profile(parent,"PressureReceiver",[Vector2(-0.12,0.025),Vector2(-0.12,0.13),Vector2(0.18,0.13),Vector2(0.24,0.075),Vector2(0.16,0.025)],0.083,iron)
			_barrel(parent,"RivetBore",0.029,0.15,0.46,0.082,iron,dark)
			for z in [0.20,0.24,0.28]: _ring(parent,"CoolingCollar",0.043,0.025,Vector3(0,0.082,z),brass)
			_profile(parent,"RivetMagazine",[Vector2(0.055,0.045),Vector2(0.14,0.04),Vector2(0.14,-0.16),Vector2(0.07,-0.14)],0.053,wood)
			_barrel(parent,"SidePressureBottle",0.025,-0.08,0.075,0.17,brass,dark)
			_sight(parent,0.40,0.12,iron)
			muzzle=Vector3(0,0.082,0.464); support=Vector3(0.025,-0.02,0.20)
		"coil_pistol":
			_pistol_frame(parent,0.22,wood,iron,brass)
			_barrel(parent,"CeramicCore",0.023,0.035,0.31,0.073,dark,dark)
			for z in [0.07,0.105,0.14,0.175,0.21,0.245]: _ring(parent,"CopperWinding",0.037,0.015,Vector3(0,0.073,z),brass)
			_ring(parent,"MuzzleCage",0.033,0.032,Vector3(0,0.073,0.30),iron)
			_ring(parent,"OpenCoilBore",0.021,0.004,Vector3(0,0.073,0.318),dark)
			muzzle=Vector3(0,0.073,0.319)
		"hand_cannon":
			_pistol_frame(parent,0.25,wood,iron,brass)
			_barrel(parent,"HeavyBore",0.038,0.075,0.37,0.08,iron,dark)
			_ring(parent,"ReinforcedMuzzle",0.046,0.046,Vector3(0,0.08,0.35),brass)
			_ring(parent,"OpenHeavyBore",0.029,0.004,Vector3(0,0.08,0.375),dark)
			_drum(parent,0.057,brass,dark)
			_sight(parent,0.30,0.13,iron)
			muzzle=Vector3(0,0.08,0.378)
		_:
			var ornate := weapon_id == "duelist_revolver"
			var length := 0.34 if ornate else 0.27
			_pistol_frame(parent,0.18,wood,iron,brass)
			_barrel(parent,"OctagonBore",0.026,0.065,length,0.075,iron,dark,8)
			_drum(parent,0.045,brass,dark)
			_sight(parent,length-0.035,0.112,brass)
			if ornate: _profile(parent,"EngravedTopRib",[Vector2(0.065,0.105),Vector2(length-0.02,0.10),Vector2(length-0.04,0.116),Vector2(0.065,0.125)],0.025,brass)
			muzzle=Vector3(0,0.075,length+0.003)
	_trigger_guard(parent,brass)
	parent.set_meta("silhouette_version",2)
	parent.set_meta("support_grip",support)
	return {"muzzle":muzzle,"support_grip":support}


static func _stock(parent: Node3D, length: float, wood: Material, iron: Material) -> void:
	_profile(parent,"ShapedWalnutStock",[Vector2(-length,0.12),Vector2(-length,-0.035),Vector2(-0.22,-0.025),Vector2(-0.105,0.015),Vector2(0.015,0.025),Vector2(0.015,0.085),Vector2(-0.20,0.075)],0.071,wood)
	_profile(parent,"ButtPlate",[Vector2(-length-0.012,0.12),Vector2(-length-0.012,-0.04),Vector2(-length+0.01,-0.04),Vector2(-length+0.01,0.12)],0.077,iron)
	_profile(parent,"Grip",[Vector2(-0.11,0.048),Vector2(-0.065,-0.118),Vector2(-0.01,-0.108),Vector2(-0.015,0.015)],0.058,wood)


static func _pistol_frame(parent: Node3D, length: float, wood: Material, iron: Material, brass: Material) -> void:
	_profile(parent,"ForgedFrame",[Vector2(-0.085,0.095),Vector2(length,0.093),Vector2(length,0.04),Vector2(0.04,0.027),Vector2(-0.01,-0.01),Vector2(-0.065,0.00)],0.055,iron)
	_profile(parent,"RakedGrip",[Vector2(-0.055,0.045),Vector2(-0.006,0.017),Vector2(-0.034,-0.12),Vector2(-0.103,-0.112)],0.060,wood)
	_profile(parent,"GripHeel",[Vector2(-0.104,-0.108),Vector2(-0.033,-0.117),Vector2(-0.035,-0.129),Vector2(-0.107,-0.120)],0.064,brass)
	_bolt(parent,Vector3(0.030,-0.045,-0.061),brass,0.008)


static func _drum(parent: Node3D, radius: float, brass: Material, dark: Material) -> void:
	_ring(parent,"RevolverCylinder",radius,0.105,Vector3(0,0.07,0.018),brass)
	for index in range(6):
		var angle := TAU*index/6.0
		_ring(parent,"Chamber",0.007,0.004,Vector3(cos(angle)*radius*0.63,0.07+sin(angle)*radius*0.63,0.073),dark)


static func _trigger_guard(parent: Node3D, metal: Material) -> void:
	var ring := MeshInstance3D.new(); ring.name="TriggerGuard"
	var torus := TorusMesh.new(); torus.inner_radius=0.033; torus.outer_radius=0.040; torus.rings=16; torus.ring_segments=6
	ring.mesh=torus; ring.rotation_degrees.z=90; ring.scale=Vector3(0.72,1,1.18); ring.position=Vector3(0,-0.017,0.030); ring.material_override=metal; parent.add_child(ring)
	_strut(parent,"Trigger",Vector3(0,0.018,0.020),Vector3(0,-0.023,0.027),0.005,metal)


static func _sight(parent: Node3D, z: float, y: float, metal: Material) -> void:
	_profile(parent,"FrontSight",[Vector2(z-0.020,y),Vector2(z+0.012,y),Vector2(z+0.003,y+0.025),Vector2(z-0.009,y+0.025)],0.012,metal)


static func _bolt(parent: Node3D, at: Vector3, metal: Material, radius: float = 0.016) -> void:
	_strut(parent,"BoltHandle",at-Vector3(0.025,0,0),at,0.006,metal)
	var ball := MeshInstance3D.new(); ball.name="BoltKnob"; var sphere:=SphereMesh.new(); sphere.radius=radius; sphere.height=radius*2; sphere.radial_segments=10; sphere.rings=5
	ball.mesh=sphere; ball.position=at; ball.material_override=metal; parent.add_child(ball)


static func _barrel(parent: Node3D, node_name: String, radius: float, from_z: float, to_z: float, y: float, metal: Material, dark: Material, sides: int = 16) -> void:
	_ring(parent,node_name,radius,to_z-from_z,Vector3(0,y,(from_z+to_z)*0.5),metal,sides)
	_ring(parent,node_name+"Bore",radius*0.63,0.004,Vector3(0,y,to_z+0.001),dark,sides)


static func _ring(parent: Node3D, node_name: String, radius: float, length: float, at: Vector3, metal: Material, sides: int = 16) -> MeshInstance3D:
	var instance:=MeshInstance3D.new(); instance.name=node_name
	var mesh:=CylinderMesh.new(); mesh.top_radius=radius; mesh.bottom_radius=radius; mesh.height=length; mesh.radial_segments=sides
	instance.mesh=mesh; instance.rotation_degrees.x=90; instance.position=at; instance.material_override=metal; parent.add_child(instance); return instance


static func _strut(parent: Node3D, node_name: String, from: Vector3, to: Vector3, radius: float, material: Material) -> void:
	var instance:=_ring(parent,node_name,radius,from.distance_to(to),(from+to)*0.5,material,10)
	# These points are local to the weapon, not world-space camera coordinates.
	instance.quaternion=Quaternion(Vector3.UP,(to-from).normalized())


static func _profile(parent: Node3D, node_name: String, points: PackedVector2Array, width: float, material: Material) -> void:
	var surface:=SurfaceTool.new(); surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var triangles:=Geometry2D.triangulate_polygon(points)
	for side in [-1.0,1.0]:
		for tri in range(0,triangles.size(),3):
			var indices: Array[int]=[triangles[tri],triangles[tri+1],triangles[tri+2]]
			if side<0: indices.reverse()
			for idx in indices: surface.add_vertex(Vector3(side*width*0.5,points[idx].y,points[idx].x))
	for idx in range(points.size()):
		var next:=posmod(idx+1,points.size())
		var a:=Vector3(-width*0.5,points[idx].y,points[idx].x); var b:=Vector3(width*0.5,points[idx].y,points[idx].x)
		var c:=Vector3(width*0.5,points[next].y,points[next].x); var d:=Vector3(-width*0.5,points[next].y,points[next].x)
		for vertex in [a,b,c,a,c,d]: surface.add_vertex(vertex)
	surface.generate_normals()
	var instance:=MeshInstance3D.new(); instance.name=node_name; instance.mesh=surface.commit(); instance.material_override=material; parent.add_child(instance)
