class_name BrasslineProfileState
extends RefCounted

const CURRENT_VERSION := 2
const DEFAULT_PATH := "user://brassline_profile.json"
const DAILY_SALT := "BRASSLINE_DAILY_V1"
const BASE_COSMETIC := "weathered"

var tutorial_complete := false
var blueprint_knowledge := 0
var unlocked_plan_ids: Array[String] = []
var crew_mastery: Dictionary = {}
var crew_cosmetics: Dictionary = {}
var selected_cosmetics: Dictionary = {}
var crew_scars: Dictionary = {}
var relationship_history: Dictionary = {}
var best_grades: Dictionary = {}
var completed_challenge_seeds: Array[int] = []
var discovered_car_ids: Array[String] = []
var recent_run_codes: Array[String] = []
var last_daily_date := ""
var last_daily_grade := ""


func reset() -> void:
	tutorial_complete = false
	blueprint_knowledge = 0
	unlocked_plan_ids.clear()
	crew_mastery.clear()
	crew_cosmetics.clear()
	selected_cosmetics.clear()
	crew_scars.clear()
	relationship_history.clear()
	best_grades.clear()
	completed_challenge_seeds.clear()
	discovered_car_ids.clear()
	recent_run_codes.clear()
	last_daily_date = ""
	last_daily_grade = ""


func ensure_roster(crew_ids: Array[String]) -> void:
	for crew_id in crew_ids:
		if not crew_mastery.has(crew_id):
			crew_mastery[crew_id] = 0
		if not crew_cosmetics.has(crew_id):
			crew_cosmetics[crew_id] = [BASE_COSMETIC]
		if not selected_cosmetics.has(crew_id):
			selected_cosmetics[crew_id] = BASE_COSMETIC
		if not crew_scars.has(crew_id):
			crew_scars[crew_id] = []


func load_from_disk(path: String = DEFAULT_PATH) -> bool:
	reset()
	if not FileAccess.file_exists(path):
		return false
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return false
	var parsed = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary:
		return false
	return from_data(Dictionary(parsed))


func save_to_disk(path: String = DEFAULT_PATH) -> bool:
	var file := FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(to_data(), "\t"))
	file.close()
	return DirAccess.rename_absolute(path + ".tmp", path) == OK


func to_data() -> Dictionary:
	return {
		"version": CURRENT_VERSION,
		"tutorial_complete": tutorial_complete,
		"blueprint_knowledge": blueprint_knowledge,
		"unlocked_plan_ids": unlocked_plan_ids.duplicate(),
		"crew_mastery": crew_mastery.duplicate(true),
		"crew_cosmetics": crew_cosmetics.duplicate(true),
		"selected_cosmetics": selected_cosmetics.duplicate(true),
		"crew_scars": crew_scars.duplicate(true),
		"relationship_history": relationship_history.duplicate(true),
		"best_grades": best_grades.duplicate(true),
		"completed_challenge_seeds": completed_challenge_seeds.duplicate(),
		"discovered_car_ids": discovered_car_ids.duplicate(),
		"recent_run_codes": recent_run_codes.duplicate(),
		"last_daily_date": last_daily_date,
		"last_daily_grade": last_daily_grade,
	}


func from_data(data: Dictionary) -> bool:
	var version := int(data.get("version", 0))
	if version < 0 or version > CURRENT_VERSION:
		return false
	tutorial_complete = bool(data.get("tutorial_complete", false))
	blueprint_knowledge = maxi(0, int(data.get("blueprint_knowledge", 0)))
	unlocked_plan_ids.assign(_unique_strings(Array(data.get("unlocked_plan_ids", []))))
	crew_mastery = _sanitized_nonnegative_dictionary(Dictionary(data.get("crew_mastery", {})))
	crew_cosmetics = _sanitized_string_array_dictionary(Dictionary(data.get("crew_cosmetics", {})))
	selected_cosmetics = _sanitized_string_dictionary(Dictionary(data.get("selected_cosmetics", {})))
	crew_scars = _sanitized_string_array_dictionary(Dictionary(data.get("crew_scars", {})))
	relationship_history = _sanitized_relationships(Dictionary(data.get("relationship_history", {})))
	best_grades = _sanitized_string_dictionary(Dictionary(data.get("best_grades", {})))
	completed_challenge_seeds.assign(_unique_ints(Array(data.get("completed_challenge_seeds", []))))
	discovered_car_ids.assign(_unique_strings(Array(data.get("discovered_car_ids", []))))
	recent_run_codes.assign(_unique_strings(Array(data.get("recent_run_codes", []))))
	if recent_run_codes.size() > 12:
		recent_run_codes = recent_run_codes.slice(recent_run_codes.size() - 12)
	last_daily_date = String(data.get("last_daily_date", ""))
	last_daily_grade = String(data.get("last_daily_grade", ""))
	return true


func mark_tutorial_complete() -> void:
	tutorial_complete = true


func award_car_clear(car_id: String, crew_ids: Array[String], risky: bool, cripple_count: int, environment_actions: int) -> Dictionary:
	ensure_roster(crew_ids)
	var amount := 1
	var reasons: Array[String] = ["CAR SECURED +1"]
	if car_id not in discovered_car_ids:
		discovered_car_ids.append(car_id)
		amount += 2
		reasons.append("NEW BLUEPRINT +2")
	if risky:
		amount += 1
		reasons.append("RISK HELD +1")
	if cripple_count > 0:
		amount += 1
		reasons.append("CRIPPLING DOCTRINE +1")
	if environment_actions > 0:
		amount += 1
		reasons.append("TRAIN SYSTEM TURNED +1")
	blueprint_knowledge += amount
	for crew_id in crew_ids:
		crew_mastery[crew_id] = int(crew_mastery.get(crew_id, 0)) + 1
	_unlock_progression_rewards()
	return {"amount": amount, "reasons": reasons, "total": blueprint_knowledge}


func record_run_complete(seed: int, difficulty: String, grade: String, crew_ids: Array[String], ruleset: String = "train_takeover") -> String:
	var key := "%s:%s" % [ruleset, difficulty]
	var prior := String(best_grades.get(key, ""))
	if prior.is_empty() or _grade_rank(grade) > _grade_rank(prior):
		best_grades[key] = grade
	if seed not in completed_challenge_seeds:
		completed_challenge_seeds.append(seed)
	var code := build_challenge_code(seed, difficulty, crew_ids, ruleset)
	_push_recent_code(code)
	return code


func build_challenge_code(seed: int, difficulty: String, crew_ids: Array[String], ruleset: String = "train_takeover") -> String:
	var difficulty_code: String = String({"story": "S", "standard": "N", "brutal": "B"}.get(difficulty, "N"))
	var ruleset_code := "T" if ruleset == "train_takeover" else "L"
	var crew_code := "+".join(PackedStringArray(crew_ids))
	var payload := "%d.%s.%s.%s" % [seed, difficulty_code, ruleset_code, crew_code]
	return "BR1.%s.%s" % [payload, _checksum(payload)]


func parse_challenge_code(code: String) -> Dictionary:
	var pieces := code.strip_edges().split(".", false)
	if pieces.size() != 6 or pieces[0] != "BR1":
		return {"ok": false, "reason": "Challenge code format is invalid."}
	var payload := ".".join(pieces.slice(1, 5))
	if pieces[5].to_upper() != _checksum(payload):
		return {"ok": false, "reason": "Challenge code checksum does not match."}
	var seed_text := pieces[1]
	if not seed_text.is_valid_int() or int(seed_text) <= 0:
		return {"ok": false, "reason": "Challenge seed is invalid."}
	var difficulty: String = String({"S": "story", "N": "standard", "B": "brutal"}.get(pieces[2].to_upper(), ""))
	var ruleset: String = String({"T": "train_takeover", "L": "legacy_blueprint"}.get(pieces[3].to_upper(), ""))
	var crew_ids: Array[String] = []
	crew_ids.assign(Array(pieces[4].split("+", false)))
	if difficulty.is_empty() or ruleset.is_empty() or crew_ids.size() != 3:
		return {"ok": false, "reason": "Challenge rules are invalid."}
	var seen: Array[String] = []
	for crew_id in crew_ids:
		if crew_id not in ["ada", "marlow", "nix", "iona", "silas", "rook"] or crew_id in seen:
			return {"ok": false, "reason": "Choose three different known operatives."}
		seen.append(crew_id)
	return {"ok": true, "seed": int(seed_text), "difficulty": difficulty, "ruleset": ruleset, "crew_ids": crew_ids}


func daily_seed(date: Dictionary = {}) -> int:
	var selected_date := date if not date.is_empty() else Time.get_date_dict_from_system()
	var stamp := "%04d-%02d-%02d" % [int(selected_date.get("year", 2026)), int(selected_date.get("month", 1)), int(selected_date.get("day", 1))]
	return 100000 + posmod(_stable_hash("%s:%s" % [DAILY_SALT, stamp]), 899999)


func daily_date_label(date: Dictionary = {}) -> String:
	var selected_date := date if not date.is_empty() else Time.get_date_dict_from_system()
	return "%04d-%02d-%02d" % [int(selected_date.get("year", 2026)), int(selected_date.get("month", 1)), int(selected_date.get("day", 1))]


func record_daily_result(date_label: String, grade: String) -> void:
	# Reuse the existing versioned best-grade ledger; no profile schema change.
	var key := "daily:%s" % date_label
	if _grade_rank(grade) > _grade_rank(String(best_grades.get(key, ""))):
		best_grades[key] = grade
	if date_label > last_daily_date or (date_label == last_daily_date and _grade_rank(grade) > _grade_rank(last_daily_grade)):
		last_daily_date = date_label
		last_daily_grade = grade


func daily_best_grade(date_label: String) -> String:
	return String(best_grades.get("daily:%s" % date_label, last_daily_grade if date_label == last_daily_date else ""))


func mastery_for(crew_id: String) -> int:
	return int(crew_mastery.get(crew_id, 0))


func cosmetic_for(crew_id: String) -> String:
	return String(selected_cosmetics.get(crew_id, BASE_COSMETIC))


func available_cosmetics(crew_id: String) -> Array[String]:
	var result: Array[String] = []
	result.assign(Array(crew_cosmetics.get(crew_id, [BASE_COSMETIC])))
	return result


func scars_for(crew_id: String) -> Array[String]:
	var result: Array[String] = []
	result.assign(Array(crew_scars.get(crew_id, [])))
	return result


func record_injuries(injuries: Array) -> void:
	for raw_injury in injuries:
		var injury := Dictionary(raw_injury)
		var crew_id := String(injury.get("roster_id", ""))
		if crew_id.is_empty():
			continue
		var scars: Array = crew_scars.get(crew_id, [])
		for raw_change in Array(injury.get("changes", [])):
			var change := String(raw_change)
			if ("crippled" in change or "severed" in change) and change not in scars:
				scars.append(change)
		if bool(injury.get("down", false)) and "fell during a heist" not in scars:
			scars.append("fell during a heist")
		while scars.size() > 3:
			scars.pop_front()
		crew_scars[crew_id] = scars


func record_relationships(relationships: Array) -> void:
	for raw_relationship in relationships:
		var relationship := Dictionary(raw_relationship)
		var key := String(relationship.get("key", ""))
		if key.is_empty():
			continue
		relationship_history[key] = {
			"crew_ids": Array(relationship.get("crew_ids", [])).duplicate(),
			"bond": int(relationship.get("bond", 0)),
			"label": String(relationship.get("label", "TESTED")),
			"shared_jobs": int(relationship.get("shared_jobs", 0)),
			"history": Array(relationship.get("history", [])).slice(0, 3),
		}


func relationship_summary_for(crew_id: String) -> String:
	var summaries: Array[String] = []
	for key in relationship_history:
		var data := Dictionary(relationship_history[key])
		if crew_id not in Array(data.get("crew_ids", [])):
			continue
		var partner := "CREW"
		for other_id in Array(data.get("crew_ids", [])):
			if String(other_id) != crew_id:
				partner = String(other_id).to_upper()
		summaries.append("%s / %s" % [partner, String(data.get("label", "TESTED"))])
	return "UNTESTED" if summaries.is_empty() else " · ".join(summaries)


func select_cosmetic(crew_id: String, cosmetic_id: String) -> bool:
	if cosmetic_id not in available_cosmetics(crew_id):
		return false
	selected_cosmetics[crew_id] = cosmetic_id
	return true


func _unlock_progression_rewards() -> void:
	var plan_thresholds := {4: "blueprint_crossfire", 10: "blueprint_countermarch", 18: "blueprint_pressure_play"}
	for threshold in plan_thresholds:
		var plan_id := String(plan_thresholds[threshold])
		if blueprint_knowledge >= int(threshold) and plan_id not in unlocked_plan_ids:
			unlocked_plan_ids.append(plan_id)
	for crew_id in crew_mastery:
		var mastery := int(crew_mastery[crew_id])
		var colors: Array = crew_cosmetics.get(crew_id, [BASE_COSMETIC])
		if mastery >= 3 and "brassbound" not in colors:
			colors.append("brassbound")
		if mastery >= 7 and "night_rail" not in colors:
			colors.append("night_rail")
		crew_cosmetics[crew_id] = colors


func _push_recent_code(code: String) -> void:
	recent_run_codes.erase(code)
	recent_run_codes.append(code)
	if recent_run_codes.size() > 12:
		recent_run_codes.pop_front()


func _checksum(payload: String) -> String:
	return "%06X" % posmod(_stable_hash(payload), 0xFFFFFF)


func _stable_hash(value: String) -> int:
	var result: int = 2166136261
	for byte in value.to_utf8_buffer():
		result = (result ^ int(byte)) * 16777619
		result &= 0x7FFFFFFF
	return result


func _grade_rank(grade: String) -> int:
	return {"F": 0, "D": 1, "C": 2, "B": 3, "A": 4, "S": 5}.get(grade.to_upper(), 0)


func _unique_strings(values: Array) -> Array[String]:
	var result: Array[String] = []
	for value in values:
		var text := String(value)
		if not text.is_empty() and text not in result:
			result.append(text)
	return result


func _unique_ints(values: Array) -> Array[int]:
	var result: Array[int] = []
	for value in values:
		var number := int(value)
		if number not in result:
			result.append(number)
	return result


func _sanitized_nonnegative_dictionary(values: Dictionary) -> Dictionary:
	var result := {}
	for key in values:
		result[String(key)] = maxi(0, int(values[key]))
	return result


func _sanitized_string_dictionary(values: Dictionary) -> Dictionary:
	var result := {}
	for key in values:
		result[String(key)] = String(values[key])
	return result


func _sanitized_string_array_dictionary(values: Dictionary) -> Dictionary:
	var result := {}
	for key in values:
		result[String(key)] = _unique_strings(Array(values[key]))
	return result


func _sanitized_relationships(values: Dictionary) -> Dictionary:
	var result := {}
	for key in values:
		var raw := Dictionary(values[key])
		result[String(key)] = {
			"crew_ids": _unique_strings(Array(raw.get("crew_ids", []))),
			"bond": clampi(int(raw.get("bond", 0)), -3, 5),
			"label": String(raw.get("label", "TESTED")),
			"shared_jobs": maxi(0, int(raw.get("shared_jobs", 0))),
			"history": _unique_strings(Array(raw.get("history", []))).slice(0, 3),
		}
	return result
