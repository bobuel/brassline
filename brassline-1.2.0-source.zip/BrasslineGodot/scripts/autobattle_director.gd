class_name AutobattleDirector
extends Node

signal timeline_changed(entries: Array, active_index: int)
signal intent_changed(unit: TacticalUnit, caption: String, explanation: String, status: String)
signal plan_status_changed(status: String, explanation: String)
signal speed_changed(speed: float, paused: bool)
signal round_started(round_number: int)
signal milestone_added(text: String)
signal consumable_used(item_id: String, unit: TacticalUnit)
signal train_event_changed(event: Dictionary, result: Dictionary)
signal doctrine_changed(doctrine: Dictionary)
signal presentation_beat(beat: Dictionary)

const Types := preload("res://scripts/game_types.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")
const BASE_PACE_SCALE := 0.5
const INSPECT_TIME_SCALE := 0.2

var turn: TurnController
var active_plan: Dictionary = {}
var active_fallback: Dictionary = {}
var running := false
var paused := false
var inspection_paused := false
var battle_speed := 1.0
var inspect_slowdown := false
var current_plan_status := "on_plan"
var current_plan_explanation := "The opening is intact."
var initiative_entries: Array = []
var active_initiative_index := -1
var event_history: Array[String] = []
var milestones: Array[String] = []
var initial_body_states: Dictionary = {}
var environment_action_used := false
var fallback_triggered := false
var activation_count := 0
var _target_pressure: Dictionary = {}
var _run_serial := 0
var _combat_inventory: Dictionary = {}
var _grenade_committed := false
var _gear_attempted: Dictionary = {}
var train_event_history: Array[Dictionary] = []
var current_doctrine: Dictionary = {}
var _train_counter_actions: Dictionary = {}
var _last_doctrine_status := ""
var decisive_beats: Array[Dictionary] = []
var _first_plan_failure_cause := ""
var _fallback_activation_count := 0
var _risk_exposure_count := 0
var _crew_damage_events: Array[Dictionary] = []
var _item_outcomes: Dictionary = {}
var fallback_actions: Array[Dictionary] = []
var _fallback_action_rounds: Dictionary = {}
var _observed_fallback_protection: Dictionary = {}
var _beat_sequence := 0
var _control_gate_states: Dictionary = {}
var _control_condition_records: Array[Dictionary] = []


func setup(controller: TurnController) -> void:
	turn = controller
	if not turn.attack_resolved.is_connected(_on_attack_resolved):
		turn.attack_resolved.connect(_on_attack_resolved)
	if not turn.environment_resolved.is_connected(_on_environment_resolved):
		turn.environment_resolved.connect(_on_environment_resolved)
	if not turn.unit_surrendered.is_connected(_on_unit_surrendered):
		turn.unit_surrendered.connect(_on_unit_surrendered)
	if not turn.environment_injury_resolved.is_connected(_on_environment_injury_resolved):
		turn.environment_injury_resolved.connect(_on_environment_injury_resolved)


func configure(plan: Dictionary, fallback: Dictionary, inventory: Dictionary = {}) -> void:
	active_plan = plan.duplicate(true)
	active_fallback = fallback.duplicate(true)
	_combat_inventory = inventory.duplicate(true)
	running = false
	paused = false
	inspection_paused = false
	battle_speed = 1.0
	inspect_slowdown = false
	current_plan_status = "on_plan"
	current_plan_explanation = "The crew begins on the chosen opening."
	initiative_entries.clear()
	active_initiative_index = -1
	event_history.clear()
	milestones.clear()
	initial_body_states.clear()
	environment_action_used = false
	fallback_triggered = false
	activation_count = 0
	_grenade_committed = false
	_gear_attempted.clear()
	train_event_history.clear()
	current_doctrine.clear()
	_train_counter_actions.clear()
	_last_doctrine_status = ""
	decisive_beats.clear()
	_first_plan_failure_cause = ""
	_fallback_activation_count = 0
	_risk_exposure_count = 0
	_crew_damage_events.clear()
	_item_outcomes.clear()
	fallback_actions.clear()
	_fallback_action_rounds.clear()
	_observed_fallback_protection.clear()
	_beat_sequence = 0
	_control_gate_states.clear()
	_control_condition_records.clear()
	var planned_gear := String(active_plan.get("gear_item", ""))
	if not planned_gear.is_empty():
		_item_outcomes[planned_gear] = "committed_waiting"
	_target_pressure.clear()
	for unit in turn.units:
		initial_body_states[unit.get_instance_id()] = unit.export_body_state()


func build_deployment(plan: Dictionary) -> Dictionary:
	var deployment := {}
	var claimed := turn.occupied_cells()
	# Enemy cells are genuinely occupied; current crew cells are placeholders that
	# may be reassigned during planning.
	for crew in turn.player_units(false):
		claimed.erase(crew.grid_cell)
	var orders: Dictionary = plan.get("orders", {})
	for crew in turn.player_units(true):
		var order: Dictionary = orders.get(crew.roster_id, {})
		var position_name := String(order.get("position", "mid_cover"))
		var cell := _best_deployment_cell(position_name, claimed)
		if cell.x < 0:
			return {}
		deployment[crew.roster_id] = cell
		claimed[cell] = true
	return deployment


func deployment_is_safe(deployment: Dictionary) -> bool:
	var claimed := turn.occupied_cells()
	var crew_cells: Array[Vector2i] = []
	for crew in turn.player_units(true):
		claimed.erase(crew.grid_cell)
	for crew in turn.player_units(true):
		if not deployment.has(crew.roster_id):
			return false
		var cell: Vector2i = deployment[crew.roster_id]
		if cell.x > GridBoard.CREW_DEPLOYMENT_MAX_X or not turn.board.is_walkable(cell, claimed) or turn.board.hazard_cells.has(cell):
			return false
		if _nearest_enemy_cell_distance(cell) < GridBoard.MIN_DEPLOYMENT_DISTANCE:
			return false
		for ally_cell in crew_cells:
			if turn.board.grid_distance(cell, ally_cell) < GridBoard.MIN_CREW_DEPLOYMENT_DISTANCE:
				return false
		crew_cells.append(cell)
		claimed[cell] = true
	return true


func apply_deployment(deployment: Dictionary) -> bool:
	# Validate the whole formation before moving anyone. This also protects loaded
	# or stale plan data from crossing the opposing front at commit time.
	if not deployment_is_safe(deployment):
		return false
	for crew in turn.player_units(true):
		var cell: Vector2i = deployment[crew.roster_id]
		crew.grid_cell = cell
		crew.position = turn.board.cell_to_world(cell) + Vector3(0.0, 0.12, 0.0)
		crew.clear_autobattle_intent()
	return true


func start_battle() -> void:
	if running or active_plan.is_empty():
		return
	running = true
	_run_serial += 1
	var serial := _run_serial
	turn.begin_autobattle_encounter()
	set_speed(1.0)
	_run_battle.bind(serial).call_deferred()


func stop() -> void:
	_run_serial += 1
	running = false
	paused = false
	inspection_paused = false
	inspect_slowdown = false
	Engine.time_scale = 1.0
	if is_instance_valid(turn):
		for unit in turn.units:
			if is_instance_valid(unit):
				unit.clear_autobattle_intent()


func toggle_pause() -> void:
	set_paused(not paused)


func set_paused(value: bool) -> void:
	paused = value and running
	Engine.time_scale = effective_time_scale()
	speed_changed.emit(battle_speed, paused or inspection_paused)


func set_inspection_paused(value: bool) -> void:
	inspection_paused = value and running
	Engine.time_scale = effective_time_scale()
	speed_changed.emit(battle_speed, paused or inspection_paused)


func set_speed(value: float) -> void:
	battle_speed = clampf(value, 1.0, 4.0)
	Engine.time_scale = effective_time_scale()
	speed_changed.emit(battle_speed, paused or inspection_paused)


func set_inspect_slowdown(value: bool) -> void:
	inspect_slowdown = value and running
	Engine.time_scale = effective_time_scale()


func effective_time_scale() -> float:
	if paused or inspection_paused:
		return 0.0
	if inspect_slowdown and running:
		return INSPECT_TIME_SCALE
	return battle_speed * BASE_PACE_SCALE if running else 1.0


func _run_battle(serial: int) -> void:
	while running and serial == _run_serial and turn.encounter_active:
		await _wait_until_resumed(serial)
		if not running or serial != _run_serial or not turn.encounter_active:
			break
		turn.round_number += 1
		turn.encounter_stats["rounds"] = turn.round_number
		round_started.emit(turn.round_number)
		await _advance_signature_arc(serial)
		if not running or serial != _run_serial or not turn.encounter_active:
			break
		current_doctrine = turn.apply_enemy_doctrine_round()
		if not current_doctrine.is_empty():
			doctrine_changed.emit(current_doctrine.duplicate(true))
			var doctrine_status := String(current_doctrine.get("status", "active"))
			if doctrine_status != _last_doctrine_status:
				if doctrine_status == "broken":
					_add_milestone("ENEMY DOCTRINE BROKEN / %s" % String(current_doctrine.get("name", "GUARD LINE")))
				else:
					_add_milestone("ENEMY DOCTRINE / %s" % String(current_doctrine.get("name", "GUARD LINE")))
			_last_doctrine_status = doctrine_status
		_apply_plan_guard_to_crew()
		_build_initiative()
		for index in range(initiative_entries.size()):
			await _wait_until_resumed(serial)
			if not running or serial != _run_serial or not turn.encounter_active:
				break
			var unit: TacticalUnit = initiative_entries[index].get("unit") as TacticalUnit
			if not is_instance_valid(unit) or not unit.is_combat_active():
				continue
			active_initiative_index = index
			initiative_entries[index]["state"] = "active"
			timeline_changed.emit(_public_timeline(), active_initiative_index)
			activation_count += 1
			_apply_plan_guard_to_crew()
			if unit.team == Types.Team.PLAYER:
				await _run_crew_activation(unit, serial)
			else:
				await _run_guard_activation(unit, serial)
			if not running or serial != _run_serial or index >= initiative_entries.size():
				break
			initiative_entries[index]["state"] = "done"
			timeline_changed.emit(_public_timeline(), active_initiative_index)
			await _action_beat(0.35)
		if serial != _run_serial:
			return
		if turn.encounter_active:
			_target_pressure.clear()
			_update_plan_integrity()
	if serial != _run_serial:
		return
	active_initiative_index = -1
	running = false
	paused = false
	inspection_paused = false
	Engine.time_scale = 1.0
	speed_changed.emit(1.0, false)


func _build_initiative() -> void:
	initiative_entries.clear()
	for unit in turn.units:
		if not is_instance_valid(unit) or not unit.is_combat_active():
			continue
		var score := _initiative_score(unit)
		initiative_entries.append({
			"unit": unit,
			"name": unit.display_name,
			"team": int(unit.team),
			"score": score,
			"state": "waiting",
		})
	initiative_entries.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var score_a := float(a.get("score", 0.0))
		var score_b := float(b.get("score", 0.0))
		if not is_equal_approx(score_a, score_b):
			return score_a > score_b
		return String(a.get("name", "")) < String(b.get("name", ""))
	)
	timeline_changed.emit(_public_timeline(), -1)


func _initiative_score(unit: TacticalUnit) -> float:
	var score := float(unit.base_movement)
	if unit.team == Types.Team.PLAYER:
		var tags := PlanCatalog.operative_tags(unit.roster_id)
		if "fast" in tags:
			score += 3.0
		if "patient" in tags:
			score -= 0.5
	else:
		match unit.role_id:
			"duelist": score += 2.0
			"officer": score += 1.0
			"bruiser": score -= 1.0
	if unit.legs_crippled():
		score -= 4.0
	return score + float(posmod(hash("%d:%s" % [turn.round_number, unit.display_name]), 101)) / 1000.0


func _public_timeline() -> Array:
	var result: Array = []
	for entry in initiative_entries:
		result.append({
			"name": entry.get("name", ""),
			"team": entry.get("team", 0),
			"state": entry.get("state", "waiting"),
		})
	return result


func _run_crew_activation(unit: TacticalUnit, serial: int) -> void:
	if serial != _run_serial or not is_instance_valid(unit):
		return
	turn.phase = Types.Phase.PLAYER
	unit.begin_turn()
	unit.set_meta("signature_guard", 0.0)
	unit.damage_resistance = maxf(unit.damage_resistance, _plan_resistance(unit))
	turn.select_unit(unit)
	_update_plan_integrity()
	var order: Dictionary = Dictionary(Dictionary(active_plan.get("orders", {})).get(unit.roster_id, {})).duplicate(true)
	var protective_override := (_protect_wounded_active() and _is_wounded(unit)) or (_save_crew_active() and current_plan_status == "broken")
	if protective_override:
		order["objective"] = "survive"
		order["doctrine"] = "survive"
		order["body_priority"] = int(Types.BodyZone.TORSO)
		order["secondary_zone"] = int(Types.BodyZone.TORSO)
	if await _try_protective_fallback(unit, serial):
		if serial != _run_serial or not unit.is_alive:
			return
	var environment_role := String(order.get("assignment", "")) == String(active_plan.get("ability_role", ""))
	if not protective_override and not environment_action_used and environment_role and not String(active_plan.get("environment_action", "")).is_empty():
		_set_intent(unit, "TRIGGERING / %s" % String(active_plan.get("environment_action", "")).to_upper(), "Executing the plan's environmental opening.")
		var environment_result := await turn.perform_plan_environment_action(String(active_plan.get("environment_action", "")), unit)
		if serial != _run_serial or not is_instance_valid(unit):
			return
		environment_action_used = bool(environment_result.get("ok", false))

	var ability_attempted := false
	while running and serial == _run_serial and is_instance_valid(unit) and unit.is_alive and turn.encounter_active and unit.action_points > 0:
		await _wait_until_resumed(serial)
		if not running or serial != _run_serial or not is_instance_valid(unit):
			return
		var target := _choose_target(unit, order)
		if not is_instance_valid(target):
			if turn.encounter_mode == "takeover_finale":
				await _run_finale_objective_activation(unit, serial)
			elif turn.encounter_mode == "finale":
				await _run_legacy_finale_objective_activation(unit, serial)
			break
		if capture_requires_controls(target, order):
			_set_intent(unit, "CAPTURE / SECURING CONTROLS", "Both limb zones are crippled; completing the capture instead of firing into disabled limbs.", "adapting")
			await _run_finale_objective_activation(unit, serial)
			break
		if bool(order.get("use_ability", false)) and not ability_attempted and not unit.ability_used:
			_set_intent(unit, "ABILITY / %s" % unit.ability_name.to_upper(), "Preparing the authored opening ability.")
			ability_attempted = true
			var ability_applied := turn.try_signature_ability()
			if ability_applied:
				_emit_presentation_beat("signature_move", unit, target, {"ability": unit.ability_name})
				await _action_beat(0.12)
				continue

		if await _advance_control_objective(unit, order, serial):
			if serial != _run_serial or not is_instance_valid(unit):
				return
			continue

		if unit.uses_ammunition and unit.ammunition <= 0:
			_set_intent(unit, "RELOADING", "The weapon is empty; the plan pauses for a reload.", "adapting")
			if turn.try_reload():
				await _action_beat(0.10)
				continue
			break

		if _should_prepare_called_shot(unit, target, order):
			_set_intent(unit, "SETTING UP / %s SHOT" % Types.zone_name(int(order.get("body_priority", Types.BodyZone.ARMS))).to_upper(), "One action remains. Holding the disabling priority for the next activation.")
			if unit.can_take_cover() and not unit.crouched:
				turn.try_take_cover()
			break
		var zone := _choose_body_zone(unit, target, order)
		if await _try_plan_consumable(unit, target, zone, order):
			if serial != _run_serial or not is_instance_valid(unit):
				return
			continue
		if turn.can_attack(unit, target) and unit.action_points >= Types.zone_ap_cost(zone):
			turn.set_target(target)
			turn.set_target_zone(zone)
			var chance := turn.attack_chance(unit, target, zone)
			_set_intent(
				unit,
				"AIMING / %s %s" % [target.display_name.to_upper(), Types.zone_name(zone).to_upper()],
				"%d%% shot; %s doctrine." % [roundi(chance * 100.0), String(order.get("doctrine", "reliable"))]
			)
			await turn.try_attack(target)
			continue

		# A successful retreat must not be undone with the remaining AP merely to
		# regain the original firing lane or complete an aggressive control order.
		if protective_override:
			if unit.can_take_cover() and not unit.crouched and turn.try_take_cover():
				continue
			break
		var destination := _best_crew_destination(unit, target, order)
		if destination != unit.grid_cell:
			_set_intent(unit, "MOVING / %s" % String(order.get("position", "cover")).replace("_", " ").to_upper(), "Seeking a legal firing position.", "adapting" if current_plan_status != "broken" else "broken")
			await turn.try_move(destination)
			_apply_plan_guard_to_crew()
			continue

		if unit.can_take_cover() and not unit.crouched:
			_set_intent(unit, "HOLDING COVER", "No clean shot; preserving the operative.", "adapting")
			if turn.try_take_cover():
				continue
		if unit.can_overwatch():
			_set_intent(unit, "OVERWATCH / AISLE", "No clean shot; covering the next enemy move.", "adapting")
			if turn.try_overwatch():
				continue
		break
	if is_instance_valid(unit) and unit.is_alive:
		unit.set_autobattle_intent("WAITING / NEXT ROUND", current_plan_status)


func _try_protective_fallback(unit: TacticalUnit, serial: int) -> bool:
	var saving := _save_crew_active() and current_plan_status == "broken"
	if not saving and not (_protect_wounded_active() and _is_wounded(unit)):
		return false
	var key := "%s:%d" % [unit.roster_id, turn.round_number]
	if _fallback_action_rounds.has(key) or unit.action_points < 1:
		return false
	_fallback_action_rounds[key] = true
	var start := unit.grid_cell
	var destination := protective_fallback_destination(unit)
	if destination != start:
		_set_intent(unit, "FALLBACK / WITHDRAWING", "Moving to safer ground before taking another shot.", "adapting")
		await turn.try_move(destination)
		if serial != _run_serial or not is_instance_valid(unit):
			return true
		if unit.grid_cell != start:
			var steps := turn.board.grid_distance(start, unit.grid_cell)
			_record_fallback_action(unit, "withdraw", "%s withdrew %d tile%s before firing." % [unit.display_name, steps, "" if steps == 1 else "s"])
			_apply_plan_guard_to_crew()
			return true
	if unit.can_take_cover() and not unit.crouched and turn.try_take_cover():
		_record_fallback_action(unit, "cover", "%s took cover; no safer retreat was available." % unit.display_name)
		return true
	_record_fallback_action(unit, "blocked", "%s could not reach safer ground; the fallback kept %d%% protection." % [unit.display_name, roundi(_plan_resistance(unit) * 100.0)])
	return false


func protective_fallback_destination(unit: TacticalUnit) -> Vector2i:
	var destination := unit.grid_cell
	var best_score := _retreat_position_score(unit, destination)
	var reachable := turn.board.get_reachable(unit.grid_cell, unit.movement_range(), turn.occupied_cells(unit))
	for cell_variant in reachable:
		var cell: Vector2i = cell_variant
		if turn.board.hazard_cells.has(cell):
			continue
		var score := _retreat_position_score(unit, cell)
		if score + 0.05 < best_score:
			best_score = score
			destination = cell
	return destination


func _retreat_position_score(unit: TacticalUnit, cell: Vector2i) -> float:
	# Keep the established boarding-side retreat preference while guards can
	# threaten this position. Once beyond their move-and-fire reach, stop instead
	# of spending another AP solely to reduce the tile's X coordinate.
	var score := float(cell.x) * 0.7
	var can_be_threatened := false
	for enemy in turn.enemy_units(true):
		var distance := turn.board.grid_distance(cell, enemy.grid_cell)
		can_be_threatened = can_be_threatened or distance <= enemy.attack_range + enemy.movement_range()
		if distance <= enemy.attack_range and turn.board.has_line_of_sight(enemy.grid_cell, cell):
			score += 7.0 - turn.board.cover_penalty(enemy.grid_cell, cell) * 16.0
		score += maxf(0.0, 5.0 - float(distance))
	return score if can_be_threatened else 0.0


func _record_fallback_action(unit: TacticalUnit, kind: String, explanation: String) -> void:
	fallback_triggered = true
	fallback_actions.append({"roster_id": unit.roster_id, "round": turn.round_number, "kind": kind, "summary": explanation})
	_add_milestone(explanation)


func _should_prepare_called_shot(unit: TacticalUnit, target: TacticalUnit, order: Dictionary) -> bool:
	var zone: Types.BodyZone = int(order.get("body_priority", Types.BodyZone.TORSO))
	if zone == Types.BodyZone.TORSO or unit.action_points >= Types.zone_ap_cost(zone) or turn.round_number >= 7:
		return false
	if String(order.get("doctrine", "")) not in ["disable", "lure", "decisive"]:
		return false
	if target.is_zone_detached(zone) or bool(target.body_state[zone].get("disabled", false)):
		return false
	# A genuine finishing opportunity still takes precedence, but moving into the
	# lane must not silently turn every disabling approach into torso rush fire.
	return int(target.body_state[Types.BodyZone.TORSO]["hp"]) > roundi(unit.base_damage * unit.damage_multiplier())


func _try_plan_consumable(unit: TacticalUnit, target: TacticalUnit, zone: Types.BodyZone, order: Dictionary) -> bool:
	# The planning card is the player's authorization to spend gear. A failed
	# trigger is explained once and never silently consumes or reassigns the item.
	var gear_item := String(order.get("gear_item", ""))
	if gear_item.is_empty() or bool(_gear_attempted.get(unit.roster_id, false)):
		return false
	if (
		gear_item == "clockwork_grenade"
		and
		not _grenade_committed
		and int(_combat_inventory.get("clockwork_grenade", 0)) > 0
	):
		var gear_target := instance_from_id(int(order.get("gear_target_instance_id", 0))) as TacticalUnit
		if not is_instance_valid(gear_target) or not gear_target.is_combat_active():
			gear_target = target
		# Keep carrying the committed grenade while closing the distance. It is only
		# cancelled when the blast itself becomes unsafe, never merely because the
		# first activation began outside throwing range.
		if turn.board.grid_distance(unit.grid_cell, gear_target.grid_cell) > 6:
			return false
		if not turn.can_use_grenade(gear_target) or not _grenade_blast_is_clear(gear_target):
			if String(_item_outcomes.get("clockwork_grenade", "")) != "waiting_safe_trigger":
				_add_milestone("%s is holding the grenade until the crew clears its blast." % unit.display_name)
			_item_outcomes["clockwork_grenade"] = "waiting_safe_trigger"
			return false
		turn.set_target(gear_target)
		_set_intent(unit, "GEAR / CLOCKWORK GRENADE", "The committed breach is legal and clear of the crew.", "adapting")
		var grenade_applied := await turn.try_grenade(gear_target)
		if grenade_applied:
			_gear_attempted[unit.roster_id] = true
			_grenade_committed = true
			_combat_inventory["clockwork_grenade"] = maxi(0, int(_combat_inventory.get("clockwork_grenade", 0)) - 1)
			_item_outcomes["clockwork_grenade"] = "used"
			consumable_used.emit("clockwork_grenade", unit)
			_emit_presentation_beat("item", unit, gear_target, {"item_id": "clockwork_grenade", "result": "used"})
			_add_milestone("%s committed a Clockwork Grenade to the plan." % unit.display_name)
			return true

	if (
		gear_item == "focus_tonic"
		and
		int(_combat_inventory.get("focus_tonic", 0)) > 0
		and not unit.is_focused()
		and unit.signature_accuracy_bonus <= 0.0
		and turn.can_attack(unit, target)
		and unit.action_points >= Types.zone_ap_cost(zone)
	):
		var chance := turn.attack_chance(unit, target, zone)
		if zone != Types.BodyZone.TORSO and chance < 0.90:
			_set_intent(unit, "GEAR / FOCUS TONIC", "%d%% called shot improved before committing." % roundi(chance * 100.0), "adapting")
			if unit.apply_focus_tonic():
				_combat_inventory["focus_tonic"] = maxi(0, int(_combat_inventory.get("focus_tonic", 0)) - 1)
				_item_outcomes["focus_tonic"] = "used"
				consumable_used.emit("focus_tonic", unit)
				_emit_presentation_beat("item", unit, target, {"item_id": "focus_tonic", "result": "used"})
				_gear_attempted[unit.roster_id] = true
				_add_milestone("%s used a Focus Tonic for a difficult called shot." % unit.display_name)
				await _action_beat(0.10)
				return true
	return false


func _grenade_blast_is_clear(target: TacticalUnit) -> bool:
	for crew in turn.player_units(true):
		if turn.board.grid_distance(crew.grid_cell, target.grid_cell) <= 1:
			return false
	return true


func _advance_control_objective(unit: TacticalUnit, order: Dictionary, serial: int) -> bool:
	if String(order.get("objective", "")) != "control" or turn.board.control_claimed or unit.action_points < 1:
		return false
	if not control_advance_ready(order):
		_record_control_condition(unit, order, "waiting")
		return false
	if not String(order.get("control_after_role", "")).is_empty():
		_record_control_condition(unit, order, "released")
	if turn.board.grid_distance(unit.grid_cell, turn.board.control_cell) <= 1:
		_set_intent(unit, "SECURING / CARRIAGE CONTROLS", "Attempting to break the guard's control of this car.", "adapting")
		return turn.try_claim_control()
	var reachable := turn.board.get_reachable(unit.grid_cell, unit.movement_range(), turn.occupied_cells(unit))
	var destination := unit.grid_cell
	var best_distance := turn.board.grid_distance(unit.grid_cell, turn.board.control_cell)
	for cell_variant in reachable:
		var cell: Vector2i = cell_variant
		if turn.board.hazard_cells.has(cell):
			continue
		var distance := turn.board.grid_distance(cell, turn.board.control_cell)
		if distance < best_distance:
			best_distance = distance
			destination = cell
	if destination == unit.grid_cell:
		return false
	_set_intent(unit, "ADVANCING / CARRIAGE CONTROLS", "This operative is carrying the takeover objective.", "adapting")
	await turn.try_move(destination)
	return serial == _run_serial


func control_advance_ready(order: Dictionary) -> bool:
	var guard_role := String(order.get("control_after_role", ""))
	if guard_role.is_empty():
		return true
	for enemy in turn.enemy_units(true):
		if enemy.role_id == guard_role and not enemy.arms_crippled():
			return false
	return true


func capture_requires_controls(target: TacticalUnit, order: Dictionary) -> bool:
	return bool(order.get("capture_target", false)) and turn.encounter_mode == "takeover_finale" and target.role_id == "boss" and target.arms_crippled() and target.legs_crippled() and not turn.board.control_claimed


func _record_control_condition(unit: TacticalUnit, order: Dictionary, state: String) -> void:
	if String(_control_gate_states.get(unit.roster_id, "")) == state:
		return
	_control_gate_states[unit.roster_id] = state
	_control_condition_records.append({"roster_id": unit.roster_id, "round": turn.round_number, "condition_role": String(order.get("control_after_role", "")), "condition_zone": int(Types.BodyZone.ARMS), "state": state})
	_add_milestone("%s holds the firing line until the command guard's arms break." % unit.display_name if state == "waiting" else "%s advances: the command threat is suppressed." % unit.display_name)


func _run_finale_objective_activation(unit: TacticalUnit, serial: int) -> void:
	var goal := turn.board.control_cell
	var caption := "SECURING / ENGINE CONTROLS"
	while running and serial == _run_serial and is_instance_valid(unit) and unit.action_points > 0 and unit.is_alive and turn.encounter_active:
		if turn.board.grid_distance(unit.grid_cell, goal) <= 1:
			turn.try_claim_control()
			return
		var reachable := turn.board.get_reachable(unit.grid_cell, unit.movement_range(), turn.occupied_cells(unit))
		var destination := unit.grid_cell
		var distance := turn.board.grid_distance(unit.grid_cell, goal)
		for cell_variant in reachable:
			var cell: Vector2i = cell_variant
			var candidate_distance := turn.board.grid_distance(cell, goal)
			if candidate_distance < distance and not turn.board.hazard_cells.has(cell):
				distance = candidate_distance
				destination = cell
		if destination == unit.grid_cell:
			return
		_set_intent(unit, caption, "The surviving crew is taking command of the locomotive.", "adapting")
		await turn.try_move(destination)


func _run_legacy_finale_objective_activation(unit: TacticalUnit, serial: int) -> void:
	var goal := turn.board.objective_cell
	var caption := "SECURING / BLUEPRINT CASE"
	if turn.board.objective_collected:
		if not unit.carries_objective:
			if unit.can_overwatch():
				turn.try_overwatch()
			return
		goal = turn.board.extraction_cell
		caption = "ESCAPING / BLUEPRINT CASE"
	while running and serial == _run_serial and is_instance_valid(unit) and unit.action_points > 0 and unit.is_alive and turn.encounter_active:
		if unit.grid_cell == goal:
			turn._resolve_cell_effects(unit)
			return
		var reachable := turn.board.get_reachable(unit.grid_cell, unit.movement_range(), turn.occupied_cells(unit))
		var destination := unit.grid_cell
		var distance := turn.board.grid_distance(unit.grid_cell, goal)
		for cell_variant in reachable:
			var cell: Vector2i = cell_variant
			var candidate_distance := turn.board.grid_distance(cell, goal)
			if candidate_distance < distance and not turn.board.hazard_cells.has(cell):
				distance = candidate_distance
				destination = cell
		if destination == unit.grid_cell:
			return
		_set_intent(unit, caption, "Completing the legacy blueprint contract.", "adapting")
		await turn.try_move(destination)
		if unit.carries_objective:
			goal = turn.board.extraction_cell
			caption = "ESCAPING / BLUEPRINT CASE"


func _run_guard_activation(unit: TacticalUnit, serial: int) -> void:
	if serial != _run_serial or not is_instance_valid(unit) or not unit.is_combat_active():
		return
	turn.phase = Types.Phase.ENEMY
	var target := _nearest_living_crew(unit)
	var caption := "PRESSING / CREW"
	if is_instance_valid(target):
		caption = "%s / %s" % [_guard_verb(unit.role_id), target.display_name.to_upper()]
	unit.set_autobattle_intent(caption, "broken")
	intent_changed.emit(unit, caption, "Enemy initiative resolves automatically.", "enemy")
	await turn.run_enemy_activation(unit, _target_pressure)
	if serial != _run_serial:
		return
	if is_instance_valid(unit) and unit.is_alive:
		unit.set_autobattle_intent("WAITING", "broken")
	_update_plan_integrity()


func _choose_target(unit: TacticalUnit, order: Dictionary) -> TacticalUnit:
	var enemies := turn.enemy_units(true)
	if enemies.is_empty():
		return null
	var fallback_id := String(active_fallback.get("id", "hold_plan"))
	var planned := _planned_target(order)
	if fallback_id == "improvise" and current_plan_status != "on_plan":
		planned = null
	if fallback_id == "finish_target" and is_instance_valid(planned):
		return planned
	var best: TacticalUnit
	var best_score := 1_000_000.0
	for enemy in enemies:
		var score := float(turn.board.grid_distance(unit.grid_cell, enemy.grid_cell)) * 0.18
		if enemy == planned:
			score -= 6.0
		if String(order.get("target_role", "")) == enemy.role_id:
			score -= 3.0
		var torso: Dictionary = enemy.body_state[Types.BodyZone.TORSO]
		score += float(torso["hp"]) / maxf(1.0, float(torso["max_hp"])) * 2.0
		score += turn.board.cover_penalty(unit.grid_cell, enemy.grid_cell) * 8.0
		if String(order.get("doctrine", "")) in ["aggressive", "flank"]:
			score += float(turn.board.grid_distance(unit.grid_cell, enemy.grid_cell)) * 0.28
		if fallback_id == "improvise" and current_plan_status != "on_plan":
			var instincts := PlanCatalog.operative_tags(unit.roster_id)
			if "close_range" in instincts or "frontline" in instincts:
				score += float(turn.board.grid_distance(unit.grid_cell, enemy.grid_cell)) * 0.55
			if "precision" in instincts or "exposed_hunter" in instincts:
				score += turn.board.cover_penalty(unit.grid_cell, enemy.grid_cell) * 8.0
		if score < best_score:
			best_score = score
			best = enemy
	return best


func _planned_target(order: Dictionary) -> TacticalUnit:
	var target_id := int(order.get("target_instance_id", 0))
	if target_id != 0:
		var target := instance_from_id(target_id) as TacticalUnit
		if is_instance_valid(target) and target.is_combat_active():
			return target
	var target_role := String(order.get("target_role", ""))
	for enemy in turn.enemy_units(true):
		if target_role.is_empty() or enemy.role_id == target_role:
			return enemy
	# A plan-level target only remains a compatibility fallback for legacy plans.
	target_id = int(active_plan.get("target_instance_id", 0))
	if target_id != 0:
		var legacy_target := instance_from_id(target_id) as TacticalUnit
		if is_instance_valid(legacy_target) and legacy_target.is_combat_active():
			return legacy_target
	return null


func _choose_body_zone(unit: TacticalUnit, target: TacticalUnit, order: Dictionary) -> Types.BodyZone:
	if String(active_fallback.get("id", "")) == "improvise" and current_plan_status != "on_plan":
		return _improvised_body_zone(unit, target)
	var primary: Types.BodyZone = int(order.get("body_priority", Types.BodyZone.TORSO))
	var secondary: Types.BodyZone = int(order.get("secondary_zone", Types.BodyZone.TORSO))
	var zone := primary
	var primary_state: Dictionary = target.body_state.get(primary, {})
	if target.is_zone_detached(primary) or bool(primary_state.get("disabled", false)):
		zone = secondary
	if target.is_zone_detached(zone):
		zone = Types.BodyZone.TORSO
	var torso: Dictionary = target.body_state[Types.BodyZone.TORSO]
	if not (bool(order.get("capture_target", false)) and target.role_id == "boss") and int(torso["hp"]) <= roundi(unit.base_damage * unit.damage_multiplier()):
		zone = Types.BodyZone.TORSO
	if Types.zone_ap_cost(zone) > unit.action_points:
		zone = Types.BodyZone.TORSO
	if turn.can_attack(unit, target):
		var chance := turn.attack_chance(unit, target, zone)
		if chance < 0.28 and String(order.get("doctrine", "")) != "decisive":
			zone = Types.BodyZone.TORSO
	return zone


func _improvised_body_zone(unit: TacticalUnit, target: TacticalUnit) -> Types.BodyZone:
	var zone := Types.BodyZone.TORSO
	match unit.roster_id:
		"ada", "iona": zone = Types.BodyZone.ARMS
		"nix": zone = Types.BodyZone.LEGS
		"silas": zone = Types.BodyZone.HEAD
	if target.is_zone_detached(zone) or bool(target.body_state[zone].get("disabled", false)) or Types.zone_ap_cost(zone) > unit.action_points:
		return Types.BodyZone.TORSO
	if turn.can_attack(unit, target) and turn.attack_chance(unit, target, zone) < (0.42 if zone == Types.BodyZone.HEAD else 0.26):
		return Types.BodyZone.TORSO
	return zone


func _best_crew_destination(unit: TacticalUnit, target: TacticalUnit, order: Dictionary) -> Vector2i:
	var reachable := turn.board.get_reachable(unit.grid_cell, unit.movement_range(), turn.occupied_cells(unit))
	var best := unit.grid_cell
	var best_score := _crew_position_score(unit, target, order, best)
	for cell_variant in reachable:
		var cell: Vector2i = cell_variant
		var score := _crew_position_score(unit, target, order, cell)
		if score + 0.01 < best_score:
			best_score = score
			best = cell
	return best


func _crew_position_score(unit: TacticalUnit, target: TacticalUnit, order: Dictionary, cell: Vector2i) -> float:
	var distance := turn.board.grid_distance(cell, target.grid_cell)
	var doctrine := String(order.get("doctrine", "reliable"))
	var preferred_range := mini(unit.attack_range, 6)
	if doctrine in ["aggressive", "flank", "hazard"]:
		preferred_range = mini(unit.attack_range, 3)
	elif doctrine in ["lure", "disable", "decisive"]:
		preferred_range = mini(unit.attack_range, 6)
	if String(order.get("position", "")) == "rear_sightline":
		preferred_range = mini(unit.attack_range, 6)
	var score := absf(float(distance - preferred_range)) * 1.3
	if turn.board.has_line_of_sight(cell, target.grid_cell) and distance <= unit.attack_range:
		score -= 5.2
	else:
		score += 5.0
	score -= turn.board.cover_penalty(target.grid_cell, cell) * 14.0
	score += turn.board.cover_penalty(cell, target.grid_cell) * 6.0
	if turn.board.hazard_cells.has(cell):
		score += 14.0
	var position_name := String(order.get("position", "mid_cover"))
	match position_name:
		"rear_sightline": score += maxf(0.0, float(cell.x - 5)) * 0.16
		"front_cover": score += absf(float(cell.x - 6)) * 0.10
		"boarding_choke": score += float(cell.x) * 0.18
		"side_lane": score += minf(float(cell.y), float(turn.board.BOARD_SIZE.y - 1 - cell.y)) * 0.35
		"bait_lane": score += absf(float(cell.x - 7)) * 0.10
	if _protect_wounded_active():
		if _is_wounded(unit):
			score += float(cell.x) * 0.38
		else:
			var wounded_ally := _most_wounded_crew(unit)
			if is_instance_valid(wounded_ally) and _is_wounded(wounded_ally):
				score += absf(float(turn.board.grid_distance(cell, wounded_ally.grid_cell) - 2)) * 0.30
	if _save_crew_active() and current_plan_status == "broken":
		score += float(cell.x) * 0.50
	return score


func _most_wounded_crew(except_unit: TacticalUnit = null) -> TacticalUnit:
	var result: TacticalUnit
	var lowest := 2.0
	for crew in turn.player_units(true):
		if crew == except_unit:
			continue
		var torso: Dictionary = crew.body_state[Types.BodyZone.TORSO]
		var ratio := float(torso["hp"]) / maxf(1.0, float(torso["max_hp"]))
		if ratio < lowest:
			lowest = ratio
			result = crew
	return result


func _best_deployment_cell(position_name: String, occupied: Dictionary) -> Vector2i:
	var desired := Vector2i(3, 2)
	match position_name:
		"rear_sightline": desired = Vector2i(2, 2)
		"front_cover": desired = Vector2i(4, 2)
		"boarding_choke": desired = Vector2i(1, 2)
		"side_lane": desired = Vector2i(3, 3)
		"bait_lane": desired = Vector2i(4, 3)
	var best := Vector2i(-1, -1)
	var best_score := 999.0
	for x in range(0, GridBoard.CREW_DEPLOYMENT_MAX_X + 1):
		# Keep boarding positions off the wall rows, where carriage racks and window
		# fittings obscure a standing operative even when the tactical tile is legal.
		for y in range(1, turn.board.BOARD_SIZE.y - 1):
			var cell := Vector2i(x, y)
			if not turn.board.is_walkable(cell, occupied) or turn.board.hazard_cells.has(cell):
				continue
			var crowded := false
			for occupied_cell in occupied:
				if Vector2i(occupied_cell).x <= GridBoard.CREW_DEPLOYMENT_MAX_X and turn.board.grid_distance(cell, Vector2i(occupied_cell)) < GridBoard.MIN_CREW_DEPLOYMENT_DISTANCE:
					crowded = true
			if crowded:
				continue
			var score := float(turn.board.grid_distance(cell, desired))
			var nearest_enemy := _nearest_enemy_cell_distance(cell)
			if nearest_enemy < GridBoard.MIN_DEPLOYMENT_DISTANCE:
				continue
			score -= turn.board.cover_penalty(_nearest_enemy_cell(cell), cell) * 8.0 if nearest_enemy < 99 else 0.0
			if score < best_score:
				best_score = score
				best = cell
	return best


func _nearest_enemy_cell(from_cell: Vector2i) -> Vector2i:
	var best := from_cell
	var distance := 999
	for enemy in turn.enemy_units(true):
		var candidate := turn.board.grid_distance(from_cell, enemy.grid_cell)
		if candidate < distance:
			distance = candidate
			best = enemy.grid_cell
	return best


func _nearest_enemy_cell_distance(from_cell: Vector2i) -> int:
	var cell := _nearest_enemy_cell(from_cell)
	return turn.board.grid_distance(from_cell, cell) if cell != from_cell else (0 if not turn.enemy_units(true).is_empty() else 99)


func _nearest_living_crew(enemy: TacticalUnit) -> TacticalUnit:
	var best: TacticalUnit
	var distance := 999
	for crew in turn.player_units(true):
		var candidate := turn.board.grid_distance(enemy.grid_cell, crew.grid_cell)
		if candidate < distance:
			distance = candidate
			best = crew
	return best


func _guard_verb(role_id: String) -> String:
	match role_id:
		"marksman": return "SIGHTING"
		"duelist": return "FLANKING"
		"bruiser": return "CHARGING"
		"medic": return "SUPPORTING"
		"officer": return "COMMANDING"
		"boss": return "HUNTING"
	return "PRESSING"


func _update_plan_integrity() -> void:
	var living := turn.player_units(true).size()
	var total := turn.player_units(false).size()
	var wounded := 0
	var crippled := 0
	var injury_causes: Array[String] = []
	for crew in turn.player_units(true):
		if _is_wounded(crew):
			wounded += 1
			injury_causes.append("%s's torso is critical" % crew.display_name)
		if crew.arms_crippled() or crew.legs_crippled():
			crippled += 1
			injury_causes.append("%s has crippled %s" % [crew.display_name, "arms" if crew.arms_crippled() else "legs"])
	var new_status := "on_plan"
	var explanation := "Assignments and the opening priority remain viable."
	if living == 0 or (living < total and living <= 1) or (_save_crew_active() and crippled >= 2):
		new_status = "broken"
		explanation = "%d of %d crew remain; the fallback now controls survival decisions." % [living, total] if living < total else "%d operatives are crippled; Save the Crew calls a withdrawal." % crippled
	elif wounded > 0 or crippled > 0:
		new_status = "adapting"
		explanation = "; ".join(injury_causes) + "."
	elif turn.round_number >= 7:
		new_status = "adapting"
		explanation = "The opening ran long; the crew is switching to finishing shots."
	elif int(active_plan.get("target_instance_id", 0)) != 0:
		var opening_target := instance_from_id(int(active_plan["target_instance_id"])) as TacticalUnit
		if not is_instance_valid(opening_target) or not opening_target.is_combat_active():
			explanation = "Opening priority neutralized; the crew is clearing remaining threats."
	if new_status != current_plan_status or explanation != current_plan_explanation:
		var previous_status := current_plan_status
		current_plan_status = new_status
		current_plan_explanation = explanation
		fallback_triggered = fallback_triggered or new_status != "on_plan"
		if new_status != "on_plan" and _first_plan_failure_cause.is_empty():
			_first_plan_failure_cause = explanation
		if previous_status == "on_plan" and new_status != "on_plan":
			_fallback_activation_count += 1
		if new_status == "broken" and previous_status != "broken":
			_emit_presentation_beat("plan_break", null, null, {"explanation": explanation, "fallback": String(active_fallback.get("title", "HOLD THE PLAN"))})
		plan_status_changed.emit(current_plan_status, current_plan_explanation)


func _protect_wounded_active() -> bool:
	return String(active_fallback.get("id", "")) == "protect_wounded"


func _save_crew_active() -> bool:
	return String(active_fallback.get("id", "")) == "save_crew"


func _is_wounded(unit: TacticalUnit) -> bool:
	var torso: Dictionary = unit.body_state[Types.BodyZone.TORSO]
	return float(torso["hp"]) / maxf(1.0, float(torso["max_hp"])) < 0.40


func _apply_plan_guard_to_crew() -> void:
	for crew in turn.player_units(true):
		crew.damage_resistance = maxf(maxf(float(crew.get_meta("doctrine_resistance", 0.0)), float(crew.get_meta("signature_guard", 0.0))), _plan_resistance(crew))
		if crew.damage_resistance >= 0.46 and ((_protect_wounded_active() and _is_wounded(crew)) or (_save_crew_active() and current_plan_status == "broken")):
			_observed_fallback_protection[crew.display_name] = crew.damage_resistance


func _plan_resistance(unit: TacticalUnit) -> float:
	var resistance := formation_resistance(unit, active_plan)
	if _protect_wounded_active() and _is_wounded(unit):
		resistance = maxf(resistance, 0.46)
	if _save_crew_active() and current_plan_status == "broken":
		resistance = maxf(resistance, 0.46)
	return resistance


func formation_resistance(unit: TacticalUnit, plan: Dictionary) -> float:
	if not bool(plan.get("safe", false)):
		return 0.0
	if unit.is_in_physical_cover():
		return 0.40
	for ally in turn.player_units(true):
		if ally != unit and turn.board.grid_distance(unit.grid_cell, ally.grid_cell) <= 3:
			return 0.40
	return 0.0


func _set_intent(unit: TacticalUnit, caption: String, explanation: String, forced_status: String = "") -> void:
	var status := forced_status if not forced_status.is_empty() else current_plan_status
	unit.set_autobattle_intent(caption, status)
	intent_changed.emit(unit, caption, explanation, status)


func _on_attack_resolved(attacker: TacticalUnit, target: TacticalUnit, zone: Types.BodyZone, result: Dictionary) -> void:
	var text := "%s %s %s's %s" % [
		attacker.display_name,
		"hit" if bool(result.get("hit", false)) else "missed",
		target.display_name,
		Types.zone_name(zone).to_lower(),
	]
	event_history.append(text)
	var beat_result := result.duplicate(true)
	beat_result["zone"] = int(zone)
	var beat_type := "ordinary_attack"
	if bool(result.get("defeated", false)):
		beat_type = "casualty"
	elif bool(result.get("disabled", false)) or bool(result.get("detached", false)):
		beat_type = "cripple"
	_emit_presentation_beat(beat_type, attacker, target, beat_result)
	if attacker.team == Types.Team.ENEMY and target.team == Types.Team.PLAYER and bool(result.get("hit", false)):
		var damage_record := {
			"attacker": attacker.display_name,
			"target": target.display_name,
			"roster_id": target.roster_id,
			"zone": int(zone),
			"damage": int(result.get("damage", 0)),
			"disabled": bool(result.get("disabled", false)),
			"defeated": bool(result.get("defeated", false)),
		}
		_crew_damage_events.append(damage_record)
		if _first_plan_failure_cause.is_empty() and (bool(result.get("disabled", false)) or bool(result.get("defeated", false)) or _is_wounded(target)):
			_first_plan_failure_cause = "%s hit %s's %s for %d; %s." % [attacker.display_name, target.display_name, Types.zone_name(zone).to_lower(), int(result.get("damage", 0)), "the operative fell" if not target.is_alive else ("the zone was crippled" if bool(result.get("disabled", false)) else "their torso became critical")]
		if target.roster_id == String(active_plan.get("risk_unit_id", "")):
			_risk_exposure_count += 1
		_apply_plan_guard_to_crew()
	if bool(result.get("disabled", false)):
		_add_milestone("%s disabled %s's %s." % [attacker.display_name, target.display_name, Types.zone_name(zone).to_lower()])
	elif bool(result.get("defeated", false)):
		_add_milestone("%s took %s out of the fight." % [attacker.display_name, target.display_name])


func _on_environment_injury_resolved(source_name: String, unit: TacticalUnit, zone: Types.BodyZone, result: Dictionary) -> void:
	if unit.team == Types.Team.PLAYER:
		_crew_damage_events.append({"attacker": source_name, "target": unit.display_name, "roster_id": unit.roster_id, "zone": int(zone), "damage": int(result.get("damage", 0)), "disabled": bool(result.get("disabled", false)), "defeated": bool(result.get("defeated", false))})
		if _first_plan_failure_cause.is_empty() and (not unit.is_alive or _is_wounded(unit) or bool(result.get("disabled", false))):
			_first_plan_failure_cause = "%s hit %s's %s for %d." % [source_name, unit.display_name, Types.zone_name(zone).to_lower(), int(result.get("damage", 0))]
		if unit.roster_id == String(active_plan.get("risk_unit_id", "")):
			_risk_exposure_count += 1
		_apply_plan_guard_to_crew()
	if bool(result.get("defeated", false)) or bool(result.get("disabled", false)):
		var beat_result := result.duplicate(true)
		beat_result["zone"] = int(zone)
		beat_result["source_name"] = source_name
		_emit_presentation_beat("casualty" if bool(result.get("defeated", false)) else "cripple", null, unit, beat_result)


func _on_environment_resolved(action_id: String, actor: TacticalUnit, result: Dictionary) -> void:
	_train_counter_actions[action_id] = true
	_emit_presentation_beat("environment", actor, null, result.merged({"action_id": action_id}, true))
	if bool(result.get("control_only", false)):
		_add_milestone("%s secured the %s; its train surge is countered." % [actor.display_name, action_id.replace("_", " ")])
		return
	_add_milestone("%s triggered the %s and caught %d guard%s." % [
		actor.display_name,
		action_id.replace("_", " "),
		Array(result.get("victims", [])).size(),
		"" if Array(result.get("victims", [])).size() == 1 else "s",
	])


func _advance_signature_arc(serial: int) -> void:
	if serial != _run_serial or not SignatureArc.is_signature_car(turn.active_car_id):
		return
	var event := SignatureArc.event_for_round(turn.active_car_id, turn.round_number)
	if event.is_empty():
		return
	if String(event.get("phase", "")) == "warning":
		train_event_history.append(event.duplicate(true))
		train_event_changed.emit(event.duplicate(true), {})
		_emit_presentation_beat("train_warning", null, null, event)
		_add_milestone("LIVING TRAIN WARNING / %s" % String(event.get("title", "HAZARD")))
		await _action_beat(0.16)
		return
	var counter_action := String(event.get("counter_action", ""))
	var countered := bool(_train_counter_actions.get(counter_action, false))
	var result := turn.resolve_living_train_event(event, countered)
	var record := event.duplicate(true)
	record["result"] = result.duplicate(true)
	train_event_history.append(record)
	train_event_changed.emit(event.duplicate(true), result.duplicate(true))
	_emit_presentation_beat("environment", null, null, result.merged({"action_id": String(event.get("title", "train_event")), "countered": countered}, true))
	if countered:
		_add_milestone("LIVING TRAIN COUNTERED / %s" % String(event.get("title", "HAZARD")))
	else:
		_add_milestone("%s caught %d crew and %d guards." % [
			String(event.get("title", "THE TRAIN")),
			Array(result.get("crew_victims", [])).size(),
			Array(result.get("enemy_victims", [])).size(),
		])
	await _action_beat(0.16)


func _add_milestone(text: String) -> void:
	milestones.append(text)
	if milestones.size() > 8:
		milestones.pop_front()
	milestone_added.emit(text)


func record_mission_result(victory: bool, message: String) -> void:
	_emit_presentation_beat("victory" if victory else "defeat", null, null, {"message": message})


func _emit_presentation_beat(beat_type: String, actor: TacticalUnit, target: TacticalUnit, result: Dictionary) -> void:
	_beat_sequence += 1
	var bark := _bark_for_beat(beat_type, actor, target, result)
	var beat := {
		"type": beat_type,
		"actor": actor,
		"target": target,
		"actor_name": actor.display_name if is_instance_valid(actor) else "",
		"target_name": target.display_name if is_instance_valid(target) else "",
		"result": result.duplicate(true),
		"bark": bark,
		"round": turn.round_number,
		"sequence": _beat_sequence,
	}
	if beat_type in ["environment", "signature_move", "cripple", "plan_break", "casualty", "surrender", "victory", "defeat", "item"]:
		decisive_beats.append(_serializable_beat(beat))
		if decisive_beats.size() > 12:
			decisive_beats.pop_front()
	presentation_beat.emit(beat)


func _bark_for_beat(beat_type: String, actor: TacticalUnit, target: TacticalUnit, result: Dictionary) -> String:
	match beat_type:
		"signature_move":
			return "Make the opening count."
		"item":
			return "Clockwork. Stand clear."
		"environment":
			return "Brace. The carriage is moving." if result.has("countered") and not bool(result["countered"]) else "The train works for us now."
		"cripple":
			return "That part is finished."
		"plan_break":
			return "Plan bent. Fallback moving."
		"casualty":
			return "Guard down. Keep moving." if is_instance_valid(target) and target.team == Types.Team.ENEMY else "Crew down. Keep breathing."
		"surrender":
			return "Good. Drop it."
		"victory":
			return "Carriage ours. Keep moving."
		"defeat":
			return "The Rail collected its debt."
	return String(result.get("bark", ""))


func _serializable_beat(beat: Dictionary) -> Dictionary:
	return {
		"type": String(beat.get("type", "event")),
		"actor_name": String(beat.get("actor_name", "")),
		"target_name": String(beat.get("target_name", "")),
		"result": Dictionary(beat.get("result", {})).duplicate(true),
		"bark": String(beat.get("bark", "")),
		"round": int(beat.get("round", 0)),
		"sequence": int(beat.get("sequence", 0)),
	}


func _on_unit_surrendered(unit: TacticalUnit) -> void:
	_emit_presentation_beat("surrender", unit, null, {"result": "weapon_dropped"})


func build_aftermath(victory: bool) -> Dictionary:
	var injuries: Array[Dictionary] = []
	for crew in turn.player_units(false):
		var before: Dictionary = initial_body_states.get(crew.get_instance_id(), {})
		var changes: Array[String] = []
		for zone in crew.body_state:
			var now: Dictionary = crew.body_state[zone]
			var old: Dictionary = before.get(zone, now)
			if bool(now.get("detached", false)) and not bool(old.get("detached", false)):
				changes.append("%s severed" % Types.zone_name(zone))
			elif bool(now.get("disabled", false)) and not bool(old.get("disabled", false)):
				changes.append("%s crippled" % Types.zone_name(zone))
			elif int(now.get("hp", 0)) < int(old.get("hp", 0)):
				changes.append("%s %d/%d" % [Types.zone_name(zone), int(now.get("hp", 0)), int(now.get("max_hp", 0))])
		if not changes.is_empty() or not crew.is_alive:
			injuries.append({"name": crew.display_name, "roster_id": crew.roster_id, "changes": changes, "down": not crew.is_alive})
	var story := "The crew executed %s" % String(active_plan.get("title", "the plan"))
	story += " and cleared the carriage." if victory else ", but the carriage broke the crew."
	if fallback_triggered:
		story += " %s took over when the opening bent." % String(active_fallback.get("title", "The fallback"))
	var decisive_injury := _decisive_injury_text()
	var failure_analysis := {
		"why_plan_broke": "The plan held through the final exchange." if _first_plan_failure_cause.is_empty() else _first_plan_failure_cause,
		"fallback_effect": _fallback_aftermath_text(),
		"decisive_injury": decisive_injury,
		"suggested_adjustment": _suggested_adjustment(victory),
		"risk_carrier": String(active_plan.get("risk_unit_name", "CREW")),
		"risk_exposures": _risk_exposure_count,
		"fallback_activations": _fallback_activation_count,
		"fallback_actions": fallback_actions.duplicate(true),
		"fallback_protection": _observed_fallback_protection.duplicate(true),
		"item_outcomes": _item_outcomes.duplicate(true),
		"control_conditions": _control_condition_records.duplicate(true),
	}
	return {
		"victory": victory,
		"story": story,
		"plan_title": String(active_plan.get("title", "Unknown plan")),
		"fallback_title": String(active_fallback.get("title", "Hold the plan")),
		"plan_status": current_plan_status,
		"fallback_triggered": fallback_triggered,
		"milestones": milestones.duplicate(),
		"injuries": injuries,
		"rounds": turn.round_number,
		"stats": turn.encounter_stats.duplicate(true),
		"train_events": train_event_history.duplicate(true),
		"doctrine": current_doctrine.duplicate(true),
		"decisive_beats": decisive_beats.duplicate(true),
		"failure_analysis": failure_analysis,
	}


func _decisive_injury_text() -> String:
	if _crew_damage_events.is_empty():
		return "No operative suffered a decisive injury."
	var chosen := Dictionary(_crew_damage_events.back())
	for event in _crew_damage_events:
		var candidate := Dictionary(event)
		if bool(candidate.get("defeated", false)) or (bool(candidate.get("disabled", false)) and not bool(chosen.get("defeated", false))):
			chosen = candidate
	return "%s's %s took %d from %s%s." % [
		String(chosen.get("target", "An operative")),
		Types.zone_name(int(chosen.get("zone", Types.BodyZone.TORSO))).to_lower(),
		int(chosen.get("damage", 0)),
		String(chosen.get("attacker", "the guard line")),
		" and fell" if bool(chosen.get("defeated", false)) else (" and became crippled" if bool(chosen.get("disabled", false)) else ""),
	]


func _fallback_aftermath_text() -> String:
	var protection_text := ""
	if not _observed_fallback_protection.is_empty():
		var names: Array[String] = []
		for crew_name in _observed_fallback_protection:
			names.append(String(crew_name))
		protection_text = "46%% protection covered %s. " % ", ".join(names)
	if not fallback_actions.is_empty():
		var summaries: Array[String] = []
		for action in fallback_actions:
			if String(action.get("summary", "")) not in summaries:
				summaries.append(String(action.get("summary", "")))
		return protection_text + " ".join(summaries.slice(0, 2))
	if not fallback_triggered:
		return "%s never needed to activate." % String(active_fallback.get("title", "HOLD THE PLAN"))
	match String(active_fallback.get("id", "hold_plan")):
		"protect_wounded": return protection_text + "No protective movement was executed before the encounter ended."
		"save_crew": return protection_text + "No withdrawal was executed before the encounter ended."
		"finish_target": return "Finish the Target preserved pressure on the original priority despite injuries."
		"improvise": return "Improvise released authored assignments and returned each operative to their personal combat instinct."
	return "Hold the Plan preserved the original assignments after the opening bent."


func _suggested_adjustment(victory: bool) -> String:
	if victory:
		return "Keep this plan in the dossier; compare its injuries against another tactical family next time."
	if bool(active_plan.get("capture_target", false)) and not bool(current_doctrine.get("broken", false)):
		return "Try Break Voss's Timing: head damage stops command aim; venting alone only stops steam."
	if String(active_fallback.get("id", "")) not in ["protect_wounded", "save_crew"]:
		return "Retry with Protect the Wounded so an exposed risk carrier gains exact 46% resistance after injury."
	if String(active_plan.get("tactic_family", "")) == "high_risk":
		return "Choose the formation/control offer to lower opening variance before committing a risky maneuver."
	for outcome in _item_outcomes:
		if String(_item_outcomes[outcome]) != "used":
			return "Choose a route or deployment that gives %s a legal safe trigger." % String(outcome).replace("_", " ").capitalize()
	return "Change the primary body zone or risk carrier instead of repeating the same opening."


func _wait_until_resumed(serial: int) -> void:
	while (paused or inspection_paused) and running and serial == _run_serial:
		await get_tree().process_frame


func _action_beat(seconds: float) -> void:
	if not running:
		return
	await get_tree().create_timer(seconds).timeout
