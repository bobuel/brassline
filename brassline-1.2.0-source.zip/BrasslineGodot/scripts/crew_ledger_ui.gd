class_name CrewLedgerUI
extends Control

signal closed
signal operative_selected(unit: TacticalUnit)
signal settings_requested

const Types := preload("res://scripts/game_types.gd")
const RunState := preload("res://scripts/run_state.gd")
const CrewSelectionStageScript := preload("res://scripts/crew_selection_stage.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")

var crew: Array[TacticalUnit] = []
var inventory: Dictionary = {}
var bonuses: Dictionary = {}
var car: Dictionary = {}
var campaign: Dictionary = {}
var selected_roster_id := ""
var selected_tab := "crew"
var plan: Dictionary = {}
var gear_outcomes: Dictionary = {}
var phase := "planning"
var selected_item := "clockwork_grenade"
var selected_zone: int = Types.BodyZone.HEAD

var crew_list: VBoxContainer
var stage: CrewSelectionStage
var operative_title: Label
var body_grid: GridContainer
var tabs: Dictionary = {}
var detail_title: Label
var detail_body: RichTextLabel
var item_grid: GridContainer
var item_buttons: Dictionary = {}
var settings_button: Button
var _text_scale := 1.0
var _crew_buttons: Dictionary = {}
var _body_buttons: Dictionary = {}
var _staged_unit_key := ""
var _rendered_tab := ""
var _rendered_actor := ""
var context_label: Label

var _panel_color := Color(0.012, 0.028, 0.034, 0.985)
var _soft_panel := Color(0.025, 0.061, 0.068, 0.96)
var _border := Color(0.26, 0.53, 0.53, 0.72)
var _brass := Color("#e3b65c")
var _ink := Color("#e5f6f2")
var _muted := Color("#8fb3b2")
var _green := Color("#72d8b6")
var _danger := Color("#ff7d6e")


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 80
	_build()
	visible = false


func show_context(context: Dictionary, roster_id: String = "", tab_id: String = "crew") -> void:
	_read_context(context)
	selected_roster_id = roster_id if not roster_id.is_empty() else (unit_key(crew[0]) if not crew.is_empty() else "")
	selected_tab = tab_id if tab_id in ["crew", "gear", "injuries", "train"] else "crew"
	_populate_crew_list()
	_refresh()
	visible = true
	var selected_button := _crew_buttons.get(selected_roster_id) as Button
	if is_instance_valid(selected_button):
		_focus_weak.call_deferred(weakref(selected_button))


func _focus_weak(reference: WeakRef) -> void:
	var control = reference.get_ref()
	if is_instance_valid(control) and control.is_inside_tree() and control.is_visible_in_tree():
		control.grab_focus()


func update_context(context: Dictionary) -> void:
	# Keep the player's actor, tab, rotation, scroll and focus while values change.
	var previous_keys := _crew_buttons.keys()
	_read_context(context)
	var current_keys: Array = []
	for unit in crew:
		current_keys.append(unit_key(unit))
	if current_keys != previous_keys:
		_populate_crew_list()
	_refresh()


static func unit_key(unit: TacticalUnit) -> String:
	if unit.has_meta("inspection_id"):
		return String(unit.get_meta("inspection_id"))
	if not unit.roster_id.is_empty():
		return unit.roster_id
	return "enemy:%d" % unit.get_instance_id()


func _read_context(context: Dictionary) -> void:
	crew.clear()
	for raw_unit in Array(context.get("crew", [])):
		if raw_unit is TacticalUnit:
			crew.append(raw_unit)
	inventory = Dictionary(context.get("inventory", {})).duplicate(true)
	bonuses = Dictionary(context.get("bonuses", {})).duplicate(true)
	car = Dictionary(context.get("car", {})).duplicate(true)
	campaign = Dictionary(context.get("campaign", {})).duplicate(true)
	plan = Dictionary(context.get("plan", {})).duplicate(true)
	gear_outcomes = Dictionary(context.get("gear_outcomes", {})).duplicate(true)
	phase = String(context.get("phase", "planning"))


func set_text_scale(value: float) -> void:
	_text_scale = clampf(value, 1.0, 1.30)
	_apply_text_scale(self)


func close() -> void:
	visible = false
	closed.emit()


func _unhandled_input(event: InputEvent) -> void:
	if not visible or bool(get_meta("settings_open", false)):
		return
	if event.is_action_pressed("ui_cancel") or (event is InputEventKey and event.pressed and event.keycode in [KEY_I, KEY_Y]):
		get_viewport().set_input_as_handled()
		close()


func _build() -> void:
	var veil := ColorRect.new()
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	veil.color = Color(0.0, 0.0, 0.0, 0.78)
	add_child(veil)
	var shell := PanelContainer.new()
	shell.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shell.offset_left = 18; shell.offset_right = -18; shell.offset_top = 18; shell.offset_bottom = -18
	shell.add_theme_stylebox_override("panel", _box(_panel_color, _border, 8))
	add_child(shell)
	var margin := _margin(18, 18, 14, 14); shell.add_child(margin)
	var root_col := VBoxContainer.new(); root_col.add_theme_constant_override("separation", 10); margin.add_child(root_col)
	var header := HBoxContainer.new(); root_col.add_child(header)
	var title := _label("CREW LEDGER", 24, _ink); title.size_flags_horizontal = Control.SIZE_EXPAND_FILL; header.add_child(title)
	context_label = _label("CREW / INSPECTION", 12, _green); context_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; header.add_child(context_label)
	settings_button = _button("SETTINGS", false)
	settings_button.pressed.connect(func() -> void: settings_requested.emit())
	header.add_child(settings_button)
	var close_button := _button("CLOSE  [I / Y]", true); close_button.pressed.connect(close); header.add_child(close_button)
	root_col.add_child(HSeparator.new())
	var columns := HBoxContainer.new(); columns.size_flags_vertical = Control.SIZE_EXPAND_FILL; columns.add_theme_constant_override("separation", 12); root_col.add_child(columns)

	var left := PanelContainer.new(); left.custom_minimum_size.x = 280; left.add_theme_stylebox_override("panel", _box(_soft_panel, _border, 6)); columns.add_child(left)
	var left_margin := _margin(10, 10, 10, 10); left.add_child(left_margin)
	var left_col := VBoxContainer.new(); left_col.add_theme_constant_override("separation", 8); left_margin.add_child(left_col)
	left_col.add_child(_label("OPERATIVES", 12, _brass))
	crew_list = VBoxContainer.new(); crew_list.add_theme_constant_override("separation", 8); left_col.add_child(crew_list)

	var center := PanelContainer.new(); center.size_flags_horizontal = Control.SIZE_EXPAND_FILL; center.add_theme_stylebox_override("panel", _box(Color(0.015, 0.042, 0.048, 0.95), _border, 6)); columns.add_child(center)
	var center_margin := _margin(10, 10, 8, 8); center.add_child(center_margin)
	var center_col := VBoxContainer.new(); center_col.add_theme_constant_override("separation", 6); center_margin.add_child(center_col)
	operative_title = _label("OPERATIVE", 18, _ink); operative_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; center_col.add_child(operative_title)
	stage = CrewSelectionStageScript.new(); stage.size_flags_vertical = Control.SIZE_EXPAND_FILL; stage.custom_minimum_size = Vector2(360, 300); center_col.add_child(stage)
	body_grid = GridContainer.new(); body_grid.columns = 2; body_grid.add_theme_constant_override("h_separation", 8); body_grid.add_theme_constant_override("v_separation", 8); center_col.add_child(body_grid)

	var right := PanelContainer.new(); right.custom_minimum_size.x = 390; right.size_flags_horizontal = Control.SIZE_EXPAND_FILL; right.add_theme_stylebox_override("panel", _box(_soft_panel, _border, 6)); columns.add_child(right)
	var right_margin := _margin(12, 12, 10, 10); right.add_child(right_margin)
	var right_col := VBoxContainer.new(); right_col.add_theme_constant_override("separation", 9); right_margin.add_child(right_col)
	var tab_row := HBoxContainer.new(); tab_row.add_theme_constant_override("separation", 5); right_col.add_child(tab_row)
	for tab_id in ["crew", "gear", "injuries", "train"]:
		var tab_button := _button(tab_id.to_upper(), false); tab_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL; tab_button.pressed.connect(_select_tab.bind(tab_id)); tab_row.add_child(tab_button); tabs[tab_id] = tab_button
	detail_title = _label("CREW", 20, _brass); right_col.add_child(detail_title)
	item_grid = GridContainer.new(); item_grid.columns = 2
	item_grid.add_theme_constant_override("h_separation", 8); item_grid.add_theme_constant_override("v_separation", 8)
	right_col.add_child(item_grid)
	for item_id in ["clockwork_grenade", "focus_tonic", "medkit", "limb_brace"]:
		var item_button := _button("", false)
		item_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		item_button.custom_minimum_size = Vector2(0, 64)
		item_button.alignment = HORIZONTAL_ALIGNMENT_LEFT; item_button.clip_text = true
		item_button.add_theme_font_size_override("font_size", 11)
		for state in ["normal", "hover", "pressed", "focus"]:
			var style := item_button.get_theme_stylebox(state).duplicate() as StyleBox
			style.content_margin_left = 46
			item_button.add_theme_stylebox_override(state, style)
		var icon := TextureRect.new(); icon.name = "ItemIcon"; icon.texture = _item_icon(item_id)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED; icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		icon.anchor_top = 0.5; icon.anchor_bottom = 0.5; icon.offset_left = 5; icon.offset_right = 41; icon.offset_top = -20; icon.offset_bottom = 20
		item_button.add_child(icon)
		item_button.pressed.connect(_select_item.bind(item_id)); item_grid.add_child(item_button); item_buttons[item_id] = item_button
	detail_body = RichTextLabel.new(); detail_body.bbcode_enabled = true; detail_body.size_flags_vertical = Control.SIZE_EXPAND_FILL; detail_body.add_theme_font_size_override("normal_font_size", 14); detail_body.add_theme_color_override("default_color", _ink); right_col.add_child(detail_body)


func _populate_crew_list() -> void:
	_clear_children(crew_list)
	_crew_buttons.clear()
	for unit in crew:
		var key := unit_key(unit)
		var button := _button("", false)
		var portrait_path := "res://assets/ui/portraits/%s.png" % unit.roster_id
		if unit.team == Types.Team.PLAYER and ResourceLoader.exists(portrait_path):
			button.icon = load(portrait_path) as Texture2D
			button.expand_icon = true
			button.add_theme_constant_override("icon_max_width", 44)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT; button.custom_minimum_size.y = 62; button.pressed.connect(_select_crew.bind(key)); crew_list.add_child(button)
		_crew_buttons[key] = button


func _select_crew(roster_id: String) -> void:
	selected_roster_id = roster_id
	_refresh()
	var unit := _selected_unit()
	if is_instance_valid(unit):
		operative_selected.emit(unit)


func _select_tab(tab_id: String) -> void:
	selected_tab = tab_id
	if tab_id == "injuries" and selected_item not in ["medkit", "limb_brace"]:
		selected_item = "medkit"
	_refresh()


func _select_item(item_id: String) -> void:
	selected_item = item_id
	_refresh()


func _inspect_zone(zone: int) -> void:
	selected_zone = zone
	selected_tab = "injuries"
	selected_item = "limb_brace" if zone in [Types.BodyZone.ARMS, Types.BodyZone.LEGS] else "medkit"
	_refresh()


func _selected_unit() -> TacticalUnit:
	for unit in crew:
		if unit_key(unit) == selected_roster_id:
			return unit
	return crew[0] if not crew.is_empty() else null


func _refresh() -> void:
	var unit := _selected_unit()
	if not is_instance_valid(unit):
		return
	var previous_scroll := detail_body.get_v_scroll_bar().value
	var preserve_scroll := _rendered_actor == unit_key(unit) and _rendered_tab == selected_tab
	selected_roster_id = unit_key(unit)
	var is_enemy := unit.team == Types.Team.ENEMY
	context_label.text = "ENEMY / INSPECTION" if is_enemy else "CREW / INSPECTION"
	context_label.add_theme_color_override("font_color", _danger if is_enemy else _green)
	operative_title.text = "%s  /  %s" % [unit.display_name.to_upper(), unit.role_label if is_enemy else String(unit.get_meta("crew_role", "OPERATIVE"))]
	var cosmetic_id := String(unit.get_meta("cosmetic_id", "weathered"))
	var stage_key := "%s:%s:%s" % [selected_roster_id, unit.weapon_id, cosmetic_id]
	if _staged_unit_key != stage_key:
		stage.show_member({"id": selected_roster_id, "model": unit.visual_model_path.get_file(), "weapon_id": unit.weapon_id}, cosmetic_id)
		_staged_unit_key = stage_key
	for candidate in crew:
		var key := unit_key(candidate)
		var button := _crew_buttons.get(key) as Button
		if not is_instance_valid(button):
			continue
		var torso: Dictionary = candidate.body_state.get(Types.BodyZone.TORSO, {})
		var state := "LOST" if not candidate.is_alive else ("CRIPPLED" if candidate.arms_crippled() or candidate.legs_crippled() else "ACTIVE")
		button.text = "%s\n%s  /  TORSO %d/%d" % [candidate.display_name.to_upper(), state, int(torso.get("hp", 0)), int(torso.get("max_hp", 0))]
		button.add_theme_stylebox_override("normal", _box(Color(0.20, 0.14, 0.04, 0.98) if key == selected_roster_id else _soft_panel, _brass if key == selected_roster_id else _border, 4))
	for zone in [Types.BodyZone.HEAD, Types.BodyZone.TORSO, Types.BodyZone.ARMS, Types.BodyZone.LEGS]:
		var zone_state: Dictionary = unit.body_state.get(zone, {})
		var disabled := bool(zone_state.get("disabled", false)) or bool(zone_state.get("detached", false))
		var zone_button := _body_buttons.get(zone) as Button
		if not is_instance_valid(zone_button):
			zone_button = _button("", false)
			zone_button.custom_minimum_size.y = 42; zone_button.pressed.connect(_inspect_zone.bind(zone)); body_grid.add_child(zone_button)
			_body_buttons[zone] = zone_button
		zone_button.text = "%s   %d/%d%s" % [Types.zone_name(zone).to_upper(), int(zone_state.get("hp", 0)), int(zone_state.get("max_hp", 0)), "  LOST" if bool(zone_state.get("detached", false)) else ("  CRIPPLED" if disabled else "")]
		zone_button.add_theme_color_override("font_color", _danger if disabled else _ink)
		zone_button.tooltip_text = _zone_effect_text(unit, zone)
	for tab_id in tabs:
		var selected: bool = String(tab_id) == selected_tab
		(tabs[tab_id] as Button).add_theme_stylebox_override("normal", _box(Color(0.20, 0.14, 0.04, 0.98) if selected else Color(0.03, 0.10, 0.11, 0.95), _brass if selected else _border, 4))
	_refresh_details(unit)
	_apply_text_scale(self)
	_rendered_tab = selected_tab
	_rendered_actor = selected_roster_id
	if preserve_scroll:
		_restore_scroll.call_deferred(selected_roster_id, selected_tab, previous_scroll)
	else:
		detail_body.get_v_scroll_bar().value = 0


func _restore_scroll(actor_id: String, tab_id: String, value: float) -> void:
	if selected_roster_id == actor_id and selected_tab == tab_id:
		detail_body.get_v_scroll_bar().value = value


func _refresh_details(unit: TacticalUnit) -> void:
	item_grid.visible = selected_tab in ["gear", "injuries"] and unit.team == Types.Team.PLAYER
	for item_id in item_buttons:
		var button := item_buttons[item_id] as Button
		button.visible = selected_tab != "injuries" or item_id in ["medkit", "limb_brace"]
		var committed: bool = String(plan.get("gear_item", "")) == String(item_id) and int(inventory.get(item_id, 0)) > 0
		var status := "COMMITTED" if committed else ("BETWEEN CARS" if item_id in ["medkit", "limb_brace"] else "PLAN USE" if phase == "planning" else "NOT COMMITTED")
		if int(inventory.get(item_id, 0)) <= 0: status = "NOT CARRIED"
		if String(gear_outcomes.get(item_id, "")) == "used": status = "USED THIS CAR"
		button.text = "%s x%d\n%s" % [_item_name(item_id), int(inventory.get(item_id, 0)), status]
		button.tooltip_text = _item_explanation(item_id).replace("[color=#e3b65c]", "").replace("[/color]", "")
		var style := _box(Color(0.20, 0.14, 0.04, 0.98) if item_id == selected_item else _soft_panel, _brass if item_id == selected_item else _border, 4)
		style.content_margin_left = 46
		button.add_theme_stylebox_override("normal", style)
	match selected_tab:
		"gear":
			detail_title.text = "GEAR"
			detail_body.text = "[color=#e5f6f2]EQUIPPED / %s[/color]\n%d / %d AMMO\n\n%s" % [unit.weapon_name.to_upper(), unit.ammunition, unit.magazine_size, _item_explanation(selected_item) if unit.team == Types.Team.PLAYER else "Enemy equipment. Crew supplies are separate."]
		"injuries":
			detail_title.text = "INJURIES"
			var state := Dictionary(unit.body_state.get(selected_zone, {}))
			var severity := "LOST" if not unit.is_alive else ("CRIPPLED" if bool(state.get("disabled", false)) else ("WOUNDED" if int(state.get("hp", 0)) < int(state.get("max_hp", 0)) else "INTACT"))
			detail_body.text = "[color=#e3b65c]%s / %d-%d HP / %s[/color]\n%s\n\n[color=#8fb3b2]Select a body zone below the operative.[/color]" % [Types.zone_name(selected_zone).to_upper(), int(state.get("hp", 0)), int(state.get("max_hp", 0)), severity, _zone_effect_text(unit, selected_zone)]
			if unit.team == Types.Team.PLAYER:
				detail_body.text += "\n\n" + ("Lost operatives cannot be treated." if not unit.is_alive else _item_explanation(selected_item))
		"train":
			detail_title.text = "TRAIN"
			detail_body.text = "[color=#e3b65c]%s[/color]\n%s\n\n[color=#72d8b6]ACTIVE BUFFS[/color]\n%s" % [String(car.get("name", "CURRENT CAR")).to_upper(), String(car.get("tagline", "The carriage is in motion.")), RunState.format_bonus_summary(bonuses)]
		_:
			if unit.team == Types.Team.ENEMY:
				detail_title.text = "ENEMY"
				detail_body.text = "[color=#ff7d6e]%s[/color]\n%s\n\nDAMAGE %.1f  /  RANGE %d  /  MOVE %d\n\nPOST / %s" % [unit.role_label, unit.weapon_name.to_upper(), unit.base_damage, unit.attack_range, unit.movement_range(), String(unit.get_meta("spawn_post", "GUARD LINE"))]
				var doctrine := SignatureArc.car_profile(String(car.get("id", "")))
				if not doctrine.is_empty():
					detail_body.text += "\n\n[color=#e3b65c]%s[/color]\n%s" % [String(doctrine.get("doctrine_name", "GUARD LINE")), String(doctrine.get("doctrine_text", ""))]
				return
			detail_title.text = "CREW"
			var operative := Dictionary(Dictionary(campaign.get("operatives", {})).get(unit.roster_id, {}))
			var relationships: Array[String] = []
			for raw_relationship in Array(campaign.get("relationships", [])):
				var relationship := Dictionary(raw_relationship)
				if unit.roster_id in Array(relationship.get("crew_ids", [])):
					relationships.append("%s  •  %s" % [String(relationship.get("label", "UNTESTED")), " / ".join(Array(relationship.get("crew_ids", [])))])
			detail_body.text = "[color=#e5f6f2]%s[/color]\nDAMAGE %.1f  •  RANGE %d  •  MOVE %d\n\nNERVE  %s\nBOND AIM  %+d%%\n\n[color=#8fb3b2]%s[/color]" % [unit.weapon_name.to_upper(), unit.base_damage, unit.attack_range, unit.movement_range(), String(operative.get("nerve_label", "STEADY")), roundi(float(operative.get("bond_accuracy", 0.0)) * 100.0), "\n".join(relationships) if not relationships.is_empty() else "No tested relationships."]


func _item_name(item_id: String) -> String:
	return String({"clockwork_grenade": "GRENADE", "focus_tonic": "TONIC", "medkit": "MEDKIT", "limb_brace": "BRACE"}.get(item_id, item_id.to_upper()))


func _item_explanation(item_id: String) -> String:
	var description := String({
		"clockwork_grenade": "A plan commits the grenade. The operative waits for a legal blast without crew in the blast area.",
		"focus_tonic": "Next shot: +18% aim, +16% critical chance. A committed tonic waits for a non-torso shot below 90%, without an active aim signature.",
		"medkit": "BETWEEN CARS / Restores up to 2 HP to each damaged attached zone. Does not revive lost crew.",
		"limb_brace": "BETWEEN CARS / Restores up to 4 HP to the weakest damaged attached arms or legs.",
	}.get(item_id, "Select an item to inspect."))
	if String(gear_outcomes.get(item_id, "")) == "used":
		return "[color=#e3b65c]USED THIS CAR[/color]\n%d remaining for later cars.\n\n%s" % [int(inventory.get(item_id, 0)), description]
	if String(plan.get("gear_item", "")) == item_id:
		var actor := String(plan.get("gear_user_name", "CREW"))
		var status := "COMMITTED / " + actor if int(inventory.get(item_id, 0)) > 0 else "NO REMAINING STOCK"
		description = "[color=#e3b65c]%s[/color]\n%s\n\n%s" % [status, String(plan.get("gear_trigger", "Waits for a safe legal trigger.")), description]
	elif item_id in ["clockwork_grenade", "focus_tonic"] and int(inventory.get(item_id, 0)) > 0:
		description = ("Choose an item-assisted approach to commit this.\n\n" if phase == "planning" else "CARRIED / NOT IN THIS PLAN\nOnly committed items are used.\n\n") + description
	return description


func _zone_effect_text(unit: TacticalUnit, zone: int) -> String:
	match zone:
		Types.BodyZone.HEAD:
			var head := Dictionary(unit.body_state.get(zone, {}))
			var impaired := float(head.get("hp", 0)) <= float(head.get("max_hp", 1)) * 0.5
			return ("ACTIVE / -8% aim.\n" if impaired and unit.is_alive else "") + "At half head HP: -8% aim. At zero: lost."
		Types.BodyZone.TORSO:
			return "At zero torso HP: lost. Torso wounds carry into the next car."
		Types.BodyZone.ARMS:
			return ("ACTIVE / " if unit.arms_crippled() else "AT ZERO / ") + "-36% aim, half damage. Cannot reload or overwatch."
		Types.BodyZone.LEGS:
			return ("ACTIVE / " if unit.legs_crippled() else "AT ZERO / ") + "Movement 1; no cover stance. Initiative -4."
	return ""


func _item_icon(item_id: String) -> AtlasTexture:
	var texture := AtlasTexture.new()
	texture.atlas = load("res://assets/ui/items/brassline_item_atlas.png") as Texture2D
	var tile_size := texture.atlas.get_size() * 0.5
	var cells := {"medkit": Vector2.ZERO, "limb_brace": Vector2.RIGHT, "clockwork_grenade": Vector2.DOWN, "focus_tonic": Vector2.ONE}
	texture.region = Rect2(Vector2(cells.get(item_id, Vector2.ZERO)) * tile_size, tile_size)
	return texture


func _button(text_value: String, prominent: bool) -> Button:
	var button := Button.new(); button.text = text_value; button.add_theme_font_size_override("font_size", 13); button.add_theme_color_override("font_color", _ink); button.add_theme_stylebox_override("normal", _box(Color(0.22, 0.15, 0.05, 0.97) if prominent else Color(0.03, 0.10, 0.11, 0.95), _brass if prominent else _border, 4)); button.add_theme_stylebox_override("hover", _box(Color(0.30, 0.21, 0.07, 1.0), _brass, 4)); return button


func _label(text_value: String, size: int, color: Color) -> Label:
	var label := Label.new(); label.text = text_value; label.add_theme_font_size_override("font_size", size); label.add_theme_color_override("font_color", color); return label


func _box(color: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new(); style.bg_color = color; style.border_color = border; style.set_border_width_all(1); style.set_corner_radius_all(radius); style.content_margin_left = 10; style.content_margin_right = 10; style.content_margin_top = 7; style.content_margin_bottom = 7; return style


func _margin(left: int, right: int, top: int, bottom: int) -> MarginContainer:
	var margin := MarginContainer.new(); margin.add_theme_constant_override("margin_left", left); margin.add_theme_constant_override("margin_right", right); margin.add_theme_constant_override("margin_top", top); margin.add_theme_constant_override("margin_bottom", bottom); return margin


func _clear_children(parent: Node) -> void:
	for child in parent.get_children():
		parent.remove_child(child); child.queue_free()


func _apply_text_scale(node: Node) -> void:
	if node is Label or node is Button:
		var control := node as Control
		if not control.has_meta("ledger_font_size"):
			control.set_meta("ledger_font_size", control.get_theme_font_size("font_size"))
		control.add_theme_font_size_override("font_size", maxi(10, roundi(float(control.get_meta("ledger_font_size")) * _text_scale)))
	elif node is RichTextLabel:
		var rich := node as RichTextLabel
		if not rich.has_meta("ledger_font_size"):
			rich.set_meta("ledger_font_size", rich.get_theme_font_size("normal_font_size"))
		rich.add_theme_font_size_override("normal_font_size", maxi(10, roundi(float(rich.get_meta("ledger_font_size")) * _text_scale)))
	for child in node.get_children():
		_apply_text_scale(child)
