class_name TacticalCameraRig
extends Node3D

var camera: Camera3D
var move_speed := 10.0
var zoom_distance := 19.5
var min_zoom := 10.0
var max_zoom := 28.0
var input_enabled := true
var _base_direction := Vector3(0.0, 0.56, 0.83).normalized()
var _focus_tween: Tween
var _car_frame_locked := false
var _planning_rect := Rect2()
var _presentation_points: Array[Vector3] = []
var _planning_bottom_inset := 166.0

const CAR_BOUNDS := AABB(Vector3(-11.4, -0.25, -4.1), Vector3(22.8, 3.45, 8.2))


func _ready() -> void:
	camera = Camera3D.new()
	camera.name = "TacticalCamera"
	camera.fov = 39.0
	camera.near = 0.15
	camera.far = 160.0
	camera.current = true
	add_child(camera)
	_apply_zoom()
	position = Vector3(0.0, 0.0, 0.0)
	get_viewport().size_changed.connect(_on_viewport_resized)


func _process(delta: float) -> void:
	if not input_enabled:
		return
	var input_direction := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_A):
		input_direction.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D):
		input_direction.x += 1.0
	if Input.is_physical_key_pressed(KEY_W):
		input_direction.y -= 1.0
	if Input.is_physical_key_pressed(KEY_S):
		input_direction.y += 1.0
	if input_direction.length_squared() > 0.0:
		input_direction = input_direction.normalized()
		var right := global_transform.basis.x
		var forward := -global_transform.basis.z
		right.y = 0.0
		forward.y = 0.0
		position += (right.normalized() * input_direction.x + forward.normalized() * input_direction.y) * move_speed * delta
		var pan_limit_x := 2.4 if _car_frame_locked else 12.0
		var pan_limit_z := 1.4 if _car_frame_locked else 8.0
		position.x = clampf(position.x, -pan_limit_x, pan_limit_x)
		position.z = clampf(position.z, -pan_limit_z, pan_limit_z)

	if not _car_frame_locked and Input.is_physical_key_pressed(KEY_Q):
		rotate_y(0.9 * delta)
	if not _car_frame_locked and Input.is_physical_key_pressed(KEY_E):
		rotate_y(-0.9 * delta)


func _unhandled_input(event: InputEvent) -> void:
	if not input_enabled:
		return
	if not _car_frame_locked and event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE):
		rotate_y(-event.relative.x * 0.005)
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_distance = maxf(min_zoom, zoom_distance - 1.25)
			_apply_zoom()
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_distance = minf(max_zoom, zoom_distance + 1.25)
			_apply_zoom()


func _apply_zoom() -> void:
	if not is_instance_valid(camera):
		return
	camera.position = _base_direction * zoom_distance
	# Camera orientation is local to the rig. Looking at world zero made every
	# off-centre presentation cut look away from the requested actor.
	camera.rotation = Basis.looking_at(-_base_direction, Vector3.UP).get_euler()


func reset_view() -> void:
	if _planning_rect.has_area():
		frame_planning_area(_planning_rect)
		return
	if _car_frame_locked:
		frame_active_car()
		return
	position = Vector3.ZERO
	rotation = Vector3.ZERO
	zoom_distance = 19.5
	_apply_zoom()


func focus_world(world_position: Vector3) -> void:
	position = Vector3(world_position.x, 0.0, world_position.z)


func focus_world_smooth(world_position: Vector3) -> void:
	if is_instance_valid(_focus_tween):
		_focus_tween.kill()
	_focus_tween = create_tween()
	_focus_tween.set_trans(Tween.TRANS_QUINT)
	_focus_tween.set_ease(Tween.EASE_IN_OUT)
	_focus_tween.tween_property(self, "position", Vector3(world_position.x, 0.0, world_position.z), 0.46)


func set_presentation_view(focus: Vector3, distance: float) -> void:
	set_presentation_subjects([focus], distance)


func set_presentation_subjects(subjects: Array[Vector3], distance: float) -> void:
	_car_frame_locked = false
	_planning_rect = Rect2()
	_presentation_points.clear()
	for subject in subjects:
		_presentation_points.append_array(_box_points(AABB(subject + Vector3(-0.9, -0.1, -0.7), Vector3(1.8, 2.8, 1.4))))
	if not _presentation_points.is_empty():
		_fit_points(_presentation_points, combat_battlefield_rect(), distance)


func frame_active_car() -> void:
	# The combat camera treats the current encounter as one complete cutaway set.
	# A small pan allowance remains for inspection, but adjacent-car wandering and
	# rotations that reveal the missing camera-side wall are deliberately removed.
	_car_frame_locked = true
	_planning_rect = Rect2()
	_presentation_points.clear()
	position = Vector3.ZERO
	rotation = Vector3.ZERO
	_base_direction = Vector3(0.0, 0.68, 0.74).normalized()
	if is_instance_valid(camera):
		camera.fov = 36.0
	_fit_points(_car_points(), combat_battlefield_rect(), 18.0)


func frame_planning_area(available_rect: Rect2) -> void:
	# Fit the whole carriage into the *unobscured* screen region. Centering on a
	# boarding tile behind a dossier hid the opposing line and half the crew.
	frame_active_car()
	_planning_rect = available_rect
	_planning_bottom_inset = get_viewport().get_visible_rect().size.y - available_rect.end.y
	_base_direction = Vector3(0.0, 0.78, 0.63).normalized()
	_fit_points(_car_points(), available_rect, 18.0)


func combat_battlefield_rect() -> Rect2:
	var viewport_size := get_viewport().get_visible_rect().size
	return Rect2(12, 66, viewport_size.x - 24, viewport_size.y - 144)


func _fit_points(points: Array[Vector3], available_rect: Rect2, closest_distance: float) -> void:
	if not is_instance_valid(camera) or points.is_empty() or not available_rect.has_area():
		return
	var fit_rect := available_rect.grow(-18.0)
	var bounds := AABB(points[0], Vector3.ZERO)
	for point in points:
		bounds = bounds.expand(point)
	position = bounds.get_center()
	zoom_distance = maxf(closest_distance, min_zoom)
	for _attempt in range(16):
		_apply_zoom()
		var projected := _project_points(points)
		var scale_needed := maxf(projected.size.x / fit_rect.size.x, projected.size.y / fit_rect.size.y)
		if scale_needed > 1.0:
			zoom_distance *= scale_needed * 1.015
			_apply_zoom()
			projected = _project_points(points)
		var correction := camera.project_position(projected.get_center(), zoom_distance) - camera.project_position(fit_rect.get_center(), zoom_distance)
		position += correction
		if fit_rect.encloses(_project_points(points)):
			break


func _on_viewport_resized() -> void:
	if _planning_rect.has_area():
		var viewport_size := get_viewport().get_visible_rect().size
		frame_planning_area(Rect2(_planning_rect.position, Vector2(viewport_size.x - 24, viewport_size.y - _planning_rect.position.y - _planning_bottom_inset)))
	elif _car_frame_locked:
		frame_active_car()
	elif not _presentation_points.is_empty():
		_fit_points(_presentation_points, combat_battlefield_rect(), 12.2)


func _box_points(bounds: AABB) -> Array[Vector3]:
	var points: Array[Vector3] = []
	for corner in range(8):
		points.append(bounds.get_endpoint(corner))
	return points


func _car_points() -> Array[Vector3]:
	var points: Array[Vector3] = []
	# Fit the actual cutaway silhouette rather than an imaginary solid roof over
	# the near wall. Include each current actor's body and caption envelope.
	points.append_array(_box_points(AABB(Vector3(-11.1,-0.70,-4.0),Vector3(22.2,1.60,8.0))))
	points.append_array(_box_points(AABB(Vector3(-11.1,0.0,-4.0),Vector3(22.2,3.05,0.5))))
	var scene := get_tree().current_scene
	if is_instance_valid(scene):
		for child in scene.find_children("*", "CharacterBody3D", true, false):
			if child is TacticalUnit:
				points.append_array(_box_points(AABB(child.global_position + Vector3(-0.72,-0.12,-0.48),Vector3(1.44,2.75,0.96))))
	return points


func planning_projected_bounds() -> Rect2:
	return _project_points(_car_points())


func presentation_projected_bounds() -> Rect2:
	return _project_points(_presentation_points)


func _project_points(points: Array[Vector3]) -> Rect2:
	var result := Rect2()
	var first := true
	for world_point in points:
		var point := camera.unproject_position(world_point)
		if first:
			result = Rect2(point, Vector2.ZERO)
			first = false
		else:
			result = result.expand(point)
	return result
