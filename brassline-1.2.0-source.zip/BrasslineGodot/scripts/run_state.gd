class_name BrasslineRunState
extends RefCounted

const Types := preload("res://scripts/game_types.gd")

const TOTAL_CARS := 7
const FIRST_CAR_ID := "baggage"
const REQUIRED_CAR_IDS: Array[String] = ["dining", "bar", "crew", "armory", "engine"]
const OPTIONAL_CAR_IDS: Array[String] = ["observation", "sleeper", "cargo", "casino"]
const ENCOUNTER_VARIANTS := {
	"baggage": ["Loose Luggage", "Broken Manifest", "Smuggler Cache"],
	"dining": ["Overturned Banquet", "Kitchen Crossfire", "Officer's Supper"],
	"bar": ["Last Call", "Bottle Maze", "Duelist's Table"],
	"crew": ["Shift Change", "Locker Ambush", "Conductor's Watch"],
	"armory": ["Cage Line", "Ammunition Press", "Fortified Requisition"],
	"engine": ["Valve Corridor", "Piston Hall", "Boiler Crown"],
	"observation": ["Glass Gallery", "Moonlit Scope", "Rear Balcony"],
	"cargo": ["Freight Maze", "Loader Bay", "Contraband Stack"],
	"casino": ["House Floor", "Loaded Tables", "High Roller Suite"],
}

const CAR_CATALOG := {
	"baggage": {
		"name": "Boarding Car",
		"tagline": "One green railhand. Too many loose trunks.",
		"kicker": "GUARANTEED OPENING / SUPPLY CACHE",
		"description": "Loose trunks, emergency stores, and one inexperienced rail guard stand between the crew and the train proper.",
		"challenge": "One easy guard / scattered cover",
		"reward": "2 Medkits / 1 Limb Brace",
		"buff_preview": "2 MEDKITS + 1 LIMB BRACE / NO PERMANENT STAT BUFF",
		"difficulty": 1,
		"kind": "combat",
	},
	"dining": {
		"name": "Dining Car",
		"tagline": "The officers own the room. The chandelier disagrees.",
		"kicker": "SUSTENANCE / CLOSE TABLE COVER",
		"description": "A chandelier-lit carriage of overturned tables, silver service, and officers protecting the galley stores.",
		"challenge": "Close cover / officers and service staff",
		"reward": "Galley stores / squad recovery",
		"buff_preview": "+2 MAX HP PER ZONE + 1 HEAL / BAR-FIRST: +1 HP / CREW-FIRST: 1 MEDKIT",
		"difficulty": 2,
		"kind": "combat",
	},
	"bar": {
		"name": "Bar Car",
		"tagline": "Last call. The bottles and duelists both travel fast.",
		"kicker": "FOCUS / VOLATILE BOTTLES",
		"description": "A narrow brass saloon with breakable sightlines, gambling booths, and armed smugglers.",
		"challenge": "Flammable hazards / pistol duelists",
		"reward": "Focus tonic",
		"buff_preview": "+4% HIT + 1 FOCUS TONIC / DINING-FIRST: +2% HIT",
		"difficulty": 2,
		"kind": "combat",
	},
	"crew": {
		"name": "Crew Car",
		"tagline": "The relief shift knows every locker. Break their rhythm.",
		"kicker": "MOBILITY / SHIFT LOCKERS",
		"description": "Bunks, lockers, and maintenance passages offer supplies to a crew willing to fight through the conductor's watch.",
		"challenge": "Mixed ranges / reinforcements",
		"reward": "Medkit / crew tools",
		"buff_preview": "+1 MOVE + 1 MEDKIT + 1 LIMB BRACE / DINING-FIRST: +1 MOVE",
		"difficulty": 2,
		"kind": "combat",
	},
	"armory": {
		"name": "Armory Car",
		"tagline": "Everything is bolted down except the ammunition.",
		"kicker": "FIREPOWER / HARD COVER",
		"description": "Weapon cages and ammunition presses make this one of the train's most dangerous and most valuable compartments.",
		"challenge": "Armored guards / fortified firing lanes",
		"reward": "Clockwork grenade",
		"buff_preview": "+0.50 DAMAGE +1 RANGE +1 GRENADE / CREW-FIRST: +0.25 DAMAGE",
		"difficulty": 3,
		"kind": "combat",
	},
	"engine": {
		"name": "Engine Car",
		"tagline": "Voss owns the throttle. The redline owns everyone else.",
		"kicker": "MOMENTUM / STEAM HAZARDS",
		"description": "The locomotive heart is a furnace maze of pistons, pressure valves, and the engineer's elite guard.",
		"challenge": "Steam vents / elite engineer",
		"reward": "Control of the Green Rail",
		"buff_preview": "FINAL OBJECTIVE / SEIZE THE ENGINE CONTROLS",
		"difficulty": 3,
		"kind": "combat",
	},
	"observation": {
		"name": "Observation Car",
		"tagline": "Beautiful view. Excellent place to get shot.",
		"kicker": "OPTIONAL / LONG SIGHTLINES",
		"description": "A glass-roofed gallery exposes both the crew and a marksman team to long, clean lines of fire.",
		"challenge": "Snipers / little hard cover",
		"reward": "Optical calibrator",
		"buff_preview": "+5% CRITICAL / BAR-FIRST: +3% CRITICAL",
		"difficulty": 2,
		"kind": "combat",
	},
	"sleeper": {
		"name": "Sleeper Car",
		"tagline": "Quiet compartments hide medicine and complicated witnesses.",
		"kicker": "OPTIONAL / RECOVERY",
		"description": "Curtained compartments conceal passengers, medicine, and a quiet route if the crew moves carefully.",
		"challenge": "Short ambush / civilian complications",
		"reward": "Major squad healing / Medkit",
		"buff_preview": "CHOOSE +6 HEAL OR +2 HEAL + 2 MEDKITS + 1 TONIC / NO STAT BUFF",
		"difficulty": 1,
		"kind": "event",
	},
	"cargo": {
		"name": "Cargo Car",
		"tagline": "The crates move. The loader hits harder.",
		"kicker": "OPTIONAL / SALVAGE",
		"description": "Stacked freight creates a shifting maze around contraband machinery and salvageable weapon parts.",
		"challenge": "Crate maze / heavy loader",
		"reward": "Limb brace / possible grenade",
		"buff_preview": "+0.25 DAMAGE + 1 LIMB BRACE / ARMORY-FIRST: 1 GRENADE",
		"difficulty": 2,
		"kind": "combat",
	},
	"casino": {
		"name": "Casino Car",
		"tagline": "The house cheats. Today the tables roll too.",
		"kicker": "OPTIONAL / HIGH RISK",
		"description": "A private gaming floor trades predictable cover for volatile jackpots and hired guns.",
		"challenge": "Duelists / randomized hazards",
		"reward": "Lucky chamber calibration",
		"buff_preview": "+2% HIT + 3% CRITICAL",
		"difficulty": 3,
		"kind": "combat",
	},
}

var run_seed := 0
var ruleset_id := "train_takeover"
var difficulty_id := "standard"
var rng := RandomNumberGenerator.new()
var phase := "idle"
var selected_crew_ids: Array[String] = []
var current_car_id := ""
var pending_car_id := ""
var completed_car_ids: Array[String] = []
var current_offers: Array[String] = []
var available_car_ids: Array[String] = []
var inventory: Dictionary = {}
var crew_states: Dictionary = {}
var squad_bonuses: Dictionary = {}
var buff_history: Array[Dictionary] = []
var plan_history: Array[Dictionary] = []
var recent_plan_ids: Array[String] = []
var pending_event_choice := ""
var run_stats: Dictionary = {}
var last_recovery: Dictionary = {"total": 0, "crew": {}}
var crew_relationships: Dictionary = {}
var crew_consequence_history: Array[Dictionary] = []
var last_crew_consequences: Array[Dictionary] = []
var pending_crew_scene_id := ""
var crew_scene_history: Array[Dictionary] = []


func start_new_run(crew_ids: Array[String], seed: int = 0, selected_difficulty: String = "standard") -> void:
	ruleset_id = "train_takeover"
	run_seed = seed if seed != 0 else int(Time.get_unix_time_from_system())
	difficulty_id = selected_difficulty if selected_difficulty in ["story", "standard", "brutal"] else "standard"
	rng.seed = run_seed
	phase = "encounter"
	selected_crew_ids = crew_ids.duplicate()
	current_car_id = FIRST_CAR_ID
	pending_car_id = ""
	completed_car_ids.clear()
	current_offers.clear()
	available_car_ids = REQUIRED_CAR_IDS.duplicate()
	available_car_ids.append_array(OPTIONAL_CAR_IDS)
	inventory = {"medkit": 0, "limb_brace": 0, "clockwork_grenade": 0, "focus_tonic": 0}
	squad_bonuses = {
		"damage": 0.0,
		"range": 0,
		"movement": 0,
		"accuracy": 0.0,
		"critical": 0.0,
		"max_zone_hp": 0,
	}
	buff_history.clear()
	plan_history.clear()
	recent_plan_ids.clear()
	pending_event_choice = ""
	last_recovery = {"total": 0, "crew": {}}
	crew_relationships.clear()
	crew_consequence_history.clear()
	last_crew_consequences.clear()
	pending_crew_scene_id = ""
	crew_scene_history.clear()
	run_stats = {
		"shots": 0,
		"hits": 0,
		"kills": 0,
		"moves": 0,
		"reloads": 0,
		"overwatch_shots": 0,
		"abilities": 0,
		"grenades": 0,
		"rounds": 0,
		"boss_kills": 0,
		"finale_escapes": 0,
		"surrenders": 0,
		"control_claims": 0,
		"train_seized": 0,
		"ai_moves": 0,
		"ai_cover_moves": 0,
		"ai_cover_actions": 0,
		"ai_flanks": 0,
		"ai_shots": 0,
		"cars_cleared": 0,
		"items_used": 0,
		"plans_selected": 0,
		"fallbacks_triggered": 0,
	}
	crew_states.clear()
	for crew_id in selected_crew_ids:
		crew_states[crew_id] = _fresh_crew_state()
	_initialize_relationships()


func complete_current_car() -> Dictionary:
	if phase != "encounter" or current_car_id.is_empty():
		return {"ok": false, "reason": "No active car can be completed."}
	var completed_id := current_car_id
	completed_car_ids.append(completed_id)
	run_stats["cars_cleared"] = int(run_stats.get("cars_cleared", 0)) + 1
	# Every secured carriage includes a small automatic field-triage pass. It
	# reduces attrition without erasing wounds and makes this screen a real recovery
	# phase even when the player has no consumable supplies.
	last_recovery = _heal_everyone(1)
	var buff_event := _apply_car_reward_and_buff(completed_id)
	pending_event_choice = ""
	pending_crew_scene_id = _crew_scene_for_clear_count(completed_car_ids.size())
	pending_car_id = ""
	current_car_id = ""
	current_offers.clear()
	if completed_car_ids.size() >= TOTAL_CARS:
		phase = "complete"
		return {"ok": true, "run_complete": true, "car_id": completed_id, "buff": buff_event}
	phase = "intermission"
	current_offers = _generate_offers()
	return {"ok": true, "run_complete": false, "car_id": completed_id, "buff": buff_event, "offers": current_offers.duplicate()}


func choose_next_car(car_id: String) -> bool:
	if phase != "intermission" or has_pending_crew_scene() or car_id not in current_offers:
		return false
	if not is_candidate_eligible(car_id):
		return false
	current_car_id = car_id
	available_car_ids.erase(car_id)
	current_offers.clear()
	phase = "encounter"
	return true


func prepare_next_car(car_id: String) -> bool:
	if phase != "intermission" or has_pending_crew_scene() or car_id not in current_offers:
		return false
	if not is_candidate_eligible(car_id):
		return false
	pending_car_id = car_id
	phase = "preparation"
	return true


func cancel_preparation() -> bool:
	if phase != "preparation":
		return false
	pending_car_id = ""
	phase = "intermission"
	return true


func confirm_prepared_car() -> bool:
	if phase != "preparation" or pending_car_id.is_empty():
		return false
	if pending_car_id not in current_offers or not is_candidate_eligible(pending_car_id):
		return false
	current_car_id = pending_car_id
	available_car_ids.erase(current_car_id)
	current_offers.clear()
	pending_car_id = ""
	phase = "encounter"
	return true


func is_candidate_eligible(car_id: String) -> bool:
	if car_id not in available_car_ids:
		return false
	if ruleset_id == "train_takeover":
		if car_id == "engine":
			return completed_car_ids.size() == TOTAL_CARS - 1
		if completed_car_ids.size() == TOTAL_CARS - 1:
			return false
	# Car seven is always the Voss encounter. An optional recovery event may alter
	# the route earlier, but it cannot consume the finale slot and silently complete
	# the contract without the blueprint-case fight and extraction.
	if completed_car_ids.size() == TOTAL_CARS - 1 and String(CAR_CATALOG.get(car_id, {}).get("kind", "combat")) != "combat":
		return false
	var missing_after := missing_required_car_ids()
	missing_after.erase(car_id)
	var future_slots_after_pick := TOTAL_CARS - (completed_car_ids.size() + 1)
	return missing_after.size() <= future_slots_after_pick


func missing_required_car_ids() -> Array[String]:
	var missing := REQUIRED_CAR_IDS.duplicate()
	for car_id in completed_car_ids:
		missing.erase(car_id)
	if not current_car_id.is_empty():
		missing.erase(current_car_id)
	return missing


func car_data(car_id: String) -> Dictionary:
	return Dictionary(CAR_CATALOG.get(car_id, {}))


func car_number() -> int:
	return mini(TOTAL_CARS, completed_car_ids.size() + (1 if not current_car_id.is_empty() else 0))


func squad_bonus_summary() -> String:
	return format_bonus_summary(squad_bonuses)


static func format_bonus_summary(bonuses: Dictionary) -> String:
	var parts: Array[String] = []
	var damage := float(bonuses.get("damage", 0.0))
	var range_bonus := int(bonuses.get("range", 0))
	var movement := int(bonuses.get("movement", 0))
	var accuracy := roundi(float(bonuses.get("accuracy", 0.0)) * 100.0)
	var critical := roundi(float(bonuses.get("critical", 0.0)) * 100.0)
	var zone_hp := int(bonuses.get("max_zone_hp", 0))
	if not is_zero_approx(damage):
		parts.append("DMG +%.2f" % damage)
	if range_bonus != 0:
		parts.append("RANGE +%d" % range_bonus)
	if movement != 0:
		parts.append("MOVE +%d" % movement)
	if accuracy != 0:
		parts.append("HIT +%d%%" % accuracy)
	if critical != 0:
		parts.append("CRIT +%d%%" % critical)
	if zone_hp != 0:
		parts.append("ZONE HP +%d" % zone_hp)
	return "NONE YET" if parts.is_empty() else "  •  ".join(parts)


func train_sequence() -> Array[String]:
	var sequence := completed_car_ids.duplicate()
	if not current_car_id.is_empty():
		sequence.append(current_car_id)
	elif not pending_car_id.is_empty():
		sequence.append(pending_car_id)
	return sequence


func encounter_variant_index(car_id: String = "") -> int:
	var resolved_id := current_car_id if car_id.is_empty() else car_id
	var stable_value := run_seed + car_number() * 97
	for byte in resolved_id.to_utf8_buffer():
		stable_value += int(byte)
	return posmod(stable_value, 3)


func encounter_variant_name(car_id: String = "") -> String:
	var resolved_id := current_car_id if car_id.is_empty() else car_id
	var names: Array = ENCOUNTER_VARIANTS.get(resolved_id, ["Standard Approach", "Crossfire", "Hard Entry"])
	return String(names[encounter_variant_index(resolved_id) % names.size()])


func record_crew_body_state(crew_id: String, body_state: Dictionary) -> void:
	if not crew_states.has(crew_id):
		return
	crew_states[crew_id]["body"] = body_state.duplicate(true)


func record_crew_status(crew_id: String, body_state: Dictionary, is_alive: bool) -> void:
	if not crew_states.has(crew_id):
		return
	crew_states[crew_id]["body"] = body_state.duplicate(true)
	crew_states[crew_id]["down"] = not is_alive


func crew_is_down(crew_id: String) -> bool:
	return not crew_states.has(crew_id) or bool(crew_states[crew_id].get("down", false))


func body_state_for(crew_id: String) -> Dictionary:
	if not crew_states.has(crew_id):
		return {}
	return Dictionary(crew_states[crew_id]["body"]).duplicate(true)


func crew_health_ratio(crew_id: String) -> float:
	var body := body_state_for(crew_id)
	if body.is_empty():
		return 0.0
	var hp_total := 0.0
	var max_total := 0.0
	for zone in body:
		var state: Dictionary = body[zone]
		hp_total += float(state.get("hp", 0))
		max_total += float(state.get("max_hp", 1))
	return hp_total / maxf(1.0, max_total)


func crew_readiness(crew_id: String) -> Dictionary:
	# Total body HP is not survival health: intact legs cannot protect a critical torso.
	var result := {"status": "READY", "critical": false, "treatment_recommended": "", "summary": "FIT FOR BOARDING", "health_ratio": crew_health_ratio(crew_id)}
	var body := body_state_for(crew_id)
	if crew_is_down(crew_id) or body.is_empty():
		result.merge({"status": "LOST", "summary": "LOST / CANNOT BE TREATED", "health_ratio": 0.0}, true)
		return result
	for zone in [Types.BodyZone.TORSO, Types.BodyZone.HEAD]:
		var state := Dictionary(body.get(zone, {}))
		var hp := int(state.get("hp", 0))
		var maximum := maxi(1, int(state.get("max_hp", 1)))
		if hp <= 0 or bool(state.get("detached", false)):
			result.merge({"status": "LOST", "summary": "LOST / CANNOT BE TREATED", "health_ratio": 0.0}, true)
			return result
		if float(hp) / float(maximum) <= 0.4:
			result.merge({"status": "CRITICAL", "critical": true, "treatment_recommended": "medkit", "summary": "CRITICAL %s / %d-%d HP" % [Types.zone_name(zone).to_upper(), hp, maximum]}, true)
			return result
	for zone in [Types.BodyZone.ARMS, Types.BodyZone.LEGS]:
		var state := Dictionary(body.get(zone, {}))
		if int(state.get("hp", 0)) <= 0 or bool(state.get("disabled", false)) or bool(state.get("detached", false)):
			var detached := bool(state.get("detached", false))
			result.merge({"status": "CRIPPLED", "treatment_recommended": "" if detached else "limb_brace", "summary": "%s %s" % [Types.zone_name(zone).to_upper(), "LOST / PERMANENT" if detached else "CRIPPLED / BRACE ADVISED"]}, true)
			return result
	if float(result["health_ratio"]) < 1.0:
		result.merge({"status": "WOUNDED", "treatment_recommended": "medkit", "summary": "WOUNDED / MEDKIT ADVISED"}, true)
	return result


func use_item(item_id: String, crew_id: String) -> Dictionary:
	var preview := item_use_preview(item_id, crew_id)
	if not bool(preview.get("can_use", false)):
		return {"ok": false, "reason": String(preview.get("reason", "That supply cannot be used."))}
	var body: Dictionary = crew_states[crew_id]["body"]
	var healed_total := 0
	var changed_zones: Array[String] = []
	match item_id:
		"medkit":
			for zone in body:
				var state: Dictionary = body[zone]
				if bool(state.get("detached", false)) or int(state["hp"]) >= int(state["max_hp"]):
					continue
				var before := int(state["hp"])
				state["hp"] = mini(int(state["max_hp"]), before + 2)
				state["disabled"] = int(state["hp"]) <= 0
				body[zone] = state
				healed_total += int(state["hp"]) - before
				changed_zones.append(Types.zone_name(zone))
		"limb_brace":
			var weakest_zone := int(preview.get("zone", -1))
			if weakest_zone >= 0:
				var state: Dictionary = body[weakest_zone]
				var before := int(state["hp"])
				state["hp"] = mini(int(state["max_hp"]), int(state["hp"]) + 4)
				state["disabled"] = int(state["hp"]) <= 0
				body[weakest_zone] = state
				healed_total = int(state["hp"]) - before
				changed_zones.append(Types.zone_name(weakest_zone))
		_:
			return {"ok": false, "reason": "%s is used automatically during combat." % item_id.replace("_", " ")}
	if healed_total <= 0:
		return {"ok": false, "reason": "That item would not improve this crew member."}
	crew_states[crew_id]["body"] = body
	inventory[item_id] = int(inventory[item_id]) - 1
	return {
		"ok": true,
		"item_id": item_id,
		"crew_id": crew_id,
		"health_ratio": crew_health_ratio(crew_id),
		"healed": healed_total,
		"zones": changed_zones,
		"summary": "%s restored %d HP across %s." % [item_id.replace("_", " ").capitalize(), healed_total, ", ".join(changed_zones)],
	}


func item_use_preview(item_id: String, crew_id: String) -> Dictionary:
	if phase not in ["intermission", "preparation"]:
		return {"can_use": false, "reason": "Supplies are used between cars."}
	if int(inventory.get(item_id, 0)) <= 0:
		return {"can_use": false, "reason": "No supplies remaining."}
	if not crew_states.has(crew_id):
		return {"can_use": false, "reason": "Select an operative first."}
	if crew_is_down(crew_id):
		return {"can_use": false, "reason": "Downed operatives cannot be restored."}
	var body: Dictionary = crew_states[crew_id]["body"]
	match item_id:
		"medkit":
			var total_heal := 0
			var wounded_zones := 0
			for zone in body:
				var state: Dictionary = body[zone]
				if bool(state.get("detached", false)) or int(state["hp"]) >= int(state["max_hp"]):
					continue
				total_heal += mini(2, int(state["max_hp"]) - int(state["hp"]))
				wounded_zones += 1
			if total_heal <= 0:
				return {"can_use": false, "reason": "All intact body zones are already full."}
			return {
				"can_use": true,
				"healed": total_heal,
				"description": "+%d HP across %d wounded zone%s" % [total_heal, wounded_zones, "" if wounded_zones == 1 else "s"],
			}
		"limb_brace":
			var weakest_zone := -1
			var weakest_ratio := 2.0
			for zone in [Types.BodyZone.ARMS, Types.BodyZone.LEGS]:
				var state: Dictionary = body[zone]
				if bool(state.get("detached", false)) or int(state["hp"]) >= int(state["max_hp"]):
					continue
				var ratio := float(state["hp"]) / maxf(1.0, float(state["max_hp"]))
				if ratio < weakest_ratio:
					weakest_ratio = ratio
					weakest_zone = int(zone)
			if weakest_zone < 0:
				return {"can_use": false, "reason": "No damaged attached limb needs a brace."}
			var state: Dictionary = body[weakest_zone]
			var healed := mini(4, int(state["max_hp"]) - int(state["hp"]))
			return {
				"can_use": true,
				"zone": weakest_zone,
				"healed": healed,
				"description": "+%d HP to %s (%d/%d → %d/%d)" % [
					healed, Types.zone_name(weakest_zone), int(state["hp"]), int(state["max_hp"]),
					int(state["hp"]) + healed, int(state["max_hp"]),
				],
			}
	return {"can_use": false, "reason": "That supply is used during combat."}


func consume_inventory_item(item_id: String) -> bool:
	if int(inventory.get(item_id, 0)) <= 0:
		return false
	inventory[item_id] = int(inventory[item_id]) - 1
	return true


func record_item_use() -> void:
	run_stats["items_used"] = int(run_stats.get("items_used", 0)) + 1


func add_encounter_stats(stats: Dictionary) -> void:
	for key in ["shots", "hits", "kills", "moves", "reloads", "overwatch_shots", "abilities", "grenades", "rounds", "boss_kills", "finale_escapes", "surrenders", "control_claims", "train_seized", "ai_moves", "ai_cover_moves", "ai_cover_actions", "ai_flanks", "ai_shots"]:
		run_stats[key] = int(run_stats.get(key, 0)) + int(stats.get(key, 0))


func record_plan_result(plan: Dictionary, fallback: Dictionary, aftermath: Dictionary) -> void:
	var train_impacts := 0
	var train_counters := 0
	for raw_event in Array(aftermath.get("train_events", [])):
		var train_event := Dictionary(raw_event)
		if String(train_event.get("phase", "")) != "impact":
			continue
		train_impacts += 1
		if bool(Dictionary(train_event.get("result", {})).get("countered", false)):
			train_counters += 1
	var doctrine: Dictionary = aftermath.get("doctrine", {})
	var entry := {
		"car_id": current_car_id,
		"plan_id": String(plan.get("id", "unknown")),
		"plan_title": String(plan.get("title", "Unknown plan")),
		"fallback_id": String(fallback.get("id", "hold_plan")),
		"fallback_triggered": bool(aftermath.get("fallback_triggered", false)),
		"status": String(aftermath.get("plan_status", "on_plan")),
		"rounds": int(aftermath.get("rounds", 0)),
		"milestones": Array(aftermath.get("milestones", [])).duplicate(),
		"risk_unit_id": String(plan.get("risk_unit_id", "")),
		"train_impacts": train_impacts,
		"train_counters": train_counters,
		"doctrine_id": String(doctrine.get("id", "")),
		"doctrine_name": String(doctrine.get("name", "")),
		"doctrine_broken": bool(doctrine.get("broken", false)),
	}
	plan_history.append(entry)
	if plan_history.size() > TOTAL_CARS:
		plan_history.pop_front()
	recent_plan_ids.push_front(String(entry["plan_id"]))
	if recent_plan_ids.size() > 3:
		recent_plan_ids.resize(3)
	run_stats["plans_selected"] = int(run_stats.get("plans_selected", 0)) + 1
	if bool(entry["fallback_triggered"]):
		run_stats["fallbacks_triggered"] = int(run_stats.get("fallbacks_triggered", 0)) + 1


func campaign_chapter() -> Dictionary:
	var cleared := completed_car_ids.size()
	if phase == "complete" or cleared >= TOTAL_CARS:
		return {"id": "epilogue", "label": "EPILOGUE / WHAT THE CREW BECAME", "stakes": "The train is taken. What remains is the price written into the crew."}
	if cleared >= 6:
		return {"id": "finale", "label": "FINAL ACT / TAKE THE REDLINE", "stakes": "Voss has nowhere left to retreat. The Engine decides who owns the Green Rail."}
	if cleared >= 4:
		return {"id": "act_three", "label": "ACT III / THE GREEN RAIL HUNTS BACK", "stakes": "The guard line knows the crew now. Every doctrine and every wound follows them forward."}
	if cleared >= 2:
		return {"id": "act_two", "label": "ACT II / MAKE THE TRAIN YOURS", "stakes": "The heist is no longer an intrusion. Route order, carriage upgrades, and trust now shape the takeover."}
	return {"id": "act_one", "label": "ACT I / GET ABOARD", "stakes": "Read the moving train, test the crew, and establish a route before the Green Rail can organize."}


func has_pending_crew_scene() -> bool:
	return phase == "intermission" and not pending_crew_scene_id.is_empty()


func crew_scene_data() -> Dictionary:
	match pending_crew_scene_id:
		"first_cost":
			return {
				"chapter": "ACT BREAK / AFTER CAR TWO",
				"title": "THE FIRST COST",
				"prompt": "The Rail noticed. Decide what kind of crew answers back.",
				"body": "The Green Rail has stopped treating this as a robbery. In the coupling dark, the crew decides what kind of takeover they are actually attempting.",
				"choices": [
					{"id": "share_the_weight", "title": "SHARE THE WEIGHT", "effect": "+1 trust to every crew pairing / +1 healing", "risk": "No extra supplies or firepower.", "effect_short": "+1 trust / +1 healing", "risk_short": "No new firepower"},
					{"id": "harden_the_line", "title": "HARDEN THE LINE", "effect": "+1 Nerve to every survivor", "risk": "-1 trust to every crew pairing.", "effect_short": "+1 Nerve", "risk_short": "-1 crew trust"},
					{"id": "strip_the_car", "title": "STRIP THE CAR", "effect": "+1 Medkit / +1 Limb Brace", "risk": "Every survivor loses 1 Nerve.", "effect_short": "+1 Medkit / Brace", "risk_short": "-1 Nerve"},
				],
			}
		"train_answers":
			return {
				"chapter": "ACT BREAK / AFTER CAR FOUR",
				"title": "THE TRAIN ANSWERS",
				"prompt": "Orders race ahead through the tubes. Send one answer faster.",
				"body": "Guard orders are moving ahead through the speaking tubes. There is time for one answer before the next carriage learns the crew's names.",
				"choices": [
					{"id": "study_the_doctrines", "title": "STUDY THE DOCTRINES", "effect": "+3% squad accuracy", "risk": "No immediate healing or damage.", "effect_short": "+3% accuracy", "risk_short": "No immediate recovery"},
					{"id": "load_overpressure", "title": "LOAD OVERPRESSURE", "effect": "+0.25 squad damage", "risk": "Every survivor loses 1 Nerve.", "effect_short": "+0.25 damage", "risk_short": "-1 Nerve"},
					{"id": "repair_the_line", "title": "REPAIR THE LINE", "effect": "+3 healing / +1 trust to every pairing", "risk": "No permanent weapon upgrade.", "effect_short": "+3 healing / +1 trust", "risk_short": "No weapon upgrade"},
				],
			}
		"before_redline":
			return {
				"chapter": "FINAL ACT / OUTSIDE THE ENGINE",
				"title": "WHAT DO WE PROMISE?",
				"prompt": "Voss waits beyond the coupling. Decide what survives the Engine.",
				"body": "The redline gauge is visible through the final coupling. Voss is waiting. The last decision is not a route—it is the promise the crew carries into the cab.",
				"choices": [
					{"id": "bring_them_home", "title": "EVERYONE COMES HOME", "effect": "+2 maximum body health / +2 healing / +1 trust", "risk": "No offensive upgrade for Voss.", "effect_short": "+2 health / heal / trust", "risk_short": "No offense upgrade"},
					{"id": "break_voss_first", "title": "BREAK VOSS FIRST", "effect": "+5% squad critical chance", "risk": "No healing before the Engine.", "effect_short": "+5% critical", "risk_short": "No healing"},
					{"id": "take_the_engine_fast", "title": "TAKE IT FAST", "effect": "+0.50 squad damage", "risk": "Every survivor enters with 1 leg damage.", "effect_short": "+0.50 damage", "risk_short": "1 leg damage each"},
				],
			}
	return {}


func resolve_crew_scene_choice(choice_id: String) -> Dictionary:
	if not has_pending_crew_scene():
		return {"ok": false, "reason": "There is no unresolved crew council."}
	var scene_id := pending_crew_scene_id
	var valid_choice := false
	for raw_choice in Array(crew_scene_data().get("choices", [])):
		if String(Dictionary(raw_choice).get("id", "")) == choice_id:
			valid_choice = true
	if not valid_choice:
		return {"ok": false, "reason": "That crew answer is not available."}
	var summary := "The crew makes its choice."
	var details: Array[String] = []
	match choice_id:
		"share_the_weight":
			_change_all_relationships(1, "The crew shared the weight after the first cost.")
			_heal_everyone(1)
			summary = "The crew redistributes the dangerous work instead of pretending the first wounds did not matter."
			details = ["+1 trust to every crew pairing", "+1 healing to intact zones"]
		"harden_the_line":
			_change_all_nerve(1, "The crew hardened itself for the guard response.")
			_change_all_relationships(-1, "Orders replaced trust after the first cost.")
			summary = "They stop discussing fear and turn the formation into procedure."
			details = ["+1 Nerve to every survivor", "-1 trust to every crew pairing"]
		"strip_the_car":
			_add_item("medkit", 1)
			_add_item("limb_brace", 1)
			_change_all_nerve(-1, "The crew chose supplies over rest after the first cost.")
			summary = "They strip the secured carriage to the rivets and carry the unease forward."
			details = ["1 Medkit", "1 Limb Brace", "-1 Nerve to every survivor"]
		"study_the_doctrines":
			squad_bonuses["accuracy"] = float(squad_bonuses["accuracy"]) + 0.03
			summary = "The crew maps Green Rail roles, signals, and anatomical dependencies before moving."
			details = ["+3% squad accuracy"]
		"load_overpressure":
			squad_bonuses["damage"] = float(squad_bonuses["damage"]) + 0.25
			_change_all_nerve(-1, "The crew loaded overpressure rounds and accepted what they would do.")
			summary = "They answer the guard response with ammunition meant to end arguments quickly."
			details = ["+0.25 squad damage", "-1 Nerve to every survivor"]
		"repair_the_line":
			_heal_everyone(3)
			_change_all_relationships(1, "The crew repaired one another before the train could answer.")
			summary = "They spend the interval on wounds, straps, and the quiet work of keeping each other functional."
			details = ["+3 healing to intact zones", "+1 trust to every crew pairing"]
		"bring_them_home":
			squad_bonuses["max_zone_hp"] = int(squad_bonuses["max_zone_hp"]) + 2
			_increase_max_hp_everyone(2)
			_heal_everyone(2)
			_change_all_relationships(1, "The crew promised that every surviving operative would leave the Engine.")
			summary = "The promise changes how they fasten every brace and check every chamber."
			details = ["+2 maximum health per body zone", "+2 healing", "+1 trust to every pairing"]
		"break_voss_first":
			squad_bonuses["critical"] = float(squad_bonuses["critical"]) + 0.05
			summary = "Every opening is rewritten around one instant: Voss exposed beneath the red gauge."
			details = ["+5% squad critical chance"]
		"take_the_engine_fast":
			squad_bonuses["damage"] = float(squad_bonuses["damage"]) + 0.50
			_damage_survivors(Types.BodyZone.LEGS, 1)
			summary = "They cross the final coupling before the train settles and accept the impact standing."
			details = ["+0.50 squad damage", "1 leg damage to every survivor"]
	var memory := summary
	for crew_id in selected_crew_ids:
		if not crew_is_down(crew_id):
			_add_crew_memory(crew_id, memory)
	var event := {"scene_id": scene_id, "choice_id": choice_id, "summary": summary, "details": details.duplicate()}
	crew_scene_history.append(event)
	if crew_scene_history.size() > 3:
		crew_scene_history.pop_front()
	buff_history.append({"car_id": "crew_council", "order": completed_car_ids.size(), "title": "CREW COUNCIL / %s" % choice_id.replace("_", " ").to_upper(), "details": details.duplicate(), "synergy": summary})
	pending_crew_scene_id = ""
	return {"ok": true, "summary": summary, "details": details}


func _crew_scene_for_clear_count(cleared: int) -> String:
	return {2: "first_cost", 4: "train_answers", 6: "before_redline"}.get(cleared, "")


func _change_all_relationships(delta: int, reason: String) -> void:
	for key in crew_relationships:
		var relationship: Dictionary = Dictionary(crew_relationships[key]).duplicate(true)
		relationship["bond"] = clampi(int(relationship.get("bond", 0)) + delta, -3, 5)
		var history: Array = relationship.get("history", [])
		history.push_front(reason)
		if history.size() > 3:
			history.resize(3)
		relationship["history"] = history
		crew_relationships[key] = relationship


func _change_all_nerve(delta: int, reason: String) -> void:
	for crew_id in selected_crew_ids:
		if crew_is_down(crew_id) or not crew_states.has(crew_id):
			continue
		crew_states[crew_id]["nerve"] = clampi(int(crew_states[crew_id].get("nerve", 0)) + delta, -3, 3)
		_add_crew_memory(crew_id, reason)


func _damage_survivors(zone: Types.BodyZone, amount: int) -> void:
	for crew_id in selected_crew_ids:
		if crew_is_down(crew_id) or not crew_states.has(crew_id):
			continue
		var body: Dictionary = crew_states[crew_id]["body"]
		var state: Dictionary = body[zone]
		state["hp"] = maxi(1, int(state.get("hp", 1)) - amount)
		body[zone] = state
		crew_states[crew_id]["body"] = body


func campaign_outcome_metrics() -> Dictionary:
	var doctrine_breaks := 0
	var train_counters := 0
	var train_impacts := 0
	var clean_plans := 0
	for raw_entry in plan_history:
		var entry := Dictionary(raw_entry)
		if bool(entry.get("doctrine_broken", false)):
			doctrine_breaks += 1
		train_counters += int(entry.get("train_counters", 0))
		train_impacts += int(entry.get("train_impacts", 0))
		if String(entry.get("status", "on_plan")) == "on_plan" and not bool(entry.get("fallback_triggered", false)):
			clean_plans += 1
	var survivors: Array[String] = []
	var fallen: Array[String] = []
	for crew_id in selected_crew_ids:
		if crew_is_down(crew_id):
			fallen.append(crew_id)
		else:
			survivors.append(crew_id)
	var total_bond := 0
	for key in crew_relationships:
		total_bond += int(Dictionary(crew_relationships[key]).get("bond", 0))
	var average_bond := float(total_bond) / maxf(1.0, float(crew_relationships.size()))
	return {
		"doctrine_breaks": doctrine_breaks,
		"train_counters": train_counters,
		"train_impacts": train_impacts,
		"clean_plans": clean_plans,
		"survivors": survivors,
		"fallen": fallen,
		"average_bond": average_bond,
	}


func campaign_epilogue() -> Dictionary:
	var metrics := campaign_outcome_metrics()
	var survivors: Array = metrics.get("survivors", [])
	var fallen: Array = metrics.get("fallen", [])
	var doctrine_breaks := int(metrics.get("doctrine_breaks", 0))
	var train_counters := int(metrics.get("train_counters", 0))
	var clean_plans := int(metrics.get("clean_plans", 0))
	var average_bond := float(metrics.get("average_bond", 0.0))
	var title := "THE GREEN RAIL CHANGES HANDS"
	var thesis := "The crew wins carriage by carriage, learning the machine faster than its guards can defend it."
	var short_thesis := "The crew learns the machine, breaks its defenders, and takes the throttle."
	if survivors.size() == 1:
		title = "THE LAST HAND ON THE THROTTLE"
		thesis = "One operative reaches the controls carrying every empty place in the formation. The train is theirs, but never quietly."
		short_thesis = "One operative takes the throttle carrying every empty place in the formation."
	elif survivors.size() == 2:
		title = "THE SEAT LEFT EMPTY"
		thesis = "The surviving pair take the locomotive with a name missing from every future manifest. Victory and debt leave together."
		short_thesis = "Two take the locomotive. One name stays missing from every future manifest."
	elif survivors.size() == 3 and _crew_scene_choice_was("bring_them_home") and average_bond >= 1.0:
		title = "EVERY SEAT FILLED"
		thesis = "They made the promise outside the Engine and kept it under redline pressure. Every operative steps down from the captured cab."
		short_thesis = "They promised everyone would return. Every operative steps down from the captured cab."
	elif survivors.size() == 3 and doctrine_breaks >= 5 and train_counters >= 3:
		title = "THE QUIET LINE"
		thesis = "The crew learns the train, breaks its practiced defenders, and reaches the cab as professionals rather than survivors."
		short_thesis = "They break every practiced defense and reach the cab as professionals."
	elif survivors.size() == 3 and average_bond >= 2.0:
		title = "A CREW, NOT A CONTRACT"
		thesis = "The heist begins as work and ends as loyalty. The locomotive is valuable; the people trusted with it are worth more."
		short_thesis = "The heist begins as work and ends as loyalty."
	elif doctrine_breaks <= 2 and int(run_stats.get("kills", 0)) >= 12:
		title = "THE IRON TAKEOVER"
		thesis = "The Green Rail yields to force before its doctrine can bend. Every carriage remembers how the new owners arrived."
		short_thesis = "The Rail yields to force. Every carriage remembers its new owners."
	var route_names: Array[String] = []
	for car_id in completed_car_ids:
		route_names.append(String(car_data(car_id).get("name", car_id)).replace(" Car", ""))
	var score := survivors.size() * 20 + doctrine_breaks * 4 + train_counters * 3 + clean_plans * 3 + roundi(average_bond * 2.0)
	var grade := "S" if score >= 100 else ("A" if score >= 82 else ("B" if score >= 62 else "C"))
	var crew_lines: Array[Dictionary] = []
	for crew_id in selected_crew_ids:
		var state: Dictionary = crew_states.get(crew_id, {})
		var memories: Array = state.get("memories", [])
		var nerve := int(state.get("nerve", 0))
		var line := "Leaves the cab changed by the run."
		if crew_id in fallen:
			line = "Does not step down from the cab; the crew carries the last promise forward."
		elif not memories.is_empty():
			line = "%s Nerve ends %s." % [String(memories[0]), _nerve_label(nerve).to_lower()]
		elif nerve >= 2:
			line = "Takes the controls with steady hands and a hardened nerve."
		elif nerve < 0:
			line = "Survives the train, though its rhythm will follow for a long time."
		crew_lines.append({"crew_id": crew_id, "down": crew_id in fallen, "nerve": nerve, "line": line})
	return {
		"title": title,
		"thesis": thesis,
		"short_thesis": short_thesis,
		"grade": grade,
		"score": score,
		"route": " → ".join(route_names),
		"metrics": metrics,
		"crew_lines": crew_lines,
	}


func _crew_scene_choice_was(choice_id: String) -> bool:
	for raw_event in crew_scene_history:
		if String(Dictionary(raw_event).get("choice_id", "")) == choice_id:
			return true
	return false


func resolve_crew_consequences(plan: Dictionary, fallback: Dictionary, aftermath: Dictionary) -> Array[Dictionary]:
	last_crew_consequences.clear()
	var assignments: Dictionary = plan.get("assignments", {})
	var risk_id := String(plan.get("risk_unit_id", ""))
	if risk_id.is_empty() or risk_id not in selected_crew_ids:
		risk_id = String(assignments.get("anchor", selected_crew_ids[0] if not selected_crew_ids.is_empty() else ""))
	var partner_id := ""
	for role in ["anchor", "shooter", "scout"]:
		var candidate := String(assignments.get(role, ""))
		if not candidate.is_empty() and candidate != risk_id:
			partner_id = candidate
			break
	var injured_ids: Array[String] = []
	var down_ids: Array[String] = []
	for raw_injury in Array(aftermath.get("injuries", [])):
		var injury := Dictionary(raw_injury)
		var crew_id := String(injury.get("roster_id", ""))
		if not crew_id.is_empty():
			injured_ids.append(crew_id)
			if bool(injury.get("down", false)):
				down_ids.append(crew_id)
	var victory := bool(aftermath.get("victory", false))
	var fallback_triggered := bool(aftermath.get("fallback_triggered", false))
	var fallback_id := String(fallback.get("id", "hold_plan"))
	if not risk_id.is_empty() and not partner_id.is_empty():
		var delta := 1 if victory else -1
		var reason := "%s and %s came through %s together." % [risk_id.capitalize(), partner_id.capitalize(), String(plan.get("title", "the plan"))]
		if risk_id in down_ids:
			delta = -2
			reason = "%s was lost carrying the risk; %s remembers the call." % [risk_id.capitalize(), partner_id.capitalize()]
		elif fallback_triggered and fallback_id in ["protect_wounded", "save_crew"]:
			delta += 1
			reason = "%s broke formation to bring %s through alive." % [partner_id.capitalize(), risk_id.capitalize()]
		elif fallback_triggered and fallback_id == "hold_plan":
			delta = -1
			reason = "%s held the plan while %s carried the damage." % [partner_id.capitalize(), risk_id.capitalize()]
		var key := _pair_key(risk_id, partner_id)
		var relationship: Dictionary = Dictionary(crew_relationships.get(key, {"bond": 0, "shared_jobs": 0, "history": []})).duplicate(true)
		relationship["bond"] = clampi(int(relationship.get("bond", 0)) + delta, -3, 5)
		relationship["shared_jobs"] = int(relationship.get("shared_jobs", 0)) + 1
		var history: Array = relationship.get("history", [])
		history.push_front(reason)
		if history.size() > 3:
			history.resize(3)
		relationship["history"] = history
		crew_relationships[key] = relationship
		last_crew_consequences.append({
			"type": "relationship",
			"crew_ids": [risk_id, partner_id],
			"delta": delta,
			"bond": int(relationship["bond"]),
			"label": "TRUST %+d / %s" % [delta, _relationship_label(int(relationship["bond"]))],
			"text": reason,
		})
		_add_crew_memory(risk_id, reason)
		_add_crew_memory(partner_id, reason)
	for crew_id in selected_crew_ids:
		if not crew_states.has(crew_id):
			continue
		var nerve_delta := 0
		if crew_id in down_ids:
			nerve_delta = -2
		elif crew_id in injured_ids:
			nerve_delta = -1
		elif victory:
			nerve_delta = 1
		if nerve_delta == 0:
			continue
		crew_states[crew_id]["nerve"] = clampi(int(crew_states[crew_id].get("nerve", 0)) + nerve_delta, -3, 3)
		last_crew_consequences.append({
			"type": "nerve",
			"crew_ids": [crew_id],
			"delta": nerve_delta,
			"nerve": int(crew_states[crew_id]["nerve"]),
			"label": "NERVE %+d / %s" % [nerve_delta, _nerve_label(int(crew_states[crew_id]["nerve"]))],
			"text": "%s %s." % [crew_id.capitalize(), "hardens under a clean result" if nerve_delta > 0 else "carries this carriage forward"],
		})
	crew_consequence_history.append({
		"car_id": current_car_id,
		"plan_id": String(plan.get("id", "unknown")),
		"events": last_crew_consequences.duplicate(true),
	})
	if crew_consequence_history.size() > TOTAL_CARS:
		crew_consequence_history.pop_front()
	return last_crew_consequences.duplicate(true)


func crew_campaign_context() -> Dictionary:
	var operatives := {}
	for crew_id in selected_crew_ids:
		var state: Dictionary = crew_states.get(crew_id, {})
		operatives[crew_id] = {
			"nerve": int(state.get("nerve", 0)),
			"nerve_label": _nerve_label(int(state.get("nerve", 0))),
			"memories": Array(state.get("memories", [])).duplicate(),
			"bond_accuracy": crew_bond_accuracy_bonus(crew_id),
		}
	var relationships: Array[Dictionary] = []
	for key in crew_relationships:
		var data: Dictionary = crew_relationships[key]
		relationships.append({
			"key": key,
			"crew_ids": String(key).split("|"),
			"bond": int(data.get("bond", 0)),
			"label": _relationship_label(int(data.get("bond", 0))),
			"shared_jobs": int(data.get("shared_jobs", 0)),
			"history": Array(data.get("history", [])).duplicate(),
		})
	return {"operatives": operatives, "relationships": relationships, "last_events": last_crew_consequences.duplicate(true)}


func crew_bond_accuracy_bonus(crew_id: String) -> float:
	var total := 0
	var count := 0
	for other_id in selected_crew_ids:
		if other_id == crew_id or crew_is_down(other_id):
			continue
		var relationship: Dictionary = crew_relationships.get(_pair_key(crew_id, other_id), {})
		total += int(relationship.get("bond", 0))
		count += 1
	return clampf(float(total) / maxf(1.0, float(count)) * 0.01, -0.03, 0.05)


func crew_nerve_modifiers(crew_id: String) -> Dictionary:
	var nerve := int(Dictionary(crew_states.get(crew_id, {})).get("nerve", 0))
	return {
		"nerve": nerve,
		"accuracy": float(mini(0, nerve)) * 0.01,
		"critical": float(maxi(0, nerve)) * 0.01,
	}


func _initialize_relationships() -> void:
	for first_index in range(selected_crew_ids.size()):
		for second_index in range(first_index + 1, selected_crew_ids.size()):
			var key := _pair_key(selected_crew_ids[first_index], selected_crew_ids[second_index])
			if not crew_relationships.has(key):
				crew_relationships[key] = {"bond": 0, "shared_jobs": 0, "history": []}


func _pair_key(first: String, second: String) -> String:
	var pair: Array[String] = [first, second]
	pair.sort()
	return "%s|%s" % [pair[0], pair[1]]


func _add_crew_memory(crew_id: String, memory: String) -> void:
	if not crew_states.has(crew_id):
		return
	var memories: Array = crew_states[crew_id].get("memories", [])
	memories.push_front(memory)
	if memories.size() > 3:
		memories.resize(3)
	crew_states[crew_id]["memories"] = memories


func _relationship_label(bond: int) -> String:
	if bond >= 4: return "BLOOD-BOUND"
	if bond >= 2: return "TRUSTED"
	if bond <= -2: return "STRAINED"
	if bond < 0: return "UNEASY"
	return "WORKING"


func _nerve_label(nerve: int) -> String:
	if nerve >= 3: return "UNSHAKEABLE"
	if nerve >= 1: return "STEADY"
	if nerve <= -2: return "RATTLED"
	if nerve < 0: return "SHAKEN"
	return "TESTED"


func resolve_event_choice(choice_id: String) -> Dictionary:
	if phase != "encounter" or current_car_id != "sleeper":
		return {"ok": false, "reason": "No Sleeper Car choice is active."}
	if choice_id not in ["rest", "scavenge"]:
		return {"ok": false, "reason": "Unknown event choice."}
	pending_event_choice = choice_id
	return {
		"ok": true,
		"choice_id": choice_id,
		"summary": "Deep rest restores the crew." if choice_id == "rest" else "The medicine cabinets yield portable supplies.",
	}


func difficulty_label() -> String:
	match difficulty_id:
		"story":
			return "STORY"
		"brutal":
			return "BRUTAL"
	return "STANDARD"


func to_save_data() -> Dictionary:
	var serialized_crew := {}
	for crew_id in crew_states:
		var source_state: Dictionary = crew_states[crew_id]
		var body_out := {}
		var source_body: Dictionary = source_state["body"]
		for zone in source_body:
			body_out[str(int(zone))] = Dictionary(source_body[zone]).duplicate(true)
		serialized_crew[crew_id] = {
			"body": body_out,
			"down": bool(source_state.get("down", false)),
			"nerve": int(source_state.get("nerve", 0)),
			"memories": Array(source_state.get("memories", [])).duplicate(),
		}
	return {
		"version": 7,
		"ruleset_id": ruleset_id,
		"run_seed": run_seed,
		"difficulty_id": difficulty_id,
		"rng_state": str(rng.state),
		"phase": phase,
		"selected_crew_ids": selected_crew_ids.duplicate(),
		"current_car_id": current_car_id,
		"pending_car_id": pending_car_id,
		"completed_car_ids": completed_car_ids.duplicate(),
		"current_offers": current_offers.duplicate(),
		"available_car_ids": available_car_ids.duplicate(),
		"inventory": inventory.duplicate(true),
		"crew_states": serialized_crew,
		"squad_bonuses": squad_bonuses.duplicate(true),
		"buff_history": buff_history.duplicate(true),
		"plan_history": plan_history.duplicate(true),
		"recent_plan_ids": recent_plan_ids.duplicate(),
		"pending_event_choice": pending_event_choice,
		"last_recovery": last_recovery.duplicate(true),
		"crew_relationships": crew_relationships.duplicate(true),
		"crew_consequence_history": crew_consequence_history.duplicate(true),
		"last_crew_consequences": last_crew_consequences.duplicate(true),
		"pending_crew_scene_id": pending_crew_scene_id,
		"crew_scene_history": crew_scene_history.duplicate(true),
		"run_stats": run_stats.duplicate(true),
	}


func load_from_save_data(data: Dictionary) -> bool:
	var save_version := int(data.get("version", 0))
	if save_version not in [1, 2, 3, 4, 5, 6, 7]:
		return false
	var saved_crew: Array = data.get("selected_crew_ids", [])
	var saved_completed: Array = data.get("completed_car_ids", [])
	if saved_crew.size() != 3 or saved_completed.size() > TOTAL_CARS:
		return false
	run_seed = int(data.get("run_seed", 0))
	# Ruleset IDs were introduced in v5. A modern field copied into an older
	# payload must not silently convert that checkpoint's contract semantics.
	ruleset_id = "legacy_blueprint" if save_version <= 4 else String(data.get("ruleset_id", "train_takeover"))
	if ruleset_id not in ["legacy_blueprint", "train_takeover"]:
		ruleset_id = "legacy_blueprint"
	if run_seed == 0:
		return false
	rng.seed = run_seed
	difficulty_id = String(data.get("difficulty_id", "standard"))
	if difficulty_id not in ["story", "standard", "brutal"]:
		difficulty_id = "standard"
	rng.state = int(str(data.get("rng_state", rng.state)))
	phase = String(data.get("phase", "idle"))
	if phase not in ["encounter", "intermission", "preparation", "complete"]:
		return false
	selected_crew_ids.clear()
	selected_crew_ids.assign(saved_crew)
	current_car_id = String(data.get("current_car_id", ""))
	pending_car_id = String(data.get("pending_car_id", ""))
	completed_car_ids.clear()
	completed_car_ids.assign(saved_completed)
	current_offers.clear()
	current_offers.assign(Array(data.get("current_offers", [])))
	available_car_ids.clear()
	available_car_ids.assign(Array(data.get("available_car_ids", [])))
	var saved_inventory: Dictionary = data.get("inventory", {})
	inventory = {
		"medkit": int(saved_inventory.get("medkit", 0)),
		"limb_brace": int(saved_inventory.get("limb_brace", 0)),
		"clockwork_grenade": int(saved_inventory.get("clockwork_grenade", 0)),
		"focus_tonic": int(saved_inventory.get("focus_tonic", 0)),
	}
	var saved_bonuses: Dictionary = data.get("squad_bonuses", {})
	squad_bonuses = {
		"damage": float(saved_bonuses.get("damage", 0.0)),
		"range": int(saved_bonuses.get("range", 0)),
		"movement": int(saved_bonuses.get("movement", 0)),
		"accuracy": float(saved_bonuses.get("accuracy", 0.0)),
		"critical": float(saved_bonuses.get("critical", 0.0)),
		"max_zone_hp": int(saved_bonuses.get("max_zone_hp", 0)),
	}
	buff_history.clear()
	buff_history.assign(Array(data.get("buff_history", [])))
	plan_history.clear()
	plan_history.assign(Array(data.get("plan_history", [])))
	recent_plan_ids.clear()
	recent_plan_ids.assign(Array(data.get("recent_plan_ids", [])))
	pending_event_choice = String(data.get("pending_event_choice", ""))
	last_recovery = Dictionary(data.get("last_recovery", {"total": 0, "crew": {}})).duplicate(true)
	crew_relationships = Dictionary(data.get("crew_relationships", {})).duplicate(true)
	crew_consequence_history.clear()
	crew_consequence_history.assign(Array(data.get("crew_consequence_history", [])))
	last_crew_consequences.clear()
	last_crew_consequences.assign(Array(data.get("last_crew_consequences", [])))
	pending_crew_scene_id = String(data.get("pending_crew_scene_id", "")) if save_version >= 7 else ""
	crew_scene_history.clear()
	crew_scene_history.assign(Array(data.get("crew_scene_history", [])))
	var saved_stats: Dictionary = data.get("run_stats", {})
	run_stats = {}
	for key in ["shots", "hits", "kills", "moves", "reloads", "overwatch_shots", "abilities", "grenades", "rounds", "boss_kills", "finale_escapes", "surrenders", "control_claims", "train_seized", "ai_moves", "ai_cover_moves", "ai_cover_actions", "ai_flanks", "ai_shots", "cars_cleared", "items_used", "plans_selected", "fallbacks_triggered"]:
		run_stats[key] = int(saved_stats.get(key, completed_car_ids.size() if key == "cars_cleared" else 0))
	crew_states.clear()
	var serialized_crew: Dictionary = data.get("crew_states", {})
	for crew_id in selected_crew_ids:
		if not serialized_crew.has(crew_id):
			return false
		var saved_state: Dictionary = serialized_crew[crew_id]
		var body_in: Dictionary = saved_state.get("body", {})
		var body_out := {}
		if save_version <= 2 and body_in.size() >= 6:
			body_out = _migrate_six_zone_body(body_in)
		else:
			for zone_key in body_in:
				var zone := int(String(zone_key))
				if not Types.BODY_ZONE_NAMES.has(zone):
					continue
				body_out[zone] = Dictionary(body_in[zone_key]).duplicate(true)
		if body_out.size() != Types.BODY_ZONE_NAMES.size():
			return false
		crew_states[crew_id] = {
			"body": body_out,
			"down": bool(saved_state.get("down", false)),
			"nerve": int(saved_state.get("nerve", 0)),
			"memories": Array(saved_state.get("memories", [])).duplicate(),
		}
	_initialize_relationships()
	if phase == "encounter" and (current_car_id.is_empty() or not CAR_CATALOG.has(current_car_id)):
		return false
	if phase == "intermission" and current_offers.is_empty():
		return false
	if phase == "preparation" and (
		pending_car_id.is_empty()
		or pending_car_id not in current_offers
		or not CAR_CATALOG.has(pending_car_id)
		or not current_car_id.is_empty()
	):
		return false
	return true


func _migrate_six_zone_body(legacy: Dictionary) -> Dictionary:
	var head := _legacy_zone_state(legacy, 0)
	var torso := _legacy_zone_state(legacy, 1)
	var left_arm := _legacy_zone_state(legacy, 2)
	var right_arm := _legacy_zone_state(legacy, 3)
	var left_leg := _legacy_zone_state(legacy, 4)
	var right_leg := _legacy_zone_state(legacy, 5)
	if head.is_empty() or torso.is_empty() or left_arm.is_empty() or right_arm.is_empty() or left_leg.is_empty() or right_leg.is_empty():
		return {}
	var bonus_hp := maxi(0, int(head.get("max_hp", 4)) - 4)
	return {
		Types.BodyZone.HEAD: head.duplicate(true),
		Types.BodyZone.TORSO: torso.duplicate(true),
		Types.BodyZone.ARMS: _merge_legacy_pair(left_arm, right_arm, int(Types.BODY_ZONE_MAX_HP[Types.BodyZone.ARMS]) + bonus_hp),
		Types.BodyZone.LEGS: _merge_legacy_pair(left_leg, right_leg, int(Types.BODY_ZONE_MAX_HP[Types.BodyZone.LEGS]) + bonus_hp),
	}


func _legacy_zone_state(legacy: Dictionary, zone_index: int) -> Dictionary:
	if legacy.has(str(zone_index)):
		return Dictionary(legacy[str(zone_index)])
	if legacy.has(zone_index):
		return Dictionary(legacy[zone_index])
	return {}


func _merge_legacy_pair(first: Dictionary, second: Dictionary, new_max_hp: int) -> Dictionary:
	var first_ratio := float(first.get("hp", 0)) / maxf(1.0, float(first.get("max_hp", 1)))
	var second_ratio := float(second.get("hp", 0)) / maxf(1.0, float(second.get("max_hp", 1)))
	var first_disabled := bool(first.get("disabled", false)) or int(first.get("hp", 0)) <= 0
	var second_disabled := bool(second.get("disabled", false)) or int(second.get("hp", 0)) <= 0
	var disabled := first_disabled and second_disabled
	var detached := bool(first.get("detached", false)) and bool(second.get("detached", false))
	var merged_hp := clampi(roundi((first_ratio + second_ratio) * 0.5 * float(new_max_hp)), 0, new_max_hp)
	# A single lost legacy limb becomes a grave paired-zone wound, but does not
	# erase the other limb during migration. Both lost limbs remain fully crippled.
	if disabled:
		merged_hp = 0
	elif first_disabled or second_disabled:
		merged_hp = mini(merged_hp, maxi(1, floori(float(new_max_hp) * 0.33)))
	return {
		"hp": merged_hp,
		"max_hp": new_max_hp,
		"disabled": disabled,
		"detached": detached,
	}


func save_summary() -> String:
	var position := completed_car_ids.size() + (1 if phase in ["encounter", "preparation"] else 0)
	return "CAR %d / 7  ·  RUN %d" % [maxi(1, position), run_seed]


func _generate_offers() -> Array[String]:
	var candidates: Array[String] = []
	for car_id in available_car_ids:
		if is_candidate_eligible(car_id):
			candidates.append(car_id)
	_shuffle_with_run_rng(candidates)
	var result: Array[String] = []
	for index in range(mini(3, candidates.size())):
		result.append(candidates[index])
	return result


func _shuffle_with_run_rng(values: Array[String]) -> void:
	for index in range(values.size() - 1, 0, -1):
		var swap_index := rng.randi_range(0, index)
		var held := values[index]
		values[index] = values[swap_index]
		values[swap_index] = held


func _apply_car_reward_and_buff(car_id: String) -> Dictionary:
	var order := completed_car_ids.size()
	var title := "SUPPLIES SECURED"
	var details: Array[String] = []
	var synergy := ""
	match car_id:
		"baggage":
			_add_item("medkit", 2)
			_add_item("limb_brace", 1)
			details = ["2 Medkits", "1 Limb Brace"]
		"dining":
			var hp_gain := 2
			if _completed_before("bar"):
				hp_gain += 1
				synergy = "Last Call Feast: Bar-first routing adds +1 zone health."
			elif _completed_before("crew"):
				_add_item("medkit", 1)
				synergy = "Galley Keys: Crew-first routing uncovers a Medkit."
			squad_bonuses["max_zone_hp"] = int(squad_bonuses["max_zone_hp"]) + hp_gain
			_increase_max_hp_everyone(hp_gain)
			_heal_everyone(1)
			title = "GALLEY PROVISIONS"
			details = ["+%d maximum health per body zone" % hp_gain, "+1 healing to intact zones"]
		"bar":
			var accuracy_gain := 0.04
			if _completed_before("dining"):
				accuracy_gain += 0.02
				synergy = "Steady Hands: Dining-first routing adds +2% accuracy."
			squad_bonuses["accuracy"] = float(squad_bonuses["accuracy"]) + accuracy_gain
			_add_item("focus_tonic", 1)
			title = "SMUGGLER'S COURAGE"
			details = ["+%d%% squad accuracy" % roundi(accuracy_gain * 100.0), "1 Focus Tonic"]
		"crew":
			var movement_gain := 1
			if _completed_before("dining"):
				movement_gain += 1
				synergy = "Fed and Ready: Dining-first routing adds +1 movement."
			squad_bonuses["movement"] = int(squad_bonuses["movement"]) + movement_gain
			_add_item("medkit", 1)
			if ruleset_id == "train_takeover":
				_add_item("limb_brace", 1)
			title = "SHIFT CHANGE"
			details = ["+%d squad movement" % movement_gain, "1 Medkit"]
			if ruleset_id == "train_takeover":
				details.append("1 Limb Brace")
		"armory":
			var damage_gain := 0.50
			if ruleset_id == "legacy_blueprint" and _completed_before("engine"):
				damage_gain += 0.25
				synergy = "Boiler-Loaded Rounds: Engine-first routing adds +0.25 damage."
			elif ruleset_id == "train_takeover" and _completed_before("crew"):
				damage_gain += 0.25
				synergy = "Shift-Fitted Rounds: Crew-first routing adds +0.25 damage."
			squad_bonuses["damage"] = float(squad_bonuses["damage"]) + damage_gain
			if ruleset_id == "train_takeover":
				squad_bonuses["range"] = int(squad_bonuses["range"]) + 1
			_add_item("clockwork_grenade", 1)
			title = "ARMORY REQUISITION"
			details = ["+%.2f squad weapon damage" % damage_gain, "1 Clockwork Grenade"]
			if ruleset_id == "train_takeover":
				details.insert(1, "+1 weapon range")
		"engine":
			if ruleset_id == "legacy_blueprint":
				var range_gain := 1
				if _completed_before("armory"):
					range_gain += 1
					synergy = "Pressure-Sighted Barrels: Armory-first routing adds +1 range."
				squad_bonuses["range"] = int(squad_bonuses["range"]) + range_gain
				_add_item("limb_brace", 1)
				title = "FULL STEAM"
				details = ["+%d squad weapon range" % range_gain, "1 Limb Brace"]
			else:
				title = "THE TRAIN IS YOURS"
				details = ["Engine secured", "Green Rail command broken"]
		"observation":
			var critical_gain := 0.05
			if _completed_before("bar"):
				critical_gain += 0.03
				synergy = "Liquid Courage Optics: Bar-first routing adds +3% critical chance."
			squad_bonuses["critical"] = float(squad_bonuses["critical"]) + critical_gain
			title = "CALIBRATED OPTICS"
			details = ["+%d%% squad critical chance" % roundi(critical_gain * 100.0)]
		"sleeper":
			if pending_event_choice == "scavenge":
				_heal_everyone(2)
				_add_item("medkit", 2)
				_add_item("focus_tonic", 1)
				title = "CABINETS RAIDED"
				details = ["+2 healing to every intact zone", "2 Medkits", "1 Focus Tonic"]
			else:
				_heal_everyone(6)
				title = "A FULL NIGHT'S REST"
				details = ["+6 healing to every intact zone"]
		"cargo":
			var cargo_damage := 0.25
			squad_bonuses["damage"] = float(squad_bonuses["damage"]) + cargo_damage
			_add_item("limb_brace", 1)
			if _completed_before("armory"):
				_add_item("clockwork_grenade", 1)
				synergy = "Matched Crates: Armory-first routing finds a Clockwork Grenade."
			title = "SALVAGED MACHINERY"
			details = ["+0.25 squad weapon damage", "1 Limb Brace"]
		"casino":
			squad_bonuses["accuracy"] = float(squad_bonuses["accuracy"]) + 0.02
			squad_bonuses["critical"] = float(squad_bonuses["critical"]) + 0.03
			title = "LOADED CHAMBERS"
			details = ["+2% squad accuracy", "+3% squad critical chance"]
	var event := {
		"car_id": car_id,
		"order": order,
		"title": title,
		"details": details,
		"synergy": synergy,
	}
	buff_history.append(event)
	return event


func _completed_before(car_id: String) -> bool:
	var index := completed_car_ids.find(car_id)
	return index >= 0 and index < completed_car_ids.size() - 1


func _add_item(item_id: String, count: int) -> void:
	inventory[item_id] = int(inventory.get(item_id, 0)) + count


func _heal_everyone(amount: int) -> Dictionary:
	var result := {"total": 0, "crew": {}}
	for crew_id in crew_states:
		if crew_is_down(crew_id):
			continue
		var body: Dictionary = crew_states[crew_id]["body"]
		var crew_healed := 0
		for zone in body:
			var state: Dictionary = body[zone]
			if bool(state.get("detached", false)):
				continue
			var before := int(state["hp"])
			state["hp"] = mini(int(state["max_hp"]), int(state["hp"]) + amount)
			state["disabled"] = int(state["hp"]) <= 0
			body[zone] = state
			crew_healed += int(state["hp"]) - before
		crew_states[crew_id]["body"] = body
		if crew_healed > 0:
			result["crew"][crew_id] = crew_healed
			result["total"] = int(result["total"]) + crew_healed
	return result


func _increase_max_hp_everyone(amount: int) -> void:
	for crew_id in crew_states:
		var body: Dictionary = crew_states[crew_id]["body"]
		for zone in body:
			var state: Dictionary = body[zone]
			state["max_hp"] = int(state["max_hp"]) + amount
			state["hp"] = int(state["hp"]) + amount
			body[zone] = state
		crew_states[crew_id]["body"] = body


func _fresh_crew_state() -> Dictionary:
	var body := {}
	for zone in Types.BODY_ZONE_NAMES:
		body[zone] = {
			"hp": int(Types.BODY_ZONE_MAX_HP[zone]),
			"max_hp": int(Types.BODY_ZONE_MAX_HP[zone]),
			"disabled": false,
			"detached": false,
		}
	return {"body": body, "down": false, "nerve": 0, "memories": []}
