class_name AutobattleUI
extends CanvasLayer

const TacticalFamilyIcon := preload("res://scripts/tactical_family_icon.gd")

signal plan_previewed(plan: Dictionary, fallback: Dictionary)
signal planning_confirmed(plan: Dictionary, fallback: Dictionary)
signal pause_requested
signal speed_requested(speed: float)
signal aftermath_continue_requested
signal inspector_requested(roster_id: String)
signal inspection_visibility_changed(open: bool)
signal settings_requested

const Types := preload("res://scripts/game_types.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")
const RunState := preload("res://scripts/run_state.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")
const CrewLedgerScript := preload("res://scripts/crew_ledger_ui.gd")
const PLANNING_DOCK_HEIGHT := 176.0
const PLANNING_WORLD_TOP := 58.0

var planning_root: Control
var combat_root: Control
var aftermath_root: Control
var plan_list: HBoxContainer
var planning_dock: PanelContainer
var planning_details: PanelContainer
var planning_preview_label: RichTextLabel
var plan_detail_title: Label
var plan_detail_body: RichTextLabel
var fallback_list: BoxContainer
var fallback_button: Button
var fallback_effect_label: Label
var fallback_picker: PanelContainer
var confirm_button: Button
var planning_crew_row: HBoxContainer
var scene_report_label: Label
var planning_bonus_label: Label
var plan_buttons: Array[Button] = []
var fallback_buttons: Array[Button] = []
var plans: Array[Dictionary] = []
var selected_plan_index := 0
var selected_fallback_index := 0

var combat_round_label: Label
var combat_plan_label: Label
var combat_status_label: Label
var timeline_row: HBoxContainer
var intent_label: RichTextLabel
var milestone_label: Label
var combat_crew_row: HBoxContainer
var pause_button: Button
var settings_button: Button
var speed_buttons: Dictionary = {}
var inspector_panel: Control
var inspector_name: Label
var inspector_body: Label
var inspector_combat: Label
var inspector_grid: GridContainer
var _inspected_unit: TacticalUnit
var _focus_before_inspector: Control
var current_crew: Array[TacticalUnit] = []
var current_bonuses: Dictionary = {}
var current_car: Dictionary = {}
var current_inventory: Dictionary = {}
var gear_outcomes: Dictionary = {}
var current_crew_campaign: Dictionary = {}
var _intent_lines: Array[String] = []
var combat_train_label: Label
var combat_doctrine_label: Label
var combat_warning_panel: PanelContainer

var aftermath_story: Label
var aftermath_plan: Label
var aftermath_milestones: Label
var aftermath_injuries: Label
var aftermath_reward: Label
var aftermath_panel: PanelContainer
var aftermath_details: Button
var _aftermath_reward_full := ""
var _aftermath_reward_short := ""
var aftermath_continue: Button
var training_banner: PanelContainer
var training_label: Label
var training_mode := false
var training_step := 0
var controller_mode := false
var text_scale := 1.0
var current_speed := 1.0
var current_paused := false
var previous_plan_id := ""
var previous_fallback_id := ""
var presentation_panel: PanelContainer
var presentation_label: Label
var _presentation_serial := 0
var _context_warning_active := false
var _settings_open := false

var _panel_color := Color(0.016, 0.036, 0.043, 0.94)
var _soft_panel := Color(0.020, 0.055, 0.062, 0.88)
var _border := Color(0.26, 0.53, 0.53, 0.64)
var _brass := Color("#e3b65c")
var _ink := Color("#e5f6f2")
var _muted := Color("#8fb3b2")
var _green := Color("#72d8b6")
var _danger := Color("#ff7d6e")
const BASE_PACE_SCALE := 0.5


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_planning()
	_build_combat()
	_build_aftermath()
	_build_training_banner()
	_build_presentation_banner()
	hide_all()


func set_settings_open(value: bool) -> void:
	_settings_open = value
	if is_instance_valid(inspector_panel):
		inspector_panel.set_meta("settings_open", value)


func hide_all() -> void:
	planning_root.visible = false
	combat_root.visible = false
	aftermath_root.visible = false
	inspector_panel.visible = false
	if is_instance_valid(training_banner):
		training_banner.visible = false
	if is_instance_valid(presentation_panel):
		presentation_panel.visible = false
	_inspected_unit = null


func set_controller_mode(enabled: bool) -> void:
	controller_mode = enabled
	if is_instance_valid(pause_button):
		pause_button.text = "RESUME" if current_paused else "PAUSE"
	if is_instance_valid(planning_preview_label) and planning_root.visible:
		_refresh_plan_detail()
	if is_instance_valid(training_banner) and training_banner.visible:
		_refresh_training_prompt()


func set_text_scale(value: float) -> void:
	text_scale = clampf(value, 1.0, 1.30)
	for root in [planning_root, combat_root, aftermath_root, training_banner, presentation_panel]:
		if is_instance_valid(root):
			_apply_text_scale(root)
	if inspector_panel is CrewLedgerUI:
		(inspector_panel as CrewLedgerUI).set_text_scale(text_scale)
	if is_instance_valid(planning_dock):
		_set_planning_dock_bounds(planning_dock)
		_set_planning_dock_bounds(planning_details)
		planning_preview_label.custom_minimum_size.y = 36.0 * text_scale
		fallback_picker.offset_bottom = -_planning_dock_height() - 8
		fallback_picker.offset_top = fallback_picker.offset_bottom - 218.0 * text_scale
	_refresh_compact_intent()


func show_presentation_beat(beat: Dictionary, speed: float, reduced_motion: bool) -> void:
	if not combat_root.visible:
		return
	if is_instance_valid(training_banner) and training_step >= 4:
		training_banner.visible = false
	_presentation_serial += 1
	var serial := _presentation_serial
	var beat_type := String(beat.get("type", "event"))
	var result := Dictionary(beat.get("result", {}))
	var actor_name := String(beat.get("actor_name", ""))
	var target_name := String(beat.get("target_name", ""))
	var title := beat_type.replace("_", " ").to_upper()
	var detail := ""
	var color := _brass
	match beat_type:
		"ordinary_attack":
			title = "HIT" if bool(result.get("hit", false)) else "MISS"
			detail = "%s → %s / %s" % [actor_name, target_name, Types.zone_name(int(result.get("zone", Types.BodyZone.TORSO))).to_upper()]
			color = _ink if bool(result.get("hit", false)) else _muted
		"cripple":
			title = "CRIPPLED / %s" % Types.zone_name(int(result.get("zone", Types.BodyZone.TORSO))).to_upper()
			detail = "%s breaks %s / -%d" % [actor_name, target_name, int(result.get("damage", 0))]
			color = _danger
		"casualty":
			title = "CASUALTY"
			detail = "%s takes %s out of the fight" % [actor_name, target_name]
			color = _danger
		"signature_move":
			title = "SIGNATURE / %s" % String(result.get("ability", "ABILITY")).to_upper()
			detail = actor_name
			color = _green
		"environment":
			title = "TRAIN SYSTEM / %s" % String(result.get("action_id", "ACTIVATED")).replace("_", " ").to_upper()
			detail = actor_name if not actor_name.is_empty() else ("COUNTERED" if bool(result.get("countered", false)) else "THE CARRIAGE MOVES")
			color = _brass
		"train_warning":
			title = "TRAIN WARNING / %s" % String(result.get("title", "HAZARD")).to_upper()
			detail = "Brace or counter before next round."
			color = _brass
		"plan_break":
			title = "PLAN BREAK"
			detail = "%s TAKES OVER" % String(result.get("fallback", "FALLBACK"))
			color = _danger
		"item":
			title = "GEAR / %s" % String(result.get("item_id", "ITEM")).replace("_", " ").to_upper()
			detail = "%s commits the item" % actor_name
			color = _brass
		"surrender":
			title = "SURRENDER"
			detail = "%s drops their weapon" % actor_name
			color = _green
		"victory":
			title = "CAR SECURED"
			detail = String(result.get("message", "The plan resolves."))
			color = _green
		"defeat":
			title = "THE PLAN ENDS"
			detail = String(result.get("message", "The crew is down."))
			color = _danger
	var bark := String(beat.get("bark", result.get("bark", "")))
	if not bark.is_empty():
		detail = bark
	presentation_label.text = "%s\n%s" % [title, detail]
	presentation_label.add_theme_color_override("font_color", color)
	presentation_panel.add_theme_stylebox_override("panel", _box(Color(0.018, 0.040, 0.043, 0.97), color, 7))
	presentation_panel.modulate = Color.WHITE
	presentation_panel.visible = true
	if is_instance_valid(combat_warning_panel):
		combat_warning_panel.visible = false
	var effective_speed := maxf(0.2, speed * BASE_PACE_SCALE)
	var base_duration := 0.75
	if beat_type in ["casualty", "surrender", "plan_break", "victory", "defeat"]:
		base_duration = 1.75
	elif beat_type != "ordinary_attack":
		base_duration = 1.35
	var duration := base_duration / sqrt(effective_speed)
	_hide_presentation_later(serial, duration, reduced_motion)


func _hide_presentation_later(serial: int, duration: float, reduced_motion: bool) -> void:
	await get_tree().create_timer(duration, true, false, true).timeout
	if serial != _presentation_serial or not is_instance_valid(presentation_panel):
		return
	if reduced_motion:
		presentation_panel.visible = false
		if is_instance_valid(combat_warning_panel): combat_warning_panel.visible = _context_warning_active
		return
	var fade := presentation_panel.create_tween()
	fade.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	fade.tween_property(presentation_panel, "modulate:a", 0.0, 0.12)
	fade.tween_callback(func() -> void:
		presentation_panel.visible = false
		if is_instance_valid(combat_warning_panel): combat_warning_panel.visible = _context_warning_active
	)


func show_planning(context: Dictionary) -> void:
	gear_outcomes.clear()
	current_car = Dictionary(context.get("car", {})).duplicate(true)
	current_bonuses = Dictionary(context.get("bonuses", {})).duplicate(true)
	current_inventory = Dictionary(context.get("inventory", {})).duplicate(true)
	current_crew_campaign = Dictionary(context.get("crew_campaign", {})).duplicate(true)
	current_crew.clear()
	for unit in Array(context.get("crew", [])):
		if unit is TacticalUnit:
			current_crew.append(unit)
	plans.clear()
	for plan in Array(context.get("plans", [])):
		plans.append(Dictionary(plan).duplicate(true))
	selected_plan_index = clampi(int(context.get("selected_plan", 0)), 0, maxi(0, plans.size() - 1))
	selected_fallback_index = clampi(int(context.get("selected_fallback", 0)), 0, PlanCatalog.FALLBACKS.size() - 1)
	previous_plan_id = String(context.get("previous_plan_id", ""))
	previous_fallback_id = String(context.get("previous_fallback_id", ""))
	training_mode = bool(context.get("training", false))
	training_step = 1 if training_mode else 0
	planning_details.visible = false
	fallback_picker.visible = false
	inspector_panel.visible = false
	_populate_scene_report(context)
	_populate_crew_row(planning_crew_row, true)
	_populate_plan_cards()
	_populate_fallbacks()
	_refresh_plan_detail()
	planning_root.visible = true
	combat_root.visible = false
	aftermath_root.visible = false
	_refresh_training_prompt()
	set_text_scale(text_scale)
	if not plan_buttons.is_empty():
		_schedule_focus(plan_buttons[selected_plan_index])


func show_combat(plan: Dictionary, fallback: Dictionary, crew: Array[TacticalUnit], car: Dictionary, bonuses: Dictionary) -> void:
	current_crew = crew
	current_car = car.duplicate(true)
	current_bonuses = bonuses.duplicate(true)
	_intent_lines.clear()
	combat_plan_label.text = "%s  /  %s" % [String(car.get("name", "CAR")).to_upper(), String(plan.get("title", "PLAN")).to_upper()]
	combat_status_label.text = "ON PLAN"
	combat_status_label.add_theme_color_override("font_color", _green)
	var profile := SignatureArc.car_profile(String(car.get("id", "")))
	combat_train_label.text = "LIVING TRAIN / %s" % String(profile.get("hazard_name", "CALM TRACK"))
	combat_doctrine_label.text = "ENEMY DOCTRINE / %s" % String(profile.get("doctrine_name", "UNFORMED"))
	combat_train_label.tooltip_text = String(profile.get("hazard_preview", ""))
	combat_doctrine_label.tooltip_text = String(profile.get("doctrine_text", ""))
	combat_warning_panel.visible = false
	_context_warning_active = false
	combat_round_label.text = "ROUND 01"
	intent_label.remove_meta("intent_summary")
	intent_label.text = "[color=#8fb3b2]The crew is taking its marks.[/color]"
	milestone_label.text = ""
	_populate_crew_row(combat_crew_row, false)
	inspector_panel.visible = false
	current_speed = 1.0
	current_paused = false
	pause_button.text = "PAUSE"
	_update_speed_buttons(1.0, false)
	planning_root.visible = false
	combat_root.visible = true
	aftermath_root.visible = false
	if training_mode:
		training_step = 4
		_refresh_training_prompt()
		var tutorial_tween := training_banner.create_tween()
		tutorial_tween.tween_interval(5.0)
		tutorial_tween.tween_callback(func() -> void: training_banner.visible = false)
	set_text_scale(text_scale)


func show_aftermath(data: Dictionary, reward_text: String, continue_text: String = "CONTINUE THE HEIST") -> void:
	inspector_panel.visible = false
	planning_root.visible = false
	combat_root.visible = false
	aftermath_root.visible = true
	training_banner.visible = false
	presentation_panel.visible = false
	aftermath_story.text = "%s — %s" % ["CAR SECURED" if bool(data.get("victory", true)) else "HEIST BROKEN", String(data.get("plan_title", "THE PLAN"))]
	aftermath_plan.text = "%s\n%s%s\n%d ROUNDS" % [
		String(data.get("plan_title", "Unknown")).to_upper(),
		String(data.get("fallback_title", "Hold the plan")),
		"  •  USED" if bool(data.get("fallback_triggered", false)) else "  •  HELD",
		int(data.get("rounds", 0)),
	]
	var highlight_lines: Array[String] = []
	var decisive: Array = data.get("decisive_beats", [])
	var highlight_start := maxi(0, decisive.size() - 3)
	for index in range(highlight_start, decisive.size()):
		highlight_lines.append("%d / %s" % [index - highlight_start + 1, _beat_aftermath_summary(Dictionary(decisive[index]))])
	aftermath_milestones.text = "\n%s" % ("\n".join(highlight_lines) if not highlight_lines.is_empty() else "1 / Clean exchange.")
	var injury_lines: Array[String] = []
	for raw_injury in Array(data.get("injuries", [])):
		var injury := Dictionary(raw_injury)
		var changes: Array[String] = []
		for change in Array(injury.get("changes", [])):
			changes.append(String(change))
		injury_lines.append("• %s — %s" % [String(injury.get("name", "Operative")), "DOWN" if bool(injury.get("down", false)) else ", ".join(changes)])
	aftermath_injuries.text = "\n".join(injury_lines) if not injury_lines.is_empty() else "No new lasting injuries."
	_aftermath_reward_full = reward_text
	_aftermath_reward_short = reward_text
	var knowledge_start := reward_text.find("BLUEPRINT KNOWLEDGE")
	if knowledge_start >= 0:
		var breakdown_start := reward_text.find("\n", knowledge_start)
		if breakdown_start >= 0:
			_aftermath_reward_short = reward_text.left(breakdown_start)
	aftermath_reward.text = _aftermath_reward_short
	aftermath_details.text = "REWARD DETAILS"
	aftermath_details.visible = _aftermath_reward_short != _aftermath_reward_full
	aftermath_continue.text = continue_text
	set_text_scale(text_scale)
	if is_instance_valid(aftermath_continue):
		_schedule_focus(aftermath_continue)


func _beat_aftermath_summary(beat: Dictionary) -> String:
	var result := Dictionary(beat.get("result", {}))
	match String(beat.get("type", "event")):
		"cripple": return "%s crippled %s's %s." % [String(beat.get("actor_name", "The crew")), String(beat.get("target_name", "a guard")), Types.zone_name(int(result.get("zone", Types.BodyZone.TORSO))).to_lower()]
		"casualty": return "%s took %s out of the fight." % [String(beat.get("actor_name", "The crew")), String(beat.get("target_name", "a threat"))]
		"environment": return "The carriage system %s changed the exchange." % String(result.get("action_id", "activated")).replace("_", " ")
		"signature_move": return "%s used %s." % [String(beat.get("actor_name", "An operative")), String(result.get("ability", "a signature move"))]
		"plan_break": return "The opening broke and %s took over." % String(result.get("fallback", "the fallback"))
		"surrender": return "%s surrendered." % String(beat.get("actor_name", "A guard"))
		"item": return "%s committed %s." % [String(beat.get("actor_name", "The crew")), String(result.get("item_id", "gear")).replace("_", " ")]
		"victory": return String(result.get("message", "The car was secured."))
	return String(beat.get("type", "event")).replace("_", " ").capitalize()


func on_timeline_changed(entries: Array, active_index: int) -> void:
	_clear_children(timeline_row)
	for index in range(entries.size()):
		var entry := Dictionary(entries[index])
		var chip := Label.new()
		chip.text = String(entry.get("name", "?")).left(1).to_upper()
		chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		chip.custom_minimum_size = Vector2(30.0, 26.0)
		chip.add_theme_font_size_override("font_size", 12)
		var team_color := _green if int(entry.get("team", 0)) == int(Types.Team.PLAYER) else _danger
		var state := String(entry.get("state", "waiting"))
		chip.add_theme_color_override("font_color", team_color.darkened(0.42) if state == "done" else team_color)
		chip.add_theme_stylebox_override("normal", _box(_brass.darkened(0.72) if index == active_index else Color(0.03, 0.09, 0.10, 0.86), _brass if index == active_index else _border, 4))
		timeline_row.add_child(chip)


func on_intent_changed(unit: TacticalUnit, caption: String, explanation: String, status: String) -> void:
	var color := "#72d8b6"
	if status == "adapting":
		color = "#e3b65c"
	elif status in ["broken", "enemy"]:
		color = "#ff7d6e"
	intent_label.set_meta("intent_summary", "%s / %s" % [unit.display_name.to_upper(), caption])
	intent_label.set_meta("intent_color", color)
	intent_label.tooltip_text = "%s / %s\n%s" % [unit.display_name, caption, explanation]
	_refresh_compact_intent()
	_populate_crew_row(combat_crew_row, false)


func _refresh_compact_intent() -> void:
	if not is_instance_valid(intent_label) or not intent_label.has_meta("intent_summary"):
		return
	var full := String(intent_label.get_meta("intent_summary"))
	var shown := full
	var font := intent_label.get_theme_font("normal_font")
	var font_size := intent_label.get_theme_font_size("normal_font_size")
	var available := maxf(24, intent_label.size.x - 4)
	while shown.length() > 3 and font.get_string_size(shown + ("..." if shown != full else ""), HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > available:
		shown = shown.left(shown.length() - 1)
	intent_label.text = "[color=%s]%s%s[/color]" % [String(intent_label.get_meta("intent_color", "#72d8b6")), shown, "..." if shown != full else ""]


func on_plan_status_changed(status: String, explanation: String) -> void:
	var heading := "ON PLAN"
	var color := _green
	if status == "adapting":
		heading = "ADAPTING"
		color = _brass
	elif status == "broken":
		heading = "BROKEN"
		color = _danger
	combat_status_label.text = heading
	combat_status_label.tooltip_text = explanation
	combat_status_label.add_theme_color_override("font_color", color)


func on_round_started(round_number: int) -> void:
	combat_round_label.text = "R%02d" % round_number
	_populate_crew_row(combat_crew_row, false)


func on_milestone_added(text: String) -> void:
	milestone_label.text = text


func on_train_event_changed(event: Dictionary, result: Dictionary) -> void:
	_context_warning_active = true
	var phase := String(event.get("phase", "warning"))
	if phase == "warning":
		combat_train_label.text = "WARNING / %s" % String(event.get("title", "HAZARD"))
		combat_train_label.tooltip_text = "%s\nCOUNTER / %s" % [String(event.get("detail", "")), String(event.get("counter_action", "none")).replace("_", " ").to_upper()]
		combat_train_label.add_theme_color_override("font_color", _brass)
		return
	var countered := bool(result.get("countered", false))
	combat_train_label.text = "%s / %s" % ["COUNTERED" if countered else "IMPACT", String(event.get("title", "HAZARD"))]
	combat_train_label.tooltip_text = String(event.get("detail", ""))
	combat_train_label.add_theme_color_override("font_color", _green if countered else _danger)


func on_doctrine_changed(doctrine: Dictionary) -> void:
	_context_warning_active = true
	combat_warning_panel.visible = not presentation_panel.visible
	var broken := bool(doctrine.get("broken", false))
	var short_status := "BROKEN" if broken else "ACTIVE"
	if not broken and not String(doctrine.get("focus_name", "")).is_empty():
		short_status = "FOCUS: %s" % String(doctrine.get("focus_name", "CREW")).get_slice(" ", 0).to_upper()
	combat_doctrine_label.text = "%s / %s" % [String(doctrine.get("name", "GUARD LINE")), short_status]
	combat_doctrine_label.tooltip_text = "%s\n%s" % [String(doctrine.get("text", "")), String(doctrine.get("round_effect", ""))]
	combat_doctrine_label.add_theme_color_override("font_color", _green if broken else _danger)


func on_speed_changed(speed: float, is_paused: bool) -> void:
	current_speed = speed
	current_paused = is_paused
	pause_button.text = "RESUME" if is_paused else "PAUSE"
	_update_speed_buttons(speed, is_paused)


func refresh_combat_crew() -> void:
	if combat_root.visible:
		_populate_crew_row(combat_crew_row, false)
	if inspector_panel.visible and inspector_panel is CrewLedgerUI:
		(inspector_panel as CrewLedgerUI).update_context(_ledger_context())


func toggle_inspector(roster_id: String = "") -> void:
	if inspector_panel.visible and (roster_id.is_empty() or String(inspector_panel.get_meta("roster_id", "")) == roster_id):
		inspector_panel.visible = false
		return
	if roster_id.is_empty() and not current_crew.is_empty():
		roster_id = current_crew[0].roster_id
	show_inspector(roster_id)


func show_inspector(roster_id: String) -> void:
	var unit: TacticalUnit
	for candidate in current_crew:
		if candidate.roster_id == roster_id:
			unit = candidate
			break
	if not is_instance_valid(unit):
		return
	show_unit_inspector(unit)


func show_unit_inspector(unit: TacticalUnit) -> void:
	if not is_instance_valid(unit):
		return
	if not inspector_panel.visible:
		_focus_before_inspector = get_viewport().gui_get_focus_owner()
	_inspected_unit = unit
	inspector_panel.set_meta("roster_id", CrewLedgerUI.unit_key(unit))
	planning_details.visible = false
	if is_instance_valid(fallback_picker): fallback_picker.visible = false
	inspector_name.text = "%s / %s" % [unit.display_name.to_upper(), String(unit.get_meta("crew_role", "OPERATIVE")) if unit.team == Types.Team.PLAYER else unit.role_label]
	inspector_body.text = "HEAD  %s\nTORSO  %s\nARMS  %s\nLEGS  %s" % [
		unit.zone_hp_text(Types.BodyZone.HEAD), unit.zone_hp_text(Types.BodyZone.TORSO),
		unit.zone_hp_text(Types.BodyZone.ARMS), unit.zone_hp_text(Types.BodyZone.LEGS),
	]
	var effects: Array[String] = []
	if unit.arms_crippled(): effects.append("ARMS: -36% aim, half damage, no reload/overwatch")
	if unit.legs_crippled(): effects.append("LEGS: movement 1, cannot take cover")
	if effects.is_empty(): effects.append("No crippling injuries")
	var stat_line := "DAMAGE %.1f  •  RANGE %d  •  MOVE %d" % [unit.base_damage, unit.attack_range, unit.movement_range()]
	if unit.team == Types.Team.PLAYER:
		stat_line = "DAMAGE %.1f (BASE %.1f + CAR +%.2f)\nRANGE %d (BASE %d + CAR +%d)  •  MOVE %d (BASE %d + CAR +%d)" % [
			unit.base_damage, float(unit.get_meta("unbuffed_damage", unit.base_damage)), float(current_bonuses.get("damage", 0.0)),
			unit.attack_range, int(unit.get_meta("unbuffed_range", unit.attack_range)), int(current_bonuses.get("range", 0)),
			unit.movement_range(), int(unit.get_meta("unbuffed_move", unit.base_movement)), int(current_bonuses.get("movement", 0)),
		]
	inspector_combat.text = "%s  •  %d/%d AMMO\n%s\n%s\n\n%s" % [
		unit.weapon_name.to_upper(), unit.ammunition, unit.magazine_size, stat_line, "\n".join(effects),
		"CAR BUFFS / %s" % RunState.format_bonus_summary(current_bonuses) if unit.team == Types.Team.PLAYER else "ENEMY POST / %s" % String(unit.get_meta("spawn_post", "GUARD LINE")),
	]
	if inspector_panel is CrewLedgerUI:
		(inspector_panel as CrewLedgerUI).show_context(_ledger_context(), CrewLedgerUI.unit_key(unit), "crew")


func mark_item_used(item_id: String) -> void:
	gear_outcomes[item_id] = "used"
	refresh_combat_crew()


func _ledger_context() -> Dictionary:
	var ledger_crew: Array[TacticalUnit] = current_crew.duplicate()
	if is_instance_valid(_inspected_unit) and _inspected_unit not in ledger_crew:
		ledger_crew.append(_inspected_unit)
	var plan := plans[selected_plan_index] if selected_plan_index >= 0 and selected_plan_index < plans.size() else {}
	return {"crew": ledger_crew, "inventory": current_inventory, "bonuses": current_bonuses, "car": current_car, "campaign": current_crew_campaign, "plan": plan, "phase": "planning" if planning_root.visible else "combat", "gear_outcomes": gear_outcomes}


func _on_ledger_operative_selected(unit: TacticalUnit) -> void:
	_inspected_unit = unit
	inspector_panel.set_meta("roster_id", CrewLedgerUI.unit_key(unit))


func _on_inspector_visibility_changed() -> void:
	inspection_visibility_changed.emit(inspector_panel.visible)
	if not inspector_panel.visible:
		if is_instance_valid(_focus_before_inspector) and _focus_before_inspector.is_visible_in_tree():
			_schedule_focus(_focus_before_inspector)
		else:
			_restore_mode_focus()
		_focus_before_inspector = null


func planning_battlefield_rect() -> Rect2:
	var viewport_size := get_viewport().get_visible_rect().size
	var world_top := PLANNING_WORLD_TOP + (text_scale - 1.0) * 68.0
	return Rect2(12.0, world_top, viewport_size.x - 24.0, viewport_size.y - _planning_dock_height() - world_top - 8.0)


func _planning_dock_height() -> float:
	return PLANNING_DOCK_HEIGHT + (text_scale - 1.0) * 128.0


func _set_planning_dock_bounds(panel: Control) -> void:
	panel.anchor_left = 0.0; panel.anchor_right = 1.0; panel.anchor_top = 1.0; panel.anchor_bottom = 1.0
	panel.offset_left = 12; panel.offset_right = -12; panel.offset_top = -_planning_dock_height(); panel.offset_bottom = -12


func toggle_plan_details() -> void:
	inspector_panel.visible = false
	fallback_picker.visible = false
	planning_details.visible = not planning_details.visible


func _build_planning() -> void:
	planning_root = _full_root("PlanningRoot")
	add_child(planning_root)
	var header := _panel()
	header.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	header.offset_left = 12.0; header.offset_right = -12.0; header.offset_top = 7.0; header.offset_bottom = 52.0
	planning_root.add_child(header)
	var header_row := HBoxContainer.new(); header_row.add_theme_constant_override("separation", 16); header.add_child(header_row)
	scene_report_label = _label("PLAN / CAR REPORT", 15, _ink); scene_report_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; scene_report_label.clip_text = true; header_row.add_child(scene_report_label)
	planning_crew_row = HBoxContainer.new(); planning_crew_row.add_theme_constant_override("separation", 5); header_row.add_child(planning_crew_row)
	planning_bonus_label = _label("BUFFS / NONE", 12, _green); planning_bonus_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT; header_row.add_child(planning_bonus_label)
	planning_bonus_label.custom_minimum_size.x = 170.0

	planning_dock = _panel()
	planning_dock.name = "DecisionDock"
	_set_planning_dock_bounds(planning_dock)
	planning_root.add_child(planning_dock)
	var margin := _margin(6, 6, 4, 4); planning_dock.add_child(margin)
	var column := VBoxContainer.new(); column.add_theme_constant_override("separation", 5); margin.add_child(column)
	plan_list = HBoxContainer.new(); plan_list.add_theme_constant_override("separation", 8); column.add_child(plan_list)
	planning_preview_label = RichTextLabel.new(); planning_preview_label.bbcode_enabled = true; planning_preview_label.scroll_active = false; planning_preview_label.custom_minimum_size.y = 36; planning_preview_label.size_flags_vertical = Control.SIZE_EXPAND_FILL; planning_preview_label.add_theme_font_size_override("normal_font_size", 12); column.add_child(planning_preview_label)
	var controls := HBoxContainer.new(); controls.add_theme_constant_override("separation", 8); column.add_child(controls)
	fallback_button = _button("FALLBACK / HOLD THE PLAN  v", false); fallback_button.custom_minimum_size.x = 245; fallback_button.pressed.connect(_toggle_fallback_picker); controls.add_child(fallback_button)
	fallback_effect_label = _label("Keep assignments until the opening cannot continue.", 11, _muted); fallback_effect_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; fallback_effect_label.clip_text = true; controls.add_child(fallback_effect_label)
	var details_button := _button("PLAN DETAILS", false); details_button.pressed.connect(toggle_plan_details); controls.add_child(details_button)
	confirm_button = _button("COMMIT", true); confirm_button.custom_minimum_size = Vector2(130, 36); confirm_button.pressed.connect(_confirm_plan); controls.add_child(confirm_button)

	fallback_picker = _panel(Color(0.016, 0.036, 0.043, 1.0)); fallback_picker.name = "FallbackPicker"
	fallback_picker.anchor_left = 0.0; fallback_picker.anchor_right = 0.0; fallback_picker.anchor_top = 1.0; fallback_picker.anchor_bottom = 1.0
	fallback_picker.offset_left = 18; fallback_picker.offset_right = 430; fallback_picker.offset_top = -374; fallback_picker.offset_bottom = -166; fallback_picker.z_index = 12; planning_root.add_child(fallback_picker)
	var picker_margin := _margin(8, 8, 8, 8); fallback_picker.add_child(picker_margin)
	var picker_col := VBoxContainer.new(); picker_col.add_theme_constant_override("separation", 5); picker_margin.add_child(picker_col)
	picker_col.add_child(_label("IF THE OPENING BREAKS", 12, _brass))
	fallback_list = HBoxContainer.new(); fallback_list = VBoxContainer.new(); fallback_list.add_theme_constant_override("separation", 5); picker_col.add_child(fallback_list)
	fallback_picker.visible = false

	# Full prose remains available without ever covering the battlefield.
	planning_details = _panel(Color(0.016, 0.036, 0.043, 1.0)); planning_details.name = "PlanDetailsDock"
	_set_planning_dock_bounds(planning_details); planning_details.z_index = 11; planning_root.add_child(planning_details)
	var details_margin := _margin(6, 6, 4, 4); planning_details.add_child(details_margin)
	var details_col := VBoxContainer.new(); details_col.add_theme_constant_override("separation", 6); details_margin.add_child(details_col)
	var details_header := HBoxContainer.new(); details_col.add_child(details_header)
	plan_detail_title = _label("SELECT A PLAN", 18, _ink); plan_detail_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL; details_header.add_child(plan_detail_title)
	var close_details := _button("BACK TO PLANS [ESC]", false); close_details.pressed.connect(toggle_plan_details); details_header.add_child(close_details)
	plan_detail_body = RichTextLabel.new(); plan_detail_body.bbcode_enabled = true; plan_detail_body.size_flags_vertical = Control.SIZE_EXPAND_FILL; plan_detail_body.add_theme_font_size_override("normal_font_size", 13); plan_detail_body.add_theme_color_override("default_color", _ink); details_col.add_child(plan_detail_body)
	planning_details.visible = false


func _build_training_banner() -> void:
	training_banner = _panel(Color(0.05, 0.11, 0.12, 0.98))
	training_banner.name = "ContextTrainingBanner"
	training_banner.anchor_left = 0.5
	training_banner.anchor_right = 0.5
	training_banner.anchor_top = 0.0
	training_banner.anchor_bottom = 0.0
	training_banner.offset_left = -390.0
	training_banner.offset_right = 390.0
	training_banner.offset_top = 72.0
	training_banner.offset_bottom = 118.0
	training_banner.z_index = 30
	training_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(training_banner)
	training_label = _label("TRAINING", 14, _ink)
	training_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	training_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	training_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	training_banner.add_child(training_label)
	training_banner.visible = false


func _build_presentation_banner() -> void:
	presentation_panel = _panel(Color(0.018, 0.040, 0.043, 0.97))
	presentation_panel.name = "PresentationBeatBanner"
	presentation_panel.anchor_left = 0.5
	presentation_panel.anchor_right = 0.5
	presentation_panel.anchor_top = 0.0
	presentation_panel.anchor_bottom = 0.0
	presentation_panel.offset_left = -285.0
	presentation_panel.offset_right = 285.0
	presentation_panel.offset_top = 174.0
	presentation_panel.offset_bottom = 230.0
	presentation_panel.z_index = 40
	presentation_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(presentation_panel)
	presentation_label = _label("KEY BEAT", 15, _brass)
	presentation_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	presentation_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	presentation_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	presentation_panel.add_child(presentation_label)
	presentation_panel.visible = false


func _refresh_training_prompt() -> void:
	if not is_instance_valid(training_banner):
		return
	training_banner.visible = training_mode and training_step > 0
	if not training_banner.visible:
		return
	match training_step:
		1:
			training_label.text = "1 / 4  [A] CHOOSE A PLAN" if controller_mode else "1 / 4  CLICK OR 1–4: CHOOSE A PLAN"
		2:
			training_label.text = "2 / 4  READ START • TARGET • RISK  [X] DETAILS  [Y] LEDGER" if controller_mode else "2 / 4  READ START • TARGET • RISK  CLICK CREW: LEDGER"
		3:
			training_label.text = "3 / 4  [A] PICK A FALLBACK" if controller_mode else "3 / 4  PICK A FALLBACK"
		4:
			training_label.text = "4 / 4  WATCH: GREEN / BRASS / RED"


func _build_combat() -> void:
	combat_root = _full_root("AutobattleHUD")
	add_child(combat_root)
	var top := _panel()
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE); top.offset_left = 12; top.offset_right = -12; top.offset_top = 8; top.offset_bottom = 58
	combat_root.add_child(top)
	var top_margin := _margin(10, 10, 5, 5); top.add_child(top_margin)
	var top_line := HBoxContainer.new(); top_line.add_theme_constant_override("separation", 8); top_margin.add_child(top_line)
	combat_round_label = _label("R01", 15, _brass); combat_round_label.custom_minimum_size.x = 52; top_line.add_child(combat_round_label)
	combat_plan_label = _label("PLAN", 13, _ink); combat_plan_label.custom_minimum_size.x = 180; combat_plan_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; combat_plan_label.clip_text = true; combat_plan_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS; top_line.add_child(combat_plan_label)
	combat_status_label = _label("ON PLAN", 12, _green); combat_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; combat_status_label.custom_minimum_size.x = 130; top_line.add_child(combat_status_label)
	combat_status_label.clip_text = true
	timeline_row = HBoxContainer.new(); timeline_row.alignment = BoxContainer.ALIGNMENT_END; timeline_row.add_theme_constant_override("separation", 3); timeline_row.custom_minimum_size.x = 380; top_line.add_child(timeline_row)
	settings_button = _button("SETTINGS", false)
	settings_button.add_theme_font_size_override("font_size", 11)
	settings_button.pressed.connect(func() -> void: settings_requested.emit())
	top_line.add_child(settings_button)

	combat_warning_panel = _panel(Color(0.016, 0.036, 0.043, 0.94))
	combat_warning_panel.anchor_left = 0.5; combat_warning_panel.anchor_right = 0.5; combat_warning_panel.anchor_top = 0.0; combat_warning_panel.anchor_bottom = 0.0
	combat_warning_panel.offset_left = -370; combat_warning_panel.offset_right = 370; combat_warning_panel.offset_top = 64; combat_warning_panel.offset_bottom = 98
	combat_root.add_child(combat_warning_panel)
	var signature_row := HBoxContainer.new(); signature_row.add_theme_constant_override("separation", 18); combat_warning_panel.add_child(signature_row)
	combat_train_label = _label("LIVING TRAIN / CALM TRACK", 11, _brass); combat_train_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; combat_train_label.clip_text = true; signature_row.add_child(combat_train_label)
	combat_doctrine_label = _label("ENEMY DOCTRINE / UNFORMED", 11, _danger); combat_doctrine_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; combat_doctrine_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT; combat_doctrine_label.clip_text = true; signature_row.add_child(combat_doctrine_label)
	combat_train_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	combat_doctrine_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS

	var feed := _panel()
	feed.anchor_left = 0.0; feed.anchor_right = 0.0; feed.anchor_top = 1.0; feed.anchor_bottom = 1.0
	feed.offset_left = 12; feed.offset_right = 500; feed.offset_top = -66; feed.offset_bottom = -12
	combat_root.add_child(feed)
	var feed_margin := _margin(10, 10, 6, 5); feed.add_child(feed_margin)
	var feed_col := VBoxContainer.new(); feed_col.add_theme_constant_override("separation", 1); feed_margin.add_child(feed_col)
	intent_label = RichTextLabel.new(); intent_label.bbcode_enabled = true; intent_label.fit_content = false; intent_label.scroll_active = false; intent_label.clip_contents = true; intent_label.autowrap_mode = TextServer.AUTOWRAP_OFF; intent_label.custom_minimum_size.y = 20.0; intent_label.add_theme_font_size_override("normal_font_size", 11); feed_col.add_child(intent_label)
	intent_label.resized.connect(_refresh_compact_intent)
	milestone_label = _label("", 10, _green); milestone_label.visible = false; feed_col.add_child(milestone_label)

	var crew_panel := _panel()
	crew_panel.anchor_left = 0.0; crew_panel.anchor_right = 1.0; crew_panel.anchor_top = 1.0; crew_panel.anchor_bottom = 1.0
	crew_panel.offset_left = 510; crew_panel.offset_right = -298; crew_panel.offset_top = -66; crew_panel.offset_bottom = -12
	combat_root.add_child(crew_panel)
	var crew_margin := _margin(5, 5, 4, 4); crew_panel.add_child(crew_margin)
	var crew_col := VBoxContainer.new(); crew_margin.add_child(crew_col); combat_crew_row = HBoxContainer.new(); combat_crew_row.add_theme_constant_override("separation", 4); crew_col.add_child(combat_crew_row)

	var speed_panel := _panel()
	speed_panel.anchor_left = 1.0; speed_panel.anchor_right = 1.0; speed_panel.anchor_top = 1.0; speed_panel.anchor_bottom = 1.0
	speed_panel.offset_left = -288; speed_panel.offset_right = -12; speed_panel.offset_top = -66; speed_panel.offset_bottom = -12
	combat_root.add_child(speed_panel)
	var speed_margin := _margin(6, 6, 5, 5); speed_panel.add_child(speed_margin)
	var speed_row := HBoxContainer.new(); speed_row.add_theme_constant_override("separation", 4); speed_margin.add_child(speed_row)
	pause_button = _button("PAUSE", false); pause_button.custom_minimum_size.x = 78; pause_button.pressed.connect(func() -> void: pause_requested.emit()); speed_row.add_child(pause_button)
	for speed in [1.0, 2.0, 4.0]:
		var speed_button := _button("%dx" % int(speed), false); speed_button.custom_minimum_size.x = 42; speed_button.pressed.connect(func() -> void: speed_requested.emit(speed)); speed_row.add_child(speed_button); speed_buttons[speed] = speed_button

	# Compatibility text nodes remain queryable by the regression suite; the
	# visible interface is the full-screen Ledger below.
	inspector_name = _label("OPERATIVE", 16, _ink)
	inspector_body = _label("BODY", 13, _ink)
	inspector_combat = _label("COMBAT", 13, _muted)
	inspector_grid = GridContainer.new()
	inspector_panel = CrewLedgerScript.new()
	add_child(inspector_panel)
	inspector_panel.visibility_changed.connect(_on_inspector_visibility_changed)
	(inspector_panel as CrewLedgerUI).operative_selected.connect(_on_ledger_operative_selected)
	(inspector_panel as CrewLedgerUI).settings_requested.connect(func() -> void: settings_requested.emit())


func _build_aftermath() -> void:
	aftermath_root = _full_root("AftermathRoot")
	add_child(aftermath_root)
	var veil := ColorRect.new(); veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); veil.color = Color(0.0, 0.0, 0.0, 0.54); veil.mouse_filter = Control.MOUSE_FILTER_STOP; aftermath_root.add_child(veil)
	var panel := _panel()
	aftermath_panel = panel
	panel.name = "AftermathPanel"
	panel.anchor_left = 0.5; panel.anchor_right = 0.5; panel.anchor_top = 0.5; panel.anchor_bottom = 0.5
	panel.offset_left = -520; panel.offset_right = 520; panel.offset_top = -280; panel.offset_bottom = 280
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	aftermath_root.add_child(panel)
	var margin := _margin(26, 26, 22, 22); panel.add_child(margin)
	var col := VBoxContainer.new(); col.add_theme_constant_override("separation", 10); margin.add_child(col)
	var kicker := _label("THE CARRIAGE FALLS QUIET", 13, _brass); kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; col.add_child(kicker)
	aftermath_story = _label("The crew clears the carriage.", 22, _ink); aftermath_story.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; aftermath_story.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; aftermath_story.custom_minimum_size.y = 52; col.add_child(aftermath_story)
	col.add_child(HSeparator.new())
	var split := HBoxContainer.new(); split.add_theme_constant_override("separation", 12); split.size_flags_vertical = Control.SIZE_EXPAND_FILL; col.add_child(split)
	var happened := _aftermath_card_body(split, "WHAT HAPPENED", _brass)
	aftermath_plan = _label("PLAN", 14, _ink); aftermath_plan.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; happened.add_child(aftermath_plan)
	aftermath_milestones = _label("KEY BEATS", 12, _muted); aftermath_milestones.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; happened.add_child(aftermath_milestones)
	var hurt := _aftermath_card_body(split, "WHO WAS HURT", _danger)
	aftermath_injuries = _label("CREW CONDITION", 13, _ink); aftermath_injuries.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; hurt.add_child(aftermath_injuries)
	var gained := _aftermath_card_body(split, "WHAT WE GAINED", _green)
	aftermath_reward = _label("REWARD", 13, _ink); aftermath_reward.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; gained.add_child(aftermath_reward)
	var actions := HBoxContainer.new(); actions.add_theme_constant_override("separation", 10); col.add_child(actions)
	aftermath_details = _button("REWARD DETAILS", false); aftermath_details.custom_minimum_size = Vector2(210, 50); actions.add_child(aftermath_details)
	aftermath_details.pressed.connect(func() -> void:
		var expanded := aftermath_reward.text == _aftermath_reward_full
		aftermath_reward.text = _aftermath_reward_short if expanded else _aftermath_reward_full
		aftermath_details.text = "REWARD DETAILS" if expanded else "HIDE DETAILS"
	)
	aftermath_continue = _button("CONTINUE THE HEIST", true); aftermath_continue.custom_minimum_size.y = 50; aftermath_continue.size_flags_horizontal = Control.SIZE_EXPAND_FILL; aftermath_continue.pressed.connect(func() -> void: aftermath_continue_requested.emit()); actions.add_child(aftermath_continue)


func _aftermath_card_body(parent: HBoxContainer, title: String, color: Color) -> VBoxContainer:
	var card := _panel(_soft_panel)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(card)
	var margin := _margin(12, 12, 10, 10); card.add_child(margin)
	var column := VBoxContainer.new(); column.add_theme_constant_override("separation", 8); margin.add_child(column)
	column.add_child(_label(title, 13, color))
	# Scroll bodies do not contribute their full prose height to the fixed-height action frame.
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.focus_mode = Control.FOCUS_ALL
	scroll.follow_focus = true
	column.add_child(scroll)
	var body := VBoxContainer.new(); body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(body)
	return body


func _populate_scene_report(context: Dictionary) -> void:
	var car := Dictionary(context.get("car", {}))
	var enemy_names: Array[String] = []
	for enemy in Array(context.get("enemies", [])):
		if enemy is TacticalUnit:
			enemy_names.append((enemy as TacticalUnit).role_label)
	var tags: Array[String] = []
	for tag in PlanCatalog.car_tags(String(car.get("id", ""))):
		tags.append(tag.replace("_", " ").to_upper())
	var signature := SignatureArc.car_profile(String(car.get("id", "")))
	scene_report_label.text = "%s / %d GUARD%s\nTRAIN: %s" % [String(car.get("name", "UNKNOWN CAR")).to_upper(), enemy_names.size(), "" if enemy_names.size() == 1 else "S", String(signature.get("hazard_name", "STABLE"))]
	scene_report_label.tooltip_text = "%s\n%s\n%s\nClick a character to inspect. Teal lines are clear shots; amber dashed lines require movement." % [String(signature.get("situation", "")), ", ".join(enemy_names), " • ".join(tags)]
	var grenade_count := int(current_inventory.get("clockwork_grenade", 0))
	var tonic_count := int(current_inventory.get("focus_tonic", 0))
	var active_bonds := 0
	for raw_relationship in Array(current_crew_campaign.get("relationships", [])):
		if int(Dictionary(raw_relationship).get("bond", 0)) != 0:
			active_bonds += 1
	planning_bonus_label.text = "GEAR / %dG / %dT" % [grenade_count, tonic_count]
	planning_bonus_label.tooltip_text = "CAR BUFFS / %s\nClick any operative for the full breakdown." % RunState.format_bonus_summary(current_bonuses)


func _populate_plan_cards() -> void:
	_clear_children(plan_list)
	plan_buttons.clear()
	for index in range(plans.size()):
		var plan := plans[index]
		var family := String(plan.get("tactic_family", ""))
		var button := _button(_plan_card_text(plan, index), false)
		button.custom_minimum_size.y = 46; button.size_flags_horizontal = Control.SIZE_EXPAND_FILL; button.clip_text = true; button.add_theme_font_size_override("font_size", 11); button.alignment = HORIZONTAL_ALIGNMENT_LEFT; button.tooltip_text = "%s\n%s" % [String(plan.get("short_summary", "")), String(plan.get("summary", ""))]; button.pressed.connect(_select_plan.bind(index)); plan_list.add_child(button); plan_buttons.append(button)
		_reserve_button_content(button, 42)
		var icon := TacticalFamilyIcon.new()
		icon.name = "FamilyIcon"
		icon.family = family
		icon.anchor_top = 0.5; icon.anchor_bottom = 0.5
		icon.offset_left = 8; icon.offset_right = 34; icon.offset_top = -13; icon.offset_bottom = 13
		button.add_child(icon)
	_update_plan_button_styles()


func _opening_label(plan: Dictionary) -> String:
	if bool(plan.get("opening_requires_move", false)):
		return "MOVE FIRST"
	if plan.has("opening_hit_chance"):
		return "OPENING SHOT %d%%" % roundi(float(plan["opening_hit_chance"]) * 100.0)
	return "POSITION DEPENDENT"


func _plan_card_text(plan: Dictionary, index: int) -> String:
	var marker := "PREVIOUS / " if String(plan.get("id", "")) == previous_plan_id else ""
	return "%s%d  %s\n%s / %s RISK" % [marker, index + 1, String(plan.get("title", "Plan")).to_upper(), _opening_label(plan), String(plan.get("risk_level", "MEDIUM"))]


func _populate_fallbacks() -> void:
	_clear_children(fallback_list)
	fallback_buttons.clear()
	for index in range(PlanCatalog.FALLBACKS.size()):
		var fallback := Dictionary(PlanCatalog.FALLBACKS[index])
		var marker := "↻ " if String(fallback.get("id", "")) == previous_fallback_id else ""
		var button := _button("%s%s  —  %s" % [marker, String(fallback.get("title", "FALLBACK")), String(fallback.get("short_description", ""))], false); button.tooltip_text = String(fallback.get("description", "")); button.size_flags_horizontal = Control.SIZE_EXPAND_FILL; button.custom_minimum_size.y = 30; button.add_theme_font_size_override("font_size", 11); button.alignment = HORIZONTAL_ALIGNMENT_LEFT; button.pressed.connect(_select_fallback.bind(index)); fallback_list.add_child(button); fallback_buttons.append(button)
	_update_fallback_button_styles()
	var selected := Dictionary(PlanCatalog.FALLBACKS[selected_fallback_index])
	fallback_button.text = "FALLBACK / %s  v" % String(selected.get("title", "HOLD THE PLAN"))
	fallback_effect_label.text = String(selected.get("short_description", ""))


func _refresh_plan_detail() -> void:
	if plans.is_empty():
		plan_detail_title.text = "NO VIABLE PLAN"; plan_detail_body.text = "The current crew and encounter produced no valid authored approach."; confirm_button.disabled = true; return
	var plan := plans[selected_plan_index]
	var fallback := Dictionary(PlanCatalog.FALLBACKS[selected_fallback_index])
	# The board and director calculate exact opening facts synchronously before copy is drawn.
	plan_previewed.emit(plan, fallback)
	plan_detail_title.text = String(plan.get("title", "Plan"))
	var hit_text := _opening_label(plan)
	if selected_plan_index < plan_buttons.size():
		plan_buttons[selected_plan_index].text = _plan_card_text(plan, selected_plan_index)
	var warning := String(plan.get("compatibility_warning", ""))
	var assignment_lines: Array[String] = []
	for crew_id in Dictionary(plan.get("orders", {})):
		var order: Dictionary = Dictionary(plan.get("orders", {}))[crew_id]
		assignment_lines.append("%s → %s / %s / %s" % [String(crew_id).to_upper(), String(order.get("target_name", "nearest threat")).to_upper(), Types.zone_name(int(order.get("body_priority", Types.BodyZone.TORSO))).to_upper(), String(order.get("objective", "pressure")).to_upper()])
	var execution_text := "\n[color=#8fb3b2]ASSIGNMENTS[/color]  %s" % "  •  ".join(assignment_lines)
	var gear_text := ""
	if not String(plan.get("gear_item", "")).is_empty():
		gear_text = "\n[color=#e3b65c]COMMITTED GEAR[/color]  %s / %s — %s" % [String(plan.get("gear_item", "")).replace("_", " ").to_upper(), String(plan.get("gear_user_name", "CREW")).to_upper(), String(plan.get("gear_trigger", "Use when legal."))]
	var fallback_text := "\n[color=#72d8b6]FALLBACK PREVIEW / %s[/color]  %s" % [String(fallback.get("title", "HOLD THE PLAN")), _fallback_effect_text(fallback, plan)]
	var signature := SignatureArc.car_profile(String(current_car.get("id", "")))
	var train_text := "\n[color=#e3b65c]LIVING TRAIN[/color]  %s — %s" % [String(signature.get("hazard_name", "STABLE")), String(signature.get("counter_text", "No authored counter."))] if not signature.is_empty() else ""
	if not signature.is_empty():
		train_text += "\n[color=#ff9b82]ENEMY DOCTRINE / %s[/color]  %s" % [String(signature.get("doctrine_name", "GUARD LINE")), String(signature.get("doctrine_text", ""))]
	var counterplay := String(plan.get("counterplay_short", ""))
	if not counterplay.is_empty():
		train_text += "\n[color=#72d8b6]COUNTERPLAY[/color]  " + counterplay
	plan_detail_body.text = (
		"[color=#e5f6f2]%s[/color]\n\n"
		+ "[color=#72d8b6]ADVANTAGE[/color]  %s\n"
		+ "[color=#ff9b82]RISK / %s[/color]  %s\n"
		+ "[color=#e3b65c]OPENING[/color]  %s → %s / %s%s%s%s%s"
	) % [String(plan.get("summary", "")), String(plan.get("advantage", "")), String(plan.get("risk_unit_name", "CREW")).to_upper(), String(plan.get("risk_short", plan.get("risk", ""))), String(plan.get("target_name", "nearest guard")), Types.zone_name(int(plan.get("body_priority", Types.BodyZone.TORSO))).to_upper(), hit_text, _formation_preview_text(plan, fallback), execution_text, gear_text, fallback_text + train_text + ("\n[color=#e3b65c]FIT WARNING[/color]  %s" % warning if not warning.is_empty() else "")]
	var gear := String(plan.get("gear_item", ""))
	var overview := String(plan.get("short_summary", "Execute the opening."))
	if String(plan.get("risk_level", "")).to_lower() == "high" or plan.has("risk_short"):
		overview = "DANGER / " + _concise_risk(plan)
	planning_preview_label.text = "[color=#e5f6f2]%s[/color]\n[color=#e3b65c]OPEN[/color] %s • %s • %s  [color=#ff7d6e]RISK[/color] %s%s" % [overview, String(plan.get("target_name", "nearest guard")), Types.zone_name(int(plan.get("body_priority", Types.BodyZone.TORSO))).to_upper(), hit_text, String(plan.get("risk_unit_name", "CREW")).to_upper(), "  [color=#e3b65c]GEAR[/color] %s" % gear.replace("_", " ").to_upper() if not gear.is_empty() else ""]
	planning_preview_label.tooltip_text = String(plan.get("risk", ""))
	confirm_button.disabled = false


func _concise_risk(plan: Dictionary) -> String:
	var authored := String(plan.get("risk_short", plan.get("risk", "See Plan Details before committing.")))
	var words := authored.split(" ", false)
	return authored if words.size() <= 16 else " ".join(words.slice(0, 16)) + "..."


func _formation_preview_text(plan: Dictionary, fallback: Dictionary) -> String:
	var protection := Dictionary(plan.get("formation_protection", {}))
	var lines: Array[String] = []
	for unit in current_crew:
		var resistance := float(protection.get(unit.roster_id, 0.0))
		var torso := Dictionary(unit.body_state.get(Types.BodyZone.TORSO, {}))
		if String(fallback.get("id", "")) == "protect_wounded" and float(torso.get("hp", 0)) / maxf(1.0, float(torso.get("max_hp", 1))) < 0.4:
			resistance = maxf(resistance, 0.46)
		lines.append("%s %d%%" % [unit.display_name.get_slice(" ", 0).to_upper(), roundi(resistance * 100.0)])
	return "\n[color=#72d8b6]OPENING PROTECTION[/color] %s less body damage; formation needs physical cover or an ally within 3 tiles." % " / ".join(lines)


func _select_plan(index: int) -> void:
	selected_plan_index = index
	inspector_panel.visible = false
	planning_details.visible = false
	_update_plan_button_styles()
	_refresh_plan_detail()
	if training_mode and training_step == 1:
		training_step = 2
		_refresh_training_prompt()


func _select_fallback(index: int) -> void:
	selected_fallback_index = index
	fallback_picker.visible = false
	var fallback := Dictionary(PlanCatalog.FALLBACKS[selected_fallback_index])
	fallback_button.text = "FALLBACK / %s  v" % String(fallback.get("title", "HOLD THE PLAN"))
	fallback_effect_label.text = String(fallback.get("short_description", ""))
	_update_fallback_button_styles()
	_refresh_plan_detail()
	if training_mode and training_step <= 2:
		training_step = 3
		_refresh_training_prompt()


func _confirm_plan() -> void:
	if plans.is_empty(): return
	if training_mode:
		training_step = 4
		_refresh_training_prompt()
	planning_confirmed.emit(plans[selected_plan_index].duplicate(true), Dictionary(PlanCatalog.FALLBACKS[selected_fallback_index]).duplicate(true))


func _toggle_fallback_picker() -> void:
	planning_details.visible = false
	inspector_panel.visible = false
	fallback_picker.visible = not fallback_picker.visible
	if fallback_picker.visible and not fallback_buttons.is_empty():
		_schedule_focus(fallback_buttons[selected_fallback_index])


func _restore_mode_focus() -> void:
	if planning_root.visible and not plan_buttons.is_empty():
		_schedule_focus(plan_buttons[selected_plan_index])
	elif combat_root.visible and is_instance_valid(pause_button):
		_schedule_focus(pause_button)


func _schedule_focus(control: Control) -> void:
	_focus_weak.call_deferred(weakref(control))


func _focus_weak(reference: WeakRef) -> void:
	var control = reference.get_ref()
	if is_instance_valid(control) and control.is_inside_tree() and control.is_visible_in_tree():
		control.grab_focus()


func _fallback_effect_text(fallback: Dictionary, plan: Dictionary) -> String:
	match String(fallback.get("id", "hold_plan")):
		"protect_wounded":
			return "When torso health drops below 40%, that operative seeks safety and gains up to 46% body-damage resistance."
		"finish_target":
			return "The crew keeps pressure on %s after injuries force an adaptation." % String(plan.get("target_name", "the opening target"))
		"save_crew":
			return "At plan break, the crew retreats toward the boarding choke and gains up to 46% body-damage resistance."
		"improvise":
			return "Assignments dissolve; each operative selects targets and body zones from their personal combat instinct."
		_:
			return "Assignments persist with no additional protection unless an objective becomes impossible."


func _update_plan_button_styles() -> void:
	for index in range(plan_buttons.size()):
		var selected := index == selected_plan_index
		var style := _box(Color(0.18, 0.13, 0.05, 0.96) if selected else Color(0.03, 0.10, 0.11, 0.94), _brass if selected else _border, 5)
		style.content_margin_left = 42
		plan_buttons[index].add_theme_stylebox_override("normal", style)


func _update_fallback_button_styles() -> void:
	for index in range(fallback_buttons.size()):
		var selected := index == selected_fallback_index
		fallback_buttons[index].add_theme_stylebox_override("normal", _box(Color(0.17, 0.12, 0.04, 0.96) if selected else Color(0.03, 0.09, 0.10, 0.94), _brass if selected else _border, 4))


func _populate_crew_row(row: HBoxContainer, detailed: bool) -> void:
	if row.get_child_count() != current_crew.size():
		_clear_children(row)
		for unit in current_crew:
			var new_button := _button("", false)
			new_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			new_button.custom_minimum_size = Vector2(0.0, 84.0 if detailed else 46.0)
			if row == combat_crew_row:
				new_button.add_theme_font_size_override("font_size", 10)
			if row == planning_crew_row:
				new_button.custom_minimum_size = Vector2(132.0, 44.0)
				new_button.add_theme_font_size_override("font_size", 12)
			new_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
			var portrait_path := "res://assets/ui/portraits/%s.png" % unit.roster_id
			if ResourceLoader.exists(portrait_path):
				if row == planning_crew_row:
					# Native Button icons shrink to zero when labels get long. Reserve a fixed portrait column.
					_reserve_button_content(new_button, 42)
					var portrait := TextureRect.new()
					portrait.name = "CrewPortrait"
					portrait.texture = load(portrait_path) as Texture2D
					portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
					portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
					portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
					portrait.anchor_top = 0.5; portrait.anchor_bottom = 0.5
					portrait.offset_left = 8; portrait.offset_right = 34; portrait.offset_top = -17; portrait.offset_bottom = 17
					new_button.add_child(portrait)
				else:
					new_button.icon = load(portrait_path) as Texture2D
					new_button.expand_icon = true
					new_button.add_theme_constant_override("icon_max_width", 36)
			new_button.tooltip_text = "Open body, weapon, and car-buff details."
			new_button.pressed.connect(_on_crew_card_pressed.bind(unit.roster_id))
			row.add_child(new_button)
	for index in range(current_crew.size()):
		var unit := current_crew[index]
		var button := row.get_child(index) as Button
		if button == null or not is_instance_valid(unit):
			continue
		var condition := "READY"
		if not unit.is_alive: condition = "DOWN"
		elif unit.arms_crippled() and unit.legs_crippled(): condition = "ARMS + LEGS CRIPPLED"
		elif unit.arms_crippled(): condition = "ARMS CRIPPLED"
		elif unit.legs_crippled(): condition = "LEGS CRIPPLED"
		var torso: Dictionary = unit.body_state[Types.BodyZone.TORSO]
		if unit.is_alive and int(torso["hp"]) <= int(torso["max_hp"]) * 0.4:
			condition = "CRITICAL TORSO"
		button.text = "%s\n%s  •  TORSO %d/%d%s" % [unit.display_name.to_upper(), condition, int(torso["hp"]), int(torso["max_hp"]), "\n%s / %d-%d AMMO" % [unit.weapon_name.to_upper(), unit.ammunition, unit.magazine_size] if detailed else ""]
		if row == combat_crew_row:
			button.clip_text = true
			button.text = "%s\n%s" % [unit.display_name.get_slice(" ", 0).to_upper(), "LOST" if not unit.is_alive else "T %d/%d  /  %d/%d%s" % [int(torso["hp"]), int(torso["max_hp"]), unit.ammunition, unit.magazine_size, " !" if condition != "READY" else ""]]
		if row == planning_crew_row:
			button.text = "%s\n%d/%d%s" % [unit.display_name.get_slice(" ", 0).to_upper(), int(torso["hp"]), int(torso["max_hp"]), " !" if condition != "READY" else ""]
			button.tooltip_text = "%s / %s\n%s · %d/%d AMMO\nCLICK FOR BODY / WEAPON / BUFFS" % [unit.display_name, condition, unit.weapon_name, unit.ammunition, unit.magazine_size]


func _on_crew_card_pressed(roster_id: String) -> void:
	inspector_requested.emit(roster_id)


func _update_speed_buttons(speed: float, is_paused: bool) -> void:
	for key in speed_buttons:
		var selected := is_equal_approx(float(key), speed) and not is_paused
		speed_buttons[key].add_theme_stylebox_override("normal", _box(Color(0.18, 0.13, 0.05, 0.96) if selected else Color(0.03, 0.09, 0.10, 0.94), _brass if selected else _border, 4))


func _full_root(root_name: String) -> Control:
	var root := Control.new(); root.name = root_name; root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); root.mouse_filter = Control.MOUSE_FILTER_IGNORE; return root


func _panel(color: Color = Color.TRANSPARENT) -> PanelContainer:
	var panel := PanelContainer.new(); panel.add_theme_stylebox_override("panel", _box(_panel_color if color == Color.TRANSPARENT else color, _border, 7)); return panel


func _box(color: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new(); style.bg_color = color; style.border_color = border; style.set_border_width_all(1); style.set_corner_radius_all(radius); style.content_margin_left = 10; style.content_margin_right = 10; style.content_margin_top = 7; style.content_margin_bottom = 7; return style


func _button(text_value: String, prominent: bool) -> Button:
	var button := Button.new(); button.text = text_value; button.add_theme_font_size_override("font_size", 13); button.add_theme_color_override("font_color", _ink); button.add_theme_stylebox_override("normal", _box(Color(0.22, 0.15, 0.05, 0.97) if prominent else Color(0.03, 0.10, 0.11, 0.95), _brass if prominent else _border, 4)); button.add_theme_stylebox_override("hover", _box(Color(0.30, 0.21, 0.07, 1.0), _brass, 4)); button.add_theme_stylebox_override("pressed", _box(Color(0.13, 0.26, 0.27, 1.0), _green, 4)); return button


func _reserve_button_content(button: Button, left_inset: float) -> void:
	# Keep artwork separate in every interaction state; no whitespace-padding tricks.
	for state in ["normal", "hover", "pressed", "disabled", "focus"]:
		var style := button.get_theme_stylebox(state).duplicate() as StyleBox
		style.content_margin_left = left_inset
		button.add_theme_stylebox_override(state, style)


func _label(text_value: String, size: int, color: Color) -> Label:
	var label := Label.new(); label.text = text_value; label.add_theme_font_size_override("font_size", maxi(12, size)); label.add_theme_color_override("font_color", color); return label


func _margin(left: int, right: int, top: int, bottom: int) -> MarginContainer:
	var margin := MarginContainer.new(); margin.add_theme_constant_override("margin_left", left); margin.add_theme_constant_override("margin_right", right); margin.add_theme_constant_override("margin_top", top); margin.add_theme_constant_override("margin_bottom", bottom); return margin


func _clear_children(parent: Node) -> void:
	for child in parent.get_children():
		parent.remove_child(child)
		child.queue_free()


func _apply_text_scale(node: Node) -> void:
	if node is Label or node is Button:
		var control := node as Control
		if not control.has_meta("teen_ready_base_font_size"):
			control.set_meta("teen_ready_base_font_size", control.get_theme_font_size("font_size"))
		control.add_theme_font_size_override("font_size", maxi(10, roundi(float(control.get_meta("teen_ready_base_font_size")) * text_scale)))
	elif node is RichTextLabel:
		var rich := node as RichTextLabel
		for font_key in ["normal_font_size", "bold_font_size", "italics_font_size", "bold_italics_font_size", "mono_font_size"]:
			var meta_key := "teen_ready_%s" % font_key
			if not rich.has_meta(meta_key):
				rich.set_meta(meta_key, rich.get_theme_font_size(font_key))
			rich.add_theme_font_size_override(font_key, maxi(10, roundi(float(rich.get_meta(meta_key)) * text_scale)))
	for child in node.get_children():
		_apply_text_scale(child)
