class_name BrasslineCombatCatalog
extends RefCounted

const WEAPONS := {
	"longshot_rifle": {
		"name": "Longshot Rifle",
		"damage": 3.4,
		"range": 10,
		"magazine": 4,
		"accuracy": 0.06,
		"critical": 0.04,
		"tagline": "Four precise rounds / excels at long sightlines",
	},
	"breach_gun": {
		"name": "Breach Gun",
		"damage": 4.4,
		"range": 5,
		"magazine": 2,
		"accuracy": 0.03,
		"critical": 0.03,
		"tagline": "Two heavy shells / brutal inside six tiles",
	},
	"coil_pistol": {
		"name": "Coil Pistol",
		"damage": 2.9,
		"range": 8,
		"magazine": 6,
		"accuracy": 0.03,
		"critical": 0.02,
		"tagline": "Six charged rounds / mobile and reliable",
	},
	"rivet_carbine": {
		"name": "Rivet Carbine",
		"damage": 3.2,
		"range": 7,
		"magazine": 5,
		"accuracy": 0.04,
		"critical": 0.02,
		"tagline": "Five industrial bolts / stable workshop weapon",
	},
	"duelist_revolver": {
		"name": "Duelist Revolver",
		"damage": 3.3,
		"range": 8,
		"magazine": 6,
		"accuracy": 0.04,
		"critical": 0.07,
		"tagline": "Six quick rounds / elevated critical chance",
	},
	"hand_cannon": {
		"name": "Hand Cannon",
		"damage": 4.1,
		"range": 6,
		"magazine": 3,
		"accuracy": -0.02,
		"critical": 0.09,
		"tagline": "Three thunderous rounds / maximum stopping power",
	},
	"service_revolver": {
		"name": "Service Revolver",
		"damage": 3.0,
		"range": 7,
		"magazine": 6,
		"accuracy": 0.0,
		"critical": 0.0,
		"tagline": "Standard rail-guard sidearm",
	},
}

const ABILITIES := {
	"deadeye": {
		"name": "Deadeye",
		"description": "Free once per car: +25% hit and +20% critical chance on Ada's next shot.",
	},
	"breach_charge": {
		"name": "Breach Charge",
		"description": "Free once per car: Marlow's next shot gains +55% damage and +10% hit chance.",
	},
	"overclock": {
		"name": "Overclock",
		"description": "Free once per car: Nix gains +1 AP and +2 movement for this turn.",
	},
	"field_repair": {
		"name": "Field Repair",
		"description": "Free once per car: Iona restores 4 health to her weakest intact body zone.",
	},
	"quickdraw": {
		"name": "Quickdraw",
		"description": "Free once per car: Silas gains +1 AP and +12% critical chance on his next shot.",
	},
	"iron_stance": {
		"name": "Iron Stance",
		"description": "Free once per car: Rook reduces incoming damage by 40% until his next turn.",
	},
}

const ENEMY_ROLES := {
	"railhand": {
		"label": "RAILHAND",
		"damage_mult": 1.0,
		"range_bonus": 0,
		"move_bonus": 0,
		"hp_bonus": 0,
		"accuracy": 0.0,
		"critical": 0.0,
	},
	"duelist": {
		"label": "DUELIST",
		"damage_mult": 1.04,
		"range_bonus": 1,
		"move_bonus": 1,
		"hp_bonus": 0,
		"accuracy": 0.05,
		"critical": 0.06,
	},
	"marksman": {
		"label": "MARKSMAN",
		"damage_mult": 1.0,
		"range_bonus": 3,
		"move_bonus": 0,
		"hp_bonus": 0,
		"accuracy": 0.09,
		"critical": 0.05,
	},
	"bruiser": {
		"label": "BRUISER",
		"damage_mult": 1.08,
		"range_bonus": -1,
		"move_bonus": 1,
		"hp_bonus": 2,
		"accuracy": -0.03,
		"critical": 0.02,
	},
	"medic": {
		"label": "SURGEON",
		"damage_mult": 0.84,
		"range_bonus": 0,
		"move_bonus": 0,
		"hp_bonus": 0,
		"accuracy": 0.0,
		"critical": 0.0,
	},
	"officer": {
		"label": "OFFICER",
		"damage_mult": 1.05,
		"range_bonus": 1,
		"move_bonus": 0,
		"hp_bonus": 2,
		"accuracy": 0.07,
		"critical": 0.04,
	},
	"boss": {
		"label": "BOSS",
		"damage_mult": 1.08,
		"range_bonus": 2,
		"move_bonus": 1,
		"hp_bonus": 5,
		"accuracy": 0.08,
		"critical": 0.06,
	},
}


static func weapon(weapon_id: String) -> Dictionary:
	return Dictionary(WEAPONS.get(weapon_id, WEAPONS["service_revolver"]))


static func ability(ability_id: String) -> Dictionary:
	return Dictionary(ABILITIES.get(ability_id, {}))


static func enemy_role(role_id: String) -> Dictionary:
	return Dictionary(ENEMY_ROLES.get(role_id, ENEMY_ROLES["railhand"]))
