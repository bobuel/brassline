extends Node3D

const Types := preload("res://scripts/game_types.gd")
const CHARACTER_ROOT := "res://assets/characters/quaternius/"
const ENVIRONMENT_ART := preload("res://scripts/environment_art.gd")
const TRACK_SCENE := preload("res://assets/environment/kenney/train/track-detailed.glb")
const CAMPAIGN_UI_SCRIPT := preload("res://scripts/campaign_ui.gd")
const RUN_STATE_SCRIPT := preload("res://scripts/run_state.gd")
const CombatCatalog := preload("res://scripts/combat_catalog.gd")
const PlanCatalog := preload("res://scripts/plan_catalog.gd")
const SignatureArc := preload("res://scripts/signature_arc.gd")
const AUTOBATTLE_DIRECTOR_SCRIPT := preload("res://scripts/autobattle_director.gd")
const AUTOBATTLE_UI_SCRIPT := preload("res://scripts/autobattle_ui.gd")
const AUDIO_DIRECTOR_SCRIPT := preload("res://scripts/audio_director.gd")
const PROFILE_STATE_SCRIPT := preload("res://scripts/profile_state.gd")
const COMBAT_PRESENTER_SCRIPT := preload("res://scripts/combat_presenter.gd")
const HEIST_SHARE_CARD_SCRIPT := preload("res://scripts/heist_share_card.gd")
const SAVE_PATH := "user://brassline_run.json"
const CREW_START_CELLS: Array[Vector2i] = [Vector2i(1, 2), Vector2i(2, 1), Vector2i(2, 3)]
const CAR_FOCUS_CELLS: Array[Vector2i] = [Vector2i(3, 2), Vector2i(10, 2), Vector2i(16, 2)]
const ENEMY_CAP_BY_CAR: Array[int] = [1, 2, 3, 3, 4, 4, 5]

var board: GridBoard
var turn: TurnController
var camera_rig: TacticalCameraRig
var ui: HeistUI
var campaign_ui: CampaignUI
var autobattle_ui: AutobattleUI
var autobattle_director: AutobattleDirector
var audio_director: BrasslineAudioDirector
var combat_presenter: BrasslineCombatPresenter
var run_state: RefCounted
var profile_state: BrasslineProfileState
var train_art: Node3D
var _moving_scenery: Array[Node3D] = []
var _scenery_speed := 9.0
var _heist_started := false
var _capture_mode := false
var _automation_mode := false
var _save_path := SAVE_PATH
var _profile_path := BrasslineProfileState.DEFAULT_PATH
var _active_car_data: Dictionary = {}
var _active_bonuses: Dictionary = {}
var _pending_autobattle_completion: Dictionary = {}
var _pending_autobattle_victory := false
var _encounter_retry_snapshot: Dictionary = {}
var _active_daily_date := ""
var _controller_mode := false
var _retry_previous_choices := false
var _previous_plan_id := ""
var _previous_fallback_id := ""
var _ledger_pause_open := false
var _settings_pause_open := false
var _share_card_png := PackedByteArray()
var _share_card_cache_code := ""
var _share_card_rendering := false


func _ready() -> void:
	_setup_controller_navigation()
	_capture_mode = "--capture" in OS.get_cmdline_user_args()
	_automation_mode = _is_automation_run()
	if _capture_mode or _automation_mode:
		_profile_path = "user://brassline_profile_automation_%d.json" % OS.get_process_id()
	profile_state = PROFILE_STATE_SCRIPT.new()
	if not (_capture_mode or _automation_mode):
		profile_state.load_from_disk(_profile_path)
	profile_state.ensure_roster(["ada", "marlow", "nix", "iona", "silas", "rook"])
	profile_state.save_to_disk(_profile_path)

	_build_environment()
	_build_moving_scenery()

	board = GridBoard.new()
	board.name = "ClockworkExpress"
	add_child(board)
	train_art = ENVIRONMENT_ART.new()
	train_art.name = "ModularTrainArt"
	board.add_child(train_art)
	train_art.setup(board)

	camera_rig = TacticalCameraRig.new()
	camera_rig.name = "CameraRig"
	add_child(camera_rig)

	turn = TurnController.new()
	turn.name = "TurnController"
	turn.setup(board)
	add_child(turn)

	_spawn_unit("Ada Brass", Types.Team.PLAYER, Vector2i(1, 2), 3.0, 9, "Casual_2.gltf", 4)
	_spawn_unit("Marlow Pike", Types.Team.PLAYER, Vector2i(2, 1), 3.8, 6, "Adventurer.gltf", 5)
	_spawn_unit("Nix Bell", Types.Team.PLAYER, Vector2i(2, 3), 2.8, 8, "Punk.gltf", 6)
	_spawn_unit("Conductor Voss", Types.Team.ENEMY, Vector2i(8, 1), 3.2, 7, "Suit.gltf")
	_spawn_unit("Boiler Guard", Types.Team.ENEMY, Vector2i(11, 3), 3.5, 6, "Worker.gltf")
	_spawn_unit("Rail Marshal", Types.Team.ENEMY, Vector2i(15, 2), 3.4, 8, "Swat.gltf")
	_spawn_unit("Vault Keeper", Types.Team.ENEMY, Vector2i(18, 3), 3.0, 7, "Suit.gltf")

	ui = HeistUI.new()
	ui.name = "HeistUI"
	add_child(ui)
	campaign_ui = CAMPAIGN_UI_SCRIPT.new()
	campaign_ui.name = "CampaignUI"
	add_child(campaign_ui)
	campaign_ui.set_profile(profile_state)
	autobattle_director = AUTOBATTLE_DIRECTOR_SCRIPT.new()
	autobattle_director.name = "AutobattleDirector"
	autobattle_director.setup(turn)
	add_child(autobattle_director)
	autobattle_ui = AUTOBATTLE_UI_SCRIPT.new()
	autobattle_ui.name = "AutobattleUI"
	add_child(autobattle_ui)
	combat_presenter = COMBAT_PRESENTER_SCRIPT.new()
	combat_presenter.name = "CombatPresenter"
	combat_presenter.setup(camera_rig, autobattle_ui)
	add_child(combat_presenter)
	audio_director = AUDIO_DIRECTOR_SCRIPT.new()
	audio_director.name = "AudioDirector"
	add_child(audio_director)

	turn.state_changed.connect(_on_turn_state_changed)
	turn.selection_changed.connect(_on_selection_changed)
	turn.log_entry.connect(_on_log_entry)
	turn.mission_finished.connect(_on_mission_finished)
	turn.attack_resolved.connect(audio_director.on_attack_resolved)
	turn.environment_resolved.connect(audio_director.on_environment_resolved)
	ui.zone_requested.connect(_on_zone_requested)
	ui.attack_requested.connect(_on_attack_requested)
	ui.reload_requested.connect(_on_reload_requested)
	ui.overwatch_requested.connect(_on_overwatch_requested)
	ui.cover_requested.connect(_on_cover_requested)
	ui.ability_requested.connect(_on_ability_requested)
	ui.grenade_requested.connect(_on_grenade_requested)
	ui.tonic_requested.connect(_on_tonic_requested)
	ui.end_turn_requested.connect(_on_end_turn_requested)
	ui.restart_requested.connect(_on_restart_requested)
	campaign_ui.crew_confirmed.connect(_on_crew_confirmed)
	campaign_ui.car_selected.connect(_on_car_selected)
	campaign_ui.car_prep_requested.connect(_on_car_prep_requested)
	campaign_ui.crew_review_requested.connect(_on_crew_review_requested)
	campaign_ui.next_car_chosen.connect(_on_next_car_chosen)
	campaign_ui.prep_back_requested.connect(_on_prep_back_requested)
	campaign_ui.item_requested.connect(_on_item_requested)
	campaign_ui.event_resolved.connect(_on_event_resolved)
	campaign_ui.event_choice_requested.connect(_on_event_choice_requested)
	campaign_ui.crew_scene_choice_requested.connect(_on_crew_scene_choice_requested)
	campaign_ui.continue_requested.connect(_on_continue_requested)
	campaign_ui.audio_captions_changed.connect(audio_director.set_captions_enabled)
	campaign_ui.presentation_settings_changed.connect(_on_presentation_settings_changed)
	campaign_ui.settings_visibility_changed.connect(_on_settings_visibility_changed)
	campaign_ui.retry_requested.connect(_on_retry_requested)
	campaign_ui.abandon_requested.connect(_on_abandon_requested)
	campaign_ui.training_requested.connect(_on_training_requested)
	campaign_ui.daily_challenge_requested.connect(_on_daily_challenge_requested)
	campaign_ui.share_card_requested.connect(_on_share_card_requested)
	campaign_ui.challenge_code_copy_requested.connect(_on_challenge_code_copy_requested)
	campaign_ui.challenge_code_requested.connect(_on_challenge_code_requested)
	campaign_ui.profile_changed.connect(func() -> void: profile_state.save_to_disk(_profile_path))
	audio_director.set_captions_enabled(campaign_ui.audio_captions_enabled)
	autobattle_ui.plan_previewed.connect(_on_plan_previewed)
	autobattle_ui.planning_confirmed.connect(_on_planning_confirmed)
	autobattle_ui.pause_requested.connect(_on_autobattle_pause_requested)
	autobattle_ui.speed_requested.connect(_on_autobattle_speed_requested)
	autobattle_ui.aftermath_continue_requested.connect(_on_aftermath_continue_requested)
	autobattle_ui.inspector_requested.connect(_on_autobattle_inspector_requested)
	autobattle_ui.inspection_visibility_changed.connect(_on_ledger_visibility_changed)
	autobattle_ui.settings_requested.connect(_on_in_run_settings_requested)
	autobattle_director.timeline_changed.connect(autobattle_ui.on_timeline_changed)
	autobattle_director.intent_changed.connect(autobattle_ui.on_intent_changed)
	autobattle_director.plan_status_changed.connect(autobattle_ui.on_plan_status_changed)
	autobattle_director.speed_changed.connect(autobattle_ui.on_speed_changed)
	autobattle_director.round_started.connect(autobattle_ui.on_round_started)
	autobattle_director.round_started.connect(audio_director.on_round_started)
	autobattle_director.milestone_added.connect(autobattle_ui.on_milestone_added)
	autobattle_director.consumable_used.connect(_on_autobattle_consumable_used)
	autobattle_director.train_event_changed.connect(_on_train_event_changed)
	autobattle_director.doctrine_changed.connect(autobattle_ui.on_doctrine_changed)
	autobattle_director.doctrine_changed.connect(audio_director.on_doctrine_changed)
	autobattle_director.presentation_beat.connect(combat_presenter.present)
	autobattle_director.speed_changed.connect(combat_presenter.set_speed)
	get_viewport().size_changed.connect(_on_planning_viewport_changed)
	_on_presentation_settings_changed(campaign_ui.cinematic_focus_mode, campaign_ui.reduced_motion_enabled, campaign_ui.text_scale)

	await get_tree().process_frame
	if _capture_mode or _automation_mode:
		# Test/capture completion clears a checkpoint just like normal play. Isolate
		# that path even when automatic saving is disabled so QA cannot clear the
		# player's actual Continue Run file.
		_save_path = "user://brassline_automation_%d.json" % OS.get_process_id()
		_start_existing_heist()
	else:
		ui.set_hud_visible(false)
		camera_rig.input_enabled = false
		_refresh_continue_option()
		campaign_ui.show_intro()
	if _capture_mode:
		_capture_preview.call_deferred()


func _setup_controller_navigation() -> void:
	# Godot's built-in UI defaults in this runtime contain keyboard events only.
	# Keep those bindings and explicitly support every connected controller.
	var button_bindings := {"ui_accept": JOY_BUTTON_A, "ui_cancel": JOY_BUTTON_B, "ui_left": JOY_BUTTON_DPAD_LEFT, "ui_right": JOY_BUTTON_DPAD_RIGHT, "ui_up": JOY_BUTTON_DPAD_UP, "ui_down": JOY_BUTTON_DPAD_DOWN}
	for action in button_bindings:
		if not InputMap.has_action(action): InputMap.add_action(action)
		var event := InputEventJoypadButton.new()
		event.device = -1
		event.button_index = button_bindings[action]
		if not InputMap.action_has_event(action, event): InputMap.action_add_event(action, event)
	for action in ["ui_left", "ui_right", "ui_up", "ui_down"]:
		var event := InputEventJoypadMotion.new()
		event.device = -1
		event.axis = JOY_AXIS_LEFT_X if action in ["ui_left", "ui_right"] else JOY_AXIS_LEFT_Y
		event.axis_value = -1.0 if action in ["ui_left", "ui_up"] else 1.0
		if not InputMap.action_has_event(action, event): InputMap.action_add_event(action, event)


func _process(delta: float) -> void:
	if is_instance_valid(campaign_ui) and campaign_ui.reduced_motion_enabled:
		return
	for piece in _moving_scenery:
		piece.position.x -= _scenery_speed * delta
		if piece.position.x < -42.0:
			piece.position.x += 84.0


func _input(event: InputEvent) -> void:
	var next_controller_mode := _controller_mode
	if event is InputEventJoypadButton or event is InputEventJoypadMotion:
		next_controller_mode = true
	elif (event is InputEventKey and event.pressed) or (event is InputEventMouseButton and event.pressed):
		next_controller_mode = false
	if next_controller_mode != _controller_mode:
		_controller_mode = next_controller_mode
		campaign_ui.set_controller_mode(_controller_mode)
		autobattle_ui.set_controller_mode(_controller_mode)


func _focus_camera(world_position: Vector3) -> void:
	if is_instance_valid(campaign_ui) and campaign_ui.reduced_motion_enabled:
		camera_rig.focus_world(world_position)
	else:
		camera_rig.focus_world_smooth(world_position)


func _unhandled_input(event: InputEvent) -> void:
	if not _heist_started or campaign_ui.is_frontend_open() or campaign_ui.in_run_settings_open():
		return
	if autobattle_ui.planning_root.visible:
		if event is InputEventKey and event.pressed and not event.echo:
			if event.physical_keycode in [KEY_1, KEY_2, KEY_3, KEY_4]:
				var index := int(event.physical_keycode) - int(KEY_1)
				if index < autobattle_ui.plans.size():
					autobattle_ui._select_plan(index)
			elif event.physical_keycode == KEY_I:
				autobattle_ui.toggle_inspector()
			elif event.physical_keycode == KEY_ESCAPE:
				autobattle_ui.inspector_panel.visible = false
				autobattle_ui.planning_details.visible = false
			elif event.physical_keycode == KEY_HOME:
				_on_planning_viewport_changed()
		elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			_handle_planning_inspection(event.position)
		elif event is InputEventJoypadButton and event.pressed:
			match event.button_index:
				JOY_BUTTON_X:
					autobattle_ui.toggle_plan_details()
				JOY_BUTTON_Y:
					autobattle_ui.toggle_inspector()
				JOY_BUTTON_B:
					autobattle_ui.inspector_panel.visible = false
					autobattle_ui.planning_details.visible = false
		# Planning never routes clicks/keys into the retired manual combat controls.
		return
	if is_instance_valid(autobattle_director) and autobattle_director.running:
		if event is InputEventKey and (event.physical_keycode == KEY_SHIFT or event.keycode == KEY_SHIFT):
			autobattle_director.set_inspect_slowdown(event.pressed)
			return
		if event is InputEventJoypadMotion and event.axis == JOY_AXIS_TRIGGER_LEFT:
			autobattle_director.set_inspect_slowdown(event.axis_value > 0.45)
			return
		if event is InputEventKey and event.pressed and not event.echo:
			match event.physical_keycode:
				KEY_SPACE:
					autobattle_director.toggle_pause()
				KEY_1:
					autobattle_director.set_speed(1.0)
				KEY_2:
					autobattle_director.set_speed(2.0)
				KEY_4:
					autobattle_director.set_speed(4.0)
				KEY_I:
					autobattle_ui.toggle_inspector()
				KEY_HOME:
					camera_rig.reset_view()
		elif event is InputEventJoypadButton and event.pressed:
			match event.button_index:
				JOY_BUTTON_START:
					autobattle_director.toggle_pause()
				JOY_BUTTON_Y:
					autobattle_ui.toggle_inspector()
				JOY_BUTTON_LEFT_SHOULDER:
					autobattle_director.set_speed(1.0 if autobattle_director.battle_speed <= 2.0 else 2.0)
				JOY_BUTTON_RIGHT_SHOULDER:
					autobattle_director.set_speed(2.0 if autobattle_director.battle_speed < 2.0 else 4.0)
				JOY_BUTTON_B:
					autobattle_ui.inspector_panel.visible = false
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_1:
				turn.set_target_zone(Types.BodyZone.HEAD)
			KEY_2:
				turn.set_target_zone(Types.BodyZone.TORSO)
			KEY_3:
				turn.set_target_zone(Types.BodyZone.ARMS)
			KEY_4:
				turn.set_target_zone(Types.BodyZone.LEGS)
			KEY_F:
				turn.try_attack()
			KEY_R:
				_on_reload_requested()
			KEY_O:
				_on_overwatch_requested()
			KEY_C:
				_on_cover_requested()
			KEY_B:
				_on_ability_requested()
			KEY_L:
				ui.toggle_log()
			KEY_I:
				ui.toggle_stats()
			KEY_G:
				_on_grenade_requested()
			KEY_T:
				_on_tonic_requested()
			KEY_SPACE:
				turn.end_player_turn()
			KEY_HOME:
				camera_rig.reset_view()
			KEY_TAB:
				campaign_ui.select_next_unlocked_car()
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			_handle_world_click(event.position, false)
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			_handle_world_click(event.position, true)


func _handle_planning_inspection(screen_position: Vector2) -> void:
	if not autobattle_ui.planning_battlefield_rect().has_point(screen_position):
		return
	var camera := camera_rig.camera
	var origin := camera.project_ray_origin(screen_position)
	var query := PhysicsRayQueryParameters3D.create(origin, origin + camera.project_ray_normal(screen_position) * 120.0, 2)
	query.collide_with_areas = true
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and hit.get("collider") is TacticalUnit:
		autobattle_ui.show_unit_inspector(hit["collider"] as TacticalUnit)


func _on_planning_viewport_changed() -> void:
	if is_instance_valid(autobattle_ui) and autobattle_ui.planning_root.visible:
		camera_rig.frame_planning_area(autobattle_ui.planning_battlefield_rect())


func _handle_world_click(screen_position: Vector2, attack_click: bool) -> void:
	if not is_instance_valid(camera_rig) or not is_instance_valid(camera_rig.camera):
		return
	var camera := camera_rig.camera
	var origin := camera.project_ray_origin(screen_position)
	var end := origin + camera.project_ray_normal(screen_position) * 120.0
	var query := PhysicsRayQueryParameters3D.create(origin, end, 3)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return
	var collider: Object = hit["collider"]
	if collider is TacticalUnit:
		var unit := collider as TacticalUnit
		if unit.team == Types.Team.PLAYER:
			turn.select_unit(unit)
		else:
			turn.set_target(unit)
			if attack_click:
				turn.try_attack(unit)
		return
	if collider.has_meta("grid_cell") and not attack_click:
		var cell: Vector2i = collider.get_meta("grid_cell")
		turn.try_move(cell)


func _spawn_unit(
		unit_name: String,
		team: Types.Team,
	cell: Vector2i,
	damage: float,
	range_cells: int,
	model_file: String = "",
	movement: int = 5,
	member_id: String = "",
	weapon_id: String = "",
	ability_id: String = "",
	enemy_role_id: String = ""
	) -> TacticalUnit:
	var unit := TacticalUnit.new()
	unit.roster_id = member_id
	unit.set_meta("inspection_id", member_id if not member_id.is_empty() else "enemy:%s:%d:%d" % [unit_name, cell.x, cell.y])
	if not model_file.is_empty():
		unit.visual_model_path = CHARACTER_ROOT + model_file
	add_child(unit)
	unit.setup(unit_name, team, cell, board)
	unit.base_damage = damage
	unit.attack_range = range_cells
	unit.base_movement = movement
	if not weapon_id.is_empty():
		unit.configure_combat_identity(weapon_id, ability_id)
		unit.base_damage = damage
		unit.attack_range = range_cells
	if not enemy_role_id.is_empty():
		unit.configure_enemy_role(enemy_role_id)
	turn.register_unit(unit)
	return unit


func _start_existing_heist() -> void:
	_heist_started = true
	ui.set_hud_visible(true)
	ui.clear_log()
	camera_rig.input_enabled = true
	camera_rig.frame_active_car()
	campaign_ui.skip_to_mission()
	turn.start_battle()
	ui.update_from_turn(turn)
	_update_train_navigator()


func _on_crew_confirmed(crew_ids: Array[String], seed: int = 0) -> void:
	await _start_campaign(crew_ids, seed)


func _start_campaign(crew_ids: Array[String], seed: int, ruleset: String = "train_takeover", daily_date: String = "") -> void:
	_share_card_png.clear()
	_share_card_cache_code = ""
	_active_daily_date = daily_date
	_encounter_retry_snapshot.clear()
	_pending_autobattle_completion.clear()
	_retry_previous_choices = false
	run_state = RUN_STATE_SCRIPT.new()
	run_state.start_new_run(crew_ids, seed, campaign_ui.selected_difficulty)
	run_state.ruleset_id = ruleset
	_write_daily_context()
	campaign_ui.set_continue_available(false)
	await _load_run_encounter()


func _on_training_requested() -> void:
	profile_state.tutorial_complete = false
	profile_state.save_to_disk(_profile_path)
	campaign_ui.selected_crew_ids = ["ada", "marlow", "nix"]
	campaign_ui.show_crew_selection()


func _on_daily_challenge_requested(seed: int) -> void:
	campaign_ui.selected_difficulty = "standard"
	campaign_ui.selected_crew_ids = ["ada", "marlow", "nix"]
	await _start_campaign(campaign_ui.selected_crew_ids.duplicate(), seed, "train_takeover", profile_state.daily_date_label())


func _on_challenge_code_requested(code: String) -> void:
	var challenge := profile_state.parse_challenge_code(code)
	if not bool(challenge.get("ok", false)):
		campaign_ui.set_share_feedback(String(challenge.get("reason", "INVALID CHALLENGE")), false)
		return
	campaign_ui.selected_difficulty = String(challenge["difficulty"])
	var crew_ids: Array[String] = []
	crew_ids.assign(Array(challenge["crew_ids"]))
	campaign_ui.selected_crew_ids = crew_ids.duplicate()
	await _start_campaign(crew_ids, int(challenge["seed"]), String(challenge["ruleset"]))


func _on_challenge_code_copy_requested(code: String) -> void:
	if code.is_empty():
		campaign_ui.set_share_feedback("CHALLENGE CODE UNAVAILABLE", false)
		return
	DisplayServer.clipboard_set(code)
	campaign_ui.set_share_feedback("CHALLENGE CODE COPIED / %s" % code, true)


func _show_run_complete() -> void:
	campaign_ui.show_run_complete(run_state)
	if DisplayServer.get_name() != "headless":
		campaign_ui.set_share_ready(false)
	_prepare_share_card.call_deferred()


func _on_share_card_requested() -> void:
	if not is_instance_valid(run_state) or run_state.phase != "complete":
		campaign_ui.set_share_feedback("HEIST CARD UNAVAILABLE / Finish the run first.", false)
		return
	if _share_card_png.is_empty() or _share_card_cache_code != _share_card_identity():
		await _prepare_share_card()
		if OS.has_feature("web"):
			# A second explicit click retains the browser's user-activation token.
			# Normally the completion screen has already pre-rendered this cache.
			if not _share_card_png.is_empty():
				campaign_ui.set_share_feedback("CARD READY / CLICK SAVE HEIST CARD", true)
			return
	if _share_card_png.is_empty():
		return
	var filename := "brassline_heist_%d.png" % run_state.run_seed
	if OS.has_feature("web"):
		JavaScriptBridge.download_buffer(_share_card_png, filename, "image/png")
		campaign_ui.set_share_feedback("DOWNLOAD REQUESTED / CHECK BROWSER DOWNLOADS", true)
	else:
		var folder := ProjectSettings.globalize_path("user://heist_cards")
		DirAccess.make_dir_recursive_absolute(folder)
		var path := "%s/%s" % [folder, filename]
		var file := FileAccess.open(path, FileAccess.WRITE)
		if file == null:
			campaign_ui.set_share_feedback("HEIST CARD COULD NOT BE SAVED", false)
			return
		file.store_buffer(_share_card_png)
		file.close()
		campaign_ui.set_share_feedback("HEIST CARD SAVED / %s" % path, true)


func _share_card_identity() -> String:
	if not is_instance_valid(run_state) or not is_instance_valid(profile_state):
		return ""
	return profile_state.build_challenge_code(run_state.run_seed, run_state.difficulty_id, run_state.selected_crew_ids, run_state.ruleset_id)


func _build_share_card_data() -> Dictionary:
	if not is_instance_valid(run_state) or not is_instance_valid(profile_state):
		return {}
	var run_code := _share_card_identity()
	var epilogue: Dictionary = run_state.campaign_epilogue()
	var crew_cards: Array[Dictionary] = []
	var injury_summary: Array[String] = []
	var survivor_count := 0
	for crew_id in run_state.selected_crew_ids:
		var member := campaign_ui.roster_member(crew_id)
		var condition := "FALLEN" if run_state.crew_is_down(crew_id) else "SURVIVED"
		if not run_state.crew_is_down(crew_id):
			survivor_count += 1
		var wounds: Array[String] = []
		var body: Dictionary = run_state.body_state_for(crew_id)
		if run_state.crew_is_down(crew_id):
			injury_summary.append("%s: FALLEN" % String(member.get("name", crew_id)))
		else:
			for zone in Types.BodyZone.values():
				var state: Dictionary = body.get(zone, body.get(str(zone), {}))
				if bool(state.get("detached", false)):
					wounds.append("%s LOST" % Types.zone_name(zone).to_upper())
				elif bool(state.get("disabled", false)):
					wounds.append("%s CRIPPLED" % Types.zone_name(zone).to_upper())
				elif int(state.get("hp", 0)) < int(state.get("max_hp", 0)):
					wounds.append("%s %d/%d" % [Types.zone_name(zone).to_upper(), int(state.get("hp", 0)), int(state.get("max_hp", 0))])
			if not wounds.is_empty():
				condition += " / %s" % " / ".join(wounds)
				injury_summary.append("%s: %s" % [String(member.get("name", crew_id)), ", ".join(wounds)])
		crew_cards.append({
			"id": crew_id,
			"name": String(member.get("name", crew_id)),
			"role": String(member.get("role", "OPERATIVE")),
			"condition": condition,
			"mastery": profile_state.mastery_for(crew_id),
			"finish": profile_state.cosmetic_for(crew_id),
		})
	var decisive_moment := "The crew seized the Green Rail."
	if not run_state.plan_history.is_empty():
		var last_plan := Dictionary(run_state.plan_history.back())
		var beats: Array = last_plan.get("milestones", [])
		if not beats.is_empty():
			decisive_moment = String(beats.back())
	var card_data := {
		"grade": String(epilogue.get("grade", "C")),
		"route": String(epilogue.get("route", "THE GREEN RAIL")),
		"seed": run_state.run_seed,
		"difficulty": run_state.difficulty_label(),
		"survivors": survivor_count,
		"crew": crew_cards,
		"injuries": "NO LASTING INJURIES" if injury_summary.is_empty() else "  •  ".join(injury_summary),
		"decisive_moment": decisive_moment,
		"run_code": run_code,
		"blueprint_knowledge": profile_state.blueprint_knowledge,
	}
	return card_data


func _prepare_share_card() -> void:
	if _share_card_rendering or DisplayServer.get_name() == "headless":
		return
	var card_data := _build_share_card_data()
	if card_data.is_empty():
		return
	var run_code := String(card_data["run_code"])
	if _share_card_cache_code == run_code and not _share_card_png.is_empty():
		campaign_ui.set_share_ready(true)
		return
	_share_card_rendering = true
	campaign_ui.set_share_feedback("RENDERING HEIST CARD…", true)
	var viewport := SubViewport.new()
	viewport.size = HEIST_SHARE_CARD_SCRIPT.CARD_SIZE
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.transparent_bg = false
	add_child(viewport)
	var card := HEIST_SHARE_CARD_SCRIPT.new()
	viewport.add_child(card)
	card.setup(card_data)
	for _frame in range(4):
		await get_tree().process_frame
	var card_texture := viewport.get_texture()
	var image: Image = card_texture.get_image() if card_texture != null else null
	_share_card_rendering = false
	if image == null:
		viewport.queue_free()
		campaign_ui.set_share_feedback("HEIST CARD COULD NOT BE RENDERED ON THIS GRAPHICS DEVICE", false)
		return
	viewport.queue_free()
	if run_code != _share_card_identity():
		return
	_share_card_png = image.save_png_to_buffer()
	_share_card_cache_code = run_code
	campaign_ui.set_share_ready(not _share_card_png.is_empty())
	campaign_ui.set_share_feedback("HEIST CARD READY", not _share_card_png.is_empty())


func _load_run_encounter() -> void:
	_heist_started = false
	if is_instance_valid(autobattle_director):
		autobattle_director.stop()
	if is_instance_valid(autobattle_ui):
		autobattle_ui.hide_all()
	board.clear_deployment_preview()
	ui.set_hud_visible(false)
	camera_rig.input_enabled = false
	turn.clear_selection_highlights()
	var previous_units := turn.units.duplicate()
	turn.reset_encounter()
	for existing in previous_units:
		if is_instance_valid(existing):
			existing.queue_free()
	await get_tree().process_frame

	var encounter_variant: int = run_state.encounter_variant_index()
	turn.set_encounter_seed(
		run_state.run_seed
		+ run_state.car_number() * 1009
		+ encounter_variant * 97
		+ int(hash(run_state.current_car_id))
	)
	board.prepare_run_encounter(run_state.current_car_id, encounter_variant)
	if run_state.car_number() == RUN_STATE_SCRIPT.TOTAL_CARS:
		board.prepare_finale_objective()
	train_art.set_active_run_car(run_state.current_car_id, run_state.car_number())
	audio_director.set_car(run_state.current_car_id)
	var bonuses: Dictionary = run_state.squad_bonuses
	for index in range(mini(run_state.selected_crew_ids.size(), CREW_START_CELLS.size())):
		var member_id: String = run_state.selected_crew_ids[index]
		if run_state.crew_is_down(member_id):
			continue
		var member := campaign_ui.roster_member(member_id)
		if member.is_empty():
			continue
		var unit := _spawn_unit(
			String(member["name"]),
			Types.Team.PLAYER,
			CREW_START_CELLS[index],
			float(member["damage"]) + float(bonuses.get("damage", 0.0)),
			int(member["range"]) + int(bonuses.get("range", 0)),
			String(member["model"]),
			int(member["move"]) + int(bonuses.get("movement", 0)),
			member_id,
			String(member.get("weapon_id", "service_revolver")),
			String(member.get("ability_id", ""))
		)
		unit.set_meta("crew_role", String(member.get("role", "OPERATIVE")))
		unit.set_meta("unbuffed_damage", float(member["damage"]))
		unit.set_meta("unbuffed_range", int(member["range"]))
		unit.set_meta("unbuffed_move", int(member["move"]))
		unit.import_body_state(run_state.body_state_for(member_id))
		if is_instance_valid(profile_state) and is_instance_valid(unit._character_visual):
			var palette := profile_state.cosmetic_for(member_id)
			unit.set_meta("cosmetic_id", palette)
			unit._character_visual.apply_cosmetic_palette(palette)
		var nerve_modifiers: Dictionary = run_state.crew_nerve_modifiers(member_id)
		var trust_accuracy: float = run_state.crew_bond_accuracy_bonus(member_id)
		unit.signature_accuracy_bonus += trust_accuracy + float(nerve_modifiers.get("accuracy", 0.0))
		unit.signature_critical_bonus += float(nerve_modifiers.get("critical", 0.0))
		unit.set_meta("crew_trust_accuracy", trust_accuracy)
		unit.set_meta("crew_nerve", int(nerve_modifiers.get("nerve", 0)))
	_spawn_run_enemies(run_state.current_car_id)
	var car_data: Dictionary = run_state.car_data(run_state.current_car_id).duplicate(true)
	car_data["id"] = run_state.current_car_id
	car_data["variant_name"] = run_state.encounter_variant_name()
	car_data["is_finale"] = run_state.car_number() == RUN_STATE_SCRIPT.TOTAL_CARS
	car_data["ruleset_id"] = run_state.ruleset_id
	_active_car_data = car_data.duplicate(true)
	_active_bonuses = bonuses.duplicate(true)
	turn.configure_run_encounter(car_data, run_state.car_number(), bonuses)
	ui.set_run_context(car_data, run_state.car_number(), bonuses)
	campaign_ui.update_run_progress(run_state)
	campaign_ui.skip_to_mission()
	_heist_started = true
	ui.set_hud_visible(true)
	ui.clear_log()
	camera_rig.input_enabled = true
	camera_rig.frame_active_car()
	ui.set_combat_inventory(run_state.inventory)
	ui.push_log("RUN %d / CAR %02d / %s / %s" % [run_state.run_seed, run_state.car_number(), String(car_data.get("name", "Unknown")), run_state.encounter_variant_name().to_upper()])
	if _use_legacy_manual_combat():
		autobattle_ui.hide_all()
		turn.start_battle()
		ui.update_from_turn(turn)
	else:
		_begin_autobattle_planning(car_data, bonuses)
	_update_train_navigator()
	_encounter_retry_snapshot = run_state.to_save_data().duplicate(true)
	_save_run_checkpoint()


func _begin_autobattle_planning(car_data: Dictionary, bonuses: Dictionary) -> void:
	turn.phase = Types.Phase.BUSY
	turn.autobattle_enabled = true
	ui.set_hud_visible(false)
	campaign_ui.navigator.visible = false
	board.clear_highlights()
	camera_rig.input_enabled = false
	camera_rig.frame_planning_area(autobattle_ui.planning_battlefield_rect())
	var recent_ids: Array[String] = []
	if is_instance_valid(run_state):
		recent_ids.assign(run_state.recent_plan_ids)
	var plans := PlanCatalog.generate_plans(
		String(car_data.get("id", run_state.current_car_id if is_instance_valid(run_state) else "baggage")),
		turn.player_units(true),
		turn.enemy_units(true),
		turn,
		bonuses,
		recent_ids,
		run_state.inventory if is_instance_valid(run_state) else {},
		profile_state.unlocked_plan_ids if is_instance_valid(profile_state) else []
	)
	var viable_plans: Array[Dictionary] = []
	for plan in plans:
		plan["deployment_cells"] = autobattle_director.build_deployment(plan)
		if not autobattle_director.deployment_is_safe(Dictionary(plan["deployment_cells"])):
			continue
		_update_planned_opening_chance(plan)
		viable_plans.append(plan)
	var selected_plan := 0
	var selected_fallback := 0
	if _retry_previous_choices:
		for index in range(viable_plans.size()):
			if String(viable_plans[index].get("id", "")) == _previous_plan_id:
				selected_plan = index
				break
		for index in range(PlanCatalog.FALLBACKS.size()):
			if String(PlanCatalog.FALLBACKS[index].get("id", "")) == _previous_fallback_id:
				selected_fallback = index
				break
	autobattle_ui.show_planning({
		"car": car_data,
		"bonuses": bonuses,
		"inventory": run_state.inventory if is_instance_valid(run_state) else {},
		"crew": turn.player_units(true),
		"enemies": turn.enemy_units(true),
		"plans": viable_plans,
		"crew_campaign": run_state.crew_campaign_context() if is_instance_valid(run_state) else {},
		"training": is_instance_valid(profile_state) and not profile_state.tutorial_complete and run_state.car_number() == 1,
		"selected_plan": selected_plan,
		"selected_fallback": selected_fallback,
		"previous_plan_id": _previous_plan_id if _retry_previous_choices else "",
		"previous_fallback_id": _previous_fallback_id if _retry_previous_choices else "",
	})
	autobattle_ui.set_text_scale(campaign_ui.text_scale)


func _update_planned_opening_chance(plan: Dictionary) -> void:
	var assignments: Dictionary = plan.get("assignments", {})
	var shooter_id := String(assignments.get("shooter", ""))
	var deployment: Dictionary = plan.get("deployment_cells", {})
	var orders: Dictionary = plan.get("orders", {})
	var opening: Array[Dictionary] = []
	var original_cells := {}
	var protections := {}
	# Compute cover/formation against the complete ghost deployment, not a mix
	# of one previewed operative and two positions left over from another plan.
	for crew in turn.player_units(true):
		original_cells[crew.roster_id] = crew.grid_cell
		if deployment.has(crew.roster_id):
			crew.grid_cell = deployment[crew.roster_id]
	for crew in turn.player_units(true):
		if not deployment.has(crew.roster_id):
			continue
		protections[crew.roster_id] = autobattle_director.formation_resistance(crew, plan)
		var order: Dictionary = orders.get(crew.roster_id, {})
		var target := instance_from_id(int(order.get("target_instance_id", plan.get("target_instance_id", 0)))) as TacticalUnit
		if not is_instance_valid(target):
			continue
		var zone := int(order.get("body_priority", plan.get("body_priority", Types.BodyZone.TORSO)))
		var chance := turn.attack_chance(crew, target, zone)
		var clear := turn.can_attack(crew, target)
		opening.append({"roster_id": crew.roster_id, "from": crew.grid_cell, "to": target.grid_cell, "target_instance_id": target.get_instance_id(), "target_name": target.display_name, "zone": zone, "clear": clear, "chance": chance, "cover": board.cover_name(target.grid_cell, crew.grid_cell), "risk": crew.roster_id == String(plan.get("risk_unit_id", "")), "protection": protections[crew.roster_id], "opening_action": "FIRE" if clear else "MOVE FIRST"})
		if crew.roster_id == shooter_id:
			plan["opening_hit_chance"] = chance
			plan["opening_requires_move"] = not clear
	for crew in turn.player_units(true):
		crew.grid_cell = original_cells[crew.roster_id]
	plan["opening_preview"] = opening
	plan["formation_protection"] = protections


func _spawn_run_enemies(car_id: String) -> void:
	var data: Dictionary = run_state.car_data(car_id)
	var difficulty := int(data.get("difficulty", 1))
	var profile := _encounter_profile(car_id)
	var raw_enemy_count := 1 + difficulty + floori(float(run_state.car_number() - 1) / 3.0) + int(profile.get("count_bonus", 0))
	raw_enemy_count += _difficulty_enemy_count_bonus()
	var depth_cap: int = ENEMY_CAP_BY_CAR[clampi(run_state.car_number() - 1, 0, ENEMY_CAP_BY_CAR.size() - 1)]
	var enemy_count := 1 if car_id == RUN_STATE_SCRIPT.FIRST_CAR_ID else mini(raw_enemy_count, depth_cap)
	var survivor_count := turn.player_units(true).size()
	# Story explicitly assists a wounded run. Standard/Brutal preserve their
	# authored composition after casualties instead of silently becoming duels.
	if car_id != RUN_STATE_SCRIPT.FIRST_CAR_ID:
		var composition_cap := 4 if run_state.difficulty_id == "brutal" else 3
		if run_state.difficulty_id == "story":
			composition_cap = maxi(1, survivor_count)
		enemy_count = mini(enemy_count, composition_cap)
		if run_state.car_number() == RUN_STATE_SCRIPT.TOTAL_CARS and run_state.difficulty_id != "story":
			enemy_count = maxi(2, enemy_count)
	var models := ["Worker.gltf", "Suit.gltf", "Swat.gltf", "Worker.gltf"]
	var car_name := String(data.get("name", "Rail")).replace(" Car", "")
	var occupied := turn.occupied_cells()
	for index in range(enemy_count):
		var enemy_role_id := _enemy_role_for(car_id, index)
		var spawn_cell := _logical_enemy_spawn_cell(car_id, enemy_role_id, index, occupied)
		var role_label := String(CombatCatalog.enemy_role(enemy_role_id).get("label", "GUARD")).capitalize()
		var guard_name := "Green Railhand" if car_id == RUN_STATE_SCRIPT.FIRST_CAR_ID else "%s %s" % [car_name, role_label]
		if run_state.car_number() == RUN_STATE_SCRIPT.TOTAL_CARS and index == 0:
			guard_name = "Chief Engineer Voss" if car_id == "engine" else "Rail Marshal Voss"
		# Standard guards are attrition threats, not two-hit executioners. Car
		# profiles still create hard-hitting duelists and late-run elites.
		var damage := 2.0 if car_id == RUN_STATE_SCRIPT.FIRST_CAR_ID else (1.90 + float(run_state.car_number()) * 0.13 + float(difficulty) * 0.14) * float(profile.get("damage_multiplier", 1.0))
		damage *= _difficulty_enemy_damage_multiplier()
		var range_cells := 5 if car_id == RUN_STATE_SCRIPT.FIRST_CAR_ID else 5 + difficulty + int(profile.get("range_bonus", 0))
		var model_file: String = String(profile.get("model", models[index % models.size()])) if index == 0 else models[index % models.size()]
		var enemy := _spawn_unit(guard_name, Types.Team.ENEMY, spawn_cell, damage, range_cells, model_file, 4 + mini(2, difficulty), "", "", "", enemy_role_id)
		var enemy_profile := {
			Types.BodyZone.HEAD: 4,
			Types.BodyZone.TORSO: 8,
			Types.BodyZone.ARMS: 5,
			Types.BodyZone.LEGS: 6,
		}
		if car_id == RUN_STATE_SCRIPT.FIRST_CAR_ID:
			enemy_profile = {Types.BodyZone.HEAD: 3, Types.BodyZone.TORSO: 6, Types.BodyZone.ARMS: 4, Types.BodyZone.LEGS: 4}
		elif enemy_role_id == "boss":
			enemy_profile = {Types.BodyZone.HEAD: 10, Types.BodyZone.TORSO: 14, Types.BodyZone.ARMS: 7, Types.BodyZone.LEGS: 8}
		elif enemy_role_id == "bruiser" or car_id == "armory":
			enemy_profile = {Types.BodyZone.HEAD: 6, Types.BodyZone.TORSO: 12, Types.BodyZone.ARMS: 6, Types.BodyZone.LEGS: 7}
		elif enemy_role_id == "officer":
			enemy_profile[Types.BodyZone.TORSO] = 10
		enemy.set_body_hp_profile(enemy_profile)
		if run_state.difficulty_id != "brutal":
			# Keep normal body hits at two damage after integer rounding. Criticals,
			# head shots, and Brutal mode still break this ceiling. Story alone offers
			# the explicitly advertised last-survivor rescue assistance.
			var damage_cap := 1.49 if run_state.difficulty_id == "story" and survivor_count == 1 and run_state.car_number() >= 4 else 2.45
			enemy.base_damage = minf(enemy.base_damage, damage_cap)
		enemy.set_meta("spawn_post", _enemy_spawn_post_label(car_id, enemy_role_id))
		enemy.set_meta("spawn_had_cover", board.has_adjacent_cover(spawn_cell))
		occupied[spawn_cell] = enemy


func _logical_enemy_spawn_cell(car_id: String, role_id: String, index: int, occupied: Dictionary = {}) -> Vector2i:
	# Guards now take believable posts inside the active carriage: riflemen hold
	# the rear/window line, bruisers meet the boarding crew, and support units use
	# the actual furniture that grants cover. The green first-car guard remains an
	# intentionally exposed tutorial checkpoint.
	if car_id == RUN_STATE_SCRIPT.FIRST_CAR_ID and index == 0:
		var checkpoint := Vector2i(GridBoard.ENEMY_DEPLOYMENT_MIN_X, 2)
		if board.is_walkable(checkpoint, occupied) and not board.hazard_cells.has(checkpoint):
			return checkpoint
	var preferred := _enemy_spawn_preference(car_id, role_id, index)
	var best_cell := Vector2i(18, 2)
	var best_score := INF
	for x in range(GridBoard.ENEMY_DEPLOYMENT_MIN_X, GridBoard.BOARD_SIZE.x):
		for y in range(GridBoard.BOARD_SIZE.y):
			var candidate := Vector2i(x, y)
			if not board.is_walkable(candidate, occupied) or board.hazard_cells.has(candidate):
				continue
			var clear_of_crew := true
			for crew in turn.player_units(true):
				if board.grid_distance(candidate, crew.grid_cell) < GridBoard.MIN_DEPLOYMENT_DISTANCE:
					clear_of_crew = false
			if not clear_of_crew:
				continue
			var score := float(board.grid_distance(candidate, preferred))
			var has_cover := board.has_adjacent_cover(candidate)
			var cover_priority := 3.0
			if role_id in ["marksman", "medic", "officer", "boss"]:
				cover_priority = 7.0
			elif role_id in ["bruiser", "duelist"]:
				cover_priority = 1.5
			if has_cover:
				score -= cover_priority
			else:
				score += cover_priority * 0.70
			match role_id:
				"marksman":
					score += float(maxi(0, 14 - candidate.x)) * 1.8
					if not board.has_line_of_sight(candidate, Vector2i(2, 2)):
						score += 2.5
				"bruiser", "duelist":
					score += float(maxi(0, candidate.x - 12)) * 1.4
				"medic", "officer", "boss":
					score += float(maxi(0, 13 - candidate.x)) * 1.2
			# Deterministic variants change which equally sensible post is used without
			# ever returning to arbitrary formations or unsafe tiles.
			var variation := posmod(candidate.x * 17 + candidate.y * 11 + run_state.encounter_variant_index() * 7 + index * 5, 13)
			score += float(variation) * 0.025
			if score < best_score:
				best_score = score
				best_cell = candidate
	return best_cell


func _enemy_spawn_preference(car_id: String, role_id: String, index: int) -> Vector2i:
	var alternating_row := 1 if index % 2 == 0 else 3
	match role_id:
		"marksman":
			return Vector2i(18, 0 if index % 2 == 0 else 4)
		"bruiser":
			return Vector2i(9, 2)
		"duelist":
			return Vector2i(10, alternating_row)
		"medic":
			return Vector2i(14, 3)
		"officer":
			return Vector2i(14, 1)
		"boss":
			return Vector2i(18, 2)
	match car_id:
		"dining":
			return Vector2i(13, alternating_row)
		"bar", "casino":
			return Vector2i(12, 2 if index == 0 else alternating_row)
		"crew", "sleeper":
			return Vector2i(13, alternating_row)
		"armory", "engine":
			return Vector2i(11, alternating_row)
		"observation":
			return Vector2i(15, alternating_row)
	return Vector2i(11, alternating_row)


func _enemy_spawn_post_label(car_id: String, role_id: String) -> String:
	match role_id:
		"marksman":
			return "WINDOW OVERWATCH"
		"bruiser":
			return "FORWARD CHOKEPOINT"
		"duelist":
			return "CENTER AISLE"
		"medic":
			return "REAR SUPPORT"
		"officer":
			return "COMMAND COVER"
		"boss":
			return "FINAL REDOUBT"
	match car_id:
		"dining":
			return "TABLE LINE"
		"bar", "casino":
			return "SERVICE COUNTER"
		"crew", "sleeper":
			return "BUNK CORRIDOR"
		"armory":
			return "CRATE BARRICADE"
		"engine":
			return "MACHINERY LINE"
		"observation":
			return "WINDOW LINE"
	return "FREIGHT BARRICADE"


func _enemy_role_for(car_id: String, index: int) -> String:
	if run_state.car_number() == RUN_STATE_SCRIPT.TOTAL_CARS and index == 0:
		return "boss"
	match car_id:
		"bar", "casino":
			return "duelist" if index % 2 == 0 else "railhand"
		"observation":
			return "marksman" if index < 2 else "railhand"
		"crew":
			return "medic" if index == 0 else ("officer" if index == 1 else "railhand")
		"armory":
			return "bruiser" if index % 2 == 0 else "officer"
		"engine":
			return "bruiser" if index == 0 else ("medic" if index == 1 else "railhand")
		"cargo":
			return "bruiser" if index == 0 else "railhand"
		"dining":
			return "officer" if index == 0 else ("bruiser" if index == 1 else "railhand")
	return "railhand"


func _encounter_profile(car_id: String) -> Dictionary:
	match car_id:
		"bar":
			return {"damage_multiplier": 1.16, "range_bonus": 1, "model": "Suit.gltf"}
		"crew":
			return {"count_bonus": 1, "model": "Worker.gltf"}
		"armory":
			return {"hp_bonus": 3, "damage_multiplier": 1.00, "model": "Swat.gltf"}
		"engine":
			return {"hp_bonus": 1, "damage_multiplier": 1.04, "model": "Worker.gltf"}
		"observation":
			return {"range_bonus": 3, "damage_multiplier": 1.08, "model": "Suit.gltf"}
		"cargo":
			return {"hp_bonus": 2, "model": "Worker.gltf"}
		"casino":
			return {"range_bonus": 1, "damage_multiplier": 1.22, "model": "Suit.gltf"}
	return {}


func _difficulty_enemy_count_bonus() -> int:
	if not is_instance_valid(run_state):
		return 0
	match run_state.difficulty_id:
		"story":
			return -1
		"brutal":
			return 1
	return 0


func _difficulty_enemy_damage_multiplier() -> float:
	if not is_instance_valid(run_state):
		return 1.0
	match run_state.difficulty_id:
		"story":
			return 0.82
		"brutal":
			return 1.18
	# Authored rear posts and functional cover extend engagements compared with
	# the old close-range formations. Standard compensates with slightly lower
	# incoming damage so persistent wounds remain pressure, not a route death lock.
	return 0.90


func _snapshot_run_crew() -> void:
	if not is_instance_valid(run_state):
		return
	for unit in turn.player_units(false):
		if not unit.roster_id.is_empty():
			run_state.record_crew_status(unit.roster_id, unit.export_body_state(), unit.is_alive)


func _on_next_car_chosen(car_id: String) -> void:
	if not is_instance_valid(run_state):
		return
	var accepted := false
	if run_state.phase == "preparation":
		accepted = run_state.pending_car_id == car_id and run_state.confirm_prepared_car()
	else:
		# Direct commit remains available for automation and old integration paths;
		# the player-facing route always enters preparation first.
		accepted = run_state.choose_next_car(car_id)
	if not accepted:
		return
	var car_data: Dictionary = run_state.car_data(car_id)
	if String(car_data.get("kind", "combat")) == "event":
		_heist_started = false
		ui.set_hud_visible(false)
		camera_rig.input_enabled = false
		campaign_ui.show_car_event(run_state)
		_save_run_checkpoint()
		return
	await _load_run_encounter()


func _on_car_prep_requested(car_id: String) -> void:
	if not is_instance_valid(run_state) or not run_state.prepare_next_car(car_id):
		return
	var needs_review := false
	for crew_id in run_state.selected_crew_ids:
		if String(run_state.crew_readiness(crew_id)["status"]) != "READY":
			needs_review = true
			break
	if not needs_review:
		await _on_next_car_chosen(car_id)
		return
	_save_run_checkpoint()
	campaign_ui.show_crew_prep(run_state)


func _on_crew_review_requested(car_id: String) -> void:
	if not is_instance_valid(run_state) or not run_state.prepare_next_car(car_id):
		return
	_save_run_checkpoint()
	campaign_ui.show_crew_prep(run_state)


func _on_prep_back_requested() -> void:
	if not is_instance_valid(run_state) or not run_state.cancel_preparation():
		return
	_save_run_checkpoint()
	campaign_ui.show_intermission(run_state)


func _on_item_requested(item_id: String, crew_id: String) -> void:
	if not is_instance_valid(run_state):
		return
	var result: Dictionary = run_state.use_item(item_id, crew_id)
	if bool(result.get("ok", false)):
		run_state.record_item_use()
		var success_message := "%s / %s" % [String(campaign_ui.roster_member(crew_id).get("name", crew_id)).to_upper(), String(result.get("summary", "Supply applied."))]
		campaign_ui.set_management_feedback(success_message, true)
		ui.push_log(success_message)
		_save_run_checkpoint()
	else:
		campaign_ui.set_management_feedback("NO CHANGE / %s" % String(result.get("reason", "That supply cannot be used.")), false)
	if run_state.phase == "preparation":
		campaign_ui.show_crew_prep(run_state)
	else:
		campaign_ui.show_intermission(run_state)


func _on_event_resolved() -> void:
	if not is_instance_valid(run_state) or run_state.phase != "encounter":
		return
	if run_state.current_car_id == "sleeper" and run_state.pending_event_choice.is_empty():
		run_state.resolve_event_choice("rest")
	var completion: Dictionary = run_state.complete_current_car()
	campaign_ui.update_run_progress(run_state)
	if bool(completion.get("run_complete", false)):
		_clear_run_checkpoint()
		_show_run_complete()
	else:
		_save_run_checkpoint()
		campaign_ui.show_intermission(run_state, true)


func _on_event_choice_requested(choice_id: String) -> void:
	if not is_instance_valid(run_state):
		return
	var result: Dictionary = run_state.resolve_event_choice(choice_id)
	if not bool(result.get("ok", false)):
		return
	ui.push_log(String(result.get("summary", "The crew resolves the Sleeper Car opportunity.")))
	_on_event_resolved()


func _on_crew_scene_choice_requested(choice_id: String) -> void:
	if not is_instance_valid(run_state):
		return
	var result: Dictionary = run_state.resolve_crew_scene_choice(choice_id)
	if not bool(result.get("ok", false)):
		return
	_save_run_checkpoint()
	campaign_ui.set_management_feedback("CREW COUNCIL / %s" % String(result.get("summary", "The crew has decided.")), true)
	campaign_ui.show_intermission(run_state, true)


func _on_continue_requested() -> void:
	var saved_data := _read_run_checkpoint()
	if saved_data.is_empty():
		campaign_ui.set_continue_available(false)
		campaign_ui.show_intro()
		return
	var restored := RUN_STATE_SCRIPT.new()
	if not restored.load_from_save_data(saved_data):
		_clear_run_checkpoint()
		campaign_ui.set_continue_available(false)
		campaign_ui.show_intro()
		return
	run_state = restored
	_active_daily_date = _read_daily_context()
	match run_state.phase:
		"encounter":
			await _load_run_encounter()
		"intermission":
			_heist_started = false
			ui.set_hud_visible(false)
			camera_rig.input_enabled = false
			campaign_ui.update_run_progress(run_state)
			campaign_ui.show_intermission(run_state, true)
		"preparation":
			_heist_started = false
			ui.set_hud_visible(false)
			camera_rig.input_enabled = false
			campaign_ui.update_run_progress(run_state)
			campaign_ui.show_crew_prep(run_state, true)
		"complete":
			_clear_run_checkpoint()
			_show_run_complete()


func _refresh_continue_option() -> void:
	var saved_data := _read_run_checkpoint()
	if saved_data.is_empty():
		campaign_ui.set_continue_available(false)
		return
	var candidate := RUN_STATE_SCRIPT.new()
	if candidate.load_from_save_data(saved_data) and candidate.phase != "complete":
		campaign_ui.set_continue_available(true, candidate.save_summary())
	else:
		_clear_run_checkpoint()
		campaign_ui.set_continue_available(false)


func _save_run_checkpoint() -> void:
	if _capture_mode or _automation_mode or not is_instance_valid(run_state) or run_state.phase == "complete":
		return
	var temporary_path := _save_path + ".tmp"
	var file := FileAccess.open(temporary_path, FileAccess.WRITE)
	if file == null:
		push_warning("Could not write the Brassline run checkpoint.")
		return
	file.store_string(JSON.stringify(_checkpoint_data(), "\t"))
	file.close()
	if DirAccess.rename_absolute(temporary_path, _save_path) != OK:
		push_warning("Could not replace the Brassline run checkpoint; the previous save is intact.")
		return
	campaign_ui.set_continue_available(true, run_state.save_summary())


func _checkpoint_data() -> Dictionary:
	# An encounter is a transaction. Persist the complete pre-fight state until
	# aftermath commits all inventory, injury, and campaign effects together.
	if run_state.phase == "encounter" and not _encounter_retry_snapshot.is_empty():
		if int(_encounter_retry_snapshot.get("run_seed", -1)) == run_state.run_seed and String(_encounter_retry_snapshot.get("current_car_id", "")) == run_state.current_car_id:
			return _encounter_retry_snapshot.duplicate(true)
	return run_state.to_save_data()


func _write_daily_context() -> void:
	# A small companion file preserves daily identity without changing run v7 or
	# profile v2. Bind it to the full challenge contract, never to a date alone.
	var context_path := _save_path + ".challenge.json"
	if _active_daily_date.is_empty():
		if FileAccess.file_exists(context_path):
			DirAccess.remove_absolute(context_path)
		return
	var file := FileAccess.open(context_path, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"date": _active_daily_date, "code": profile_state.build_challenge_code(run_state.run_seed, run_state.difficulty_id, run_state.selected_crew_ids, run_state.ruleset_id)}))
		file.close()


func _read_daily_context() -> String:
	var file := FileAccess.open(_save_path + ".challenge.json", FileAccess.READ)
	if file == null:
		return ""
	var context = JSON.parse_string(file.get_as_text())
	if not context is Dictionary:
		return ""
	var code := profile_state.build_challenge_code(run_state.run_seed, run_state.difficulty_id, run_state.selected_crew_ids, run_state.ruleset_id)
	return String(context.get("date", "")) if String(context.get("code", "")) == code else ""


func _read_run_checkpoint() -> Dictionary:
	if not FileAccess.file_exists(_save_path):
		return {}
	var file := FileAccess.open(_save_path, FileAccess.READ)
	if file == null:
		return {}
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	return parsed if parsed is Dictionary else {}


func _clear_run_checkpoint() -> void:
	if FileAccess.file_exists(_save_path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(_save_path))
	if is_instance_valid(campaign_ui):
		campaign_ui.set_continue_available(false)


func _on_car_selected(car_index: int) -> void:
	if car_index < 0 or car_index >= CAR_FOCUS_CELLS.size():
		return
	# The navigator reports campaign position; combat itself is always framed as
	# the single current carriage rather than a strip of adjacent graybox rooms.
	camera_rig.frame_active_car()


func _update_train_navigator() -> void:
	if not is_instance_valid(campaign_ui) or not _heist_started:
		return
	if is_instance_valid(run_state):
		campaign_ui.update_run_progress(run_state)
		return
	var furthest_x := 0
	for unit in turn.player_units(true):
		furthest_x = maxi(furthest_x, unit.grid_cell.x)
	var selected_x := turn.selected_unit.grid_cell.x if is_instance_valid(turn.selected_unit) else -1
	campaign_ui.update_train_progress(furthest_x, selected_x)


func _is_automation_run() -> bool:
	for argument in OS.get_cmdline_args():
		if "res://tests/" in argument or "tests/" in argument:
			return true
	return false


func _use_legacy_manual_combat() -> bool:
	# Existing regression scripts still drive the old public action API directly.
	# Shipping play, captures made from a real run, and tests opting into the new
	# flag all use the narrative autobattler path.
	return _is_automation_run() and "--autobattle-test" not in OS.get_cmdline_user_args()


func _build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#030708")
	environment.background_energy_multiplier = 0.24
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#30484b")
	environment.ambient_light_energy = 0.38
	environment.reflected_light_source = Environment.REFLECTION_SOURCE_BG
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.fog_enabled = true
	environment.fog_light_color = Color("#122225")
	environment.fog_light_energy = 0.42
	environment.fog_density = 0.008
	environment.fog_aerial_perspective = 0.38
	world_environment.environment = environment
	add_child(world_environment)

	var key_light := DirectionalLight3D.new()
	key_light.rotation_degrees = Vector3(-54.0, -34.0, 0.0)
	key_light.light_color = Color("#a9c1bd")
	key_light.light_energy = 0.94
	key_light.shadow_enabled = true
	key_light.directional_shadow_max_distance = 80.0
	add_child(key_light)

	for light_data in [
		[Vector3(-9.5, 3.2, 0.0), Color("#eaa84b")],
		[Vector3(0.0, 3.2, 0.0), Color("#f08043")],
		[Vector3(9.5, 3.2, 0.0), Color("#bd87ff")],
	]:
		var lamp := OmniLight3D.new()
		lamp.position = light_data[0]
		lamp.light_color = light_data[1]
		lamp.light_energy = 2.15
		lamp.omni_range = 7.4
		lamp.shadow_enabled = true
		add_child(lamp)


func _build_moving_scenery() -> void:
	var ground_material := _material(Color("#070a0b"), 0.04, 0.98)
	var rock_material := _material(Color("#11191a"), 0.12, 0.92)
	var pole_material := _material(Color("#241814"), 0.05, 0.92)
	var metal_material := _material(Color("#252b2b"), 0.70, 0.52)

	_add_static_box(Vector3(80.0, 0.18, 26.0), Vector3(0.0, -0.84, 0.0), ground_material)

	for index in range(56):
		var track_piece := TRACK_SCENE.instantiate() as Node3D
		track_piece.name = "KenneyTrack_%02d" % index
		track_piece.position = Vector3(-42.0 + index * 1.5, -0.76, 0.0)
		track_piece.rotation_degrees.y = 90.0
		track_piece.scale = Vector3(9.4, 1.0, 1.5)
		_tint_model(track_piece, Color(0.25, 0.22, 0.18, 1.0))
		add_child(track_piece)
		_moving_scenery.append(track_piece)

	# Faceted distant embankment stays on the far side of the train; nothing large
	# drifts through the foreground and competes with the encounter.
	for index in range(22):
		var rock := MeshInstance3D.new()
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.28 + float(index % 3) * 0.14
		mesh.bottom_radius = 0.75 + float(index % 4) * 0.18
		mesh.height = 1.45 + float(index % 4) * 0.42
		mesh.radial_segments = 6
		rock.mesh = mesh
		rock.scale = Vector3(1.25 + float(index % 2) * 0.35, 1.0, 1.0)
		rock.rotation_degrees.y = float(index * 37 % 90)
		rock.position = Vector3(-41.0 + index * 3.85, 0.10 + float(index % 4) * 0.20, -9.0 - float(index % 3) * 1.15)
		rock.material_override = rock_material
		add_child(rock)
		_moving_scenery.append(rock)

	# Telegraph poles are a strong speed cue and establish an exterior railway.
	for index in range(9):
		var pole_x := -40.0 + float(index) * 10.5
		var post := _add_static_box(Vector3(0.16, 3.6, 0.16), Vector3(pole_x, 1.02, -7.45), pole_material)
		var crossbar := _add_static_box(Vector3(1.65, 0.13, 0.13), Vector3(pole_x, 2.55, -7.45), pole_material)
		var cap_left := _add_static_box(Vector3(0.10, 0.32, 0.10), Vector3(pole_x - 0.66, 2.77, -7.45), metal_material)
		var cap_right := _add_static_box(Vector3(0.10, 0.32, 0.10), Vector3(pole_x + 0.66, 2.77, -7.45), metal_material)
		_moving_scenery.append_array([post, crossbar, cap_left, cap_right])


func _add_static_box(size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _material(color: Color, metallic: float, roughness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	return material


func _tint_model(root: Node3D, tint: Color) -> void:
	for child in root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		for surface in range(mesh_instance.mesh.get_surface_count()):
			var source := mesh_instance.mesh.surface_get_material(surface) as StandardMaterial3D
			if source == null:
				continue
			var treated := source.duplicate() as StandardMaterial3D
			treated.albedo_color = treated.albedo_color * tint
			treated.metallic = maxf(treated.metallic, 0.42)
			treated.roughness = maxf(treated.roughness, 0.62)
			mesh_instance.set_surface_override_material(surface, treated)


func _on_turn_state_changed() -> void:
	ui.update_from_turn(turn)
	if is_instance_valid(autobattle_ui):
		autobattle_ui.refresh_combat_crew()
	_update_train_navigator()


func _on_selection_changed(_unit: TacticalUnit, _target: TacticalUnit) -> void:
	ui.update_from_turn(turn)
	_update_train_navigator()


func _on_log_entry(message: String) -> void:
	ui.push_log(message)
	ui.update_from_turn(turn)


func _on_mission_finished(victory: bool, message: String) -> void:
	if not is_instance_valid(run_state):
		ui.show_result(victory, message)
		return
	if turn.autobattle_enabled and not _use_legacy_manual_combat():
		_resolve_autobattle_mission(victory, message)
		return
	if not victory:
		ui.show_result(false, message)
		return
	_heist_started = false
	camera_rig.input_enabled = false
	run_state.add_encounter_stats(turn.encounter_stats)
	_snapshot_run_crew()
	var completion: Dictionary = run_state.complete_current_car()
	ui.set_hud_visible(false)
	campaign_ui.navigator.visible = false
	campaign_ui.update_run_progress(run_state)
	if bool(completion.get("run_complete", false)):
		_clear_run_checkpoint()
		_show_run_complete()
	else:
		_save_run_checkpoint()
		campaign_ui.show_intermission(run_state, true)


func _on_plan_previewed(plan: Dictionary, fallback: Dictionary) -> void:
	if not plan.has("deployment_cells"):
		return
	if not autobattle_director.apply_deployment(Dictionary(plan["deployment_cells"])):
		return
	_update_planned_opening_chance(plan)
	plan["fallback_destinations"] = {}
	if String(fallback.get("id", "")) in ["protect_wounded", "save_crew"]:
		for crew in turn.player_units(true):
			if crew.roster_id == String(plan.get("risk_unit_id", "")):
				plan["fallback_destinations"][crew.roster_id] = autobattle_director.protective_fallback_destination(crew)
	if String(fallback.get("id", "")) == "protect_wounded":
		for crew in turn.player_units(true):
			var torso: Dictionary = crew.body_state[Types.BodyZone.TORSO]
			if float(torso["hp"]) / maxf(1.0, float(torso["max_hp"])) < 0.4:
				plan["formation_protection"][crew.roster_id] = 0.46
				for raw_preview in Array(plan.get("opening_preview", [])):
					if String(raw_preview.get("roster_id", "")) == crew.roster_id:
						raw_preview["protection"] = 0.46
	board.show_deployment_preview(Dictionary(plan["deployment_cells"]), turn.player_units(true), plan, fallback)
	for crew in turn.player_units(true):
		crew.set_planning_preview(true)
		for raw_preview in Array(plan.get("opening_preview", [])):
			var preview := Dictionary(raw_preview)
			if String(preview.get("roster_id", "")) == crew.roster_id:
				var protection := String(preview.get("cover", "OPEN")).to_upper()
				if protection == "NO COVER":
					protection = "EXPOSED"
				crew.set_autobattle_intent(protection, "adapting" if bool(preview.get("risk", false)) else "on_plan")
	for enemy in turn.enemy_units(true):
		enemy.set_planning_preview(true)
		enemy.set_autobattle_intent(_enemy_threat_summary(enemy), "broken")


func _enemy_threat_summary(enemy: TacticalUnit) -> String:
	# A capability forecast, not a promise about an unrolled AI action.
	match enemy.role_id:
		"officer": return "COMMAND / DISABLE ARMS"
		"marksman": return "LONG-RANGE FIRE / DISABLE ARMS"
		"bruiser": return "CLOSES DISTANCE / DISABLE LEGS"
		"medic": return "HEALS WOUNDED GUARDS"
		"boss": return "HOLDS CONTROL / DISABLE + CLAIM"
	return "RANGED PRESSURE / ARMS STOP RELOADS"


func _on_planning_confirmed(plan: Dictionary, fallback: Dictionary) -> void:
	if plan.is_empty() or turn.encounter_active:
		return
	if not autobattle_director.apply_deployment(Dictionary(plan.get("deployment_cells", {}))):
		ui.push_log("Cannot commit: crew deployment is blocked or too close to the opposing line.")
		return
	board.clear_deployment_preview()
	for unit in turn.units:
		unit.set_planning_preview(false)
	for enemy in turn.enemy_units(true):
		enemy.clear_autobattle_intent()
	autobattle_director.configure(plan, fallback, run_state.inventory if is_instance_valid(run_state) else {})
	_retry_previous_choices = false
	audio_director.play_plan_committed(plan)
	ui.set_hud_visible(false)
	autobattle_ui.show_combat(plan, fallback, turn.player_units(true), _active_car_data, _active_bonuses)
	if is_instance_valid(profile_state) and not profile_state.tutorial_complete and is_instance_valid(run_state) and run_state.car_number() == 1:
		profile_state.mark_tutorial_complete()
		profile_state.save_to_disk(_profile_path)
	camera_rig.input_enabled = true
	camera_rig.frame_active_car()
	_heist_started = true
	autobattle_director.start_battle()


func _on_autobattle_consumable_used(item_id: String, unit: TacticalUnit) -> void:
	if not is_instance_valid(run_state) or not run_state.consume_inventory_item(item_id):
		push_warning("Autobattle consumed unavailable inventory item: %s" % item_id)
		return
	run_state.record_item_use()
	audio_director.play_consumable(item_id, unit)
	ui.set_combat_inventory(run_state.inventory)
	autobattle_ui.current_inventory = run_state.inventory.duplicate(true)
	autobattle_ui.mark_item_used(item_id)
	autobattle_ui.refresh_combat_crew()
	ui.push_log("%s commits %s to the plan." % [unit.display_name, item_id.replace("_", " ").capitalize()])
	_save_run_checkpoint()


func _on_autobattle_pause_requested() -> void:
	if is_instance_valid(autobattle_director):
		autobattle_director.toggle_pause()


func _on_ledger_visibility_changed(open: bool) -> void:
	_ledger_pause_open = open
	_sync_modal_pause()


func _on_in_run_settings_requested() -> void:
	campaign_ui.show_in_run_settings(get_viewport().gui_get_focus_owner())


func _on_settings_visibility_changed(open: bool) -> void:
	_settings_pause_open = open
	autobattle_ui.set_settings_open(open)
	_sync_modal_pause()
	camera_rig.input_enabled = not open and _heist_started and not campaign_ui.is_frontend_open()


func _sync_modal_pause() -> void:
	if is_instance_valid(autobattle_director):
		autobattle_director.set_inspection_paused(_ledger_pause_open or _settings_pause_open)


func _on_autobattle_speed_requested(speed: float) -> void:
	if is_instance_valid(autobattle_director):
		autobattle_director.set_speed(speed)


func _on_presentation_settings_changed(_cinematic_focus: String, _reduced_motion: bool, scale: float) -> void:
	if is_instance_valid(autobattle_ui):
		autobattle_ui.set_text_scale(scale)
	if is_instance_valid(combat_presenter):
		combat_presenter.set_preferences(_cinematic_focus, _reduced_motion)


func _on_autobattle_inspector_requested(roster_id: String) -> void:
	autobattle_ui.toggle_inspector(roster_id)


func _on_train_event_changed(event: Dictionary, result: Dictionary) -> void:
	if is_instance_valid(autobattle_ui):
		autobattle_ui.on_train_event_changed(event, result)
	if is_instance_valid(train_art):
		train_art.set_living_train_event(event, result)
	if is_instance_valid(audio_director):
		audio_director.on_train_event(event, result)


func _resolve_autobattle_mission(victory: bool, message: String) -> void:
	_heist_started = false
	camera_rig.input_enabled = false
	campaign_ui.navigator.visible = false
	autobattle_director.record_mission_result(victory, message)
	if not _automation_mode and not campaign_ui.reduced_motion_enabled:
		await get_tree().create_timer(0.42 / sqrt(maxf(1.0, autobattle_director.battle_speed)), true, false, true).timeout
	var aftermath := autobattle_director.build_aftermath(victory)
	var active_plan := autobattle_director.active_plan.duplicate(true)
	var active_fallback := autobattle_director.active_fallback.duplicate(true)
	_previous_plan_id = String(active_plan.get("id", ""))
	_previous_fallback_id = String(active_fallback.get("id", "hold_plan"))
	autobattle_director.stop()
	run_state.add_encounter_stats(turn.encounter_stats)
	_snapshot_run_crew()
	aftermath["crew_consequences"] = run_state.resolve_crew_consequences(active_plan, active_fallback, aftermath)
	run_state.record_plan_result(active_plan, active_fallback, aftermath)
	if is_instance_valid(profile_state):
		profile_state.record_injuries(Array(aftermath.get("injuries", [])))
		profile_state.record_relationships(Array(run_state.crew_campaign_context().get("relationships", [])))
		if victory:
			var cripple_count := 0
			var environment_actions := 0
			for raw_beat in Array(aftermath.get("decisive_beats", [])):
				var beat := Dictionary(raw_beat)
				if String(beat.get("type", "")) == "cripple":
					cripple_count += 1
				elif String(beat.get("type", "")) == "environment":
					environment_actions += 1
			var reward: Dictionary = profile_state.award_car_clear(
				String(_active_car_data.get("id", run_state.current_car_id)),
				run_state.selected_crew_ids,
				String(active_plan.get("risk_level", "")) == "HIGH",
				cripple_count,
				environment_actions
			)
			aftermath["profile_reward"] = reward
		profile_state.save_to_disk(_profile_path)
	_pending_autobattle_victory = victory
	_pending_autobattle_completion = {"message": message, "aftermath": aftermath}
	audio_director.play_mission_result(victory, message)
	var reward_text := "NO REWARD / THE JOB FAILED"
	var continue_text := "VIEW FAILED HEIST"
	if victory:
		var completion: Dictionary = run_state.complete_current_car()
		_pending_autobattle_completion["completion"] = completion
		var buff: Dictionary = completion.get("buff", {})
		var details: Array[String] = []
		for detail in Array(buff.get("details", [])):
			details.append(String(detail))
		reward_text = "REWARD / %s\n%s" % [String(buff.get("title", "SUPPLIES SECURED")), " • ".join(details)]
		if not String(buff.get("synergy", "")).is_empty():
			reward_text += "\nORDER SYNERGY / %s" % String(buff.get("synergy", ""))
		var profile_reward := Dictionary(aftermath.get("profile_reward", {}))
		if not profile_reward.is_empty():
			reward_text += "\nBLUEPRINT KNOWLEDGE / +%d  •  TOTAL %d\n%s" % [int(profile_reward.get("amount", 0)), int(profile_reward.get("total", 0)), "  •  ".join(PackedStringArray(profile_reward.get("reasons", [])))]
		if bool(completion.get("run_complete", false)) and is_instance_valid(profile_state):
			var epilogue: Dictionary = run_state.campaign_epilogue()
			var challenge_code := profile_state.record_run_complete(run_state.run_seed, run_state.difficulty_id, String(epilogue.get("grade", "C")), run_state.selected_crew_ids, run_state.ruleset_id)
			completion["challenge_code"] = challenge_code
			_pending_autobattle_completion["completion"] = completion
			if not _active_daily_date.is_empty():
				profile_state.record_daily_result(_active_daily_date, String(epilogue.get("grade", "C")))
			profile_state.save_to_disk(_profile_path)
		continue_text = "FINISH THE RUN" if bool(completion.get("run_complete", false)) else "CONTINUE TO THE TRAIN MAP"
		if bool(completion.get("run_complete", false)):
			_clear_run_checkpoint()
		else:
			_save_run_checkpoint()
	audio_director.clear_caption()
	autobattle_ui.show_aftermath(aftermath, reward_text, continue_text)
	campaign_ui.update_run_progress(run_state)


func _on_aftermath_continue_requested() -> void:
	autobattle_ui.hide_all()
	if not _pending_autobattle_victory:
		ui.set_hud_visible(false)
		campaign_ui.show_run_failed(
			run_state,
			String(_pending_autobattle_completion.get("message", "HEIST FAILED")),
			Dictionary(_pending_autobattle_completion.get("aftermath", {}))
		)
		return
	ui.set_hud_visible(false)
	var completion: Dictionary = _pending_autobattle_completion.get("completion", {})
	if bool(completion.get("run_complete", false)):
		_clear_run_checkpoint()
		_show_run_complete()
	else:
		_save_run_checkpoint()
		campaign_ui.show_intermission(run_state, true)


func _on_retry_requested() -> void:
	if _encounter_retry_snapshot.is_empty():
		campaign_ui.set_management_feedback("RETRY UNAVAILABLE / No pre-fight checkpoint was found.", false)
		campaign_ui.show_intro()
		return
	var restored := RUN_STATE_SCRIPT.new()
	if not restored.load_from_save_data(_encounter_retry_snapshot.duplicate(true)):
		campaign_ui.set_management_feedback("RETRY UNAVAILABLE / The checkpoint could not be restored.", false)
		campaign_ui.show_intro()
		return
	run_state = restored
	_retry_previous_choices = true
	_pending_autobattle_completion.clear()
	_pending_autobattle_victory = false
	await _load_run_encounter()


func _on_abandon_requested() -> void:
	_active_daily_date = ""
	_write_daily_context()
	_pending_autobattle_completion.clear()
	_pending_autobattle_victory = false
	_encounter_retry_snapshot.clear()
	_retry_previous_choices = false
	_previous_plan_id = ""
	_previous_fallback_id = ""
	_heist_started = false
	ui.set_hud_visible(false)
	camera_rig.input_enabled = false
	_clear_run_checkpoint()
	campaign_ui.show_intro()


func _on_zone_requested(zone: Types.BodyZone) -> void:
	turn.set_target_zone(zone)


func _on_attack_requested() -> void:
	turn.try_attack()


func _on_reload_requested() -> void:
	turn.try_reload()
	ui.update_from_turn(turn)


func _on_overwatch_requested() -> void:
	turn.try_overwatch()
	ui.update_from_turn(turn)


func _on_cover_requested() -> void:
	turn.try_take_cover()
	ui.update_from_turn(turn)


func _on_ability_requested() -> void:
	turn.try_signature_ability()
	ui.update_from_turn(turn)


func _on_grenade_requested() -> void:
	if not is_instance_valid(run_state) or int(run_state.inventory.get("clockwork_grenade", 0)) <= 0:
		return
	if not turn.can_use_grenade():
		ui.push_log("Select a guard within six tiles before throwing a grenade.")
		return
	if not run_state.consume_inventory_item("clockwork_grenade"):
		return
	run_state.record_item_use()
	ui.set_combat_inventory(run_state.inventory)
	_save_run_checkpoint()
	await turn.try_grenade()
	ui.update_from_turn(turn)


func _on_tonic_requested() -> void:
	if not is_instance_valid(run_state) or turn.phase != Types.Phase.PLAYER or not is_instance_valid(turn.selected_unit):
		return
	if turn.selected_unit.is_focused():
		ui.push_log("%s is already focused for their next shot." % turn.selected_unit.display_name)
		return
	if not run_state.consume_inventory_item("focus_tonic"):
		return
	run_state.record_item_use()
	turn.selected_unit.apply_focus_tonic()
	ui.push_log("%s drinks a Focus Tonic: +18%% hit and +16%% critical on the next shot." % turn.selected_unit.display_name)
	ui.set_combat_inventory(run_state.inventory)
	_save_run_checkpoint()
	ui.update_from_turn(turn)


func _on_end_turn_requested() -> void:
	turn.end_player_turn()


func _on_restart_requested() -> void:
	get_tree().reload_current_scene()


func _capture_preview() -> void:
	campaign_ui.set_continue_available(true, "CAR 03 / 7 · RUN 8675309")
	campaign_ui.show_intro()
	ui.set_hud_visible(false)
	for _frame in range(12):
		await get_tree().process_frame
	var image := get_viewport().get_texture().get_image()
	image.save_png("res://preview_intro.png")

	campaign_ui.show_how_to_play()
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_how_to.png")

	campaign_ui.show_settings()
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_settings.png")

	campaign_ui.show_crew_selection()
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_crew.png")

	var preview_run := RUN_STATE_SCRIPT.new()
	var preview_run_crew: Array[String] = ["ada", "marlow", "nix"]
	preview_run.start_new_run(preview_run_crew, 8675309)
	var preview_body: Dictionary = preview_run.body_state_for("ada")
	preview_body[Types.BodyZone.HEAD]["hp"] = 1
	preview_body[Types.BodyZone.TORSO]["hp"] = 3
	preview_body[Types.BodyZone.ARMS]["hp"] = 1
	preview_run.record_crew_body_state("ada", preview_body)
	preview_run.complete_current_car()
	campaign_ui.show_intermission(preview_run, true)
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_route.png")
	preview_run.prepare_next_car(preview_run.current_offers[0])
	campaign_ui.show_crew_prep(preview_run)
	for _frame in range(18):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_prep.png")
	var preview_treatment: Dictionary = preview_run.use_item("medkit", "ada")
	campaign_ui.set_management_feedback(
		"ADA BRASS / %s" % String(preview_treatment.get("summary", "Treatment applied.")),
		bool(preview_treatment.get("ok", false))
	)
	campaign_ui.show_crew_prep(preview_run)
	for _frame in range(18):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_recovery.png")

	var council_run := RUN_STATE_SCRIPT.new()
	council_run.start_new_run(preview_run_crew, 8675311)
	council_run.complete_current_car()
	council_run.current_car_id = "dining"
	council_run.phase = "encounter"
	council_run.complete_current_car()
	campaign_ui.show_intermission(council_run, true)
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_crew_council.png")

	var event_run := RUN_STATE_SCRIPT.new()
	event_run.start_new_run(preview_run_crew, 8675309)
	event_run.current_car_id = "sleeper"
	event_run.phase = "encounter"
	campaign_ui.show_car_event(event_run)
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_event.png")

	preview_run.completed_car_ids.assign(["baggage", "observation", "crew", "armory", "dining", "bar", "engine"])
	preview_run.plan_history.clear()
	for completed_id in preview_run.completed_car_ids:
		preview_run.plan_history.append({
			"car_id": completed_id,
			"plan_id": "master_%s" % completed_id,
			"plan_title": "Master the %s" % completed_id,
			"fallback_id": "hold_plan",
			"fallback_triggered": false,
			"status": "on_plan",
			"rounds": 3,
			"train_impacts": 1,
			"train_counters": 1,
			"doctrine_id": "doctrine_%s" % completed_id,
			"doctrine_name": "BROKEN DOCTRINE",
			"doctrine_broken": true,
		})
	for relationship_key in preview_run.crew_relationships:
		preview_run.crew_relationships[relationship_key]["bond"] = 3
	preview_run.current_car_id = ""
	preview_run.pending_car_id = ""
	preview_run.phase = "complete"
	preview_run.run_stats = {
		"cars_cleared": 7, "shots": 82, "hits": 61, "kills": 24, "moves": 39,
		"rounds": 21, "reloads": 12, "overwatch_shots": 5, "abilities": 17,
		"items_used": 8, "surrenders": 4, "control_claims": 2, "train_seized": 1,
		"finale_escapes": 0, "ai_shots": 49, "ai_moves": 31,
		"ai_cover_moves": 18, "ai_cover_actions": 12, "ai_flanks": 7,
	}
	campaign_ui.show_run_complete(preview_run)
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_complete.png")
	campaign_ui.show_run_failed(preview_run, "The guard line forced the crew off the carriage.", {
		"crew_consequences": [{"summary": "Ada was cut off; Marlow dragged the crew back to the coupling."}],
	})
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_failure_recovery.png")

	await _on_crew_confirmed(preview_run_crew)
	for _frame in range(18):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_autobattle_planning.png")
	var capture_plan_index := 0
	for index in range(autobattle_ui.plans.size()):
		if String(autobattle_ui.plans[index].get("id", "")) == "break_the_hands":
			capture_plan_index = index
	autobattle_ui._select_plan(capture_plan_index)
	autobattle_ui._select_fallback(1)
	autobattle_ui._confirm_plan()
	autobattle_director.set_speed(2.0)
	while autobattle_director.activation_count < 2 and turn.encounter_active:
		await get_tree().process_frame
	autobattle_director.set_paused(true)
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_autobattle_combat.png")
	autobattle_ui.toggle_inspector("ada")
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_autobattle_stats.png")
	autobattle_ui.inspector_panel.visible = false
	autobattle_director.set_paused(false)
	for enemy in turn.enemy_units(true):
		enemy.apply_damage(Types.BodyZone.TORSO, 999, true)
	while not autobattle_ui.aftermath_root.visible:
		await get_tree().process_frame
	for _frame in range(12):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview_autobattle_aftermath.png")

	# The main preview sells the train first; the companion combat frame preserves
	# a full view of the narrative planning and initiative interface.
	autobattle_ui.hide_all()
	turn.current_target = null
	board.clear_highlights()
	ui.set_cinematic_capture(true)
	campaign_ui.set_cinematic_capture(true)
	camera_rig.frame_active_car()
	# Keep a visual-regression frame for every combat-car identity. These are not
	# required by the runtime, but make repeated-room regressions immediately clear.
	var showcase_cars: Array[String] = ["baggage", "dining", "bar", "crew", "armory", "observation", "cargo", "casino", "engine"]
	var saved_showcase_objective: String = turn.objective_text
	for showcase_index in range(showcase_cars.size()):
		var showcase_id := showcase_cars[showcase_index]
		board.prepare_run_encounter(showcase_id, showcase_index % 3)
		train_art.set_active_run_car(showcase_id, showcase_index + 1)
		var showcase_data: Dictionary = RUN_STATE_SCRIPT.CAR_CATALOG[showcase_id]
		turn.objective_text = "Clear the %s and secure its route reward." % String(showcase_data.get("name", showcase_id.capitalize()))
		ui.update_from_turn(turn)
		for _frame in range(10):
			await get_tree().process_frame
		image = get_viewport().get_texture().get_image()
		image.save_png("res://preview_car_%s.png" % showcase_id)
		var showcase_warning := SignatureArc.event_for_round(showcase_id, 1)
		train_art.set_living_train_event(showcase_warning, {})
		for _frame in range(6):
			await get_tree().process_frame
		image = get_viewport().get_texture().get_image()
		image.save_png("res://preview_hazard_%s.png" % showcase_id)
	board.prepare_run_encounter("baggage", 0)
	train_art.set_active_run_car("baggage", 1)
	turn.objective_text = saved_showcase_objective
	ui.update_from_turn(turn)
	for _frame in range(12):
		await get_tree().process_frame
	for _frame in range(18):
		await get_tree().process_frame
	image = get_viewport().get_texture().get_image()
	image.save_png("res://preview.png")
	get_tree().quit()
