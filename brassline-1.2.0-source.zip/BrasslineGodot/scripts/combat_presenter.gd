class_name BrasslineCombatPresenter
extends Node

# This node reacts to resolved combat facts. It never asks the simulation to
# pause, reroll, reorder initiative, or change damage; presentation remains a
# disposable layer over the deterministic autobattle director.

var camera_rig: TacticalCameraRig
var interface: AutobattleUI
var focus_mode := "key_beats"
var reduced_motion := false
var battle_speed := 1.0
var _focus_serial := 0

const KEY_BEATS := [
	"environment",
	"train_warning",
	"signature_move",
	"cripple",
	"plan_break",
	"casualty",
	"surrender",
	"victory",
	"defeat",
	"item",
]
const BASE_PACE_SCALE := 0.5


func setup(rig: TacticalCameraRig, autobattle_interface: AutobattleUI) -> void:
	camera_rig = rig
	interface = autobattle_interface


func set_preferences(new_focus_mode: String, new_reduced_motion: bool) -> void:
	focus_mode = new_focus_mode if new_focus_mode in ["key_beats", "full", "off"] else "key_beats"
	reduced_motion = new_reduced_motion


func set_speed(speed: float, _paused: bool = false) -> void:
	battle_speed = clampf(speed, 1.0, 4.0)


func present(beat: Dictionary) -> void:
	if not is_instance_valid(interface) or not is_instance_valid(camera_rig):
		return
	var beat_type := String(beat.get("type", "event"))
	var consequential := beat_type in KEY_BEATS
	if not consequential and focus_mode != "full":
		return
	interface.show_presentation_beat(beat, battle_speed, reduced_motion)
	if focus_mode == "off" or reduced_motion:
		return
	var actor := beat.get("actor") as TacticalUnit
	var target := beat.get("target") as TacticalUnit
	var focus := Vector3.ZERO
	var has_focus := false
	if is_instance_valid(actor) and is_instance_valid(target):
		focus = (actor.global_position + target.global_position) * 0.5
		has_focus = true
	elif is_instance_valid(target):
		focus = target.global_position
		has_focus = true
	elif is_instance_valid(actor):
		focus = actor.global_position
		has_focus = true
	if not has_focus:
		return
	_focus_serial += 1
	var serial := _focus_serial
	# Key beats momentarily take the viewer into the carriage. The simulation is
	# untouched; this is a visual cut that makes signatures and cripples land.
	var punch_distance := 12.2 if beat_type in ["signature_move", "cripple", "casualty", "surrender", "victory", "defeat"] else 13.4
	var subjects: Array[Vector3] = []
	if is_instance_valid(actor): subjects.append(actor.global_position)
	if is_instance_valid(target) and target != actor: subjects.append(target.global_position)
	camera_rig.set_presentation_subjects(subjects, punch_distance)
	var effective_speed := maxf(0.2, battle_speed * BASE_PACE_SCALE)
	var focus_base := 1.95 if beat_type in ["casualty", "surrender", "plan_break", "victory", "defeat"] else (1.48 if consequential else 0.75)
	_restore_car_frame_later(serial, focus_base / sqrt(effective_speed))


func _restore_car_frame_later(serial: int, duration: float) -> void:
	await get_tree().create_timer(duration, true, false, true).timeout
	if serial != _focus_serial or not is_instance_valid(camera_rig):
		return
	camera_rig.frame_active_car()
