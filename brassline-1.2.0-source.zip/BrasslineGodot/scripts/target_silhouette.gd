class_name TargetSilhouette
extends Control

signal zone_picked(zone: BrasslineTypes.BodyZone)

const Types := preload("res://scripts/game_types.gd")

var target: TacticalUnit
var selected_zone: Types.BodyZone = Types.BodyZone.TORSO
var zone_chances: Dictionary = {}
var zone_affordable: Dictionary = {}

var _ink := Color("#d8f5f1")
var _muted := Color("#52777b")
var _healthy := Color("#2f9da5")
var _wounded := Color("#c58b3b")
var _critical := Color("#c94e42")
var _selected := Color("#ffd166")
var _unavailable := Color("#26383b")
var _outline := Color(0.035, 0.105, 0.12, 0.98)


func _ready() -> void:
	custom_minimum_size = Vector2(0.0, 164.0)
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	tooltip_text = "Click an anatomical zone to prepare a called shot."


func set_snapshot(
		new_target: TacticalUnit,
		new_selected_zone: Types.BodyZone,
		chances: Dictionary,
		affordable: Dictionary
	) -> void:
	target = new_target
	selected_zone = new_selected_zone
	zone_chances = chances.duplicate()
	zone_affordable = affordable.duplicate()
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var geometry := _zone_geometry()
	_draw_scan_lines()

	if not is_instance_valid(target) or not target.is_alive:
		for zone in Types.BODY_ZONE_NAMES:
			for empty_points in geometry[zone]:
				draw_colored_polygon(_offset_points(empty_points, Vector2(1.5, 2.0)), Color(0.01, 0.03, 0.035, 0.52))
				draw_colored_polygon(empty_points, _unavailable.darkened(0.15))
				draw_polyline(_closed(empty_points), _muted.darkened(0.35), 1.2, true)
		draw_string(font, Vector2(maxf(0.0, size.x * 0.5 - 58.0), size.y - 5.0), "SELECT A TARGET", HORIZONTAL_ALIGNMENT_CENTER, 116.0, 11, _muted)
		_draw_header(font)
		return

	for zone in Types.BODY_ZONE_NAMES:
		var color := _zone_color(zone)
		for points in geometry[zone]:
			# Paired arms and legs remain visually separate but share one logical target.
			draw_colored_polygon(_offset_points(points, Vector2(1.6, 2.2)), Color(0.005, 0.018, 0.02, 0.64))
			draw_colored_polygon(points, color)
			draw_polyline(_closed(points), _selected if zone == selected_zone else _outline, 2.6 if zone == selected_zone else 1.25, true)
			_draw_zone_detail(zone, points, color)

	for zone in Types.BODY_ZONE_NAMES:
		var center := _zone_label_center(zone, geometry[zone])
		var chance := int(round(float(zone_chances.get(zone, 0.0)) * 100.0))
		var chance_color := _ink if bool(zone_affordable.get(zone, false)) else _muted
		var text_value := "%d%%" % chance if chance > 0 else "--"
		draw_string(font, center + Vector2(-16.0, 4.0), text_value, HORIZONTAL_ALIGNMENT_CENTER, 32.0, 10, chance_color)

	_draw_header(font)


func _draw_header(font: Font) -> void:
	draw_string(font, Vector2(4.0, 13.0), "ANATOMICAL HIT MAP", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 10, _muted)
	draw_string(font, Vector2(size.x - 53.0, 13.0), "1—4", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 10, _muted)


func _draw_scan_lines() -> void:
	var panel_rect := Rect2(2.0, 18.0, maxf(0.0, size.x - 4.0), maxf(0.0, size.y - 23.0))
	draw_rect(panel_rect, Color(0.015, 0.055, 0.062, 0.36), true)
	for y in range(24, int(size.y) - 7, 7):
		draw_line(Vector2(4.0, float(y)), Vector2(size.x - 4.0, float(y)), Color(0.18, 0.55, 0.56, 0.035), 1.0)


func _draw_zone_detail(zone: Types.BodyZone, points: PackedVector2Array, color: Color) -> void:
	var center := _polygon_center(points)
	var detail := color.lightened(0.28)
	detail.a = 0.34
	match zone:
		Types.BodyZone.HEAD:
			draw_arc(center + Vector2(0.0, -1.5), 7.0, PI * 0.16, PI * 0.84, 9, detail, 1.0, true)
			draw_line(center + Vector2(-6.0, 4.0), center + Vector2(6.0, 4.0), detail, 1.0, true)
		Types.BodyZone.TORSO:
			draw_line(center + Vector2(0.0, -15.0), center + Vector2(0.0, 17.0), detail, 1.0, true)
			draw_arc(center + Vector2(0.0, -5.0), 13.0, PI * 0.14, PI * 0.86, 9, detail, 1.0, true)
		Types.BodyZone.ARMS:
			draw_circle(center + Vector2(0.0, -2.0), 2.4, detail)
		Types.BodyZone.LEGS:
			draw_line(center + Vector2(0.0, -14.0), center + Vector2(0.0, 15.0), detail, 1.0, true)

	if zone == selected_zone:
		var radius := 8.0 if zone == Types.BodyZone.TORSO else 6.0
		draw_arc(center, radius, 0.0, TAU, 20, Color(_selected, 0.48), 1.1, true)
		for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
			draw_line(center + direction * (radius + 1.0), center + direction * (radius + 4.0), Color(_selected, 0.62), 1.0, true)


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if not is_instance_valid(target) or not target.is_alive:
			return
		var zone := _zone_at_point(event.position)
		if zone >= 0 and not target.is_zone_detached(zone):
			zone_picked.emit(zone)
			accept_event()


func _zone_at_point(point: Vector2) -> int:
	var geometry := _zone_geometry()
	for zone in Types.BODY_ZONE_NAMES:
		for points in geometry[zone]:
			if Geometry2D.is_point_in_polygon(point, points):
				return int(zone)
	return -1


func _zone_geometry() -> Dictionary:
	var center_x := size.x * 0.5
	var top := 22.0
	return {
		Types.BodyZone.HEAD: [_ellipse_points(Vector2(center_x, top + 14.0), Vector2(13.2, 15.0), 18)],
		Types.BodyZone.TORSO: [PackedVector2Array([
			Vector2(center_x - 8.0, top + 31.0), Vector2(center_x - 17.0, top + 34.0),
			Vector2(center_x - 27.0, top + 39.0), Vector2(center_x - 24.0, top + 51.0),
			Vector2(center_x - 21.0, top + 65.0), Vector2(center_x - 22.0, top + 78.0),
			Vector2(center_x - 17.0, top + 86.0), Vector2(center_x - 6.0, top + 89.0),
			Vector2(center_x, top + 85.0), Vector2(center_x + 6.0, top + 89.0),
			Vector2(center_x + 17.0, top + 86.0), Vector2(center_x + 22.0, top + 78.0),
			Vector2(center_x + 21.0, top + 65.0), Vector2(center_x + 24.0, top + 51.0),
			Vector2(center_x + 27.0, top + 39.0), Vector2(center_x + 17.0, top + 34.0),
			Vector2(center_x + 8.0, top + 31.0),
		])],
		Types.BodyZone.ARMS: [
			PackedVector2Array([
				Vector2(center_x - 28.0, top + 39.0), Vector2(center_x - 37.0, top + 42.0),
				Vector2(center_x - 41.0, top + 51.0), Vector2(center_x - 45.0, top + 63.0),
				Vector2(center_x - 52.0, top + 77.0), Vector2(center_x - 55.0, top + 90.0),
				Vector2(center_x - 50.0, top + 96.0), Vector2(center_x - 43.0, top + 91.0),
				Vector2(center_x - 39.0, top + 78.0), Vector2(center_x - 33.0, top + 65.0),
				Vector2(center_x - 24.0, top + 52.0),
			]),
			PackedVector2Array([
				Vector2(center_x + 28.0, top + 39.0), Vector2(center_x + 37.0, top + 42.0),
				Vector2(center_x + 41.0, top + 51.0), Vector2(center_x + 45.0, top + 63.0),
				Vector2(center_x + 52.0, top + 77.0), Vector2(center_x + 55.0, top + 90.0),
				Vector2(center_x + 50.0, top + 96.0), Vector2(center_x + 43.0, top + 91.0),
				Vector2(center_x + 39.0, top + 78.0), Vector2(center_x + 33.0, top + 65.0),
				Vector2(center_x + 24.0, top + 52.0),
			]),
		],
		Types.BodyZone.LEGS: [
			PackedVector2Array([
				Vector2(center_x - 18.0, top + 89.0), Vector2(center_x - 3.0, top + 89.0),
				Vector2(center_x - 5.0, top + 102.0), Vector2(center_x - 8.0, top + 116.0),
				Vector2(center_x - 7.0, top + 132.0), Vector2(center_x - 10.0, top + 139.0),
				Vector2(center_x - 26.0, top + 139.0), Vector2(center_x - 27.0, top + 133.0),
				Vector2(center_x - 23.0, top + 117.0), Vector2(center_x - 23.0, top + 101.0),
			]),
			PackedVector2Array([
				Vector2(center_x + 18.0, top + 89.0), Vector2(center_x + 3.0, top + 89.0),
				Vector2(center_x + 5.0, top + 102.0), Vector2(center_x + 8.0, top + 116.0),
				Vector2(center_x + 7.0, top + 132.0), Vector2(center_x + 10.0, top + 139.0),
				Vector2(center_x + 26.0, top + 139.0), Vector2(center_x + 27.0, top + 133.0),
				Vector2(center_x + 23.0, top + 117.0), Vector2(center_x + 23.0, top + 101.0),
			]),
		],
	}


func _ellipse_points(center: Vector2, radii: Vector2, samples: int) -> PackedVector2Array:
	var points := PackedVector2Array()
	for index in range(samples):
		var angle := -PI * 0.5 + TAU * float(index) / float(samples)
		points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	return points


func _zone_label_center(zone: Types.BodyZone, polygons: Array) -> Vector2:
	var center := _polygon_center(polygons[0])
	match zone:
		Types.BodyZone.ARMS:
			center += Vector2(-1.0, 4.0)
		Types.BodyZone.LEGS:
			center += Vector2(-1.0, 5.0)
	return center


func _zone_color(zone: Types.BodyZone) -> Color:
	if target.is_zone_detached(zone):
		return _unavailable
	var ratio := target.zone_hp_ratio(zone)
	var color := _healthy
	if ratio <= 0.0:
		color = _critical.darkened(0.30)
	elif ratio <= 0.45:
		color = _critical
	elif ratio < 1.0:
		color = _wounded
	if not bool(zone_affordable.get(zone, false)):
		color = color.darkened(0.42)
	return color


func _closed(points: PackedVector2Array) -> PackedVector2Array:
	var result := points.duplicate()
	if not result.is_empty():
		result.append(result[0])
	return result


func _offset_points(points: PackedVector2Array, offset: Vector2) -> PackedVector2Array:
	var result := PackedVector2Array()
	for point in points:
		result.append(point + offset)
	return result


func _polygon_center(points: PackedVector2Array) -> Vector2:
	var result := Vector2.ZERO
	for point in points:
		result += point
	return result / maxf(1.0, float(points.size()))
