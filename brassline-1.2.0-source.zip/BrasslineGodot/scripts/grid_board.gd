class_name GridBoard
extends Node3D

const Types := preload("res://scripts/game_types.gd")

const CELL_SIZE := 1.5
const CELL_SIZE_X := 1.08
const CELL_SIZE_Z := 1.5
const BOARD_SIZE := Vector2i(20, 5)
const CREW_DEPLOYMENT_MAX_X := 4
const ENEMY_DEPLOYMENT_MIN_X := 9
const MIN_DEPLOYMENT_DISTANCE := 5
const MIN_CREW_DEPLOYMENT_DISTANCE := 2

var blocked_cells: Dictionary = {}
var hazard_cells: Dictionary = {}
var floor_meshes: Dictionary = {}
var cover_visuals: Dictionary = {}
var objective_cell := Vector2i(18, 2)
var extraction_cell := Vector2i(0, 2)
var objective_collected := false
var objective_marker: Node3D
var control_cell := Vector2i(17, 2)
var control_claimed := false
var control_marker: Node3D
var run_encounter_mode := false
var finale_objective_mode := false
var active_car_id := ""

var _floor_materials: Array[StandardMaterial3D] = []
var _cover_material: StandardMaterial3D
var _brass_material: StandardMaterial3D
var _wall_material: StandardMaterial3D
var _seam_material: StandardMaterial3D
var _hazard_material: StandardMaterial3D
var _objective_material: StandardMaterial3D
var _extraction_material: StandardMaterial3D
var _reachable_overlay: StandardMaterial3D
var _path_overlay: StandardMaterial3D
var _active_floor_material: StandardMaterial3D
var _run_floor_materials: Dictionary = {}
var _cover_preview_full_material: StandardMaterial3D
var _cover_preview_half_material: StandardMaterial3D
var _cover_indicator_root: Node3D
var _deployment_preview_root: Node3D
var _deployment_preview_material: StandardMaterial3D


func _ready() -> void:
	_build_materials()
	_configure_layout()
	_build_train()


func _build_materials() -> void:
	_floor_materials = [
		_make_material(Color("#2a1d18"), 0.10, 0.84),
		_make_material(Color("#202424"), 0.62, 0.52),
		_make_material(Color("#1b1c23"), 0.70, 0.46),
	]
	_cover_material = _make_material(Color("#303435"), 0.72, 0.52)
	_brass_material = _make_material(Color("#9c6a31"), 0.86, 0.38)
	_wall_material = _make_material(Color("#141819"), 0.74, 0.48)
	_seam_material = _make_material(Color("#0b0d0d"), 0.32, 0.88)
	_hazard_material = _make_material(Color("#3c1815"), 0.45, 0.62, Color("#9e2e21"), 0.65)
	_objective_material = _make_material(Color("#352842"), 0.54, 0.48, Color("#8d5ac3"), 0.80)
	_extraction_material = _make_material(Color("#183329"), 0.42, 0.62, Color("#378f66"), 0.58)
	_reachable_overlay = _make_overlay(Color(0.08, 0.42, 0.44, 0.055), Color("#1c5558"))
	_path_overlay = _make_overlay(Color(0.74, 0.42, 0.12, 0.18), Color("#a76125"))
	_cover_preview_full_material = _make_material(Color(0.20, 0.78, 0.72, 0.92), 0.42, 0.28, Color("#52d4c8"), 2.2)
	_cover_preview_half_material = _make_material(Color(0.86, 0.59, 0.20, 0.92), 0.54, 0.30, Color("#d99a39"), 1.8)
	_cover_preview_full_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_cover_preview_half_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_deployment_preview_material = _make_material(Color(0.24, 0.91, 0.72, 0.34), 0.28, 0.34, Color("#50e8b8"), 2.4)
	_deployment_preview_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_run_floor_materials = {
		"baggage": _make_material(Color("#33251c"), 0.10, 0.88),
		"cargo": _make_material(Color("#30241b"), 0.12, 0.90),
		"dining": _make_material(Color("#3b2a21"), 0.08, 0.82),
		"bar": _make_material(Color("#2b1819"), 0.12, 0.84),
		"casino": _make_material(Color("#301a2d"), 0.14, 0.78),
		"crew": _make_material(Color("#1c3030"), 0.40, 0.64),
		"armory": _make_material(Color("#242728"), 0.76, 0.46),
		"engine": _make_material(Color("#2d201b"), 0.68, 0.52),
		"observation": _make_material(Color("#273335"), 0.48, 0.42),
		"sleeper": _make_material(Color("#282335"), 0.18, 0.74),
	}
	_active_floor_material = _run_floor_materials["baggage"]


func _make_material(
		color: Color,
		metallic: float,
		roughness: float,
		emission_color: Color = Color.BLACK,
		emission_energy: float = 0.0
	) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission_color
		material.emission_energy_multiplier = emission_energy
	return material


func _make_overlay(color: Color, emission_color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color = color
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.emission_enabled = true
	material.emission = emission_color
	material.emission_energy_multiplier = 0.34
	return material


func _configure_layout() -> void:
	# Compartment walls leave a single central gangway between each train car.
	for divider_x in [6, 13]:
		for row in [0, 1, 3, 4]:
			blocked_cells[Vector2i(divider_x, row)] = true

	for cell in [
		Vector2i(2, 0), Vector2i(2, 4), Vector2i(4, 1),
		Vector2i(8, 3), Vector2i(9, 1), Vector2i(11, 0), Vector2i(11, 4),
		Vector2i(15, 1), Vector2i(16, 3), Vector2i(18, 0), Vector2i(18, 4),
	]:
		blocked_cells[cell] = true

	for cell in [Vector2i(10, 2), Vector2i(15, 4)]:
		hazard_cells[cell] = true


func _build_train() -> void:
	for y in range(BOARD_SIZE.y):
		for x in range(BOARD_SIZE.x):
			_build_floor_cell(Vector2i(x, y))

	for cell in blocked_cells:
		_build_cover(cell)

	_build_objective_marker()
	_build_control_marker()
	_rebuild_cover_indicators()


func _build_floor_cell(cell: Vector2i) -> void:
	var body := StaticBody3D.new()
	body.name = "Floor_%02d_%02d" % [cell.x, cell.y]
	body.collision_layer = 1
	body.collision_mask = 0
	body.set_meta("grid_cell", cell)
	body.position = cell_to_world(cell)
	add_child(body)

	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(CELL_SIZE_X * 0.995, 0.10, CELL_SIZE_Z * 0.995)
	mesh.mesh = box
	mesh.material_override = _material_for_cell(cell)
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	body.add_child(mesh)
	floor_meshes[cell] = mesh

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(CELL_SIZE_X * 0.96, 0.10, CELL_SIZE_Z * 0.96)
	collision.shape = shape
	body.add_child(collision)

	# One dark deck seam per tile reads as planking, not a luminous board-game grid.
	var seam := MeshInstance3D.new()
	var seam_mesh := BoxMesh.new()
	seam_mesh.size = Vector3(CELL_SIZE_X * 0.96, 0.012, 0.018)
	seam.mesh = seam_mesh
	seam.position = Vector3(0.0, 0.057, 0.0)
	seam.material_override = _seam_material
	body.add_child(seam)


func _material_for_cell(cell: Vector2i) -> StandardMaterial3D:
	if (not run_encounter_mode or finale_objective_mode) and cell == extraction_cell:
		return _extraction_material
	if (not run_encounter_mode or finale_objective_mode) and cell == objective_cell and not objective_collected:
		return _objective_material
	if hazard_cells.has(cell):
		return _hazard_material
	if run_encounter_mode and is_instance_valid(_active_floor_material):
		return _active_floor_material
	var car_index := 0 if cell.x <= 6 else (1 if cell.x <= 13 else 2)
	return _floor_materials[car_index]


func _build_cover(cell: Vector2i) -> void:
	var height := 0.72
	if cell.x in [6, 13]:
		height = 1.45
	var body := StaticBody3D.new()
	body.name = "Cover_%02d_%02d" % [cell.x, cell.y]
	body.collision_layer = 1
	body.collision_mask = 0
	body.set_meta("grid_cell", cell)
	body.position = cell_to_world(cell) + Vector3(0.0, 0.08 + height * 0.5, 0.0)
	add_child(body)

	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(CELL_SIZE_X * 0.72, height, CELL_SIZE_Z * 0.72)
	mesh.mesh = box
	mesh.material_override = _wall_material if height > 1.0 else _cover_material
	body.add_child(mesh)
	var visuals: Array[MeshInstance3D] = [mesh]

	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = box.size
	collision.shape = shape
	body.add_child(collision)

	if height < 1.0:
		var strap := MeshInstance3D.new()
		var strap_mesh := BoxMesh.new()
		strap_mesh.size = Vector3(CELL_SIZE_X * 0.76, 0.08, CELL_SIZE_Z * 0.76)
		strap.mesh = strap_mesh
		strap.position.y = height * 0.15
		strap.material_override = _brass_material
		body.add_child(strap)
		visuals.append(strap)
	cover_visuals[cell] = visuals


func _build_car_shells() -> void:
	var total_length := BOARD_SIZE.x * CELL_SIZE_X
	var total_width := BOARD_SIZE.y * CELL_SIZE_Z
	for side in [-1.0, 1.0]:
		_add_box(
			Vector3(total_length + 0.7, 0.30, 0.14),
			Vector3(0.0, 0.20, side * (total_width * 0.5 + 0.12)),
			_wall_material
		)
		_add_box(
			Vector3(total_length + 0.8, 0.10, 0.34),
			Vector3(0.0, 0.64, side * (total_width * 0.5 + 0.12)),
			_brass_material
		)

func _add_box(size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh_instance.mesh = box
	mesh_instance.position = at
	mesh_instance.material_override = material
	add_child(mesh_instance)
	return mesh_instance

func _build_objective_marker() -> void:
	objective_marker = Node3D.new()
	objective_marker.name = "BlueprintCase"
	objective_marker.position = cell_to_world(objective_cell) + Vector3(0.0, 0.52, 0.0)
	add_child(objective_marker)

	var case := MeshInstance3D.new()
	var case_mesh := BoxMesh.new()
	case_mesh.size = Vector3(0.78, 0.30, 0.52)
	case.mesh = case_mesh
	case.material_override = _objective_material
	objective_marker.add_child(case)

	var handle := MeshInstance3D.new()
	var handle_mesh := TorusMesh.new()
	handle_mesh.inner_radius = 0.13
	handle_mesh.outer_radius = 0.20
	handle.mesh = handle_mesh
	handle.position.y = 0.22
	handle.rotation_degrees.x = 90.0
	handle.material_override = _brass_material
	objective_marker.add_child(handle)

	var light := OmniLight3D.new()
	light.light_color = Color("#c68dff")
	light.light_energy = 2.1
	light.omni_range = 3.2
	light.shadow_enabled = true
	objective_marker.add_child(light)


func _build_control_marker() -> void:
	control_marker = Node3D.new()
	control_marker.name = "CarriageControl"
	control_marker.position = cell_to_world(control_cell) + Vector3(0.0, 0.08, 0.0)
	add_child(control_marker)
	var ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.34
	ring_mesh.outer_radius = 0.44
	ring_mesh.rings = 24
	ring_mesh.ring_segments = 10
	ring.mesh = ring_mesh
	ring.rotation_degrees.x = 90.0
	ring.material_override = _brass_material
	control_marker.add_child(ring)
	var plate := MeshInstance3D.new()
	var plate_mesh := CylinderMesh.new()
	plate_mesh.top_radius = 0.27
	plate_mesh.bottom_radius = 0.31
	plate_mesh.height = 0.09
	plate.mesh = plate_mesh
	plate.position.y = 0.06
	plate.material_override = _wall_material
	control_marker.add_child(plate)


func collect_objective() -> void:
	objective_collected = true
	if is_instance_valid(objective_marker):
		objective_marker.visible = false
	_refresh_cell_material(objective_cell)


func drop_objective(cell: Vector2i) -> void:
	objective_collected = false
	objective_cell = cell
	if is_instance_valid(objective_marker):
		objective_marker.position = cell_to_world(cell) + Vector3(0.0, 0.52, 0.0)
		objective_marker.visible = true
	_refresh_cell_material(cell)


func prepare_run_encounter(car_id: String, variant_index: int = 0) -> void:
	run_encounter_mode = true
	finale_objective_mode = false
	active_car_id = car_id
	_active_floor_material = _run_floor_materials.get(car_id, _run_floor_materials["baggage"])
	objective_collected = false
	control_claimed = false
	if is_instance_valid(control_marker):
		control_marker.visible = true
		control_marker.position = cell_to_world(control_cell) + Vector3(0.0, 0.08, 0.0)
	if is_instance_valid(objective_marker):
		objective_marker.visible = false
	_apply_car_layout(car_id)
	hazard_cells.clear()
	match car_id:
		"engine":
			hazard_cells[Vector2i(9, 2)] = true
			hazard_cells[Vector2i(11, 3)] = true
		"bar", "casino":
			hazard_cells[Vector2i(9, 2)] = true
		"armory":
			hazard_cells[Vector2i(10, 2)] = true
		"cargo":
			hazard_cells[Vector2i(8, 3)] = true
	match posmod(variant_index, 3):
		1:
			hazard_cells[Vector2i(10, 0)] = true
		2:
			hazard_cells[Vector2i(12, 4)] = true
			if car_id in ["engine", "armory", "cargo"]:
				hazard_cells[Vector2i(7, 1)] = true
	for cell in floor_meshes:
		_refresh_cell_material(cell)


func claim_control() -> void:
	control_claimed = true
	if is_instance_valid(control_marker):
		control_marker.scale = Vector3.ONE * 1.28
		for child in control_marker.get_children():
			if child is MeshInstance3D:
				(child as MeshInstance3D).material_override = _extraction_material


func _apply_car_layout(car_id: String) -> void:
	# Every encounter still uses the proven 20x5 combat grid, but its cover plan now
	# belongs to the current carriage instead of three permanent generic rooms.
	# The central row remains a guaranteed route for the finale extraction.
	var layout: Array[Vector2i] = []
	match car_id:
		"dining":
			layout = [Vector2i(4, 0), Vector2i(4, 4), Vector2i(7, 1), Vector2i(7, 4), Vector2i(10, 1), Vector2i(13, 0), Vector2i(13, 4), Vector2i(16, 1), Vector2i(16, 3)]
		"bar", "casino":
			layout = [Vector2i(5, 0), Vector2i(5, 4), Vector2i(8, 3), Vector2i(10, 1), Vector2i(13, 3), Vector2i(15, 0), Vector2i(15, 4), Vector2i(17, 1)]
		"crew":
			layout = [Vector2i(4, 1), Vector2i(4, 3), Vector2i(6, 0), Vector2i(6, 4), Vector2i(9, 1), Vector2i(12, 0), Vector2i(12, 3), Vector2i(15, 1), Vector2i(15, 4), Vector2i(18, 0)]
		"armory":
			layout = [Vector2i(4, 0), Vector2i(4, 4), Vector2i(6, 1), Vector2i(6, 3), Vector2i(9, 1), Vector2i(10, 2), Vector2i(12, 0), Vector2i(12, 3), Vector2i(14, 1), Vector2i(14, 3), Vector2i(17, 0), Vector2i(17, 4)]
		"engine":
			layout = [Vector2i(4, 0), Vector2i(4, 4), Vector2i(6, 1), Vector2i(6, 4), Vector2i(9, 0), Vector2i(10, 1), Vector2i(11, 3), Vector2i(13, 0), Vector2i(13, 4), Vector2i(16, 1), Vector2i(16, 3), Vector2i(18, 4)]
		"observation":
			layout = [Vector2i(5, 0), Vector2i(5, 4), Vector2i(10, 1), Vector2i(14, 0), Vector2i(14, 4)]
		"sleeper":
			layout = [Vector2i(4, 0), Vector2i(4, 4), Vector2i(7, 1), Vector2i(7, 3), Vector2i(10, 0), Vector2i(13, 1), Vector2i(13, 3), Vector2i(16, 4)]
		_:
			layout = [Vector2i(4, 0), Vector2i(4, 4), Vector2i(6, 1), Vector2i(6, 3), Vector2i(9, 0), Vector2i(12, 3), Vector2i(15, 1), Vector2i(15, 4), Vector2i(18, 0)]

	for cell in blocked_cells:
		var old_cover := get_node_or_null("Cover_%02d_%02d" % [cell.x, cell.y])
		if is_instance_valid(old_cover):
			old_cover.queue_free()
	blocked_cells.clear()
	cover_visuals.clear()
	for cell in layout:
		blocked_cells[cell] = true
		_build_cover(cell)
		set_cover_visual_visible(cell, false)
	_rebuild_cover_indicators()


func _rebuild_cover_indicators() -> void:
	if is_instance_valid(_cover_indicator_root):
		remove_child(_cover_indicator_root)
		_cover_indicator_root.queue_free()
	_cover_indicator_root = Node3D.new()
	_cover_indicator_root.name = "ContextualCoverPreview"
	add_child(_cover_indicator_root)
	for y in range(BOARD_SIZE.y):
		for x in range(BOARD_SIZE.x):
			var cell := Vector2i(x, y)
			if blocked_cells.has(cell):
				continue
			for direction in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
				if not blocked_cells.has(cell + direction):
					continue
				var indicator := MeshInstance3D.new()
				indicator.name = "CoverShield_%02d_%02d_%d_%d" % [cell.x, cell.y, direction.x, direction.y]
				var mesh := BoxMesh.new()
				mesh.size = Vector3(0.26, 0.035, 0.26)
				indicator.mesh = mesh
				indicator.position = cell_to_world(cell) + Vector3(
					float(direction.x) * CELL_SIZE_X * 0.36,
					0.094,
					float(direction.y) * CELL_SIZE_Z * 0.36
				)
				indicator.rotation_degrees.y = 45.0
				indicator.material_override = _cover_preview_half_material
				indicator.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				indicator.visible = false
				indicator.set_meta("protected_cell", cell)
				indicator.set_meta("cover_direction", direction)
				_cover_indicator_root.add_child(indicator)
	_cover_indicator_root.visible = true


func show_cover_preview(attacker_cell: Vector2i, candidate_cells: Array) -> void:
	if not is_instance_valid(_cover_indicator_root):
		return
	var candidates := {}
	for candidate in candidate_cells:
		candidates[Vector2i(candidate)] = true
	for child in _cover_indicator_root.get_children():
		var indicator := child as MeshInstance3D
		if indicator == null:
			continue
		indicator.visible = false
		var protected_cell: Vector2i = indicator.get_meta("protected_cell")
		if not candidates.has(protected_cell):
			continue
		var level := cover_level(attacker_cell, protected_cell)
		if level <= 0:
			continue
		var cover_direction := _cover_direction(attacker_cell, protected_cell, level)
		if Vector2i(indicator.get_meta("cover_direction")) != cover_direction:
			continue
		indicator.material_override = _cover_preview_full_material if level == 2 else _cover_preview_half_material
		indicator.visible = true


func hide_cover_preview() -> void:
	if not is_instance_valid(_cover_indicator_root):
		return
	for child in _cover_indicator_root.get_children():
		if child is MeshInstance3D:
			child.visible = false


func show_deployment_preview(deployment: Dictionary, crew: Array[TacticalUnit], plan: Dictionary = {}, fallback: Dictionary = {}) -> void:
	clear_deployment_preview()
	_deployment_preview_root = Node3D.new()
	_deployment_preview_root.name = "PlanDeploymentGhosts"
	_deployment_preview_root.set_meta("deployment_count", deployment.size())
	_deployment_preview_root.set_meta("preview_beat_count", 3)
	_deployment_preview_root.set_meta("fallback_id", String(fallback.get("id", "hold_plan")))
	var gear_preview_count := 0
	add_child(_deployment_preview_root)
	var risk_world := Vector3.ZERO
	var has_risk_world := false
	var first_world := Vector3.ZERO
	var has_first_world := false
	for unit in crew:
		if not is_instance_valid(unit) or not deployment.has(unit.roster_id):
			continue
		var cell: Vector2i = deployment[unit.roster_id]
		var preview_world := cell_to_world(cell)
		if not has_first_world:
			first_world = preview_world
			has_first_world = true
		var marker := MeshInstance3D.new()
		marker.name = "%s_Mark" % unit.roster_id
		var disc := TorusMesh.new()
		disc.inner_radius = 0.43
		disc.outer_radius = 0.51
		disc.rings = 20
		disc.ring_segments = 24
		marker.mesh = disc
		marker.position = cell_to_world(cell) + Vector3(0.0, 0.086, 0.0)
		marker.set_meta("deployment_cell", cell)
		var risk := unit.roster_id == String(plan.get("risk_unit_id", ""))
		if risk:
			risk_world = preview_world
			has_risk_world = true
		marker.material_override = _plan_preview_color(Color("#e3b65c") if risk else Color("#72d8b6"))
		marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_deployment_preview_root.add_child(marker)
		var order := Dictionary(Dictionary(plan.get("orders", {})).get(unit.roster_id, {}))
		var gear_item := String(order.get("gear_item", ""))
		if gear_item.is_empty() and unit.roster_id == String(plan.get("gear_user_id", "")):
			gear_item = String(plan.get("gear_item", ""))
		if not gear_item.is_empty():
			gear_preview_count += 1
			_add_gear_marker(gear_item, preview_world + Vector3(0.38, 0.28, 0.30))
	for raw_preview in Array(plan.get("opening_preview", [])):
		var preview := Dictionary(raw_preview)
		var from := cell_to_world(Vector2i(preview["from"])) + Vector3(0, 0.15, 0)
		var to := cell_to_world(Vector2i(preview["to"])) + Vector3(0, 0.15, 0)
		var clear := bool(preview.get("clear", false))
		var line := Node3D.new(); line.name = "%s_IntentLine" % String(preview.get("roster_id", "crew")); line.set_meta("clear_shot", clear); _deployment_preview_root.add_child(line)
		var material := _plan_preview_color(Color("#72d8b6") if clear else Color("#e3b65c"))
		var length := from.distance_to(to)
		var direction := (to - from).normalized()
		# A clear firing lane is solid; an obstructed/out-of-range lane is dashed,
		# explicitly telling the player the operative must move before shooting.
		if clear:
			_add_plan_line_segment(line, from + direction * 0.55, to - direction * 0.55, material)
		else:
			var step := 0.55
			while step < length - 0.55:
				_add_plan_line_segment(line, from + direction * step, from + direction * minf(step + 0.32, length - 0.55), material)
				step += 0.62
	if plan.has("target_instance_id"):
		var target := instance_from_id(int(plan["target_instance_id"])) as TacticalUnit
		if is_instance_valid(target):
			var ring := MeshInstance3D.new(); ring.name = "PriorityTarget"
			var torus := TorusMesh.new(); torus.inner_radius = 0.56; torus.outer_radius = 0.64; torus.rings = 20; torus.ring_segments = 24
			ring.mesh = torus; ring.material_override = _plan_preview_color(Color("#ff7d6e")); ring.position = cell_to_world(target.grid_cell) + Vector3(0, 0.09, 0); _deployment_preview_root.add_child(ring)
	_draw_environment_preview(Dictionary(plan.get("environment_preview", {})))
	var fallback_world := risk_world if has_risk_world else first_world
	if has_first_world and String(fallback.get("id", "")) in ["protect_wounded", "save_crew"]:
		var shield := MeshInstance3D.new()
		shield.name = "ConditionalFallbackProtection"
		var ring := TorusMesh.new(); ring.inner_radius = 0.60; ring.outer_radius = 0.66; ring.rings = 24; ring.ring_segments = 12
		shield.mesh = ring; shield.position = fallback_world + Vector3(0, 0.105, 0)
		shield.material_override = _plan_preview_color(Color("#81bdb4"))
		shield.set_meta("conditional", true)
		_deployment_preview_root.add_child(shield)
	for roster_id in Dictionary(plan.get("fallback_destinations", {})):
		if not deployment.has(roster_id): continue
		var start := Vector2i(deployment[roster_id])
		var goal := Vector2i(Dictionary(plan["fallback_destinations"])[roster_id])
		var path := find_path(start, goal)
		var retreat := Node3D.new(); retreat.name = "ConditionalRetreat_%s" % str(roster_id); retreat.set_meta("destination", goal); retreat.set_meta("conditional", true)
		_deployment_preview_root.add_child(retreat)
		for index in range(1, path.size()):
			var from := cell_to_world(path[index-1]) + Vector3(0,0.12,0)
			var to := cell_to_world(path[index]) + Vector3(0,0.12,0)
			_add_plan_line_segment(retreat, from.lerp(to,0.18), from.lerp(to,0.70), _plan_preview_color(Color("#81bdb4")))
	_deployment_preview_root.set_meta("gear_preview_count", gear_preview_count)
	_deployment_preview_root.set_meta("world_text_count", 0)


func _add_gear_marker(item_id: String, at: Vector3) -> void:
	var marker := MeshInstance3D.new(); marker.name = "CommittedGear_%s" % item_id
	var mesh := CylinderMesh.new(); mesh.top_radius = 0.07; mesh.bottom_radius = 0.12; mesh.height = 0.24
	if item_id.contains("grenade"):
		mesh.top_radius = 0.10
	marker.mesh = mesh; marker.position = at; marker.material_override = _plan_preview_color(Color("#e3b65c"))
	marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	marker.set_meta("gear_item", item_id)
	_deployment_preview_root.add_child(marker)


func _draw_environment_preview(preview: Dictionary) -> void:
	if preview.is_empty() or not bool(preview.get("valid", false)):
		return
	var control_only := bool(preview.get("control_only", false))
	var preview_color := Color("#72d8b6") if control_only else Color("#df9560")
	var cells: Array = Array(preview.get("affected_cells", []))
	if control_only:
		cells = [preview.get("impact_cell", Vector2i.ZERO)]
	for raw_cell in cells:
		var cell := Vector2i(raw_cell)
		if not is_inside(cell): continue
		var tile := MeshInstance3D.new(); tile.name = "EnvironmentArea_%d_%d" % [cell.x, cell.y]
		var mesh := BoxMesh.new(); mesh.size = Vector3(CELL_SIZE_X * 0.91, 0.012, CELL_SIZE_Z * 0.91); tile.mesh = mesh
		var material := _plan_preview_color(Color(preview_color, 0.24))
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		tile.material_override = material; tile.position = cell_to_world(cell) + Vector3(0, 0.075, 0)
		tile.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		tile.set_meta("affected_cell", cell)
		_deployment_preview_root.add_child(tile)
	for raw_victim in Array(preview.get("victims", [])):
		var victim := Dictionary(raw_victim)
		var marker := MeshInstance3D.new(); marker.name = "EnvironmentVictim_%s" % str(victim.get("instance_id", ""))
		var ring := TorusMesh.new(); ring.inner_radius = 0.54; ring.outer_radius = 0.60; ring.rings = 24; ring.ring_segments = 10
		marker.mesh = ring; marker.material_override = _plan_preview_color(preview_color)
		marker.position = cell_to_world(Vector2i(victim.get("cell", Vector2i.ZERO))) + Vector3(0, 0.11, 0)
		_deployment_preview_root.add_child(marker)


func _plan_preview_color(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = color
	return material


func _add_plan_line_segment(parent: Node3D, from: Vector3, to: Vector3, material: Material) -> void:
	if from.distance_to(to) < 0.01:
		return
	var segment := MeshInstance3D.new()
	var box := BoxMesh.new(); box.size = Vector3(0.032, 0.018, from.distance_to(to)); segment.mesh = box
	segment.material_override = material; segment.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(segment); segment.position = (from + to) * 0.5; segment.look_at(parent.to_global(to), Vector3.UP)


func _add_plan_beat_label(text: String, world_position: Vector3, color: Color, font_size: int = 26) -> Label3D:
	var label := Label3D.new()
	label.text = text
	label.font_size = font_size
	label.pixel_size = 0.0045
	label.modulate = color
	label.outline_modulate = Color("#06110f")
	label.outline_size = 8
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.render_priority = 8
	label.position = world_position
	label.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_deployment_preview_root.add_child(label)
	return label


func clear_deployment_preview() -> void:
	if not is_instance_valid(_deployment_preview_root):
		return
	remove_child(_deployment_preview_root)
	_deployment_preview_root.queue_free()
	_deployment_preview_root = null


func visible_cover_preview_count() -> int:
	var count := 0
	if not is_instance_valid(_cover_indicator_root):
		return count
	for child in _cover_indicator_root.get_children():
		if child is MeshInstance3D and child.visible:
			count += 1
	return count


func _cover_direction(attacker: Vector2i, defender: Vector2i, level: int) -> Vector2i:
	var delta := attacker - defender
	var direction := Vector2i(signi(delta.x), signi(delta.y))
	if absi(delta.x) >= absi(delta.y):
		direction.y = 0
	else:
		direction.x = 0
	if level == 2:
		return direction
	var perpendicular := Vector2i(-direction.y, direction.x)
	if blocked_cells.has(defender + perpendicular):
		return perpendicular
	return -perpendicular


func prepare_finale_objective() -> void:
	finale_objective_mode = true
	objective_collected = false
	if is_instance_valid(objective_marker):
		objective_marker.visible = false
	for cell in floor_meshes:
		_refresh_cell_material(cell)


func reveal_finale_objective(cell: Vector2i) -> void:
	finale_objective_mode = true
	drop_objective(cell)


func _refresh_cell_material(cell: Vector2i) -> void:
	if floor_meshes.has(cell):
		floor_meshes[cell].material_override = _material_for_cell(cell)


func cell_to_world(cell: Vector2i) -> Vector3:
	var center_offset := Vector3(
		(float(BOARD_SIZE.x) - 1.0) * CELL_SIZE_X * 0.5,
		0.0,
		(float(BOARD_SIZE.y) - 1.0) * CELL_SIZE_Z * 0.5
	)
	return Vector3(cell.x * CELL_SIZE_X, 0.0, cell.y * CELL_SIZE_Z) - center_offset


func world_to_cell(world_position: Vector3) -> Vector2i:
	var local := to_local(world_position)
	var center_offset := Vector3(
		(float(BOARD_SIZE.x) - 1.0) * CELL_SIZE_X * 0.5,
		0.0,
		(float(BOARD_SIZE.y) - 1.0) * CELL_SIZE_Z * 0.5
	)
	local += center_offset
	return Vector2i(roundi(local.x / CELL_SIZE_X), roundi(local.z / CELL_SIZE_Z))


func is_inside(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.y >= 0 and cell.x < BOARD_SIZE.x and cell.y < BOARD_SIZE.y


func is_walkable(cell: Vector2i, occupied: Dictionary = {}) -> bool:
	return is_inside(cell) and not blocked_cells.has(cell) and not occupied.has(cell)


func get_reachable(start: Vector2i, max_steps: int, occupied: Dictionary = {}) -> Dictionary:
	var costs := {start: 0}
	var frontier: Array[Vector2i] = [start]
	while not frontier.is_empty():
		var current: Vector2i = frontier.pop_front()
		var current_cost: int = costs[current]
		if current_cost >= max_steps:
			continue
		for neighbor in _neighbors(current):
			if not is_walkable(neighbor, occupied) or costs.has(neighbor):
				continue
			costs[neighbor] = current_cost + 1
			frontier.push_back(neighbor)
	return costs


func find_path(
		start: Vector2i,
		goal: Vector2i,
		occupied: Dictionary = {},
		max_steps: int = 999
	) -> Array[Vector2i]:
	if start == goal:
		return [start]
	if not is_walkable(goal, occupied):
		return []
	var frontier: Array[Vector2i] = [start]
	var came_from := {start: start}
	var costs := {start: 0}
	while not frontier.is_empty():
		var current: Vector2i = frontier.pop_front()
		if current == goal:
			break
		if int(costs[current]) >= max_steps:
			continue
		for neighbor in _neighbors(current):
			if not is_walkable(neighbor, occupied) or came_from.has(neighbor):
				continue
			came_from[neighbor] = current
			costs[neighbor] = int(costs[current]) + 1
			frontier.push_back(neighbor)
	if not came_from.has(goal):
		return []
	var path: Array[Vector2i] = []
	var cursor := goal
	while cursor != start:
		path.push_front(cursor)
		cursor = came_from[cursor]
	path.push_front(start)
	return path


func _neighbors(cell: Vector2i) -> Array[Vector2i]:
	return [
		cell + Vector2i.RIGHT,
		cell + Vector2i.LEFT,
		cell + Vector2i.UP,
		cell + Vector2i.DOWN,
	]


func has_line_of_sight(from_cell: Vector2i, to_cell: Vector2i) -> bool:
	var cells := _line_cells(from_cell, to_cell)
	for index in range(1, maxi(1, cells.size() - 1)):
		if blocked_cells.has(cells[index]):
			return false
	return true


func _line_cells(from_cell: Vector2i, to_cell: Vector2i) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	var x0 := from_cell.x
	var y0 := from_cell.y
	var x1 := to_cell.x
	var y1 := to_cell.y
	var dx := absi(x1 - x0)
	var sx := 1 if x0 < x1 else -1
	var dy := -absi(y1 - y0)
	var sy := 1 if y0 < y1 else -1
	var error := dx + dy
	while true:
		result.append(Vector2i(x0, y0))
		if x0 == x1 and y0 == y1:
			break
		var twice_error := 2 * error
		if twice_error >= dy:
			error += dy
			x0 += sx
		if twice_error <= dx:
			error += dx
			y0 += sy
	return result


func cover_penalty(attacker: Vector2i, defender: Vector2i) -> float:
	match cover_level(attacker, defender):
		2:
			return 0.28
		1:
			return 0.14
	return 0.0


func cover_level(attacker: Vector2i, defender: Vector2i) -> int:
	var delta := attacker - defender
	var direction := Vector2i(signi(delta.x), signi(delta.y))
	if absi(delta.x) >= absi(delta.y):
		direction.y = 0
	else:
		direction.x = 0
	if blocked_cells.has(defender + direction):
		return 2
	var perpendicular := Vector2i(-direction.y, direction.x)
	if blocked_cells.has(defender + perpendicular) or blocked_cells.has(defender - perpendicular):
		return 1
	return 0


func has_adjacent_cover(cell: Vector2i) -> bool:
	for direction in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		if blocked_cells.has(cell + direction):
			return true
	return false


func cover_name(attacker: Vector2i, defender: Vector2i) -> String:
	match cover_level(attacker, defender):
		2:
			return "FULL COVER"
		1:
			return "HALF COVER"
	return "EXPOSED"


func grid_distance(a: Vector2i, b: Vector2i) -> int:
	return absi(a.x - b.x) + absi(a.y - b.y)


func set_highlights(cells: Array, path_cells: Array = []) -> void:
	clear_highlights()
	for cell in cells:
		if floor_meshes.has(cell):
			floor_meshes[cell].material_overlay = _reachable_overlay
	for cell in path_cells:
		if floor_meshes.has(cell):
			floor_meshes[cell].material_overlay = _path_overlay


func clear_highlights() -> void:
	for mesh in floor_meshes.values():
		mesh.material_overlay = null
	hide_cover_preview()


func set_cover_visual_visible(cell: Vector2i, value: bool) -> void:
	if not cover_visuals.has(cell):
		return
	for mesh in cover_visuals[cell]:
		if is_instance_valid(mesh):
			mesh.visible = value
