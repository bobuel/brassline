class_name BrasslineSignatureArc
extends RefCounted

const Types := preload("res://scripts/game_types.gd")

const SIGNATURE_CAR_IDS: Array[String] = [
	"baggage", "dining", "bar", "crew", "armory", "observation", "cargo", "casino", "engine",
]

# These three profiles are the authored vertical slice.  Each one couples a
# readable moving-train event to an enemy doctrine with an anatomical counter.
const CAR_PROFILES := {
	"baggage": {
		"chapter": "I / THE TRAIN KICKS BACK",
		"situation": "Unlashed trunks slide with the brake slack. The railhands know exactly when to brace.",
		"hazard_name": "LOOSE FREIGHT",
		"hazard_preview": "Every second round, marked luggage lanes surge. Units caught there lose leg health and their next action.",
		"counter_action": "lash_freight",
		"counter_text": "Lash the freight before the BRAKE SLACK warning resolves.",
		"doctrine_id": "chain_of_custody",
		"doctrine_name": "CHAIN OF CUSTODY",
		"doctrine_text": "Railhands concentrate on the forward operative. Ruin a railhand's ARMS to break the firing chain.",
		"break_role": "railhand",
		"break_zone": Types.BodyZone.ARMS,
	},
	"dining": {
		"chapter": "II / SUPPER ON THE CURVE",
		"situation": "The dining room leans into a mountain curve. Silver, carts, and gunmen all slide toward the same aisle.",
		"hazard_name": "HARD CURVE",
		"hazard_preview": "Every second round, the exposed aisle is swept clean. Braced tables are safe; open tiles are not.",
		"counter_action": "lock_service_cart",
		"counter_text": "Lock the service cart to create a brace before the CURVE warning resolves.",
		"doctrine_id": "officers_table",
		"doctrine_name": "THE OFFICER'S TABLE",
		"doctrine_text": "An officer coordinates protected volleys. Cripple the officer's ARMS to remove the guard-line bonus.",
		"break_role": "officer",
		"break_zone": Types.BodyZone.ARMS,
	},
	"bar": {
		"chapter": "NIGHT WORK / LAST CALL",
		"situation": "The backbar has come unlatched. Bottles skate with every correction while the house duelists count the sway between shots.",
		"hazard_name": "BOTTLE CASCADE",
		"hazard_preview": "Every second round, loose bottles sweep a marked counter lane, wounding legs and breaking cover rhythm.",
		"counter_action": "bottle_fire",
		"counter_text": "Light the backbar on your terms before the BOTTLE RUN warning resolves.",
		"doctrine_id": "pistols_at_ten",
		"doctrine_name": "PISTOLS AT TEN",
		"doctrine_text": "Duelists share a lethal firing count. Ruin every duelist's ARMS to end their critical-shot bonus.",
		"break_role": "duelist",
		"break_zone": Types.BodyZone.ARMS,
	},
	"crew": {
		"chapter": "NIGHT WORK / SHIFT CHANGE",
		"situation": "Unlatched lockers hammer open and shut while the relief medic keeps wounded railhands cycling through the bunks.",
		"hazard_name": "LOCKER SLAM",
		"hazard_preview": "Every second round, marked locker lanes slam shut, injuring arms and costing caught units their next action.",
		"counter_action": "dog_the_lockers",
		"counter_text": "Dog the locker latches before the SHIFT LURCH warning resolves.",
		"doctrine_id": "relief_rotation",
		"doctrine_name": "RELIEF ROTATION",
		"doctrine_text": "The medic restores the weakest guard every round. Cripple the medic's ARMS to stop field treatment.",
		"break_role": "medic",
		"break_zone": Types.BodyZone.ARMS,
	},
	"armory": {
		"chapter": "NIGHT WORK / THE CAGE LINE",
		"situation": "The ammunition press cycles with the wheels. Armored requisition guards brace against weapon cages bolted into the frame.",
		"hazard_name": "AMMUNITION PRESS",
		"hazard_preview": "Every second round, a marked feed lane bucks under load, inflicting heavy torso damage and stripping cover.",
		"counter_action": "jam_the_press",
		"counter_text": "Jam the feed clutch before the PRESS CYCLE warning resolves.",
		"doctrine_id": "cage_line",
		"doctrine_name": "THE CAGE LINE",
		"doctrine_text": "Bruisers lock the formation to the weapon cages, granting the line damage resistance. Break every bruiser's LEGS to collapse it.",
		"break_role": "bruiser",
		"break_zone": Types.BodyZone.LEGS,
	},
	"observation": {
		"chapter": "HIGH COUNTRY / GLASS GALLERY",
		"situation": "The panorama glass flexes through the mountain bends. Marksmen use its reflections as a shared rangefinder.",
		"hazard_name": "GLASS SWAY",
		"hazard_preview": "Every second round, marked window lanes flex and shower inward, injuring arms and staggering exposed units.",
		"counter_action": "drop_storm_shutters",
		"counter_text": "Drop the storm shutters before the GLASS STRAIN warning resolves.",
		"doctrine_id": "spotter_glass",
		"doctrine_name": "SPOTTER GLASS",
		"doctrine_text": "Marksmen share the panorama's reflected range marks for +12% aim. Cripple every marksman's HEAD to blind the calculation.",
		"break_role": "marksman",
		"break_zone": Types.BodyZone.HEAD,
	},
	"cargo": {
		"chapter": "FREIGHT WORK / SHUNT ORDER",
		"situation": "The cargo brake is loose. Each coupling impact shifts the crate maze while a heavy loader feeds ammunition forward.",
		"hazard_name": "SHUNT IMPACT",
		"hazard_preview": "Every second round, marked freight lanes surge on the coupling, crushing legs and staggering anyone caught there.",
		"counter_action": "set_cargo_brake",
		"counter_text": "Set the independent cargo brake before the COUPLING SLACK warning resolves.",
		"doctrine_id": "loader_screen",
		"doctrine_name": "LOADER SCREEN",
		"doctrine_text": "The heavy loader feeds overpressure rounds to the railhands. Cripple the loader's LEGS to cut their damage bonus.",
		"break_role": "bruiser",
		"break_zone": Types.BodyZone.LEGS,
	},
	"casino": {
		"chapter": "GILDED WORK / HOUSE RULES",
		"situation": "Gaming tables roll free of their floor catches. House duelists fire only when the ivory timing ball crosses black.",
		"hazard_name": "HOUSE ROLL",
		"hazard_preview": "Every second round, marked gaming lanes are swept by loose tables, injuring legs and destroying exposed cover.",
		"counter_action": "lock_the_tables",
		"counter_text": "Lock the table catches before the HOUSE TILT warning resolves.",
		"doctrine_id": "house_edge",
		"doctrine_name": "THE HOUSE EDGE",
		"doctrine_text": "Duelists read the house timing for +15% critical chance. Cripple every duelist's HEAD to spoil the count.",
		"break_role": "duelist",
		"break_zone": Types.BodyZone.HEAD,
	},
	"engine": {
		"chapter": "III / TAKE THE REDLINE",
		"situation": "Voss is running the boiler above tolerance. The locomotive attacks anyone who cannot read its pressure rhythm.",
		"hazard_name": "REDLINE PRESSURE",
		"hazard_preview": "Pressure banks telegraph before venting across alternating lanes. Steam wounds arms and strips cover.",
		"counter_action": "steam_valve",
		"counter_text": "Bleed the red valve to redirect the next pressure release into the guard line.",
		"doctrine_id": "voss_redline",
		"doctrine_name": "VOSS'S REDLINE",
		"doctrine_text": "Voss accelerates every intact guard's aim. Cripple his HEAD to end command timing.",
		"break_role": "boss",
		"break_zone": Types.BodyZone.HEAD,
	},
}


static func is_signature_car(car_id: String) -> bool:
	return car_id in SIGNATURE_CAR_IDS


static func car_profile(car_id: String) -> Dictionary:
	return Dictionary(CAR_PROFILES.get(car_id, {})).duplicate(true)


static func planning_readout(car_id: String) -> String:
	var profile := car_profile(car_id)
	if profile.is_empty():
		return ""
	return "%s\nTRAIN / %s — %s\nENEMY DOCTRINE / %s — %s" % [
		String(profile.get("chapter", "SIGNATURE CAR")),
		String(profile.get("hazard_name", "MOVING TRAIN")),
		String(profile.get("hazard_preview", "")),
		String(profile.get("doctrine_name", "GUARD LINE")),
		String(profile.get("doctrine_text", "")),
	]


static func event_for_round(car_id: String, round_number: int) -> Dictionary:
	if not is_signature_car(car_id) or round_number <= 0:
		return {}
	var cycle := posmod(round_number - 1, 4)
	var profile := car_profile(car_id)
	if cycle in [0, 2]:
		var next_cycle := 0 if cycle == 0 else 1
		return {
			"id": "%s_%d" % [car_id, next_cycle],
			"car_id": car_id,
			"phase": "warning",
			"title": _warning_title(car_id, next_cycle),
			"detail": _warning_detail(car_id, next_cycle),
			"counter_action": String(profile.get("counter_action", "")),
			"cells": _event_cells(car_id, next_cycle),
		}
	var impact_cycle := 0 if cycle == 1 else 1
	return {
		"id": "%s_%d" % [car_id, impact_cycle],
		"car_id": car_id,
		"phase": "impact",
		"title": _impact_title(car_id, impact_cycle),
		"detail": _impact_detail(car_id, impact_cycle),
		"counter_action": String(profile.get("counter_action", "")),
		"cells": _event_cells(car_id, impact_cycle),
		"zone": int(_event_zone(car_id)),
		"damage": 2 if car_id in ["engine", "armory", "cargo"] else 1,
		"stagger": car_id not in ["engine", "armory", "casino"],
		"strips_cover": car_id in ["dining", "bar", "armory", "casino", "engine"],
	}


static func _event_cells(car_id: String, cycle: int) -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	match car_id:
		"baggage":
			var row := 1 if cycle == 0 else 3
			for x in range(2, 17):
				cells.append(Vector2i(x, row))
		"dining":
			var rows := [2] if cycle == 0 else [1, 3]
			for x in range(4, 17):
				for row in rows:
					cells.append(Vector2i(x, row))
		"bar":
			var row := 1 if cycle == 0 else 3
			for x in range(5, 17):
				cells.append(Vector2i(x, row))
		"crew":
			var row := 0 if cycle == 0 else 4
			for x in range(5, 17):
				cells.append(Vector2i(x, row))
		"armory":
			var rows := [2] if cycle == 0 else [1, 3]
			for x in range(7, 19):
				for row in rows:
					cells.append(Vector2i(x, row))
		"observation":
			var row := 0 if cycle == 0 else 4
			for x in range(5, 19):
				cells.append(Vector2i(x, row))
		"cargo":
			var rows := [2] if cycle == 0 else [1, 3]
			for x in range(3, 17):
				for row in rows:
					cells.append(Vector2i(x, row))
		"casino":
			var rows := [1, 3] if cycle == 0 else [0, 2, 4]
			for x in range(5, 17):
				for row in rows:
					cells.append(Vector2i(x, row))
		"engine":
			var row := 3 if cycle == 0 else 1
			for x in range(7, 19):
				cells.append(Vector2i(x, row))
	return cells


static func _event_zone(car_id: String) -> Types.BodyZone:
	return Types.BodyZone.ARMS if car_id in ["engine", "crew", "observation"] else (Types.BodyZone.TORSO if car_id == "armory" else Types.BodyZone.LEGS)


static func _warning_title(car_id: String, cycle: int) -> String:
	match car_id:
		"baggage": return "BRAKE SLACK / %s RACK" % ("GALLEY-SIDE" if cycle == 0 else "WINDOW-SIDE")
		"dining": return "CURVE AHEAD / %s" % ("CENTER AISLE" if cycle == 0 else "TABLE LANES")
		"bar": return "BOTTLE RUN / %s COUNTER" % ("GALLEY-SIDE" if cycle == 0 else "WINDOW-SIDE")
		"crew": return "SHIFT LURCH / %s LOCKERS" % ("GALLEY-SIDE" if cycle == 0 else "WINDOW-SIDE")
		"armory": return "PRESS CYCLE / %s FEED" % ("CENTER" if cycle == 0 else "SPLIT")
		"observation": return "GLASS STRAIN / %s PANORAMA" % ("GALLEY-SIDE" if cycle == 0 else "WINDOW-SIDE")
		"cargo": return "COUPLING SLACK / %s STACK" % ("CENTER" if cycle == 0 else "SPLIT")
		"casino": return "HOUSE TILT / %s TABLES" % ("OUTER" if cycle == 0 else "FULL FLOOR")
		"engine": return "PRESSURE RISING / %s MANIFOLD" % ("LOWER" if cycle == 0 else "UPPER")
	return "THE TRAIN SHIFTS"


static func _warning_detail(car_id: String, _cycle: int) -> String:
	match car_id:
		"baggage": return "Freight straps snap tight. Leave the marked lane or lash the trunks before the next round."
		"dining": return "Glassware leans and table brakes chatter. Open aisle tiles will be swept next round."
		"bar": return "Loose bottles begin to walk. Clear the marked counter lane or light the spill before it reaches the floor."
		"crew": return "Locker dogs rattle free. Clear the marked wall or secure the latches before the car corrects."
		"armory": return "The ammunition feed bites. Leave the marked press lane or jam its clutch before the next cycle."
		"observation": return "The panorama bows inward. Clear the marked glass or drop the storm shutters before it flexes."
		"cargo": return "The coupling opens under load. Leave the marked crate lane or set the independent brake."
		"casino": return "Table catches release together. Clear the marked floor or lock them before the car rolls."
		"engine": return "The pressure gauge enters the red. Vent lanes erupt next round unless the valve is bled."
	return "A moving-train hazard will resolve next round."


static func _impact_title(car_id: String, _cycle: int) -> String:
	match car_id:
		"baggage": return "CARGO SURGE"
		"dining": return "THE CAR LEANS"
		"bar": return "BOTTLES BREAK LOOSE"
		"crew": return "LOCKERS HAMMER SHUT"
		"armory": return "THE PRESS BUCKS"
		"observation": return "PANORAMA FLEX"
		"cargo": return "SHUNT IMPACT"
		"casino": return "THE HOUSE ROLLS"
		"engine": return "STEAM RELEASE"
	return "TRAIN EVENT"


static func _impact_detail(car_id: String, _cycle: int) -> String:
	match car_id:
		"baggage": return "Unlashed trunks hammer through the marked luggage lane."
		"dining": return "The carriage takes the curve and everything unsecured crosses the aisle."
		"bar": return "A glittering wave of bottles cuts across the marked counter lane."
		"crew": return "Steel locker doors hammer through the marked wall lane."
		"armory": return "The ammunition press recoils through the marked feed lane."
		"observation": return "The panorama flexes inward and showers the marked window lane."
		"cargo": return "The coupling closes and the unsecured crate maze surges forward."
		"casino": return "Gaming tables roll together and sweep the marked floor."
		"engine": return "Boiler pressure tears through the open manifold lane."
	return "The telegraphed train event resolves."
