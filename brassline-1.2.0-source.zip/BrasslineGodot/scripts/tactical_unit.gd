class_name TacticalUnit
extends CharacterBody3D

signal movement_finished(unit: TacticalUnit)
signal defeated(unit: TacticalUnit)
signal surrendered_unit(unit: TacticalUnit)

const Types := preload("res://scripts/game_types.gd")
const CharacterVisualScript := preload("res://scripts/character_visual.gd")
const CombatCatalog := preload("res://scripts/combat_catalog.gd")
const GRID_RUN_SPEED := 4.8

var display_name := "Unit"
var team: Types.Team = Types.Team.PLAYER
var grid_cell := Vector2i.ZERO
var board: GridBoard
var max_action_points := 2
var action_points := 2
var base_movement := 5
var attack_range := 8
var base_damage := 3.0
var is_alive := true
var has_surrendered := false
var is_moving := false
var carries_objective := false
var visual_model_path := ""
var roster_id := ""
var focus_accuracy_bonus := 0.0
var focus_critical_bonus := 0.0
var weapon_id := "service_revolver"
var weapon_name := "Service Revolver"
var magazine_size := 6
var ammunition := 6
var weapon_accuracy_bonus := 0.0
var weapon_critical_bonus := 0.0
var uses_ammunition := false
var ability_id := ""
var ability_name := ""
var ability_description := ""
var ability_used := false
var bonus_movement_this_turn := 0
var signature_accuracy_bonus := 0.0
var signature_critical_bonus := 0.0
var signature_damage_bonus := 0.0
var overwatch_active := false
var crouched := false
var damage_resistance := 0.0
var role_id := "crew"
var role_label := "CREW"
var autobattle_intent := ""
var autobattle_plan_status := "on_plan"

var body_state: Dictionary = {}
var zone_meshes: Dictionary = {}
var zone_part_meshes: Dictionary = {}
var _selected := false
var _targeted := false
var _ring: MeshInstance3D
var _cover_marker: MeshInstance3D
var _name_label: Label3D
var _status_label: Label3D
var _planning_preview := false
var _weapon: MeshInstance3D
var _character_visual: Node3D
var _team_material: StandardMaterial3D
var _accent_material: StandardMaterial3D
var _disabled_material: StandardMaterial3D
var _target_material: StandardMaterial3D
var _called_shot_material: StandardMaterial3D
var _cover_stance_material: StandardMaterial3D


func setup(
		new_name: String,
		new_team: Types.Team,
		new_cell: Vector2i,
		grid_board: GridBoard
	) -> void:
	display_name = new_name
	team = new_team
	grid_cell = new_cell
	board = grid_board
	name = new_name.replace(" ", "_")
	position = board.cell_to_world(grid_cell) + Vector3(0.0, 0.12, 0.0)
	_build_state()
	_build_materials()
	_build_collision()
	_build_character()
	_update_labels()


func _build_state() -> void:
	for zone in Types.BODY_ZONE_NAMES:
		body_state[zone] = {
			"hp": int(Types.BODY_ZONE_MAX_HP[zone]),
			"max_hp": int(Types.BODY_ZONE_MAX_HP[zone]),
			"disabled": false,
			"detached": false,
		}


func _build_materials() -> void:
	var team_color := Color("#45b8d0") if team == Types.Team.PLAYER else Color("#d55d4d")
	var accent_color := Color("#eac071") if team == Types.Team.PLAYER else Color("#f09a74")
	_team_material = _make_material(team_color, 0.58, 0.36)
	_accent_material = _make_material(accent_color, 0.82, 0.28, accent_color, 0.45)
	_disabled_material = _make_material(Color("#343a3d"), 0.32, 0.82)
	_target_material = _make_material(Color("#ff836d"), 0.46, 0.30, Color("#ff4e3f"), 1.2)
	_called_shot_material = _make_material(Color(0.95, 0.67, 0.15, 0.48), 0.18, 0.24, Color("#ffb52e"), 2.2)
	_called_shot_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_cover_stance_material = _make_material(Color(0.10, 0.62, 0.62, 0.26), 0.42, 0.30, Color("#2d9b96"), 1.8)
	_cover_stance_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA


func _make_material(
		color: Color,
		metallic: float,
		roughness: float,
		emission_color: Color = Color.BLACK,
		emission_energy: float = 0.0
	) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission_color
		material.emission_energy_multiplier = emission_energy
	return material


func _build_collision() -> void:
	collision_layer = 2
	collision_mask = 0
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.34
	capsule.height = 1.65
	collision.shape = capsule
	collision.position.y = 0.82
	add_child(collision)


func _build_character() -> void:
	_ring = MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.42
	ring_mesh.outer_radius = 0.50
	_ring.mesh = ring_mesh
	_ring.rotation_degrees.x = 90.0
	_ring.position.y = 0.025
	_ring.material_override = _accent_material
	_ring.visible = false
	add_child(_ring)
	_cover_marker = MeshInstance3D.new()
	_cover_marker.name = "CoverStanceMarker"
	var cover_disc := CylinderMesh.new()
	cover_disc.top_radius = 0.60
	cover_disc.bottom_radius = 0.60
	cover_disc.height = 0.018
	cover_disc.radial_segments = 24
	_cover_marker.mesh = cover_disc
	_cover_marker.position.y = 0.018
	_cover_marker.material_override = _cover_stance_material
	_cover_marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_cover_marker.visible = false
	add_child(_cover_marker)

	if not visual_model_path.is_empty() and ResourceLoader.exists(visual_model_path):
		_build_imported_character()
	else:
		_build_procedural_character()
	_build_labels()


func _build_imported_character() -> void:
	_character_visual = CharacterVisualScript.new()
	_character_visual.name = "CharacterVisual"
	add_child(_character_visual)
	if not _character_visual.setup(visual_model_path, team):
		_character_visual.queue_free()
		_character_visual = null
		_build_procedural_character()
		return

	var torso := _add_box(Vector3(0.45, 0.55, 0.28), Vector3(0.0, 1.16, 0.0), _team_material)
	var head := _add_sphere(0.18, Vector3(0.0, 1.67, 0.0), _accent_material)
	var arms := _add_box(Vector3(0.98, 0.58, 0.28), Vector3(0.0, 1.14, 0.0), _team_material)
	var legs := _add_box(Vector3(0.54, 0.70, 0.28), Vector3(0.0, 0.49, 0.0), _team_material)
	zone_meshes = {
		Types.BodyZone.TORSO: torso,
		Types.BodyZone.HEAD: head,
		Types.BodyZone.ARMS: arms,
		Types.BodyZone.LEGS: legs,
	}
	for proxy in zone_meshes.values():
		proxy.visible = false
		proxy.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _build_procedural_character() -> void:
	var torso := _add_box(Vector3(0.56, 0.68, 0.34), Vector3(0.0, 0.98, 0.0), _team_material)
	zone_meshes[Types.BodyZone.TORSO] = torso

	var head := _add_sphere(0.23, Vector3(0.0, 1.52, 0.0), _accent_material)
	zone_meshes[Types.BodyZone.HEAD] = head

	var left_arm := _add_capsule(0.10, 0.64, Vector3(-0.43, 0.98, 0.0), _team_material)
	var right_arm := _add_capsule(0.10, 0.64, Vector3(0.43, 0.98, 0.0), _team_material)
	var arms_proxy := _add_box(Vector3(1.0, 0.64, 0.34), Vector3(0.0, 0.98, 0.0), _team_material)
	arms_proxy.visible = false
	zone_meshes[Types.BodyZone.ARMS] = arms_proxy
	zone_part_meshes[Types.BodyZone.ARMS] = [left_arm, right_arm]

	var left_leg := _add_capsule(0.12, 0.70, Vector3(-0.18, 0.38, 0.0), _team_material)
	var right_leg := _add_capsule(0.12, 0.70, Vector3(0.18, 0.38, 0.0), _team_material)
	var legs_proxy := _add_box(Vector3(0.52, 0.70, 0.34), Vector3(0.0, 0.38, 0.0), _team_material)
	legs_proxy.visible = false
	zone_meshes[Types.BodyZone.LEGS] = legs_proxy
	zone_part_meshes[Types.BodyZone.LEGS] = [left_leg, right_leg]

	_weapon = _add_box(Vector3(0.58, 0.10, 0.13), Vector3(0.50, 1.04, -0.08), _accent_material)
	_weapon.rotation_degrees.z = -18.0

	var backpack := _add_cylinder(0.18, 0.55, Vector3(0.0, 1.02, 0.25), _accent_material)
	backpack.rotation_degrees.x = 90.0


func _build_labels() -> void:
	_name_label = Label3D.new()
	_name_label.position = Vector3(0.0, 2.02, 0.0)
	_name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_name_label.font_size = 34
	_name_label.outline_size = 8
	_name_label.modulate = Color("#eaf8f6")
	_name_label.outline_modulate = Color(0.01, 0.03, 0.04, 0.92)
	add_child(_name_label)

	_status_label = Label3D.new()
	_status_label.position = Vector3(0.0, 1.78, 0.0)
	_status_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_status_label.font_size = 26
	_status_label.outline_size = 6
	_status_label.modulate = _accent_material.albedo_color
	_status_label.outline_modulate = Color(0.01, 0.03, 0.04, 0.92)
	add_child(_status_label)


func _add_box(size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _add_sphere(radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _add_capsule(radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _add_cylinder(radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func begin_turn() -> void:
	if not is_alive:
		return
	action_points = max_action_points
	if bool(get_meta("train_staggered", false)):
		action_points = maxi(1, action_points - 1)
		remove_meta("train_staggered")
	bonus_movement_this_turn = 0
	overwatch_active = false
	damage_resistance = float(get_meta("doctrine_resistance", 0.0))
	set_cover_stance(false, false)
	_update_labels()


func enter_cover_stance() -> bool:
	if not is_alive or crouched or legs_crippled():
		return false
	set_cover_stance(true)
	return true


func set_cover_stance(value: bool, animate: bool = true) -> void:
	crouched = value and is_alive
	if is_instance_valid(_cover_marker):
		_cover_marker.visible = crouched
	if is_instance_valid(_character_visual):
		_character_visual.set_cover_stance(crouched, animate)
	_update_labels()


func cover_defense_bonus() -> float:
	if not crouched:
		return 0.0
	return 0.10


func is_in_physical_cover() -> bool:
	return is_instance_valid(board) and board.has_adjacent_cover(grid_cell)


func cover_stance_name() -> String:
	if not crouched:
		return ""
	return "IN COVER" if is_in_physical_cover() else "DUCKED"


func spend_action_point(cost: int = 1) -> bool:
	if action_points < cost or not is_combat_active():
		return false
	action_points -= cost
	_update_labels()
	return true


func configure_combat_identity(new_weapon_id: String, new_ability_id: String = "") -> void:
	weapon_id = new_weapon_id
	var weapon_data := CombatCatalog.weapon(weapon_id)
	weapon_name = String(weapon_data.get("name", "Service Revolver"))
	base_damage = float(weapon_data.get("damage", base_damage))
	attack_range = int(weapon_data.get("range", attack_range))
	magazine_size = int(weapon_data.get("magazine", 6))
	ammunition = magazine_size
	weapon_accuracy_bonus = float(weapon_data.get("accuracy", 0.0))
	weapon_critical_bonus = float(weapon_data.get("critical", 0.0))
	uses_ammunition = team == Types.Team.PLAYER
	ability_id = new_ability_id
	var ability_data := CombatCatalog.ability(ability_id)
	ability_name = String(ability_data.get("name", ""))
	ability_description = String(ability_data.get("description", ""))
	ability_used = false
	if is_instance_valid(_character_visual):
		_character_visual.build_weapon(weapon_id)
	_update_labels()


func configure_enemy_role(new_role_id: String) -> void:
	role_id = new_role_id
	var role_data := CombatCatalog.enemy_role(role_id)
	role_label = String(role_data.get("label", "RAILHAND"))
	weapon_accuracy_bonus += float(role_data.get("accuracy", 0.0))
	weapon_critical_bonus += float(role_data.get("critical", 0.0))
	base_damage *= float(role_data.get("damage_mult", 1.0))
	attack_range = maxi(2, attack_range + int(role_data.get("range_bonus", 0)))
	base_movement = maxi(2, base_movement + int(role_data.get("move_bonus", 0)))
	boost_body_hp(int(role_data.get("hp_bonus", 0)))
	var visual_weapon: String = String({
		"marksman": "longshot_rifle",
		"bruiser": "hand_cannon",
		"duelist": "duelist_revolver",
		"medic": "coil_pistol",
		"officer": "rivet_carbine",
		"boss": "breach_gun",
	}.get(role_id, "service_revolver"))
	if is_instance_valid(_character_visual):
		_character_visual.build_weapon(String(visual_weapon))
	_update_labels()


func consume_round() -> bool:
	if not uses_ammunition:
		return true
	if ammunition <= 0:
		return false
	ammunition -= 1
	_update_labels()
	return true


func can_reload() -> bool:
	return uses_ammunition and ammunition < magazine_size and is_alive and not arms_crippled()


func arms_crippled() -> bool:
	return bool(body_state.get(Types.BodyZone.ARMS, {}).get("disabled", false))


func legs_crippled() -> bool:
	return bool(body_state.get(Types.BodyZone.LEGS, {}).get("disabled", false))


func can_overwatch() -> bool:
	return is_alive and not arms_crippled()


func can_take_cover() -> bool:
	return is_alive and not legs_crippled()


func reload_weapon() -> bool:
	if not can_reload():
		return false
	ammunition = magazine_size
	if is_instance_valid(_character_visual):
		_character_visual.play_reload()
	_update_labels()
	return true


func apply_focus_tonic() -> bool:
	if not is_alive or focus_accuracy_bonus > 0.0:
		return false
	apply_focus_bonus(0.18, 0.16)
	return true


func apply_focus_bonus(accuracy: float, critical: float) -> void:
	focus_accuracy_bonus = maxf(focus_accuracy_bonus, accuracy)
	focus_critical_bonus = maxf(focus_critical_bonus, critical)
	_update_labels()


func clear_focus() -> void:
	focus_accuracy_bonus = 0.0
	focus_critical_bonus = 0.0
	_update_labels()


func clear_shot_bonuses() -> void:
	focus_accuracy_bonus = 0.0
	focus_critical_bonus = 0.0
	signature_accuracy_bonus = 0.0
	signature_critical_bonus = 0.0
	signature_damage_bonus = 0.0
	_update_labels()


func is_focused() -> bool:
	return focus_accuracy_bonus > 0.0


func movement_range() -> int:
	if legs_crippled():
		return 1
	return maxi(1, base_movement + bonus_movement_this_turn)


func accuracy_penalty() -> float:
	var penalty := 0.36 if arms_crippled() else 0.0
	var head: Dictionary = body_state[Types.BodyZone.HEAD]
	if float(head["hp"]) / float(head["max_hp"]) <= 0.5:
		penalty += 0.08
	return penalty


func damage_multiplier() -> float:
	return (0.50 if arms_crippled() else 1.0) * (1.0 + signature_damage_bonus)


func apply_damage(zone: Types.BodyZone, damage: int, critical: bool = false) -> Dictionary:
	if not is_alive:
		return {"damage": 0, "disabled": false, "detached": false, "defeated": false}
	var applied_damage := maxi(1, roundi(float(damage) * (1.0 - damage_resistance)))
	var state: Dictionary = body_state[zone]
	var was_disabled: bool = state["disabled"]
	state["hp"] = maxi(0, int(state["hp"]) - applied_damage)
	state["disabled"] = int(state["hp"]) <= 0
	body_state[zone] = state
	var newly_disabled := bool(state["disabled"]) and not was_disabled
	var newly_detached := false
	if bool(state["disabled"]) and zone_meshes.has(zone):
		if newly_disabled:
			_set_zone_material(zone, _disabled_material)
		# Zero health always cripples the paired zone. A critical finishing hit is
		# what escalates that injury into permanent, visible severing.
		if critical and Types.is_severable(zone) and not bool(state.get("detached", false)):
			state["detached"] = true
			body_state[zone] = state
			newly_detached = true
			_detach_zone(zone)

	if (zone == Types.BodyZone.HEAD or zone == Types.BodyZone.TORSO) and int(state["hp"]) <= 0:
		_defeat()
	elif is_instance_valid(_character_visual):
		_character_visual.play_hit()
	_show_damage_feedback(zone, applied_damage, critical, newly_disabled, newly_detached)
	_update_labels()
	return {
		"damage": applied_damage,
		"disabled": newly_disabled,
		"detached": newly_detached,
		"critical": critical,
		"defeated": not is_alive,
	}


func _detach_zone(zone: Types.BodyZone) -> void:
	if not zone_meshes.has(zone):
		return
	var part: MeshInstance3D = zone_meshes[zone]
	var character_limbs: Array[Dictionary] = []
	if is_instance_valid(_character_visual):
		character_limbs = _character_visual.build_limb_fragment_meshes(zone)
		_character_visual.sever_limb(zone)
	part.material_overlay = null
	if not character_limbs.is_empty():
		for limb_data in character_limbs:
			var side := float(limb_data.get("side", 1.0))
			_drop_character_limb(
				limb_data["mesh"],
				zone,
				Vector3(limb_data["center"]),
				Vector3(side * 1.35, 2.1, -0.65)
			)
		part.visible = false
	elif zone_part_meshes.has(zone):
		var parts: Array = zone_part_meshes[zone]
		for index in range(parts.size()):
			var visible_part := parts[index] as MeshInstance3D
			var side := -1.0 if index == 0 else 1.0
			_drop_mesh(visible_part, Vector3(side * 1.35, 2.1, -0.65))
		part.visible = false
	else:
		_drop_mesh(part, Vector3(0.0, 2.1, -0.65))
	if zone == Types.BodyZone.ARMS and is_instance_valid(_weapon) and _weapon.visible:
		_drop_mesh(_weapon, Vector3(1.75, 2.4, 0.25))


func _drop_character_limb(limb_mesh: ArrayMesh, zone: Types.BodyZone, local_center: Vector3, impulse: Vector3) -> void:
	var fragment := RigidBody3D.new()
	fragment.name = "%s_%s_Fragment" % [name, Types.zone_name(zone).replace(" ", "")]
	fragment.mass = 0.62
	fragment.collision_layer = 4
	fragment.collision_mask = 1
	fragment.set_meta("character_mesh_fragment", true)
	fragment.set_meta("body_zone", int(zone))
	get_tree().current_scene.add_child(fragment)
	var fragment_basis := global_basis.orthonormalized()
	fragment.global_transform = Transform3D(fragment_basis, global_transform * local_center)

	var fragment_visual := MeshInstance3D.new()
	fragment_visual.name = "SkinnedCharacterLimb"
	fragment_visual.mesh = limb_mesh
	fragment_visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	fragment.add_child(fragment_visual)

	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.13 if zone == Types.BodyZone.ARMS else 0.16
	shape.height = 0.60 if zone == Types.BodyZone.ARMS else 0.74
	collision.shape = shape
	fragment.add_child(collision)
	fragment.apply_central_impulse(impulse)
	fragment.angular_velocity = Vector3(7.0, 4.0, side_sign(impulse.x) * 5.0)
	_fade_fragment_after_delay(fragment)


func _drop_mesh(part: MeshInstance3D, impulse: Vector3) -> void:
	var fragment := RigidBody3D.new()
	fragment.name = "%s_Fragment" % part.name
	fragment.mass = 0.45
	fragment.collision_layer = 4
	fragment.collision_mask = 1
	get_tree().current_scene.add_child(fragment)
	fragment.global_transform = part.global_transform

	var fragment_mesh := MeshInstance3D.new()
	fragment_mesh.mesh = part.mesh
	fragment_mesh.material_override = _disabled_material
	fragment.add_child(fragment_mesh)

	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.16
	collision.shape = shape
	fragment.add_child(collision)
	fragment.apply_central_impulse(impulse)
	fragment.angular_velocity = Vector3(7.0, 4.0, side_sign(impulse.x) * 5.0)
	part.visible = false
	_fade_fragment_after_delay(fragment)


func _fade_fragment_after_delay(fragment: RigidBody3D) -> void:
	var cleanup := fragment.create_tween()
	cleanup.tween_interval(7.0)
	cleanup.tween_property(fragment, "scale", Vector3.ZERO, 0.35)
	cleanup.tween_callback(fragment.queue_free)


func side_sign(value: float) -> float:
	return -1.0 if value < 0.0 else 1.0


func _show_damage_feedback(
		zone: Types.BodyZone,
		damage: int,
		critical: bool,
		disabled: bool,
		detached: bool
	) -> void:
	var label := Label3D.new()
	var status := ""
	if detached:
		status = "\nSEVERED"
	elif disabled:
		status = "\nCRIPPLED"
	elif critical:
		status = "\nCRITICAL"
	label.text = "-%d %s%s" % [damage, Types.zone_name(zone).to_upper(), status]
	label.font_size = 30
	label.outline_size = 7
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.modulate = Color("#ffcf70") if critical else Color("#ff8170")
	label.outline_modulate = Color(0.02, 0.01, 0.01, 0.94)
	label.position = zone_local_position(zone) + Vector3(0.0, 0.22, 0.0)
	add_child(label)
	var tween := label.create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "position", label.position + Vector3(0.0, 0.72, 0.0), 1.0)
	tween.tween_property(label, "modulate:a", 0.0, 1.0).set_delay(0.35)
	tween.chain().tween_callback(label.queue_free)


func _defeat() -> void:
	if not is_alive:
		return
	is_alive = false
	action_points = 0
	collision_layer = 0
	collision_mask = 0
	_selected = false
	_targeted = false
	_ring.visible = false
	if is_instance_valid(_cover_marker):
		_cover_marker.visible = false
	set_called_shot_zone(-1)
	if is_instance_valid(_character_visual):
		_character_visual.play_death()
	else:
		rotation_degrees.z = 72.0
		position.y = 0.18
	for mesh in zone_meshes.values():
		mesh.material_override = _disabled_material
	for parts in zone_part_meshes.values():
		for mesh in parts:
			mesh.material_override = _disabled_material
	_update_labels()
	defeated.emit(self)


func force_surrender() -> void:
	if not is_alive or has_surrendered:
		return
	has_surrendered = true
	action_points = 0
	overwatch_active = false
	crouched = false
	collision_layer = 0
	collision_mask = 0
	_selected = false
	_targeted = false
	_ring.visible = false
	if is_instance_valid(_cover_marker):
		_cover_marker.visible = false
	set_called_shot_zone(-1)
	if is_instance_valid(_character_visual):
		_character_visual.play_surrender()
	autobattle_intent = "SURRENDERED"
	autobattle_plan_status = "broken"
	_update_labels()
	surrendered_unit.emit(self)


func is_combat_active() -> bool:
	return is_alive and not has_surrendered


func set_selected(value: bool) -> void:
	_selected = value
	_refresh_selection_visual()


func set_targeted(value: bool) -> void:
	_targeted = value
	if not value:
		set_called_shot_zone(-1)
	_refresh_selection_visual()


func set_called_shot_zone(zone: int) -> void:
	if is_instance_valid(_character_visual):
		_character_visual.set_called_shot_zone(zone)
	for mesh in zone_meshes.values():
		if is_instance_valid(mesh):
			mesh.material_overlay = null
	for parts in zone_part_meshes.values():
		for mesh in parts:
			if is_instance_valid(mesh):
				mesh.material_overlay = null
	if zone_meshes.has(zone) and not is_zone_detached(zone):
		zone_meshes[zone].material_overlay = _called_shot_material
		if zone_part_meshes.has(zone):
			for mesh in zone_part_meshes[zone]:
				mesh.material_overlay = _called_shot_material


func _refresh_selection_visual() -> void:
	if not is_alive or has_surrendered:
		_ring.visible = false
		return
	_ring.visible = _selected or _targeted or carries_objective
	if _targeted:
		_ring.material_override = _target_material
	else:
		_ring.material_override = _accent_material


func set_objective_carrier(value: bool) -> void:
	carries_objective = value
	_refresh_selection_visual()
	_update_labels()


func zone_hp_text(zone: Types.BodyZone) -> String:
	var state: Dictionary = body_state[zone]
	return "%d/%d %s" % [int(state["hp"]), int(state["max_hp"]), zone_condition(zone)]


func zone_condition(zone: Types.BodyZone) -> String:
	var state: Dictionary = body_state[zone]
	if bool(state.get("detached", false)):
		return "SEVERED"
	if bool(state["disabled"]):
		return "CRIPPLED"
	var ratio := float(state["hp"]) / float(state["max_hp"])
	if ratio <= 0.40:
		return "CRITICAL"
	if ratio < 1.0:
		return "WOUNDED"
	return "INTACT"


func zone_hp_ratio(zone: Types.BodyZone) -> float:
	var state: Dictionary = body_state[zone]
	return float(state["hp"]) / maxf(1.0, float(state["max_hp"]))


func is_zone_detached(zone: Types.BodyZone) -> bool:
	if not body_state.has(zone):
		return false
	return bool(body_state[zone].get("detached", false))


func export_body_state() -> Dictionary:
	return body_state.duplicate(true)


func import_body_state(saved_state: Dictionary) -> void:
	if saved_state.is_empty():
		return
	for zone in Types.BODY_ZONE_NAMES:
		if not saved_state.has(zone):
			continue
		body_state[zone] = Dictionary(saved_state[zone]).duplicate(true)
		var state: Dictionary = body_state[zone]
		if zone_meshes.has(zone) and is_instance_valid(zone_meshes[zone]):
			if bool(state.get("disabled", false)):
				_set_zone_material(zone, _disabled_material)
			if bool(state.get("detached", false)):
				zone_meshes[zone].visible = false
				if zone_part_meshes.has(zone):
					for mesh in zone_part_meshes[zone]:
						mesh.visible = false
				if is_instance_valid(_character_visual):
					_character_visual.sever_limb(zone)
	_update_labels()


func boost_body_hp(amount: int) -> void:
	if amount <= 0:
		return
	for zone in body_state:
		var state: Dictionary = body_state[zone]
		state["max_hp"] = int(state["max_hp"]) + amount
		state["hp"] = int(state["hp"]) + amount
		body_state[zone] = state
	_update_labels()


func set_body_hp_profile(profile: Dictionary) -> void:
	for zone in body_state:
		if not profile.has(zone):
			continue
		var value := maxi(1, int(profile[zone]))
		var state: Dictionary = body_state[zone]
		state["max_hp"] = value
		state["hp"] = value
		state["disabled"] = false
		state["detached"] = false
		body_state[zone] = state
	_update_labels()


func heal_weakest_body_zone(amount: int) -> bool:
	var weakest_zone := -1
	var weakest_ratio := 2.0
	for zone in body_state:
		var state: Dictionary = body_state[zone]
		if bool(state.get("detached", false)) or int(state["hp"]) >= int(state["max_hp"]):
			continue
		var ratio := float(state["hp"]) / maxf(1.0, float(state["max_hp"]))
		if ratio < weakest_ratio:
			weakest_ratio = ratio
			weakest_zone = int(zone)
	if weakest_zone < 0:
		return false
	var weakest_state: Dictionary = body_state[weakest_zone]
	weakest_state["hp"] = mini(int(weakest_state["max_hp"]), int(weakest_state["hp"]) + amount)
	weakest_state["disabled"] = int(weakest_state["hp"]) <= 0
	body_state[weakest_zone] = weakest_state
	_update_labels()
	return true


func zone_local_position(zone: Types.BodyZone) -> Vector3:
	if zone_meshes.has(zone) and is_instance_valid(zone_meshes[zone]):
		return zone_meshes[zone].position + (Vector3(0.0, -0.30, 0.0) if crouched else Vector3.ZERO)
	return Vector3(0.0, 1.0, 0.0)


func zone_world_position(zone: Types.BodyZone) -> Vector3:
	return global_transform * zone_local_position(zone)


func _set_zone_material(zone: Types.BodyZone, material: Material) -> void:
	if zone_meshes.has(zone) and is_instance_valid(zone_meshes[zone]):
		zone_meshes[zone].material_override = material
	if zone_part_meshes.has(zone):
		for mesh in zone_part_meshes[zone]:
			if is_instance_valid(mesh):
				mesh.material_override = material


func move_along_path(path: Array[Vector2i]) -> void:
	if path.size() <= 1 or not is_alive:
		movement_finished.emit(self)
		return
	if crouched:
		set_cover_stance(false)
	is_moving = true
	if is_instance_valid(_character_visual):
		_character_visual.play_move()
	for index in range(1, path.size()):
		var destination_cell := path[index]
		var destination := board.cell_to_world(destination_cell) + Vector3(0.0, 0.12, 0.0)
		var flat_target := Vector3(destination.x, global_position.y, destination.z)
		var distance := global_position.distance_to(destination)
		var step_duration := distance / GRID_RUN_SPEED
		var target_basis := global_transform.looking_at(flat_target, Vector3.UP, true).basis.orthonormalized()
		var turn_tween := create_tween()
		turn_tween.set_trans(Tween.TRANS_SINE)
		turn_tween.set_ease(Tween.EASE_OUT)
		turn_tween.tween_property(self, "quaternion", target_basis.get_rotation_quaternion(), minf(0.12, step_duration * 0.48))
		var movement_tween := create_tween()
		movement_tween.set_trans(Tween.TRANS_LINEAR)
		movement_tween.tween_property(self, "global_position", destination, step_duration)
		await movement_tween.finished
		grid_cell = destination_cell
	is_moving = false
	if is_instance_valid(_character_visual):
		_character_visual.play_idle()
	movement_finished.emit(self)


func play_shoot_animation() -> void:
	if is_instance_valid(_character_visual):
		_character_visual.play_shoot()


func play_throw_animation() -> void:
	if is_instance_valid(_character_visual):
		_character_visual.play_throw()


func shot_origin() -> Vector3:
	if is_instance_valid(_character_visual):
		return _character_visual.muzzle_global_position()
	return global_position + Vector3(0.0, 1.08, 0.0)


func set_autobattle_intent(caption: String, plan_status: String = "on_plan") -> void:
	autobattle_intent = caption
	autobattle_plan_status = plan_status
	_update_labels()


func clear_autobattle_intent() -> void:
	autobattle_intent = ""
	autobattle_plan_status = "on_plan"
	_update_labels()


func set_planning_preview(enabled: bool) -> void:
	_planning_preview = enabled
	if is_instance_valid(_name_label):
		_name_label.pixel_size = 0.007 if enabled else 0.005
		_name_label.position.y = 2.15 if enabled else 2.02
		_name_label.no_depth_test = enabled
	if is_instance_valid(_status_label):
		_status_label.pixel_size = 0.007 if enabled else 0.005
		_status_label.position.y = 1.88 if enabled else 1.78
		_status_label.no_depth_test = enabled
	_update_labels()


func _update_labels() -> void:
	if not is_instance_valid(_name_label) or not is_instance_valid(_status_label):
		return
	_name_label.text = display_name.get_slice(" ", 0) if _planning_preview and team == Types.Team.PLAYER else display_name
	var crippled_labels: Array[String] = []
	if arms_crippled():
		crippled_labels.append("ARMS")
	if legs_crippled():
		crippled_labels.append("LEGS")
	if not is_alive:
		_status_label.text = "DOWN"
		_status_label.modulate = _accent_material.albedo_color
	elif has_surrendered:
		_status_label.text = "SURRENDERED"
		_status_label.modulate = Color("#d8c79a")
	elif not autobattle_intent.is_empty():
		_status_label.text = autobattle_intent
		match autobattle_plan_status:
			"broken":
				_status_label.modulate = Color("#ff7d6e")
			"adapting":
				_status_label.modulate = Color("#e3b65c")
			_:
				_status_label.modulate = Color("#72d8b6")
	elif carries_objective:
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "BLUEPRINT | %d AP" % action_points
	elif overwatch_active:
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "%sOVERWATCH | %d/%d" % ["COVER + " if crouched else "", ammunition, magazine_size]
	elif crouched:
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "%s | %d AP%s" % [
			cover_stance_name(),
			action_points,
			" | %d/%d" % [ammunition, magazine_size] if uses_ammunition else "",
		]
	elif is_focused():
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "FOCUSED | %d AP | %d/%d" % [action_points, ammunition, magazine_size]
	elif not crippled_labels.is_empty():
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "%s CRIPPLED | %d AP | %d/%d" % [" + ".join(crippled_labels), action_points, ammunition, magazine_size]
	elif uses_ammunition:
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "%d AP | %d/%d" % [action_points, ammunition, magazine_size]
	else:
		_status_label.modulate = _accent_material.albedo_color
		_status_label.text = "%s | %d AP" % [role_label, action_points]
