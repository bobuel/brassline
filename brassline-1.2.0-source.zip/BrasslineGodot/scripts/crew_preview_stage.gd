class_name CrewPreviewStage
extends SubViewportContainer

const Types := preload("res://scripts/game_types.gd")
const CharacterVisualScript := preload("res://scripts/character_visual.gd")
const CHARACTER_ROOT := "res://assets/characters/quaternius/"

var previewed_crew_ids: Array[String] = []
var visual_nodes: Dictionary = {}
var selected_crew_id := ""
var viewport_3d: SubViewport
var selected_visual: CharacterVisual
var _dragging := false


func setup(run_state: RefCounted, roster: Array, active_crew_id: String) -> void:
	selected_crew_id = active_crew_id
	# Keep the full three-person lineup, at its original aspect ratio, while leaving
	# a guaranteed action row beneath crew preparation at the 1280x720 baseline.
	custom_minimum_size = Vector2(460.0, 220.0)
	stretch = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	tooltip_text = "Drag the highlighted operative to rotate their model. Use the arrows below to cycle the crew."
	gui_input.connect(_on_gui_input)

	viewport_3d = SubViewport.new()
	viewport_3d.name = "CrewLineupViewport"
	viewport_3d.size = Vector2i(920, 530)
	viewport_3d.transparent_bg = true
	viewport_3d.own_world_3d = true
	viewport_3d.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport_3d.msaa_3d = Viewport.MSAA_2X
	add_child(viewport_3d)

	var stage := Node3D.new()
	stage.name = "CrewStagingBay"
	viewport_3d.add_child(stage)
	_build_environment(stage)
	_build_lineup(stage, run_state, roster)


func _build_environment(stage: Node3D) -> void:
	var environment_node := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#071419")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#7fb6b1")
	environment.ambient_light_energy = 0.72
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = true
	environment.glow_intensity = 0.42
	environment_node.environment = environment
	stage.add_child(environment_node)

	var camera := Camera3D.new()
	camera.name = "LineupCamera"
	camera.fov = 39.0
	camera.look_at_from_position(Vector3(0.0, 1.28, 5.25), Vector3(0.0, 1.02, 0.0), Vector3.UP)
	camera.current = true
	stage.add_child(camera)

	var key := DirectionalLight3D.new()
	key.name = "BrassKeyLight"
	key.light_color = Color("#ffd893")
	key.light_energy = 1.55
	key.rotation_degrees = Vector3(-42.0, -28.0, 0.0)
	key.shadow_enabled = true
	stage.add_child(key)
	var rim := DirectionalLight3D.new()
	rim.name = "CyanRimLight"
	rim.light_color = Color("#62d6df")
	rim.light_energy = 0.95
	rim.rotation_degrees = Vector3(-28.0, 146.0, 0.0)
	stage.add_child(rim)

	var iron := _material(Color("#12262b"), 0.72, 0.55)
	var brass := _material(Color("#9b6d2d"), 0.84, 0.32)
	var inset := _material(Color("#071013"), 0.58, 0.74)
	_add_floor(stage, Vector2(6.2, 3.7), Vector3(0.0, -0.005, 0.1), iron)
	_add_box(stage, Vector3(6.2, 3.2, 0.14), Vector3(0.0, 1.52, -1.05), inset)
	_add_box(stage, Vector3(0.08, 3.2, 0.12), Vector3(-2.88, 1.52, -0.95), brass)
	_add_box(stage, Vector3(0.08, 3.2, 0.12), Vector3(2.88, 1.52, -0.95), brass)
	_add_box(stage, Vector3(5.84, 0.08, 0.12), Vector3(0.0, 2.98, -0.95), brass)
	for z_value in [-0.70, 0.0, 0.70, 1.40]:
		_add_box(stage, Vector3(5.8, 0.012, 0.025), Vector3(0.0, 0.004, z_value), brass)


func _build_lineup(stage: Node3D, run_state: RefCounted, roster: Array) -> void:
	previewed_crew_ids.assign(run_state.selected_crew_ids)
	if previewed_crew_ids.is_empty():
		return
	var selected_index := previewed_crew_ids.find(selected_crew_id)
	if selected_index < 0:
		selected_index = 0
		selected_crew_id = previewed_crew_ids[0]
	var ordered_ids: Array[String] = []
	ordered_ids.append(previewed_crew_ids[posmod(selected_index - 1, previewed_crew_ids.size())])
	ordered_ids.append(previewed_crew_ids[selected_index])
	ordered_ids.append(previewed_crew_ids[posmod(selected_index + 1, previewed_crew_ids.size())])
	# Every operative occupies the same camera plane and uses the same world scale.
	# Selection is communicated by light and a floor ring, never forced perspective.
	var positions := [Vector3(-1.45, 0.0, 0.0), Vector3(0.0, 0.0, 0.0), Vector3(1.45, 0.0, 0.0)]
	for slot in range(ordered_ids.size()):
		var crew_id := ordered_ids[slot]
		var member := _roster_member(roster, crew_id)
		if member.is_empty():
			continue
		var visual := CharacterVisualScript.new()
		visual.name = "Preview_%s" % crew_id
		visual.position = positions[slot]
		# Quaternius rigs face +Z by default, toward this staging camera.
		visual.rotation_degrees.y = 0.0
		visual.scale = Vector3.ONE
		stage.add_child(visual)
		if not visual.setup(CHARACTER_ROOT + String(member.get("model", "Casual_2.gltf")), Types.Team.PLAYER):
			continue
		visual.build_weapon(String(member.get("weapon_id", "service_revolver")))
		visual.apply_cosmetic_palette(String(member.get("cosmetic_id", "weathered")))
		visual_nodes[crew_id] = visual
		var body: Dictionary = run_state.body_state_for(crew_id)
		for zone in [Types.BodyZone.ARMS, Types.BodyZone.LEGS]:
			if body.has(zone) and bool(body[zone].get("detached", false)):
				visual.sever_limb(zone)
		if run_state.crew_is_down(crew_id):
			visual.play_death()
		elif crew_id == selected_crew_id:
			selected_visual = visual
			visual.play_idle()
		_build_plinth(stage, positions[slot].x, crew_id == selected_crew_id, run_state.crew_is_down(crew_id))


func _build_plinth(stage: Node3D, x_value: float, selected: bool, down: bool) -> void:
	var plinth := MeshInstance3D.new()
	var ring := TorusMesh.new()
	ring.inner_radius = 0.48 if selected else 0.42
	ring.outer_radius = 0.55 if selected else 0.47
	ring.rings = 32
	ring.ring_segments = 10
	plinth.mesh = ring
	plinth.position = Vector3(x_value, 0.018, 0.03)
	var color := Color("#e3b65c") if selected else Color("#315d60")
	if down:
		color = Color("#8d3932")
	plinth.material_override = _material(color, 0.88, 0.24, selected)
	stage.add_child(plinth)


func _add_floor(parent: Node3D, dimensions: Vector2, position_value: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = dimensions
	instance.mesh = plane
	instance.position = position_value
	instance.material_override = material
	parent.add_child(instance)
	return instance


func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_dragging = event.pressed
		accept_event()
	elif event is InputEventMouseMotion and _dragging and is_instance_valid(selected_visual):
		selected_visual.rotate_y(-event.relative.x * 0.012)
		accept_event()


func _roster_member(roster: Array, crew_id: String) -> Dictionary:
	for member in roster:
		if String(member.get("id", "")) == crew_id:
			return member
	return {}


func _add_box(parent: Node3D, size: Vector3, position_value: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	instance.mesh = box
	instance.position = position_value
	instance.material_override = material
	parent.add_child(instance)
	return instance


func _material(color: Color, metallic: float, roughness: float, emission: bool = false) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if color.a < 0.99:
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if emission:
		material.emission_enabled = true
		material.emission = Color(color.r, color.g, color.b, 1.0)
		material.emission_energy_multiplier = 1.8
	return material
