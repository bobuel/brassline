class_name HeistUI
extends CanvasLayer

signal zone_requested(zone: BrasslineTypes.BodyZone)
signal attack_requested
signal reload_requested
signal overwatch_requested
signal cover_requested
signal ability_requested
signal grenade_requested
signal tonic_requested
signal end_turn_requested
signal restart_requested

const Types := preload("res://scripts/game_types.gd")
const RunState := preload("res://scripts/run_state.gd")
const TargetSilhouetteView := preload("res://scripts/target_silhouette.gd")
const CrewEmblem := preload("res://assets/ui/faction_crew.png")
const GuardEmblem := preload("res://assets/ui/faction_guard.png")

var phase_label: Label
var round_label: Label
var objective_label: Label
var selected_label: Label
var cover_legend_label: Label
var stats_button: Button
var stats_panel: PanelContainer
var stats_name_label: Label
var stats_combat_label: Label
var stats_body_label: Label
var stats_effects_label: Label
var stats_buff_label: Label
var target_label: Label
var chance_label: Label
var target_silhouette: TargetSilhouette
var attack_button: Button
var reload_button: Button
var overwatch_button: Button
var cover_button: Button
var ability_button: Button
var grenade_button: Button
var tonic_button: Button
var end_turn_button: Button
var log_label: RichTextLabel
var zone_buttons: Dictionary = {}
var mission_overlay: PanelContainer
var mission_result: Label
var target_panel: PanelContainer
var action_panel: PanelContainer
var log_panel: PanelContainer
var log_toggle_button: Button
var help_label: Label
var hud_root: Control
var _log_lines: Array[String] = []
var _cinematic_capture := false
var _log_expanded := false
var _stats_expanded := false
var _combat_inventory: Dictionary = {"clockwork_grenade": 0, "focus_tonic": 0}
var _run_bonuses: Dictionary = {}
var _current_car_data: Dictionary = {}
var _current_car_number := 1

var _panel_color := Color(0.018, 0.045, 0.052, 0.91)
var _panel_border := Color(0.32, 0.55, 0.55, 0.52)
var _brass := Color("#e3b65c")
var _ink := Color("#d8f5f1")
var _muted := Color("#87adb0")
var _danger := Color("#ff7d6e")


func _ready() -> void:
	_build_ui()


func _build_ui() -> void:
	hud_root = Control.new()
	hud_root.name = "HUDRoot"
	hud_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hud_root)

	_build_top_bar(hud_root)
	_build_target_panel(hud_root)
	_build_action_panel(hud_root)
	_build_stats_panel(hud_root)
	_build_log_panel(hud_root)
	_build_mission_overlay(hud_root)


func _build_top_bar(root: Control) -> void:
	var panel := _make_panel()
	panel.anchor_left = 0.0
	panel.anchor_right = 1.0
	panel.offset_left = 12.0
	panel.offset_right = -12.0
	panel.offset_top = 12.0
	panel.offset_bottom = 80.0
	root.add_child(panel)

	var margin := _make_margin(12, 12, 8, 8)
	panel.add_child(margin)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	margin.add_child(row)
	row.add_child(_make_emblem(CrewEmblem, 42.0))

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(title_box)
	var kicker := _make_label("BRASSLINE / TEEN-READINESS RC 1.1", 13, _brass)
	title_box.add_child(kicker)
	phase_label = _make_label("CREW TURN", 21, _ink)
	title_box.add_child(phase_label)

	var mission_box := VBoxContainer.new()
	mission_box.custom_minimum_size.x = 430.0
	row.add_child(mission_box)
	objective_label = _make_label("OBJECTIVE / Seize the blueprint case, then return to extraction.", 14, _ink)
	objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_box.add_child(objective_label)
	round_label = _make_label("ROUND 01", 13, _muted)
	mission_box.add_child(round_label)

	end_turn_button = Button.new()
	end_turn_button.text = "END CREW TURN  [SPACE]"
	end_turn_button.custom_minimum_size = Vector2(164.0, 42.0)
	end_turn_button.add_theme_font_size_override("font_size", 13)
	end_turn_button.add_theme_color_override("font_color", _ink)
	end_turn_button.add_theme_stylebox_override("normal", _button_style(Color(0.11, 0.28, 0.31, 0.96), _panel_border))
	end_turn_button.add_theme_stylebox_override("hover", _button_style(Color(0.18, 0.42, 0.43, 0.98), _brass))
	end_turn_button.pressed.connect(func() -> void: end_turn_requested.emit())
	row.add_child(end_turn_button)


func _build_target_panel(root: Control) -> void:
	target_panel = _make_panel()
	target_panel.anchor_left = 1.0
	target_panel.anchor_right = 1.0
	target_panel.offset_left = -382.0
	target_panel.offset_right = -12.0
	target_panel.offset_top = 90.0
	target_panel.offset_bottom = -12.0
	root.add_child(target_panel)

	var margin := _make_margin(14, 14, 12, 12)
	target_panel.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	margin.add_child(column)

	var targeting_header := HBoxContainer.new()
	targeting_header.add_theme_constant_override("separation", 9)
	targeting_header.add_child(_make_emblem(GuardEmblem, 30.0))
	var targeting_title := _make_label("CALLED SHOT", 14, _brass)
	targeting_title.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	targeting_header.add_child(targeting_title)
	column.add_child(targeting_header)
	target_label = _make_label("TARGET / Select a rail guard", 14, _muted)
	target_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(target_label)

	var divider := HSeparator.new()
	column.add_child(divider)

	target_silhouette = TargetSilhouetteView.new()
	target_silhouette.zone_picked.connect(_on_zone_pressed)
	column.add_child(target_silhouette)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	grid.custom_minimum_size.y = 154.0
	column.add_child(grid)
	for zone in Types.BODY_ZONE_NAMES:
		var button := Button.new()
		button.custom_minimum_size = Vector2(162.0, 46.0)
		button.text = "%s  %s" % [Types.BODY_ZONE_SHORTCUTS[zone], Types.zone_name(zone).to_upper()]
		button.toggle_mode = true
		button.tooltip_text = Types.zone_effect(zone)
		button.add_theme_font_size_override("font_size", 13)
		button.add_theme_stylebox_override("normal", _button_style(Color(0.05, 0.14, 0.17, 0.96), Color(0.20, 0.43, 0.46, 0.82)))
		button.add_theme_stylebox_override("hover", _button_style(Color(0.13, 0.29, 0.31, 0.98), _brass))
		button.add_theme_stylebox_override("pressed", _button_style(Color(0.30, 0.23, 0.10, 0.98), _brass))
		button.pressed.connect(_on_zone_pressed.bind(zone))
		grid.add_child(button)
		zone_buttons[zone] = button

	chance_label = _make_label("Select a target to calculate the shot.", 14, _muted)
	chance_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	chance_label.custom_minimum_size.y = 42.0
	column.add_child(chance_label)

	attack_button = Button.new()
	attack_button.text = "TAKE CALLED SHOT  [F / RIGHT CLICK]"
	attack_button.custom_minimum_size.y = 48.0
	attack_button.add_theme_font_size_override("font_size", 14)
	attack_button.add_theme_color_override("font_color", Color("#fff1e5"))
	attack_button.add_theme_stylebox_override("normal", _button_style(Color(0.42, 0.14, 0.12, 0.98), _danger))
	attack_button.add_theme_stylebox_override("hover", _button_style(Color(0.62, 0.20, 0.15, 1.0), Color("#ffc0a9")))
	attack_button.pressed.connect(func() -> void: attack_requested.emit())
	column.add_child(attack_button)


func _build_action_panel(root: Control) -> void:
	action_panel = _make_panel()
	action_panel.anchor_left = 0.0
	action_panel.anchor_right = 0.0
	action_panel.anchor_top = 1.0
	action_panel.anchor_bottom = 1.0
	action_panel.offset_left = 270.0
	action_panel.offset_right = 888.0
	action_panel.offset_top = -136.0
	action_panel.offset_bottom = -12.0
	root.add_child(action_panel)

	var margin := _make_margin(10, 10, 8, 8)
	action_panel.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	margin.add_child(column)
	var selected_row := HBoxContainer.new()
	selected_row.add_theme_constant_override("separation", 8)
	column.add_child(selected_row)
	selected_label = _make_label("Select an operative", 15, _ink)
	selected_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	selected_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	selected_row.add_child(selected_label)
	stats_button = Button.new()
	stats_button.text = "STATS  [I]"
	stats_button.custom_minimum_size = Vector2(104.0, 30.0)
	stats_button.add_theme_font_size_override("font_size", 12)
	stats_button.tooltip_text = "Open the selected operative's weapon, body, and permanent car-buff breakdown."
	stats_button.add_theme_stylebox_override("normal", _button_style(Color(0.05, 0.13, 0.15, 0.96), _panel_border))
	stats_button.add_theme_stylebox_override("hover", _button_style(Color(0.12, 0.29, 0.31, 0.98), _brass))
	stats_button.pressed.connect(toggle_stats)
	selected_row.add_child(stats_button)
	cover_legend_label = _make_label("COVER / TEAL DIAMOND ON SCENERY = REAL PHYSICAL COVER", 12, _muted)
	cover_legend_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	cover_legend_label.visible = false
	column.add_child(cover_legend_label)

	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 6)
	column.add_child(action_row)
	reload_button = Button.new()
	reload_button.custom_minimum_size = Vector2(84.0, 46.0)
	reload_button.clip_text = true
	reload_button.add_theme_font_size_override("font_size", 12)
	reload_button.tooltip_text = "Spend 1 AP to refill the selected weapon's magazine."
	reload_button.add_theme_stylebox_override("normal", _button_style(Color(0.08, 0.18, 0.20, 0.98), _panel_border))
	reload_button.add_theme_stylebox_override("hover", _button_style(Color(0.12, 0.34, 0.36, 1.0), _brass))
	reload_button.pressed.connect(func() -> void: reload_requested.emit())
	action_row.add_child(reload_button)
	overwatch_button = Button.new()
	overwatch_button.custom_minimum_size = Vector2(92.0, 46.0)
	overwatch_button.clip_text = true
	overwatch_button.add_theme_font_size_override("font_size", 12)
	overwatch_button.tooltip_text = "Spend 1 AP to interrupt the first guard who enters a clean firing line."
	overwatch_button.add_theme_stylebox_override("normal", _button_style(Color(0.08, 0.18, 0.20, 0.98), _panel_border))
	overwatch_button.add_theme_stylebox_override("hover", _button_style(Color(0.12, 0.34, 0.36, 1.0), _brass))
	overwatch_button.pressed.connect(func() -> void: overwatch_requested.emit())
	action_row.add_child(overwatch_button)
	cover_button = Button.new()
	cover_button.custom_minimum_size = Vector2(94.0, 46.0)
	cover_button.clip_text = true
	cover_button.add_theme_font_size_override("font_size", 12)
	cover_button.tooltip_text = "Spend 1 AP to duck for -10% incoming hit. Teal diamonds mark scenery that provides physical cover; move markers show teal for full and brass for half cover against the selected guard."
	cover_button.add_theme_stylebox_override("normal", _button_style(Color(0.07, 0.20, 0.22, 0.98), Color(0.32, 0.74, 0.70, 0.82)))
	cover_button.add_theme_stylebox_override("hover", _button_style(Color(0.10, 0.38, 0.39, 1.0), _brass))
	cover_button.pressed.connect(func() -> void: cover_requested.emit())
	action_row.add_child(cover_button)

	ability_button = Button.new()
	ability_button.custom_minimum_size = Vector2(124.0, 46.0)
	ability_button.clip_text = true
	ability_button.add_theme_font_size_override("font_size", 12)
	ability_button.add_theme_stylebox_override("normal", _button_style(Color(0.23, 0.17, 0.07, 0.98), _brass.darkened(0.18)))
	ability_button.add_theme_stylebox_override("hover", _button_style(Color(0.42, 0.29, 0.08, 1.0), _brass))
	ability_button.pressed.connect(func() -> void: ability_requested.emit())
	action_row.add_child(ability_button)

	grenade_button = Button.new()
	grenade_button.custom_minimum_size = Vector2(86.0, 46.0)
	grenade_button.clip_text = true
	grenade_button.add_theme_font_size_override("font_size", 12)
	grenade_button.tooltip_text = "Costs 1 AP. Damages the target and guards in adjacent tiles."
	grenade_button.add_theme_stylebox_override("normal", _button_style(Color(0.25, 0.14, 0.07, 0.98), _brass.darkened(0.18)))
	grenade_button.add_theme_stylebox_override("hover", _button_style(Color(0.47, 0.24, 0.08, 1.0), _brass))
	grenade_button.pressed.connect(func() -> void: grenade_requested.emit())
	action_row.add_child(grenade_button)
	tonic_button = Button.new()
	tonic_button.custom_minimum_size = Vector2(86.0, 46.0)
	tonic_button.clip_text = true
	tonic_button.add_theme_font_size_override("font_size", 12)
	tonic_button.tooltip_text = "Gives the selected operative +18% hit and +16% critical chance on their next shot."
	tonic_button.add_theme_stylebox_override("normal", _button_style(Color(0.07, 0.20, 0.24, 0.98), _panel_border))
	tonic_button.add_theme_stylebox_override("hover", _button_style(Color(0.10, 0.38, 0.42, 1.0), _brass))
	tonic_button.pressed.connect(func() -> void: tonic_requested.emit())
	action_row.add_child(tonic_button)


func _build_stats_panel(root: Control) -> void:
	stats_panel = _make_panel()
	stats_panel.name = "OperativeStatsPanel"
	stats_panel.anchor_left = 0.0
	stats_panel.anchor_right = 0.0
	stats_panel.anchor_top = 0.0
	stats_panel.anchor_bottom = 1.0
	stats_panel.offset_left = 12.0
	stats_panel.offset_right = 370.0
	stats_panel.offset_top = 166.0
	stats_panel.offset_bottom = -148.0
	stats_panel.visible = false
	root.add_child(stats_panel)

	var margin := _make_margin(14, 14, 12, 12)
	stats_panel.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	margin.add_child(column)
	var header := HBoxContainer.new()
	column.add_child(header)
	var title := _make_label("OPERATIVE STATS", 14, _brass)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var close := Button.new()
	close.text = "CLOSE  [I]"
	close.custom_minimum_size = Vector2(94.0, 30.0)
	close.add_theme_font_size_override("font_size", 12)
	close.add_theme_stylebox_override("normal", _button_style(Color(0.05, 0.13, 0.15, 0.96), _panel_border))
	close.add_theme_stylebox_override("hover", _button_style(Color(0.12, 0.29, 0.31, 0.98), _brass))
	close.pressed.connect(toggle_stats)
	header.add_child(close)
	stats_name_label = _make_label("SELECT AN OPERATIVE", 20, _ink)
	column.add_child(stats_name_label)
	column.add_child(HSeparator.new())
	stats_combat_label = _make_label("Weapon statistics appear here.", 13, _ink)
	stats_combat_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(stats_combat_label)
	stats_body_label = _make_label("Body status appears here.", 13, _ink)
	stats_body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(stats_body_label)
	stats_effects_label = _make_label("No active conditions.", 13, _muted)
	stats_effects_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(stats_effects_label)
	column.add_child(HSeparator.new())
	stats_buff_label = _make_label("EARNED CAR BUFFS / NONE YET", 13, Color("#72b49c"))
	stats_buff_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(stats_buff_label)


func _build_log_panel(root: Control) -> void:
	log_panel = _make_panel()
	log_panel.anchor_left = 0.0
	log_panel.anchor_right = 0.0
	log_panel.anchor_top = 1.0
	log_panel.anchor_bottom = 1.0
	log_panel.offset_left = 12.0
	log_panel.offset_right = 248.0
	log_panel.offset_top = -92.0
	log_panel.offset_bottom = -12.0
	root.add_child(log_panel)

	var margin := _make_margin(10, 10, 7, 7)
	log_panel.add_child(margin)
	var column := VBoxContainer.new()
	margin.add_child(column)
	column.add_theme_constant_override("separation", 3)
	var header := HBoxContainer.new()
	column.add_child(header)
	var title := _make_label("LATEST", 13, _brass)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	log_toggle_button = Button.new()
	log_toggle_button.text = "LOG  [L]"
	log_toggle_button.custom_minimum_size = Vector2(78.0, 25.0)
	log_toggle_button.add_theme_font_size_override("font_size", 12)
	log_toggle_button.add_theme_stylebox_override("normal", _button_style(Color(0.05, 0.13, 0.15, 0.96), _panel_border))
	log_toggle_button.add_theme_stylebox_override("hover", _button_style(Color(0.12, 0.29, 0.31, 0.98), _brass))
	log_toggle_button.pressed.connect(toggle_log)
	header.add_child(log_toggle_button)
	log_label = RichTextLabel.new()
	log_label.bbcode_enabled = true
	log_label.fit_content = false
	log_label.scroll_active = false
	log_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	log_label.add_theme_font_size_override("normal_font_size", 14)
	log_label.add_theme_color_override("default_color", _ink)
	column.add_child(log_label)


func _build_mission_overlay(root: Control) -> void:
	mission_overlay = _make_panel()
	mission_overlay.anchor_left = 0.5
	mission_overlay.anchor_right = 0.5
	mission_overlay.anchor_top = 0.5
	mission_overlay.anchor_bottom = 0.5
	mission_overlay.offset_left = -260.0
	mission_overlay.offset_right = 260.0
	mission_overlay.offset_top = -110.0
	mission_overlay.offset_bottom = 110.0
	mission_overlay.visible = false
	root.add_child(mission_overlay)
	var margin := _make_margin(28, 28, 24, 24)
	mission_overlay.add_child(margin)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 16)
	margin.add_child(column)
	column.add_child(_make_label("BRASSLINE JOB RESULT", 13, _brass))
	mission_result = _make_label("BLUEPRINTS SECURED", 30, _ink)
	mission_result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(mission_result)
	var restart := Button.new()
	restart.text = "RUN THE HEIST AGAIN"
	restart.custom_minimum_size.y = 48.0
	restart.add_theme_stylebox_override("normal", _button_style(Color(0.10, 0.27, 0.29, 0.98), _panel_border))
	restart.add_theme_stylebox_override("hover", _button_style(Color(0.19, 0.42, 0.42, 1.0), _brass))
	restart.pressed.connect(func() -> void: restart_requested.emit())
	column.add_child(restart)


func _make_panel() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _panel_style())
	return panel


func _panel_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = _panel_color
	style.border_color = _panel_border
	style.set_border_width_all(1)
	style.set_corner_radius_all(7)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.32)
	style.shadow_size = 8
	return style


func _button_style(color: Color, border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	style.content_margin_left = 10.0
	style.content_margin_right = 10.0
	style.content_margin_top = 8.0
	style.content_margin_bottom = 8.0
	return style


func _make_margin(left: int, right: int, top: int, bottom: int) -> MarginContainer:
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", left)
	margin.add_theme_constant_override("margin_right", right)
	margin.add_theme_constant_override("margin_top", top)
	margin.add_theme_constant_override("margin_bottom", bottom)
	return margin


func _make_label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", maxi(size, 13))
	label.add_theme_color_override("font_color", color)
	return label


func _make_emblem(texture: Texture2D, edge: float) -> TextureRect:
	var emblem := TextureRect.new()
	emblem.texture = texture
	emblem.custom_minimum_size = Vector2(edge, edge)
	emblem.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	emblem.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	emblem.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return emblem


func _on_zone_pressed(zone: Types.BodyZone) -> void:
	zone_requested.emit(zone)


func update_from_turn(turn: TurnController) -> void:
	if not is_instance_valid(phase_label):
		return
	phase_label.text = turn.phase_name()
	round_label.text = "ROUND %02d" % turn.round_number
	end_turn_button.disabled = turn.phase != Types.Phase.PLAYER

	var selected := turn.selected_unit
	var target := turn.current_target
	var player_phase := turn.phase == Types.Phase.PLAYER
	grenade_button.text = "GRENADE\nx%d [G]" % int(_combat_inventory.get("clockwork_grenade", 0))
	tonic_button.text = "FOCUS\nx%d [T]" % int(_combat_inventory.get("focus_tonic", 0))
	grenade_button.disabled = int(_combat_inventory.get("clockwork_grenade", 0)) <= 0 or not turn.can_use_grenade(target)
	tonic_button.disabled = (
		int(_combat_inventory.get("focus_tonic", 0)) <= 0
		or not player_phase
		or not is_instance_valid(selected)
		or selected.is_focused()
	)
	action_panel.visible = is_instance_valid(selected) and selected.is_alive and not _cinematic_capture
	target_panel.visible = is_instance_valid(target) and target.is_alive and not _cinematic_capture
	stats_panel.visible = _stats_expanded and is_instance_valid(selected) and selected.is_alive and not _cinematic_capture
	stats_button.disabled = not is_instance_valid(selected) or not selected.is_alive
	stats_button.text = "CLOSE  [I]" if _stats_expanded else "STATS  [I]"
	cover_legend_label.visible = is_instance_valid(target) and target.is_alive
	cover_legend_label.text = (
		"MOVE MARKERS / TEAL = FULL COVER  •  BRASS = HALF COVER"
		if is_instance_valid(target) and target.is_alive
		else ""
	)
	if is_instance_valid(selected):
		var stance_text := "  •  %s" % selected.cover_stance_name() if selected.crouched else ""
		selected_label.text = "%s  •  %d AP  •  MOVE %d%s  •  %s  %d/%d" % [
			selected.display_name,
			selected.action_points,
			selected.movement_range(),
			stance_text,
			selected.weapon_name,
			selected.ammunition,
			selected.magazine_size,
		]
		reload_button.text = "RELOAD [R]\n%d / %d" % [selected.ammunition, selected.magazine_size]
		reload_button.disabled = not player_phase or selected.action_points < 1 or not selected.can_reload()
		overwatch_button.text = "OVERWATCH [O]\n%s" % ("ARMS CRIPPLED" if selected.arms_crippled() else "1 AP")
		overwatch_button.disabled = not player_phase or selected.action_points < 1 or selected.ammunition <= 0 or selected.overwatch_active or not selected.can_overwatch()
		cover_button.text = "%s [C]\n%s" % [selected.cover_stance_name() if selected.crouched else "TAKE COVER", "LEGS CRIPPLED" if selected.legs_crippled() else ("ACTIVE" if selected.crouched else "1 AP")]
		cover_button.disabled = not player_phase or selected.action_points < 1 or selected.crouched or not selected.can_take_cover()
		ability_button.text = "%s [B]\nFREE" % (selected.ability_name.to_upper() if not selected.ability_name.is_empty() else "NO SIGNATURE")
		ability_button.tooltip_text = selected.ability_description
		ability_button.disabled = not player_phase or selected.ability_id.is_empty() or selected.ability_used
	else:
		selected_label.text = "Select an operative"
		_stats_expanded = false
		stats_panel.visible = false
		reload_button.disabled = true
		overwatch_button.disabled = true
		cover_button.disabled = true
		ability_button.disabled = true

	if is_instance_valid(target) and target.is_alive:
		target_label.text = "TARGET / %s  •  RANGE %d  •  %s" % [
			target.display_name,
			turn.board.grid_distance(selected.grid_cell, target.grid_cell) if is_instance_valid(selected) else 0,
			turn.target_defense_text(selected, target) if is_instance_valid(selected) else "UNKNOWN DEFENSE",
		]
		var chances := {}
		var affordable := {}
		for zone in zone_buttons:
			var chance := turn.attack_chance(selected, target, zone) if is_instance_valid(selected) else 0.0
			var ap_cost := Types.zone_ap_cost(zone)
			var can_afford := (
				is_instance_valid(selected)
				and selected.action_points >= ap_cost
				and chance > 0.0
				and turn.phase == Types.Phase.PLAYER
			)
			chances[zone] = chance
			affordable[zone] = can_afford
			zone_buttons[zone].text = "%s  %s\n%s  •  %d AP" % [
				Types.BODY_ZONE_SHORTCUTS[zone],
				Types.zone_name(zone).to_upper(),
				target.zone_hp_text(zone),
				ap_cost,
			]
			zone_buttons[zone].disabled = target.is_zone_detached(zone)
			zone_buttons[zone].set_pressed_no_signal(zone == turn.target_zone)
		target_silhouette.set_snapshot(target, turn.target_zone, chances, affordable)
		if is_instance_valid(selected):
			var chance := turn.attack_chance(selected, target, turn.target_zone)
			var shot_cost := Types.zone_ap_cost(turn.target_zone)
			var crit_chance := turn.critical_chance(selected, target, turn.target_zone)
			chance_label.text = "%s  •  %d%% HIT  •  %d%% CRIT  •  %d AP\n%s" % [
				Types.zone_name(turn.target_zone).to_upper(),
				roundi(chance * 100.0),
				roundi(crit_chance * 100.0),
				shot_cost,
				Types.zone_effect(turn.target_zone),
			]
			attack_button.text = "FIRE AT %s  •  %d AP  [F]" % [Types.zone_name(turn.target_zone).to_upper(), shot_cost]
			attack_button.disabled = (
				not player_phase
				or selected.action_points < shot_cost
				or (selected.uses_ammunition and selected.ammunition <= 0)
				or chance <= 0.0
			)
		else:
			chance_label.text = "Select a crew member to calculate the shot."
			attack_button.disabled = true
	else:
		target_label.text = "TARGET / Select a rail guard"
		chance_label.text = "Select a target to calculate the shot."
		attack_button.disabled = true
		attack_button.text = "TAKE CALLED SHOT  [F / RIGHT CLICK]"
		target_silhouette.set_snapshot(null, turn.target_zone, {}, {})
		for zone in zone_buttons:
			zone_buttons[zone].text = "%s  %s" % [Types.BODY_ZONE_SHORTCUTS[zone], Types.zone_name(zone).to_upper()]
			zone_buttons[zone].disabled = true
			zone_buttons[zone].set_pressed_no_signal(false)

	_update_stats_panel(selected, turn)

	if turn.encounter_mode in ["eliminate", "secure", "takeover_finale"]:
		objective_label.text = "OBJECTIVE · %s" % turn.objective_text
	elif turn.encounter_mode == "finale":
		if turn.board.objective_collected:
			objective_label.text = "OBJECTIVE · Return the blueprint carrier to the green boarding hatch."
		elif turn.board.objective_marker.visible:
			objective_label.text = "OBJECTIVE · Voss is down. Collect the blueprint case."
		else:
			objective_label.text = "OBJECTIVE · Defeat Voss and recover the blueprints."
	elif turn.board.objective_collected:
		objective_label.text = "OBJECTIVE · Blueprint case secured. Return its carrier to the green extraction tile."
	else:
		objective_label.text = "OBJECTIVE · Seize the violet blueprint case, then return to extraction."


func set_run_context(car_data: Dictionary, car_number: int, bonuses: Dictionary) -> void:
	_current_car_data = car_data.duplicate(true)
	_current_car_number = car_number
	_run_bonuses = bonuses.duplicate(true)


func toggle_stats() -> void:
	_stats_expanded = not _stats_expanded
	if is_instance_valid(stats_panel):
		stats_panel.visible = _stats_expanded and not _cinematic_capture
	if is_instance_valid(stats_button):
		stats_button.text = "CLOSE  [I]" if _stats_expanded else "STATS  [I]"


func _update_stats_panel(selected: TacticalUnit, turn: TurnController) -> void:
	if not is_instance_valid(stats_name_label):
		return
	if not is_instance_valid(selected):
		stats_name_label.text = "SELECT AN OPERATIVE"
		stats_combat_label.text = "Weapon statistics appear here."
		stats_body_label.text = "Body status appears here."
		stats_effects_label.text = "No active conditions."
		stats_buff_label.text = "EARNED CAR BUFFS / %s" % RunState.format_bonus_summary(_run_bonuses)
		return
	var role := String(selected.get_meta("crew_role", "OPERATIVE"))
	var base_damage := float(selected.get_meta("unbuffed_damage", selected.base_damage - float(_run_bonuses.get("damage", 0.0))))
	var base_range := int(selected.get_meta("unbuffed_range", selected.attack_range - int(_run_bonuses.get("range", 0))))
	var base_move := int(selected.get_meta("unbuffed_move", selected.base_movement - int(_run_bonuses.get("movement", 0))))
	var damage_buff := float(_run_bonuses.get("damage", 0.0))
	var range_buff := int(_run_bonuses.get("range", 0))
	var move_buff := int(_run_bonuses.get("movement", 0))
	var hit_buff := roundi(float(_run_bonuses.get("accuracy", 0.0)) * 100.0)
	var crit_buff := roundi(float(_run_bonuses.get("critical", 0.0)) * 100.0)
	stats_name_label.text = "%s  /  %s" % [selected.display_name.to_upper(), role]
	stats_combat_label.text = (
		"%s  •  AMMO %d/%d\n"
		+ "DAMAGE %.1f  /  BASE %.1f  /  CAR +%.2f\n"
		+ "RANGE %d / BASE %d / CAR +%d\n"
		+ "MOVE %d / BASE %d / CAR +%d\n"
		+ "AIM MOD %+d%%  •  CRIT MOD %+d%%"
	) % [
		selected.weapon_name.to_upper(), selected.ammunition, selected.magazine_size,
		selected.base_damage, base_damage, damage_buff,
		selected.attack_range, base_range, range_buff,
		selected.movement_range(), base_move, move_buff,
		roundi(selected.weapon_accuracy_bonus * 100.0) + hit_buff,
		roundi(selected.weapon_critical_bonus * 100.0) + crit_buff,
	]
	stats_body_label.text = "BODY / HEAD %s  •  TORSO %s\nARMS %s  •  LEGS %s" % [
		selected.zone_hp_text(Types.BodyZone.HEAD),
		selected.zone_hp_text(Types.BodyZone.TORSO),
		selected.zone_hp_text(Types.BodyZone.ARMS),
		selected.zone_hp_text(Types.BodyZone.LEGS),
	]
	var conditions: Array[String] = []
	if selected.arms_crippled():
		conditions.append("ARMS CRIPPLED: -36% aim, half damage, no reload or overwatch")
	if selected.legs_crippled():
		conditions.append("LEGS CRIPPLED: move limited to 1, cannot Take Cover")
	if selected.crouched:
		conditions.append("COVER STANCE: -10% incoming hit chance")
	if selected.overwatch_active:
		conditions.append("OVERWATCH ARMED")
	if selected.is_focused():
		conditions.append("FOCUSED: +18% hit and +16% critical on next shot")
	if conditions.is_empty():
		conditions.append("CONDITION / READY")
	stats_effects_label.text = "\n".join(conditions)
	var car_name := String(_current_car_data.get("name", "CURRENT CAR")).to_upper()
	stats_buff_label.text = "EARNED CAR BUFFS / %s\nCURRENT / CAR %02d • %s" % [
		RunState.format_bonus_summary(_run_bonuses),
		_current_car_number,
		car_name,
	]


func set_combat_inventory(inventory: Dictionary) -> void:
	_combat_inventory = {
		"clockwork_grenade": int(inventory.get("clockwork_grenade", 0)),
		"focus_tonic": int(inventory.get("focus_tonic", 0)),
	}


func push_log(message: String) -> void:
	_log_lines.push_front(message)
	if _log_lines.size() > 6:
		_log_lines.resize(6)
	_render_log()


func clear_log() -> void:
	_log_lines.clear()
	_log_expanded = false
	if is_instance_valid(log_panel):
		log_panel.offset_right = 248.0
		log_panel.offset_top = -92.0
	if is_instance_valid(log_toggle_button):
		log_toggle_button.text = "LOG  [L]"
	_render_log()


func _render_log() -> void:
	if not is_instance_valid(log_label):
		return
	var rendered := ""
	var line_count := _log_lines.size() if _log_expanded else mini(1, _log_lines.size())
	for index in range(line_count):
		var color := "#e3b65c" if index == 0 else "#9fc1c2"
		var line_text: String = _log_lines[index]
		if not _log_expanded and line_text.length() > 29:
			line_text = line_text.left(28) + "…"
		rendered += "[color=%s]%s[/color]" % [color, line_text]
		if index < line_count - 1:
			rendered += "\n"
	log_label.text = rendered


func toggle_log() -> void:
	_log_expanded = not _log_expanded
	if _log_expanded:
		log_panel.offset_right = 248.0
		log_panel.offset_top = -330.0
		log_toggle_button.text = "HIDE  [L]"
	else:
		log_panel.offset_right = 248.0
		log_panel.offset_top = -92.0
		log_toggle_button.text = "LOG  [L]"
	_render_log()


func show_result(victory: bool, message: String) -> void:
	mission_result.text = message
	mission_result.add_theme_color_override("font_color", _ink if victory else _danger)
	mission_overlay.visible = true


func set_hud_visible(value: bool) -> void:
	if is_instance_valid(hud_root):
		hud_root.visible = value


func set_cinematic_capture(value: bool) -> void:
	_cinematic_capture = value
	if is_instance_valid(target_panel):
		target_panel.visible = not value and target_panel.visible
	if is_instance_valid(action_panel):
		action_panel.visible = not value and action_panel.visible
	if is_instance_valid(log_panel):
		log_panel.visible = not value
	if is_instance_valid(stats_panel):
		stats_panel.visible = not value and _stats_expanded
	if is_instance_valid(help_label):
		help_label.visible = not value
