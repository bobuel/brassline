class_name BrasslinePlanCatalog
extends RefCounted

const Types := preload("res://scripts/game_types.gd")

const OPERATIVE_TAGS := {
	"ada": ["precision", "long_range", "arm_breaker", "patient", "needs_sightline", "poor_frontline"],
	"marlow": ["breacher", "frontline", "close_range", "protective", "cover_destroyer", "accepts_risk"],
	"nix": ["saboteur", "fast", "hazard_user", "flanker", "opportunist", "fragile"],
	"iona": ["mechanist", "support", "repair", "protective", "hazard_control", "mid_range"],
	"silas": ["duelist", "precision", "opportunist", "exposed_hunter", "mid_range", "fast"],
	"rook": ["frontline", "anchor", "protective", "accepts_risk", "close_range", "armored"],
}

const CAR_TAGS := {
	"baggage": ["loose_cover", "boarding_choke", "supply_cache", "short_sightlines"],
	"dining": ["table_cover", "narrow_aisle", "galley_choke", "chandelier_hazard", "service_cart"],
	"bar": ["counter_cover", "narrow_aisle", "bottle_hazard", "dueling_lane"],
	"crew": ["bunk_cover", "locker_lane", "reinforcement_route", "crew_knowledge"],
	"armory": ["hard_cover", "weapon_cages", "ammunition_press", "fortified_lane"],
	"engine": ["steam_vents", "pressure_valves", "short_sightlines", "machinery_cover", "fire_hazard"],
	"observation": ["long_sightlines", "window_lane", "little_hard_cover", "optics"],
	"cargo": ["crate_maze", "loader_lane", "contraband", "shifting_cover"],
	"casino": ["gaming_tables", "open_floor", "volatile_hazard", "dueling_lane"],
}

const ENEMY_TAGS := {
	"railhand": ["railhand", "line_guard"],
	"duelist": ["duelist", "flanker", "exposed_hunter"],
	"marksman": ["marksman", "overwatcher", "long_range"],
	"bruiser": ["bruiser", "charger", "armored", "frontline"],
	"medic": ["medic", "support", "healer"],
	"officer": ["officer", "leader", "reinforcement_caller"],
	"boss": ["boss", "leader", "armored", "reinforcement_caller"],
}

# These templates author the prose and the tactical doctrine together. Runtime
# binding supplies the actual crew member, target, injury modifiers, deployment,
# and opening hit estimate; the player never has to edit an AI rule list.
const PLAN_TEMPLATES := [
	{
		"id": "measured_entry",
		"cars": ["baggage"],
		"title": "Read the baggage line",
		"summary": "{shooter} holds the clean aisle while {anchor} takes the nearest trunk and {scout} watches for a flank.",
		"advantage": "A reliable opening that establishes cover before committing.",
		"risk": "The railhand keeps both weapon and mobility if the opening volley misses.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "opportunist"},
		"risk_role": "anchor",
		"target_role": "railhand",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "spread",
		"doctrine": "reliable",
		"safe": true,
		"confidence": 3,
		"tags": ["safe", "cover_first", "boarding"],
	},
	{
		"id": "break_the_hands",
		"cars": ["baggage"],
		"title": "Break the trigger hand",
		"summary": "{shooter} waits for the guard to clear the luggage, then ruins his arms while {anchor} owns the aisle.",
		"advantage": "Removes most return-fire pressure and teaches the body-part doctrine.",
		"risk": "A two-action called shot leaves {shooter} unable to correct a miss.",
		"roles": {"shooter": "arm_breaker", "anchor": "frontline", "scout": "fast"},
		"risk_role": "shooter",
		"target_role": "railhand",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "disable",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 3,
		"tags": ["called_shot", "disable", "precision"],
	},
	{
		"id": "rush_the_manifest",
		"cars": ["baggage"],
		"title": "Rush the manifest",
		"summary": "{anchor} breaches through the loose trunks while {scout} cuts the escape lane and {shooter} fires center mass.",
		"advantage": "Fast torso pressure can end the boarding fight before the guard settles.",
		"risk": "{anchor} accepts the first clean return shot at close range.",
		"roles": {"anchor": "breacher", "scout": "fast", "shooter": "long_range"},
		"risk_role": "anchor",
		"target_role": "railhand",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.LEGS,
		"deployment": "forward",
		"doctrine": "aggressive",
		"ability_role": "anchor",
		"safe": false,
		"confidence": 2,
		"tags": ["breach", "fast", "aggressive"],
	},
	{
		"id": "lash_the_freight",
		"cars": ["baggage"],
		"requires_car": ["loose_cover"],
		"title": "Lash the freight",
		"summary": "{scout} catches the loose straps before the brake slack hits. {anchor} braces the aisle while {shooter} works the guard's arms.",
		"advantage": "Cancels every Loose Freight surge and denies the railhand his practiced footing.",
		"risk": "{scout} spends the opening securing cargo instead of firing.",
		"roles": {"scout": "hazard_user", "anchor": "frontline", "shooter": "precision"},
		"risk_role": "scout",
		"target_role": "railhand",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "spread",
		"doctrine": "control",
		"ability_role": "scout",
		"environment_action": "lash_freight",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "trust"],
	},
	{
		"id": "pin_the_command",
		"cars": ["dining"],
		"requires_enemy": ["leader"],
		"requires_car": ["table_cover"],
		"title": "Pin the command",
		"summary": "{shooter} fires through the serving line to ruin {target}'s arms. {anchor} crosses while {scout} watches the aisle.",
		"advantage": "Crippled command arms prevent accurate fire and the officer's reinforcement call.",
		"risk": "{shooter} begins exposed to long-range return fire.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "opportunist"},
		"risk_role": "shooter",
		"target_role": "officer",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "disable",
		"ability_role": "shooter",
		"safe": true,
		"confidence": 3,
		"tags": ["called_shot", "leader", "precision"],
	},
	{
		"id": "break_the_room",
		"cars": ["dining"],
		"requires_car": ["chandelier_hazard"],
		"title": "Break the room",
		"summary": "{scout} drops the chandelier across the table line. {anchor} breaches the debris while {shooter} hunts anyone forced open.",
		"advantage": "The opening hazard damages enemy legs and disrupts the central cover lane.",
		"risk": "Falling debris can catch {anchor} if the timing slips.",
		"roles": {"scout": "hazard_user", "anchor": "breacher", "shooter": "precision"},
		"risk_role": "anchor",
		"body_priority": Types.BodyZone.LEGS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "forward",
		"doctrine": "hazard",
		"ability_role": "scout",
		"environment_action": "chandelier",
		"safe": false,
		"confidence": 2,
		"tags": ["hazard", "breach", "legs"],
	},
	{
		"id": "lock_the_service_cart",
		"cars": ["dining"],
		"requires_car": ["service_cart"],
		"title": "Lock the service cart",
		"summary": "{anchor} rams the service cart into the brace rail. {shooter} attacks the officer's arms while {scout} owns the safe side.",
		"advantage": "Creates a fixed brace and cancels the Dining Car's repeated curve sweeps.",
		"risk": "{anchor} gives up the first attack while the officer's doctrine remains intact.",
		"roles": {"anchor": "frontline", "shooter": "precision", "scout": "hazard_user"},
		"risk_role": "anchor",
		"target_role": "officer",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "spread",
		"doctrine": "control",
		"ability_role": "anchor",
		"environment_action": "lock_service_cart",
		"tactic_family": "safe_control",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "officer"],
	},
	{
		"id": "light_the_backbar",
		"cars": ["bar"],
		"requires_car": ["bottle_hazard"],
		"title": "Light the backbar",
		"summary": "{scout} starts a bottle fire behind the counter while {anchor} holds the aisle and {shooter} splits fire onto the far threat.",
		"advantage": "A real carriage hazard pressures a clustered flank without spending carried gear.",
		"risk": "The fire lane can clip {scout} if the crew crowds the counter.",
		"roles": {"scout": "hazard_user", "anchor": "frontline", "shooter": "precision"},
		"risk_role": "scout",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "spread",
		"doctrine": "hazard",
		"ability_role": "scout",
		"environment_action": "bottle_fire",
		"safe": false,
		"confidence": 2,
		"tags": ["hazard", "crossfire", "fire"],
	},
	{
		"id": "spoil_the_draw",
		"cars": ["bar"],
		"requires_enemy": ["duelist"],
		"title": "Spoil the draw",
		"summary": "{shooter} counts the carriage sway with {target}, then ruins the duelist's arms while {anchor} denies the center aisle.",
		"advantage": "Breaking the duelists' firing arms dismantles Pistols at Ten and its critical-shot bonus.",
		"risk": "{shooter} must hold a two-action called shot while the loose backbar keeps moving.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "opportunist"},
		"risk_role": "shooter",
		"target_role": "duelist",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "disable",
		"ability_role": "shooter",
		"safe": true,
		"confidence": 2,
		"tags": ["called_shot", "doctrine_break", "duelist"],
	},
	{
		"id": "dog_the_lockers",
		"cars": ["crew"],
		"requires_car": ["locker_lane"],
		"title": "Dog the lockers",
		"summary": "{scout} secures the locker dogs before the shift lurch while {anchor} takes the bunk line and {shooter} pressures the most exposed guard.",
		"advantage": "Cancels every Locker Slam and preserves the crew's actions in the tight wall lanes.",
		"risk": "{scout} spends the opening securing the carriage instead of attacking the relief medic.",
		"roles": {"scout": "hazard_control", "anchor": "frontline", "shooter": "precision"},
		"risk_role": "scout",
		"target_role": "",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "spread",
		"doctrine": "control",
		"ability_role": "scout",
		"environment_action": "dog_the_lockers",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "lockers"],
	},
	{
		"id": "break_the_relief",
		"cars": ["crew"],
		"requires_enemy": ["healer"],
		"title": "Break the relief rotation",
		"summary": "{scout} opens the maintenance lane while {shooter} attacks {target}'s arms and {anchor} holds the returning shift.",
		"advantage": "Crippled medical arms end the guard line's automatic healing every round.",
		"risk": "The unsecured lockers remain live while the crew reaches past the frontline.",
		"roles": {"scout": "flanker", "shooter": "precision", "anchor": "frontline"},
		"risk_role": "scout",
		"target_role": "medic",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "spread",
		"doctrine": "disable",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 2,
		"tags": ["called_shot", "doctrine_break", "medic"],
	},
	{
		"id": "jam_the_press",
		"cars": ["armory"],
		"requires_car": ["ammunition_press"],
		"title": "Jam the ammunition press",
		"summary": "{scout} drives a cage pin into the feed clutch while {anchor} braces the hard lane and {shooter} works center mass.",
		"advantage": "Cancels every press recoil before it can crush the exposed feed lanes.",
		"risk": "{scout} gives up the first shot inside the train's most heavily fortified carriage.",
		"roles": {"scout": "mechanist", "anchor": "armored", "shooter": "precision"},
		"risk_role": "scout",
		"target_role": "",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "choke",
		"doctrine": "control",
		"ability_role": "scout",
		"environment_action": "jam_the_press",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "armory"],
	},
	{
		"id": "break_the_cage_line",
		"cars": ["armory"],
		"requires_enemy": ["bruiser"],
		"title": "Break the cage line",
		"summary": "{shooter} attacks {target}'s legs through the cage gap while {anchor} fixes the armored line and {scout} circles the press.",
		"advantage": "A crippled bruiser can no longer lock the formation to its damage-resistant cage positions.",
		"risk": "The live ammunition press remains free to punish a slow opening.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "flanker"},
		"risk_role": "anchor",
		"target_role": "bruiser",
		"body_priority": Types.BodyZone.LEGS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "disable",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 2,
		"tags": ["called_shot", "doctrine_break", "armored"],
	},
	{
		"id": "drop_storm_shutters",
		"cars": ["observation"],
		"requires_car": ["window_lane"],
		"title": "Drop the storm shutters",
		"summary": "{anchor} crosses the panorama controls while {scout} drops each shutter and {shooter} pins the nearest marksman.",
		"advantage": "Cancels every Glass Sway and gives the crew a stable wall in the exposed gallery.",
		"risk": "{scout} spends the opening on the shutters while the marksmen retain their reflected range marks.",
		"roles": {"anchor": "protective", "scout": "fast", "shooter": "long_range"},
		"risk_role": "scout",
		"target_role": "marksman",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.HEAD,
		"deployment": "spread",
		"doctrine": "control",
		"ability_role": "scout",
		"environment_action": "drop_storm_shutters",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "window"],
	},
	{
		"id": "blind_the_spotters",
		"cars": ["observation"],
		"requires_enemy": ["marksman"],
		"title": "Blind the spotters",
		"summary": "{shooter} uses the marksmen's own reflection to attack {target}'s head while {anchor} and {scout} cross under the shot.",
		"advantage": "Head trauma ruins the shared range calculation and ends the marksmen's +12% aim.",
		"risk": "The hardest called shot in the gallery leaves the flexing panorama unsecured.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "fast"},
		"risk_role": "shooter",
		"target_role": "marksman",
		"body_priority": Types.BodyZone.HEAD,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "decisive",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 1,
		"tags": ["called_shot", "doctrine_break", "marksman"],
	},
	{
		"id": "set_the_cargo_brake",
		"cars": ["cargo"],
		"requires_car": ["shifting_cover"],
		"title": "Set the cargo brake",
		"summary": "{scout} winds the independent brake while {anchor} braces the loader lane and {shooter} clears the most exposed guard from the crates.",
		"advantage": "Cancels every Shunt Impact and freezes the crate maze in place.",
		"risk": "{scout} spends the opening at the brake wheel instead of hunting the heavy loader.",
		"roles": {"scout": "mechanist", "anchor": "frontline", "shooter": "precision"},
		"risk_role": "scout",
		"target_role": "",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.LEGS,
		"deployment": "spread",
		"doctrine": "control",
		"ability_role": "scout",
		"environment_action": "set_cargo_brake",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "freight"],
	},
	{
		"id": "cripple_the_loader",
		"cars": ["cargo"],
		"requires_enemy": ["bruiser"],
		"title": "Cripple the loader",
		"summary": "{shooter} waits for {target} to lift the next ammunition case, then breaks the loader's legs while {anchor} holds the maze.",
		"advantage": "A crippled loader cannot feed overpressure rounds to the railhand screen.",
		"risk": "The unsecured cargo brake leaves every marked freight lane live.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "opportunist"},
		"risk_role": "anchor",
		"target_role": "bruiser",
		"body_priority": Types.BodyZone.LEGS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "choke",
		"doctrine": "disable",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 2,
		"tags": ["called_shot", "doctrine_break", "cargo"],
	},
	{
		"id": "lock_the_tables",
		"cars": ["casino"],
		"requires_car": ["gaming_tables"],
		"title": "Lock the gaming tables",
		"summary": "{anchor} takes the pit while {scout} stamps each table catch and {shooter} forces the nearest duelist off the open floor.",
		"advantage": "Cancels every House Roll and turns the casino's loose furniture into fixed cover.",
		"risk": "{scout} spends the opening on the table catches while the house timing remains intact.",
		"roles": {"anchor": "frontline", "scout": "fast", "shooter": "precision"},
		"risk_role": "scout",
		"target_role": "duelist",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.HEAD,
		"deployment": "spread",
		"doctrine": "control",
		"ability_role": "scout",
		"environment_action": "lock_the_tables",
		"safe": true,
		"confidence": 3,
		"tags": ["living_train", "counter", "casino"],
	},
	{
		"id": "beat_the_house_edge",
		"cars": ["casino"],
		"requires_enemy": ["duelist"],
		"title": "Beat the house edge",
		"summary": "{shooter} fires when the ivory ball crosses black, attacking {target}'s head while {anchor} and {scout} split the pit.",
		"advantage": "Head trauma spoils the shared count and removes the duelists' +15% critical chance.",
		"risk": "The high-risk shot leaves the rolling gaming floor unsecured.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "opportunist"},
		"risk_role": "shooter",
		"target_role": "duelist",
		"body_priority": Types.BodyZone.HEAD,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "decisive",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 1,
		"tags": ["called_shot", "doctrine_break", "casino"],
	},
	{
		"id": "bleed_the_pressure",
		"cars": ["engine"],
		"requires_car": ["pressure_valves"],
		"title": "Bleed the pressure",
		"summary": "{scout} vents the machinery lane. {shooter} disables Voss's arms, then legs; {anchor} holds the line until his arms are crippled before taking the controls.",
		"advantage": "Venting cancels steam surges. Voss surrenders when his arms and legs are crippled and the controls are claimed.",
		"risk": "Venting does not stop Voss's +8% command aim. Break his head for that; this plan instead risks the longer disarm-and-capture sequence.",
		"risk_short": "Voss keeps +8% squad aim until his head breaks or he surrenders.",
		"counterplay_short": "If Voss's arms and legs break, claimed controls force his surrender.",
		"roles": {"scout": "hazard_control", "anchor": "frontline", "shooter": "precision"},
		"risk_role": "anchor",
		"target_role": "boss",
		"capture_target": true,
		"control_after_role": "boss",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "forward",
		"doctrine": "hazard",
		"ability_role": "scout",
		"environment_action": "steam_valve",
		"safe": false,
		"confidence": 2,
		"tags": ["hazard", "engine", "control"],
	},
	{
		"id": "break_voss_timing",
		"cars": ["engine"],
		"requires_enemy": ["leader"],
		"title": "Break Voss's timing",
		"summary": "{shooter} waits for the red gauge to flare, then attacks Voss's head. {anchor} absorbs the guard line while {scout} reads the vents.",
		"advantage": "A crippled head ends Voss's Redline aim bonus for every surviving guard.",
		"risk": "{shooter} commits two actions to the train's hardest called shot.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "hazard_user"},
		"risk_role": "shooter",
		"target_role": "boss",
		"body_priority": Types.BodyZone.HEAD,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "decisive",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 1,
		"tags": ["called_shot", "doctrine_break", "finale"],
	},
	{
		"id": "make_them_chase",
		"cars": ["dining"],
		"requires_enemy": ["charger"],
		"requires_car": ["narrow_aisle"],
		"title": "Make them chase us",
		"summary": "The crew yields the center. {scout} baits {target} into the aisle, {shooter} breaks his legs, and {anchor} holds the choke.",
		"advantage": "Isolates the bruiser and removes his charge before he reaches the wounded.",
		"risk": "The officer remains active longer and controls the far side of the room.",
		"roles": {"scout": "fast", "shooter": "long_range", "anchor": "frontline"},
		"risk_role": "scout",
		"target_role": "bruiser",
		"body_priority": Types.BodyZone.LEGS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "choke",
		"doctrine": "lure",
		"tactic_family": "high_risk",
		"risk_level": "HIGH",
		"safe": true,
		"confidence": 2,
		"tags": ["isolate", "legs", "defensive"],
	},
	{
		"id": "silence_the_rifles",
		"requires_enemy": ["overwatcher"],
		"title": "Silence the rifles",
		"summary": "{shooter} and {scout} attack the marksman's arms while {anchor} advances only under clean cover.",
		"advantage": "Disables Overwatch and makes reloading impossible.",
		"risk": "Two-action limb shots slow direct elimination.",
		"roles": {"shooter": "precision", "scout": "opportunist", "anchor": "frontline"},
		"risk_role": "shooter",
		"target_role": "marksman",
		"body_priority": Types.BodyZone.ARMS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "disable",
		"safe": true,
		"confidence": 2,
		"tags": ["called_shot", "marksman", "disable"],
	},
	{
		"id": "stop_the_charge",
		"requires_enemy": ["charger"],
		"title": "Stop the charge",
		"summary": "{shooter} waits for {target} to clear cover, then attacks the legs while {anchor} screens the crew.",
		"advantage": "A crippled bruiser cannot close, flank, or reach useful cover.",
		"risk": "The supporting guards remain free to shoot during the setup.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "fast"},
		"risk_role": "anchor",
		"target_role": "bruiser",
		"body_priority": Types.BodyZone.LEGS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "choke",
		"doctrine": "disable",
		"safe": true,
		"confidence": 2,
		"tags": ["called_shot", "bruiser", "defensive"],
	},
	{
		"id": "remove_the_support",
		"requires_enemy": ["support"],
		"title": "Remove their support",
		"summary": "{scout} finds the side lane while {shooter} suppresses {target}. {anchor} prevents the frontline from peeling back.",
		"advantage": "Drops the enemy's healing or command support before attrition begins.",
		"risk": "{scout} may become isolated behind the enemy line.",
		"roles": {"scout": "flanker", "shooter": "precision", "anchor": "frontline"},
		"risk_role": "scout",
		"target_role": "medic",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "spread",
		"doctrine": "flank",
		"safe": false,
		"confidence": 2,
		"tags": ["flank", "support", "aggressive"],
	},
	{
		"id": "covered_crossing",
		"title": "Cross under cover",
		"summary": "{anchor} owns the safest forward position while {shooter} and {scout} advance only behind a clean firing line.",
		"advantage": "Keeps the crew mutually covered and adapts well to unfamiliar carriage layouts.",
		"risk": "The slower opening gives specialist guards time to establish their preferred range.",
		"roles": {"anchor": "protective", "shooter": "precision", "scout": "fast"},
		"risk_role": "anchor",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "spread",
		"doctrine": "reliable",
		"safe": true,
		"confidence": 3,
		"tags": ["safe", "cover_first", "adaptable"],
	},
	{
		"id": "cut_the_mobility",
		"title": "Cut their mobility",
		"summary": "{shooter} and {scout} attack the lead guard's legs while {anchor} denies the shortest route into the crew.",
		"advantage": "Crippled legs stop charges, flanks, and useful cover changes.",
		"risk": "Limb shots spend more of the crew's opening action economy than torso fire.",
		"roles": {"shooter": "precision", "scout": "opportunist", "anchor": "frontline"},
		"risk_role": "anchor",
		"body_priority": Types.BodyZone.LEGS,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "choke",
		"doctrine": "disable",
		"safe": true,
		"confidence": 2,
		"tags": ["called_shot", "legs", "defensive"],
	},
	{
		"id": "seize_the_side_lane",
		"title": "Seize the side lane",
		"summary": "{scout} pulls the guard line sideways, {anchor} follows the opening, and {shooter} punishes the exposed torso.",
		"advantage": "Turns furniture and narrow aisles into crossfire instead of an obstacle.",
		"risk": "{scout} can be isolated if the first movement fails to open the angle.",
		"roles": {"scout": "flanker", "anchor": "frontline", "shooter": "long_range"},
		"risk_role": "scout",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.LEGS,
		"deployment": "spread",
		"doctrine": "flank",
		"ability_role": "scout",
		"safe": false,
		"confidence": 2,
		"tags": ["flank", "crossfire", "aggressive"],
	},
	{
		"id": "steady_center_mass",
		"title": "Take the sure shots",
		"summary": "The crew stays mutually covered and concentrates torso fire on the most exposed threat.",
		"advantage": "Reliable damage, simple target transitions, and low ammunition waste.",
		"risk": "Special enemy abilities remain intact until their owner goes down.",
		"roles": {"shooter": "", "anchor": "frontline", "scout": ""},
		"risk_role": "anchor",
		"body_priority": Types.BodyZone.TORSO,
		"secondary_zone": Types.BodyZone.ARMS,
		"deployment": "spread",
		"doctrine": "reliable",
		"safe": true,
		"confidence": 3,
		"tags": ["safe", "focus_fire", "torso"],
	},
	{
		"id": "ambitious_decisive_shot",
		"requires_enemy": ["leader"],
		"title": "Cut off the command",
		"summary": "{shooter} attempts a decisive head shot on {target} while {anchor} and {scout} contain the line.",
		"advantage": "A strong opening can remove leadership before it affects the battle.",
		"risk": "Low hit probability and a full activation committed to one shot.",
		"roles": {"shooter": "precision", "anchor": "frontline", "scout": "opportunist"},
		"risk_role": "shooter",
		"target_role": "officer",
		"body_priority": Types.BodyZone.HEAD,
		"secondary_zone": Types.BodyZone.TORSO,
		"deployment": "sightline",
		"doctrine": "decisive",
		"ability_role": "shooter",
		"safe": false,
		"confidence": 1,
		"tags": ["headshot", "leader", "high_risk"],
	},
]

const FALLBACKS := [
	{
		"id": "hold_plan",
		"title": "HOLD THE PLAN",
		"description": "Preserve assignments unless an objective becomes impossible or an operative goes down.",
		"short_description": "Keep assignments until the opening cannot continue.",
	},
	{
		"id": "protect_wounded",
		"title": "PROTECT THE WOUNDED",
		"description": "If an operative's torso falls below 40%, nearby allies cover them and seek safer ground.",
		"short_description": "Wounded crew seek cover and gain protection.",
	},
	{
		"id": "finish_target",
		"title": "FINISH THE TARGET",
		"description": "Keep pressure on the opening priority even after injuries force the crew to adapt.",
		"short_description": "Keep pressure on the opening target.",
	},
	{
		"id": "save_crew",
		"title": "SAVE THE CREW",
		"description": "If two operatives become crippled, retreat toward the boarding choke and fight defensively.",
		"short_description": "Broken plans retreat and protect the crew.",
	},
	{
		"id": "improvise",
		"title": "IMPROVISE",
		"description": "When the opening breaks, each operative follows their personal combat instinct.",
		"short_description": "Crew abandon assignments and follow instinct.",
	},
]

const PLAN_SHORT_SUMMARIES := {
	"measured_entry": "Take cover, read the aisle, then fire.",
	"break_the_hands": "Break {target}'s weapon control before the line settles.",
	"rush_the_manifest": "Cross fast and seize the useful ground.",
	"lash_the_freight": "Secure loose freight; cancel cargo surges.",
	"pin_the_command": "Pin {target}; force the room to hesitate.",
	"break_the_room": "Drop the chandelier onto marked cells; damage legs and torso.",
	"lock_the_service_cart": "Brace the service cart; cancel aisle sweeps.",
	"light_the_backbar": "Ignite the backbar and own the choke.",
	"spoil_the_draw": "Ruin {target}'s arms before the duel starts.",
	"dog_the_lockers": "Secure the lockers; cancel their next slam.",
	"break_the_relief": "Cripple {target} before reinforcements find position.",
	"jam_the_press": "Jam the press; cancel recoil across its marked lane.",
	"break_the_cage_line": "Cripple the armored guard, then breach the cage.",
	"drop_storm_shutters": "Drop the shutters across the sniper lanes.",
	"blind_the_spotters": "Target {target}'s head; break the shared range calculation.",
	"set_the_cargo_brake": "Set the cargo brake; cancel load shifts.",
	"cripple_the_loader": "Take the loader's legs before it charges.",
	"lock_the_tables": "Lock the gaming tables into hard cover.",
	"beat_the_house_edge": "Target {target}'s head; spoil the duelists' shared count.",
	"bleed_the_pressure": "Vent the lane; cripple Voss's arms before advancing to capture the Engine.",
	"break_voss_timing": "Target Voss's head; end his Redline aim bonus.",
	"make_them_chase": "Pull the enemy across overlapping firing lanes.",
	"silence_the_rifles": "Disable the rifle line before it settles.",
	"stop_the_charge": "Take the nearest bruiser's legs, then hold.",
	"remove_the_support": "Drop their support first; collapse the formation.",
	"covered_crossing": "Advance behind cover with no isolated operative.",
	"cut_the_mobility": "Cripple their fastest threat and control distance.",
	"seize_the_side_lane": "Flank wide and turn their own cover.",
	"steady_center_mass": "Reliable torso fire from a protected formation.",
	"ambitious_decisive_shot": "Risk one exposed shooter for a decisive opening.",
}


static func operative_tags(roster_id: String) -> Array[String]:
	var result: Array[String] = []
	result.assign(Array(OPERATIVE_TAGS.get(roster_id, [])))
	return result


static func car_tags(car_id: String) -> Array[String]:
	var result: Array[String] = []
	result.assign(Array(CAR_TAGS.get(car_id, [])))
	return result


static func enemy_tags(role_id: String) -> Array[String]:
	var result: Array[String] = []
	result.assign(Array(ENEMY_TAGS.get(role_id, [role_id])))
	return result


static func fallback_data(fallback_id: String) -> Dictionary:
	for fallback in FALLBACKS:
		if String(fallback.get("id", "")) == fallback_id:
			return Dictionary(fallback).duplicate(true)
	return Dictionary(FALLBACKS[0]).duplicate(true)


static func generate_plans(
		car_id: String,
		crew: Array[TacticalUnit],
		enemies: Array[TacticalUnit],
		turn: TurnController,
		bonuses: Dictionary = {},
		recent_plan_ids: Array[String] = [],
		inventory: Dictionary = {},
		unlocked_plan_ids: Array[String] = []
	) -> Array[Dictionary]:
	var available_crew_tags: Array[String] = []
	for unit in crew:
		for tag in operative_tags(unit.roster_id):
			if tag not in available_crew_tags:
				available_crew_tags.append(tag)
	var available_enemy_tags: Array[String] = []
	for unit in enemies:
		for tag in enemy_tags(unit.role_id):
			if tag not in available_enemy_tags:
				available_enemy_tags.append(tag)
	var layout_tags := car_tags(car_id)
	var candidates: Array[Dictionary] = []
	for raw_template in _available_templates(crew, unlocked_plan_ids):
		var template: Dictionary = Dictionary(raw_template)
		if float(template.get("specialist_priority", 0.0)) > 0.0 and String(template.get("id", "")) in recent_plan_ids:
			continue
		var cars: Array = template.get("cars", [])
		if not cars.is_empty() and car_id not in cars:
			continue
		if not _contains_all(available_enemy_tags, Array(template.get("requires_enemy", []))):
			continue
		if not _contains_all(layout_tags, Array(template.get("requires_car", []))):
			continue
		if not _inventory_satisfies(Array(template.get("requires_item", [])), inventory):
			continue
		var bindings := _bind_roles(Dictionary(template.get("roles", {})), crew)
		if bindings.is_empty():
			continue
		var target := _find_target(String(template.get("target_role", "")), enemies)
		if not String(template.get("target_role", "")).is_empty() and not is_instance_valid(target):
			continue
		var plan := _materialize_plan(template, bindings, target, crew, enemies, turn, bonuses, inventory)
		var score := float(Array(template.get("requires_enemy", [])).size() * 3 + Array(template.get("requires_car", [])).size() * 3)
		score += 4.0 if not cars.is_empty() else 0.0
		score += 1.5 if bool(template.get("safe", false)) else 1.0
		score -= float(int(plan.get("mismatch_count", 0))) * 1.75
		if String(template.get("id", "")) in recent_plan_ids:
			score -= 5.0
		score += float(template.get("specialist_priority", 0.0))
		plan["selection_score"] = score
		candidates.append(plan)
	candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a.get("selection_score", 0.0)) > float(b.get("selection_score", 0.0)))

	# Every offer is a readable tactical quartet. Signature encounters prioritize
	# their authored carriage counter and anatomical doctrine-breaker inside the
	# matching family instead of adding near-duplicate fifth choices.
	var required_signature_plans := {
		"baggage": ["lash_the_freight", "break_the_hands"],
		"dining": ["lock_the_service_cart", "pin_the_command"],
		"bar": ["light_the_backbar", "spoil_the_draw"],
		"crew": ["dog_the_lockers", "break_the_relief"],
		"armory": ["jam_the_press", "break_the_cage_line"],
		"observation": ["drop_storm_shutters", "blind_the_spotters"],
		"cargo": ["set_the_cargo_brake", "cripple_the_loader"],
		"casino": ["lock_the_tables", "beat_the_house_edge"],
		"engine": ["bleed_the_pressure", "break_voss_timing"],
	}
	var preferred_by_family := {}
	for required_id in Array(required_signature_plans.get(car_id, [])):
		for candidate in candidates:
			if String(candidate.get("id", "")) == String(required_id):
				preferred_by_family[String(candidate.get("tactic_family", ""))] = candidate
				break
	var selected: Array[Dictionary] = []
	for family in ["safe_control", "body_disable", "environment_gear", "high_risk"]:
		var chosen := Dictionary(preferred_by_family.get(family, {}))
		if chosen.is_empty():
			for candidate in candidates:
				if String(candidate.get("tactic_family", "")) == family and float(candidate.get("specialist_priority", 0.0)) > 0.0 and _offer_accepts(selected, candidate):
					chosen = candidate
					break
		if chosen.is_empty() or not _offer_accepts(selected, chosen):
			chosen = {}
			for candidate in candidates:
				if String(candidate.get("tactic_family", "")) != family:
					continue
				if _offer_accepts(selected, candidate):
					chosen = candidate
					break
		# Each supported carriage has authored candidates for all four families.
		# This fallback keeps unusual modded encounters playable while exposing a
		# machine-readable warning for validation rather than silently duplicating.
		if chosen.is_empty():
			for candidate in candidates:
				if candidate not in selected and String(candidate.get("tactic_family", "")) == family:
					chosen = candidate
					chosen["offer_diversity_warning"] = "No conflict-free %s plan was available." % family
					break
		if not chosen.is_empty():
			selected.append(chosen)
	return selected


static func _available_templates(crew: Array[TacticalUnit], unlocked_plan_ids: Array[String]) -> Array[Dictionary]:
	var templates: Array[Dictionary] = []
	for template in PLAN_TEMPLATES:
		templates.append(Dictionary(template))
	var operative_ids: Array[String] = []
	for unit in crew:
		if unit.is_alive:
			operative_ids.append(unit.roster_id)
	# These are sidegrades composed from existing actions, never permanent stats.
	var variants := [
		{"id": "rook_holds_the_line", "base": "covered_crossing", "operative": "rook", "title": "Rook holds the line", "summary": "{anchor} braces the boarding choke with Iron Stance while the crew fires from behind him.", "short_summary": "Rook braces the choke; the crew holds a protected firing line.", "roles": {"anchor": "armored", "shooter": "precision", "scout": "fast"}, "ability_role": "anchor", "deployment": "choke", "doctrine": "lure", "risk_role": "anchor"},
		{"id": "silas_double_draw", "base": "seize_the_side_lane", "operative": "silas", "title": "Silas doubles down", "summary": "{shooter} uses Quickdraw to concentrate fire while the others contain the nearest threat.", "short_summary": "Silas uses Quickdraw; the crew focuses the opening target.", "roles": {"shooter": "duelist", "anchor": "frontline", "scout": "opportunist"}, "ability_role": "shooter", "doctrine": "aggressive", "tags": ["focus_fire", "high_risk"], "risk_role": "shooter"},
		{"id": "blueprint_crossfire", "base": "seize_the_side_lane", "unlock": true, "title": "Blueprint crossfire", "summary": "{scout} opens the side lane while the crew concentrates on one exposed guard.", "short_summary": "Open a side lane; concentrate all fire on one priority.", "tags": ["focus_fire", "flank"], "risk_role": "scout"},
		{"id": "blueprint_countermarch", "base": "cut_the_mobility", "unlock": true, "cars": ["armory", "cargo"], "requires_enemy": ["charger"], "target_role": "bruiser", "tactic_family": "high_risk", "safe": false, "title": "Blueprint countermarch", "summary": "The crew risks its opening on concentrated leg shots against the charging armored guard.", "short_summary": "Concentrate leg shots on the charger; risk the slower two-action opening.", "tags": ["focus_fire", "legs"], "risk_role": "shooter"},
		{"id": "blueprint_pressure_play", "base": "seize_the_side_lane", "unlock": true, "title": "Blueprint pressure play", "summary": "{anchor} races for carriage controls while {shooter} and {scout} keep the line occupied.", "short_summary": "Rush carriage controls; trade protection for early surrender pressure.", "deployment": "forward", "doctrine": "aggressive", "ability_role": "anchor", "risk_role": "anchor"},
	]
	for variant in variants:
		if bool(variant.get("unlock", false)) and String(variant["id"]) not in unlocked_plan_ids:
			continue
		if variant.has("operative") and String(variant["operative"]) not in operative_ids:
			continue
		for original in PLAN_TEMPLATES:
			if String(original.get("id", "")) != String(variant["base"]):
				continue
			var template: Dictionary = Dictionary(original).duplicate(true)
			template.merge(variant, true)
			template["specialist_priority"] = 10.0 if bool(variant.get("unlock", false)) else 8.0
			templates.append(template)
			break
	return templates


static func _materialize_plan(
		template: Dictionary,
		bindings: Dictionary,
		target: TacticalUnit,
		crew: Array[TacticalUnit],
		enemies: Array[TacticalUnit],
		turn: TurnController,
		bonuses: Dictionary,
		inventory: Dictionary
	) -> Dictionary:
	var plan := template.duplicate(true)
	var assignment_ids := {}
	for role_name in bindings:
		var bound_unit: TacticalUnit = bindings[role_name]
		assignment_ids[role_name] = bound_unit.roster_id
	plan["assignments"] = assignment_ids
	plan["target_instance_id"] = target.get_instance_id() if is_instance_valid(target) else 0
	plan["target_name"] = target.display_name if is_instance_valid(target) else "the most exposed guard"
	var summary := String(template.get("summary", ""))
	for role_name in bindings:
		summary = summary.replace("{%s}" % role_name, (bindings[role_name] as TacticalUnit).display_name)
	for role_name in Dictionary(template.get("roles", {})):
		summary = summary.replace("{%s}" % role_name, "the surviving crew")
	summary = summary.replace("{target}", plan["target_name"])
	plan["summary"] = summary
	var short_summary := String(template.get("short_summary", PLAN_SHORT_SUMMARIES.get(String(template.get("id", "")), "Execute the opening and keep the crew moving.")))
	for role_name in bindings:
		short_summary = short_summary.replace("{%s}" % role_name, (bindings[role_name] as TacticalUnit).display_name)
	for role_name in Dictionary(template.get("roles", {})):
		short_summary = short_summary.replace("{%s}" % role_name, "the crew")
	plan["short_summary"] = short_summary.replace("{target}", plan["target_name"])
	var risk := String(template.get("risk", ""))
	for role_name in bindings:
		risk = risk.replace("{%s}" % role_name, (bindings[role_name] as TacticalUnit).display_name)
	for role_name in Dictionary(template.get("roles", {})):
		risk = risk.replace("{%s}" % role_name, "the surviving crew")
	plan["risk"] = risk.replace("{target}", plan["target_name"])
	var advantage := String(template.get("advantage", ""))
	for role_name in bindings:
		advantage = advantage.replace("{%s}" % role_name, (bindings[role_name] as TacticalUnit).display_name)
	for role_name in Dictionary(template.get("roles", {})):
		advantage = advantage.replace("{%s}" % role_name, "the surviving crew")
	plan["advantage"] = advantage.replace("{target}", plan["target_name"])

	var body_priority: Types.BodyZone = int(template.get("body_priority", Types.BodyZone.TORSO))
	var confidence := int(template.get("confidence", 2))
	var mismatch_count := 0
	var role_specs: Dictionary = template.get("roles", {})
	for role_name in role_specs:
		if not bindings.has(role_name):
			mismatch_count += 1
			continue
		var required_tag := String(role_specs[role_name])
		var assigned: TacticalUnit = bindings.get(role_name) as TacticalUnit
		if not required_tag.is_empty() and is_instance_valid(assigned) and required_tag not in operative_tags(assigned.roster_id):
			mismatch_count += 1
	confidence -= mismatch_count
	plan["mismatch_count"] = mismatch_count
	if mismatch_count > 0:
		plan["compatibility_warning"] = "%d assignment%s rely on an operative working outside their specialty." % [mismatch_count, "" if mismatch_count == 1 else "s"]
	var shooter: TacticalUnit = bindings.get("shooter") as TacticalUnit
	if is_instance_valid(shooter):
		if shooter.arms_crippled():
			confidence -= 1
		if is_instance_valid(target):
			plan["opening_hit_chance"] = turn.attack_chance(shooter, target, body_priority)
			if float(plan["opening_hit_chance"]) >= 0.75:
				confidence += 1
	var risk_role := String(template.get("risk_role", ""))
	var risk_unit: TacticalUnit = bindings.get(risk_role) as TacticalUnit
	if not is_instance_valid(risk_unit) and not crew.is_empty():
		risk_unit = crew[0]
	if is_instance_valid(risk_unit):
		plan["risk_unit_id"] = risk_unit.roster_id
		plan["risk_unit_name"] = risk_unit.display_name
		if risk_unit.legs_crippled() and String(template.get("deployment", "")) in ["forward", "choke"]:
			confidence -= 1
	if body_priority != Types.BodyZone.TORSO and float(bonuses.get("accuracy", 0.0)) >= 0.04:
		confidence += 1
	confidence = clampi(confidence, 0, 3)
	plan["confidence_rank"] = confidence
	plan["confidence"] = ["LOW", "MEDIUM", "MEDIUM-HIGH", "HIGH"][confidence]

	var orders := {}
	var focus_assignments := (
		"focus_fire" in Array(template.get("tags", []))
		or String(template.get("id", "")) == "silence_the_rifles"
		or (enemies.size() == 1 and body_priority != Types.BodyZone.TORSO)
	)
	for role_name in bindings:
		var unit: TacticalUnit = bindings[role_name]
		var role_target := _target_for_assignment(role_name, unit, target, enemies, focus_assignments)
		var role_zone := body_priority
		if role_name == "anchor" and not focus_assignments:
			role_zone = Types.BodyZone.TORSO
		elif role_name == "scout" and String(template.get("doctrine", "")) not in ["flank", "lure", "hazard"] and not focus_assignments:
			role_zone = Types.BodyZone.TORSO
		orders[unit.roster_id] = {
			"assignment": role_name,
			"body_priority": int(role_zone),
			"secondary_zone": int(template.get("secondary_zone", Types.BodyZone.TORSO)),
			"target_role": role_target.role_id if is_instance_valid(role_target) else String(template.get("target_role", "")),
			"target_instance_id": role_target.get_instance_id() if is_instance_valid(role_target) else 0,
			"target_name": role_target.display_name if is_instance_valid(role_target) else "nearest threat",
			"doctrine": String(template.get("doctrine", "reliable")),
			"position": _position_for_role(String(template.get("deployment", "spread")), role_name),
			"use_ability": String(template.get("ability_role", "")).is_empty() or role_name == String(template.get("ability_role", "")),
			"objective": "control" if role_name == "anchor" and String(template.get("doctrine", "")) in ["aggressive", "flank", "hazard"] else ("disable" if role_zone != Types.BodyZone.TORSO else "pressure"),
			"gear_item": "",
		}
		if bool(template.get("capture_target", false)) and role_name == "shooter":
			orders[unit.roster_id]["capture_target"] = true
			orders[unit.roster_id]["secondary_zone"] = int(Types.BodyZone.LEGS)
		if role_name == "anchor" and not String(template.get("control_after_role", "")).is_empty():
			orders[unit.roster_id]["control_after_role"] = String(template["control_after_role"])
	for unit in crew:
		if not orders.has(unit.roster_id):
			orders[unit.roster_id] = {
				"assignment": "support",
				"body_priority": int(body_priority),
				"secondary_zone": int(template.get("secondary_zone", Types.BodyZone.TORSO)),
				"target_role": String(template.get("target_role", "")),
				"doctrine": String(template.get("doctrine", "reliable")),
				"position": "mid_cover",
				"use_ability": String(template.get("ability_role", "")).is_empty(),
				"objective": "support",
				"gear_item": "",
			}
	_assign_plan_gear(plan, orders, bindings, inventory, enemies, turn)
	plan["orders"] = orders
	plan["enemy_count"] = enemies.size()
	plan["execution_family"] = _execution_family(plan)
	plan["tactic_family"] = _tactic_family(plan)
	plan["risk_level"] = _risk_level(plan)
	if not String(plan.get("environment_action", "")).is_empty():
		plan["primary_target_key"] = "environment:%s" % String(plan.get("environment_action", ""))
	elif String(plan.get("tactic_family", "")) == "safe_control":
		plan["primary_target_key"] = "formation:%s" % String(plan.get("deployment", "spread"))
	else:
		plan["primary_target_key"] = "unit:%d" % int(plan.get("target_instance_id", 0))
	plan["preview_steps"] = _preview_steps(plan)
	if not String(plan.get("environment_action", "")).is_empty():
		plan["environment_preview"] = turn.plan_environment_preview(String(plan["environment_action"]))
	return plan


static func _target_for_assignment(
		role_name: String,
		unit: TacticalUnit,
		primary: TacticalUnit,
		enemies: Array[TacticalUnit],
		focus_assignments: bool
	) -> TacticalUnit:
	if focus_assignments and is_instance_valid(primary):
		return primary
	var living: Array[TacticalUnit] = []
	for enemy in enemies:
		if enemy.is_alive:
			living.append(enemy)
	if living.is_empty():
		return null
	if role_name == "shooter" and is_instance_valid(primary):
		return primary
	var preferred_roles: Array = ["bruiser", "railhand", "duelist"] if role_name == "anchor" else ["medic", "marksman", "officer", "duelist"]
	for preferred in preferred_roles:
		for enemy in living:
			if enemy.role_id == preferred and (enemy != primary or living.size() == 1):
				return enemy
	var best := living[0]
	var best_distance := 999
	for enemy in living:
		if enemy == primary and living.size() > 1:
			continue
		var distance := unit.board.grid_distance(unit.grid_cell, enemy.grid_cell)
		if distance < best_distance:
			best_distance = distance
			best = enemy
	return best


static func _assign_plan_gear(
		plan: Dictionary,
		orders: Dictionary,
		bindings: Dictionary,
		inventory: Dictionary,
		enemies: Array[TacticalUnit],
		turn: TurnController
	) -> void:
	plan["gear_item"] = ""
	plan["gear_user_name"] = ""
	plan["gear_trigger"] = ""
	var doctrine := String(plan.get("doctrine", "reliable"))
	if int(inventory.get("clockwork_grenade", 0)) > 0 and doctrine in ["aggressive", "flank", "hazard", "decisive"]:
		var actor: TacticalUnit = bindings.get("scout") as TacticalUnit
		if not is_instance_valid(actor):
			actor = bindings.get("anchor") as TacticalUnit
		var blast_target := _best_grenade_target(actor, enemies, turn)
		if is_instance_valid(actor) and is_instance_valid(blast_target):
			var order: Dictionary = orders.get(actor.roster_id, {})
			order["gear_item"] = "clockwork_grenade"
			order["gear_target_instance_id"] = blast_target.get_instance_id()
			orders[actor.roster_id] = order
			plan["gear_item"] = "clockwork_grenade"
			plan["gear_user_name"] = actor.display_name
			plan["gear_trigger"] = "Open on %s when the blast is clear." % blast_target.display_name
			return
	if int(inventory.get("focus_tonic", 0)) > 0 and int(plan.get("body_priority", Types.BodyZone.TORSO)) != Types.BodyZone.TORSO:
		var shooter: TacticalUnit = bindings.get("shooter") as TacticalUnit
		if is_instance_valid(shooter):
			var order: Dictionary = orders.get(shooter.roster_id, {})
			order["gear_item"] = "focus_tonic"
			orders[shooter.roster_id] = order
			plan["gear_item"] = "focus_tonic"
			plan["gear_user_name"] = shooter.display_name
			plan["gear_trigger"] = "Before the first difficult called shot."


static func _best_grenade_target(actor: TacticalUnit, enemies: Array[TacticalUnit], turn: TurnController) -> TacticalUnit:
	if not is_instance_valid(actor) or actor.arms_crippled():
		return null
	var best: TacticalUnit
	var best_score := -1
	for candidate in enemies:
		if not candidate.is_alive:
			continue
		var score := 2 if candidate.role_id in ["bruiser", "boss"] else 0
		for enemy in enemies:
			if enemy.is_alive and turn.board.grid_distance(candidate.grid_cell, enemy.grid_cell) <= 1:
				score += 2
		for crew in turn.player_units(true):
			if turn.board.grid_distance(candidate.grid_cell, crew.grid_cell) <= 1:
				score -= 20
		if score > best_score and score >= 2:
			best_score = score
			best = candidate
	return best


static func _execution_family(plan: Dictionary) -> String:
	var gear := String(plan.get("gear_item", "none"))
	var environment := String(plan.get("environment_action", "none"))
	return "%s:%s:%s:%s" % [String(plan.get("doctrine", "reliable")), String(plan.get("deployment", "spread")), environment, gear]


static func _tactic_family(plan: Dictionary) -> String:
	if not String(plan.get("tactic_family", "")).is_empty():
		return String(plan.get("tactic_family", ""))
	# Optional carried gear enriches a plan without erasing its underlying tactical
	# identity. Authored carriage interactions own this family; item-only templates
	# can opt in with `item_assisted_family` when added later.
	if not String(plan.get("environment_action", "")).is_empty() or bool(plan.get("item_assisted_family", false)):
		return "environment_gear"
	if int(plan.get("body_priority", Types.BodyZone.TORSO)) != Types.BodyZone.TORSO:
		return "body_disable"
	if bool(plan.get("safe", false)):
		return "safe_control"
	return "high_risk"


static func _risk_level(plan: Dictionary) -> String:
	if not String(plan.get("risk_level", "")).is_empty():
		return String(plan.get("risk_level", "")).to_upper()
	if bool(plan.get("safe", false)) and int(plan.get("confidence_rank", 0)) >= 2:
		return "LOW"
	if not bool(plan.get("safe", false)) or String(plan.get("doctrine", "")) in ["aggressive", "flank", "hazard", "decisive"]:
		return "HIGH"
	return "MEDIUM"


static func _preview_steps(plan: Dictionary) -> Array[Dictionary]:
	var opening_action := String(plan.get("environment_action", ""))
	if opening_action.is_empty():
		opening_action = "attack_%s" % Types.zone_name(int(plan.get("body_priority", Types.BodyZone.TORSO))).to_lower().replace(" ", "_")
	var follow_through := "protect_risk_carrier" if bool(plan.get("safe", false)) else "press_advantage"
	var condition := ""
	if bool(plan.get("capture_target", false)):
		follow_through = "capture_after_disarm"
		condition = "Advance controls after Voss's arms break; arms, legs and controls are required for surrender."
	return [
		{"beat": "start", "deployment": String(plan.get("deployment", "spread")), "risk_unit_id": String(plan.get("risk_unit_id", ""))},
		{"beat": "opening", "action": opening_action, "target_instance_id": int(plan.get("target_instance_id", 0)), "body_zone": int(plan.get("body_priority", Types.BodyZone.TORSO)), "gear_item": String(plan.get("gear_item", ""))},
		{"beat": "follow_through", "action": follow_through, "condition": condition, "fallback": "player_choice"},
	]


static func _offer_accepts(selected: Array[Dictionary], candidate: Dictionary) -> bool:
	var target_matches := 0
	var body_matches := 0
	var risk_matches := 0
	for plan in selected:
		if String(plan.get("primary_target_key", "")) == String(candidate.get("primary_target_key", "")):
			target_matches += 1
		if int(plan.get("body_priority", Types.BodyZone.TORSO)) == int(candidate.get("body_priority", Types.BodyZone.TORSO)):
			body_matches += 1
		if String(plan.get("risk_unit_id", "")) == String(candidate.get("risk_unit_id", "")):
			risk_matches += 1
	return target_matches < 2 and body_matches < 2 and risk_matches < 2


static func _inventory_satisfies(required_items: Array, inventory: Dictionary) -> bool:
	for item_id in required_items:
		if int(inventory.get(String(item_id), 0)) <= 0:
			return false
	return true


static func _bind_roles(role_specs: Dictionary, crew: Array[TacticalUnit]) -> Dictionary:
	var bindings := {}
	var used: Array[TacticalUnit] = []
	# Reserve genuine specialists before filling unmatched jobs. An absent
	# mechanist must not consume the rifle specialist before the shooter is bound.
	for role_name in role_specs:
		var required_tag := String(role_specs[role_name])
		for unit in crew:
			if unit in used or not unit.is_alive:
				continue
			if required_tag.is_empty() or required_tag in operative_tags(unit.roster_id):
				bindings[role_name] = unit
				used.append(unit)
				break
	for role_name in role_specs:
		if bindings.has(role_name):
			continue
		# Keep the offer usable after casualties or with unusual rosters. The
		# materialized confidence still reports every non-specialist assignment.
		for unit in crew:
			if unit not in used and unit.is_alive:
				bindings[role_name] = unit
				used.append(unit)
				break
	return bindings


static func _find_target(target_role: String, enemies: Array[TacticalUnit]) -> TacticalUnit:
	if target_role.is_empty():
		for enemy in enemies:
			if enemy.is_alive:
				return enemy
		return null
	for enemy in enemies:
		if enemy.is_alive and enemy.role_id == target_role:
			return enemy
	# Leader/support templates accept the mechanically equivalent role when the
	# exact authored label changes in the finale or another carriage.
	var target_tag := "leader" if target_role in ["officer", "boss"] else ("support" if target_role == "medic" else target_role)
	for enemy in enemies:
		if enemy.is_alive and target_tag in enemy_tags(enemy.role_id):
			return enemy
	return null


static func _position_for_role(deployment: String, role_name: String) -> String:
	match deployment:
		"forward":
			return "front_cover" if role_name in ["anchor", "scout"] else "rear_sightline"
		"sightline":
			return "rear_sightline" if role_name == "shooter" else ("front_cover" if role_name == "anchor" else "side_lane")
		"choke":
			return "boarding_choke" if role_name == "anchor" else ("rear_sightline" if role_name == "shooter" else "bait_lane")
	return "front_cover" if role_name == "anchor" else ("side_lane" if role_name == "scout" else "rear_sightline")


static func _contains_all(haystack: Array[String], needles: Array) -> bool:
	for value in needles:
		if String(value) not in haystack:
			return false
	return true


static func _contains_safe_plan(plans: Array[Dictionary]) -> bool:
	for plan in plans:
		if bool(plan.get("safe", false)):
			return true
	return false
