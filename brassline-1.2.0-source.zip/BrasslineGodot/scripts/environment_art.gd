class_name EnvironmentArt
extends Node3D

const ASSET_ROOT := "res://assets/environment/kenney/"

var board: GridBoard
var _asset_cache: Dictionary = {}
var _spinners: Array[Node3D] = []
var _steam_puffs: Array[MeshInstance3D] = []
var _active_dressing: Node3D
var _tactical_cover_root: Node3D
var _train_event_root: Node3D
var _active_car_light: OmniLight3D
var _overhead_dressing: Array[Node3D] = []

var _iron: StandardMaterial3D
var _iron_edge: StandardMaterial3D
var _brass: StandardMaterial3D
var _aged_brass: StandardMaterial3D
var _wood: StandardMaterial3D
var _wood_dark: StandardMaterial3D
var _carriage_panel: StandardMaterial3D
var _crew_panel: StandardMaterial3D
var _boiler_panel: StandardMaterial3D
var _vault_panel: StandardMaterial3D
var _glass: StandardMaterial3D
var _lamp_material: StandardMaterial3D
var _steam_material: StandardMaterial3D
var _cover_badge_material: StandardMaterial3D


func setup(board_ref: GridBoard) -> void:
	board = board_ref
	_build_materials()
	_hide_graybox_cover()
	_active_dressing = Node3D.new()
	_active_dressing.name = "ActiveRunCarDressing"
	_active_dressing.scale = Vector3(0.72, 1.0, 1.0)
	add_child(_active_dressing)
	_tactical_cover_root = Node3D.new()
	_tactical_cover_root.name = "TacticalCoverProps"
	add_child(_tactical_cover_root)
	_train_event_root = Node3D.new()
	_train_event_root.name = "LivingTrainTelegraph"
	add_child(_train_event_root)
	set_active_run_car("baggage", 1)


func set_active_run_car(car_id: String, car_number: int) -> void:
	if not is_instance_valid(_active_dressing):
		return
	for child in _active_dressing.get_children():
		_active_dressing.remove_child(child)
		child.queue_free()
	for child in _tactical_cover_root.get_children():
		_tactical_cover_root.remove_child(child)
		child.queue_free()
	_clear_train_event_visuals()
	_spinners.clear()
	_steam_puffs.clear()
	_overhead_dressing.clear()
	_active_dressing.set_meta("active_car_id", car_id)
	_active_dressing.set_meta("window_style", "porthole" if car_id == "engine" else ("armored_slit" if car_id == "armory" else ("panorama" if car_id == "observation" else "passenger")))

	var palette := {
		"baggage": Color("#d29a42"), "dining": Color("#d6b46a"),
		"bar": Color("#b85f48"), "crew": Color("#45a5a5"),
		"armory": Color("#c76d42"), "engine": Color("#f07a38"),
		"observation": Color("#68b9c8"), "sleeper": Color("#8076b8"),
		"cargo": Color("#9f7b4f"), "casino": Color("#b76bb6"),
	}
	var accent: Color = palette.get(car_id, Color("#d29a42"))
	var accent_material := _material(accent.darkened(0.42), 0.58, 0.48, accent, 0.36)
	_build_active_car_shell(car_id, accent_material)

	var sign_back := _dynamic_box(Vector3(5.6, 0.52, 0.08), Vector3(0.0, 2.50, -3.61), _iron)
	sign_back.name = "ActiveCarSignBack"
	var sign := Label3D.new()
	sign.name = "ActiveCarSign"
	sign.text = "CAR %02d / %s" % [car_number, car_id.replace("_", " ").to_upper()]
	sign.position = Vector3(0.0, 2.46, -3.52)
	sign.font_size = 30
	sign.pixel_size = 0.006
	sign.modulate = accent.lightened(0.22)
	sign.outline_modulate = Color("#080909")
	sign.outline_size = 8
	sign.scale = Vector3(1.0 / 0.72, 1.0, 1.0)
	_active_dressing.add_child(sign)

	for light_index in range(3):
		var lamp_x := -10.0 + float(light_index) * 10.0
		var housing := _dynamic_cylinder(0.19, 0.28, Vector3(lamp_x, 2.58, -2.74), _aged_brass)
		housing.rotation_degrees.z = 90.0
		var bulb := _dynamic_sphere(0.13, Vector3(lamp_x, 2.38, -2.72), _lamp_material)
		bulb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var light := OmniLight3D.new()
		light.name = "CarMoodLight_%d" % light_index
		light.position = Vector3(lamp_x, 2.28, -1.0)
		light.light_color = accent.lightened(0.12)
		light.light_energy = 2.5 if car_id != "engine" else 3.2
		light.omni_range = 8.0
		light.shadow_enabled = true
		_active_dressing.add_child(light)
		if light_index == 1:
			_active_car_light = light

	match car_id:
		"baggage":
			_build_baggage_car(accent_material)
		"cargo":
			_build_cargo_car(accent_material)
		"dining":
			_build_dining_car(accent_material)
		"bar":
			_build_bar_car(accent_material)
		"casino":
			_build_casino_car(accent_material)
		"crew":
			_build_crew_run_car(accent_material)
		"armory":
			_build_armory_car(accent_material)
		"engine":
			_build_engine_car(accent_material)
		"observation":
			_build_observation_car(accent_material)
		"sleeper":
			_build_sleeper_car(accent_material)
	_build_authored_control(car_id, accent_material)
	_build_tactical_cover_props(car_id)
	_exclude_walkable_dressing()


func decorative_walkable_conflicts() -> Array[MeshInstance3D]:
	var conflicts: Array[MeshInstance3D] = []
	for child in _active_dressing.find_children("*", "MeshInstance3D", true, false):
		var mesh := child as MeshInstance3D
		if not mesh.is_visible_in_tree() or mesh.mesh == null:
			continue
		var structural_parent := mesh.get_parent()
		var structural := false
		while structural_parent != null and structural_parent != _active_dressing:
			if structural_parent.name == "ActiveCarUnderframe": structural = true; break
			structural_parent = structural_parent.get_parent()
		if structural: continue
		var bounds: AABB = mesh.global_transform * mesh.get_aabb()
		# Floors and wall/ceiling dressing do not occupy a standing operative.
		if bounds.end.y < 0.18 or bounds.position.y > 1.90:
			continue
		var footprint := Rect2(Vector2(bounds.position.x, bounds.position.z), Vector2(bounds.size.x, bounds.size.z))
		for x in range(GridBoard.BOARD_SIZE.x):
			for y in range(GridBoard.BOARD_SIZE.y):
				var cell := Vector2i(x, y)
				if not board.is_walkable(cell):
					continue
				var cell_world := board.cell_to_world(cell)
				var standing_space := Rect2(Vector2(cell_world.x, cell_world.z) - Vector2(0.28, 0.28), Vector2(0.56, 0.56))
				if footprint.intersects(standing_space):
					conflicts.append(mesh)
					break
			if mesh in conflicts:
				break
	return conflicts


func _exclude_walkable_dressing() -> void:
	# The blocked-cell furniture is the only solid dressing inside a route. The
	# old second layer of decorative tables/lockers allowed units to walk inside
	# meshes despite a valid path. Keep those source nodes but omit conflicts.
	var excluded := decorative_walkable_conflicts()
	for mesh in excluded:
		mesh.visible = false
		mesh.set_meta("excluded_walkable_overlap", true)
	_active_dressing.set_meta("excluded_walkable_overlap_count", excluded.size())


func set_living_train_event(event: Dictionary, result: Dictionary = {}) -> void:
	if not is_instance_valid(_train_event_root) or event.is_empty():
		return
	_clear_train_event_visuals()
	var warning := String(event.get("phase", "warning")) == "warning"
	var countered := bool(result.get("countered", false))
	var color := Color(0.93, 0.56, 0.16, 0.28) if warning else (Color(0.20, 0.84, 0.62, 0.20) if countered else Color(0.94, 0.20, 0.12, 0.30))
	var material := StandardMaterial3D.new()
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = color
	material.emission_enabled = true
	material.emission = Color(color.r, color.g, color.b, 1.0)
	material.emission_energy_multiplier = 1.6 if warning else 0.8
	for raw_cell in Array(event.get("cells", [])):
		var cell := Vector2i(raw_cell)
		var marker := MeshInstance3D.new()
		marker.name = "Hazard_%02d_%02d" % [cell.x, cell.y]
		var mesh := BoxMesh.new()
		mesh.size = Vector3(GridBoard.CELL_SIZE_X * 0.91, 0.018, GridBoard.CELL_SIZE_Z * 0.91)
		marker.mesh = mesh
		marker.position = board.cell_to_world(cell) + Vector3(0.0, 0.082, 0.0)
		marker.material_override = material
		marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_train_event_root.add_child(marker)
	_train_event_root.set_meta("event_id", String(event.get("id", "")))
	_train_event_root.set_meta("phase", String(event.get("phase", "")))
	if is_instance_valid(_active_car_light):
		var pulse_color := Color("#ffad3d") if warning else (Color("#55d8a5") if countered else Color("#ff4938"))
		_active_car_light.light_color = pulse_color
		_active_car_light.light_energy = 4.4 if warning else 5.2
		var tween := create_tween()
		tween.tween_property(_active_car_light, "light_energy", 2.7, 0.55)
	# The set dressing visibly reacts as a single rolling carriage. This is kept
	# restrained so character animation and tactical readability remain primary.
	if is_instance_valid(_active_dressing):
		var lean := 0.8 if warning else 1.6
		var direction := -1.0 if String(event.get("id", "")).ends_with("_0") else 1.0
		var dressing_tween := create_tween()
		dressing_tween.tween_property(_active_dressing, "rotation_degrees:z", direction * lean, 0.12)
		dressing_tween.tween_property(_active_dressing, "rotation_degrees:z", 0.0, 0.34)
		var car_id := String(_active_dressing.get_meta("active_car_id", ""))
		for child in _active_dressing.get_children():
			if not child is Node3D:
				continue
			var prop := child as Node3D
			if car_id == "baggage" and ("FreightStack" in prop.name or "TravelTrunk" in prop.name):
				var prop_tween := create_tween()
				var home_z := prop.position.z
				prop_tween.tween_property(prop, "position:z", home_z + direction * (0.08 if warning else 0.22), 0.10)
				prop_tween.tween_property(prop, "position:z", home_z, 0.28)
			elif car_id == "dining" and prop.name == "DiningChandelier":
				var chandelier_tween := create_tween()
				chandelier_tween.tween_property(prop, "rotation_degrees:x", direction * (4.0 if warning else 11.0), 0.12)
				chandelier_tween.tween_property(prop, "rotation_degrees:x", 0.0, 0.40)
			elif car_id == "engine" and prop.name == "RedlineGauge":
				var gauge_tween := create_tween()
				gauge_tween.tween_property(prop, "rotation_degrees:z", -16.0 if warning else 24.0, 0.12)
				gauge_tween.tween_property(prop, "rotation_degrees:z", 0.0, 0.40)
			elif car_id == "bar" and prop.name == "BackbarBottle":
				var bottle_tween := create_tween()
				bottle_tween.tween_property(prop, "rotation_degrees:z", direction * (8.0 if warning else 22.0), 0.10)
				bottle_tween.tween_property(prop, "rotation_degrees:z", 0.0, 0.30)
			elif car_id == "crew" and prop.name == "CrewLocker":
				var locker_tween := create_tween()
				locker_tween.tween_property(prop, "rotation_degrees:y", 90.0 + direction * (4.0 if warning else 12.0), 0.10)
				locker_tween.tween_property(prop, "rotation_degrees:y", 90.0, 0.30)
			elif car_id == "armory" and prop.name == "AmmoPress":
				var press_tween := create_tween()
				var press_home_x := prop.position.x
				press_tween.tween_property(prop, "position:x", press_home_x + direction * (0.10 if warning else 0.32), 0.10)
				press_tween.tween_property(prop, "position:x", press_home_x, 0.30)
			elif car_id == "observation" and prop.name == "StormShutter":
				var shutter_tween := create_tween()
				var shutter_home_y := float(prop.get_meta("raised_y", prop.position.y))
				var shutter_target_y := shutter_home_y - (0.20 if warning else (1.10 if countered else 0.38))
				shutter_tween.tween_property(prop, "position:y", shutter_target_y, 0.24)
				if not countered:
					shutter_tween.tween_property(prop, "position:y", shutter_home_y, 0.34)
			elif car_id == "cargo" and (prop.name == "FreightStack" or prop.name == "CargoBrakeWheel"):
				var cargo_tween := create_tween()
				cargo_tween.tween_property(prop, "rotation_degrees:z", direction * (6.0 if warning else 18.0), 0.10)
				cargo_tween.tween_property(prop, "rotation_degrees:z", 0.0, 0.34)
			elif car_id == "casino" and prop.name == "CasinoTimingWheel":
				var wheel_tween := create_tween()
				wheel_tween.tween_property(prop, "rotation_degrees:y", prop.rotation_degrees.y + (55.0 if warning else 160.0), 0.34)


func _clear_train_event_visuals() -> void:
	if not is_instance_valid(_train_event_root):
		return
	for child in _train_event_root.get_children():
		_train_event_root.remove_child(child)
		child.queue_free()


func _build_tactical_cover_props(car_id: String) -> void:
	# The blocker map is the authority for pathing, line of sight, and cover math.
	# Every blocker now receives a matching visible, themed prop at the same cell.
	var ordered_cells: Array[Vector2i] = []
	for cell in board.blocked_cells:
		ordered_cells.append(cell)
	ordered_cells.sort_custom(func(a: Vector2i, b: Vector2i) -> bool:
		return a.x < b.x or (a.x == b.x and a.y < b.y)
	)
	for index in range(ordered_cells.size()):
		_build_tactical_cover_prop(car_id, ordered_cells[index], index)


func _build_tactical_cover_prop(car_id: String, cell: Vector2i, index: int) -> void:
	var prop := Node3D.new()
	prop.name = "CoverProp_%02d_%02d" % [cell.x, cell.y]
	prop.position = board.cell_to_world(cell)
	prop.set_meta("grid_cell", cell)
	prop.set_meta("car_id", car_id)
	prop.set_meta("functional_cover", true)
	_tactical_cover_root.add_child(prop)

	var width := GridBoard.CELL_SIZE_X * 0.76
	var depth := GridBoard.CELL_SIZE_Z * 0.70
	var height := 0.78
	match car_id:
		"baggage":
			height = 0.66
			_cover_trunk(prop, width, depth, height, index)
		"cargo":
			height = 0.82
			_cover_beveled(prop, Vector3(width, height, depth), Vector3(0,height*0.5,0), _wood_dark, 0.04)
			for plank in range(5):
				_cover_box(prop,Vector3(width*0.97,height*0.155,0.018),Vector3(0,0.09+plank*height*0.19,depth*0.51),_wood)
			for rail_x in [-width*0.37,width*0.37]:
				_cover_box(prop,Vector3(0.065,height*0.98,depth*1.015),Vector3(rail_x,height*0.5,0),_iron_edge)
			_cover_strut(prop,Vector3(-width*0.40,0.13,depth*0.535),Vector3(width*0.40,height-0.13,depth*0.535),0.028,_aged_brass)
		"dining":
			height = 0.73
			_cover_beveled(prop,Vector3(width,0.075,depth),Vector3(0,height,0),_wood,0.025)
			_cover_box(prop,Vector3(width*0.29,0.012,depth*0.98),Vector3(0,height+0.044,0),_material(Color("#b7aa8f"),0,0.98))
			for leg_x in [-width*0.37,width*0.37]:
				for leg_z in [-depth*0.35,depth*0.35]:
					_cover_cylinder(prop,0.033,height-0.07,Vector3(leg_x,(height-0.07)*0.5,leg_z),_wood_dark)
					_cover_cylinder(prop,0.041,0.13,Vector3(leg_x,0.07,leg_z),_aged_brass)
			_cover_box(prop,Vector3(width*0.82,0.09,depth*0.80),Vector3(0,height-0.085,0),_wood_dark)
			prop.set_meta("furniture_kind", "dining_table")
			_cover_cylinder(prop,0.057,0.025,Vector3(0,height+0.068,-depth*0.23),_aged_brass)
			_cover_cylinder(prop,0.018,0.13,Vector3(0,height+0.145,-depth*0.23),_brass)
			var shade := _cover_cylinder(prop,0.072,0.095,Vector3(0,height+0.22,-depth*0.23),_material(Color("#d3b575"),0,0.9))
			(shade.mesh as CylinderMesh).top_radius=0.045
			_cover_cylinder(prop,0.024,0.015,Vector3(0,height+0.274,-depth*0.23),_aged_brass)
			for plate_x in [-width * 0.24, width * 0.24]:
				var china:=_material(Color("#cec4aa"),0,0.72)
				_cover_cylinder(prop,0.098,0.016,Vector3(plate_x,height+0.048,depth*0.12),_aged_brass)
				_cover_cylinder(prop,0.087,0.013,Vector3(plate_x,height+0.061,depth*0.12),china)
				_cover_box(prop,Vector3(0.012,0.01,0.13),Vector3(plate_x+0.118,height+0.049,depth*0.12),_iron_edge)
				_cover_cylinder(prop,0.026,0.055,Vector3(plate_x,height+0.072,-depth*0.26),china)
		"bar":
			height = 0.86
			_cover_box(prop, Vector3(width, height, depth), Vector3(0.0, height * 0.5, 0.0), _wood_dark)
			_cover_box(prop, Vector3(width * 1.10, 0.11, depth * 1.08), Vector3(0.0, height + 0.055, 0.0), _brass)
			_cover_box(prop, Vector3(width * 0.78, 0.16, 0.04), Vector3(0.0, height * 0.55, depth * 0.51), _vault_panel)
		"casino":
			height = 0.70
			var table_radius := minf(width,depth)*0.52
			_cover_cylinder(prop, table_radius, 0.18, Vector3(0.0, height, 0.0), _wood_dark)
			_cover_cylinder(prop, table_radius*0.90, 0.035, Vector3(0.0, height + 0.11, 0.0), _vault_panel)
			_cover_cylinder(prop, 0.10, height, Vector3(0.0, height * 0.50, 0.0), _aged_brass)
		"crew", "sleeper":
			height = 0.94
			_cover_locker(prop,width,depth,height,false,car_id=="sleeper")
		"armory":
			height = 0.92
			_cover_locker(prop,width,depth,height,true,false)
		"engine":
			height = 0.90
			_cover_cylinder(prop, depth * 0.34, width * 0.94, Vector3(0.0, height * 0.52, 0.0), _boiler_panel, Vector3(0.0, 0.0, 90.0))
			_cover_box(prop, Vector3(width * 0.92, 0.16, depth * 0.88), Vector3(0.0, 0.12, 0.0), _iron_edge)
			_cover_box(prop, Vector3(0.10, height * 0.90, depth * 1.04), Vector3(0.0, height * 0.50, 0.0), _brass)
		"observation":
			height = 0.70
			_cover_box(prop, Vector3(width, 0.28, depth), Vector3(0.0, 0.30, 0.0), _wood_dark)
			_cover_box(prop, Vector3(width, 0.52, 0.15), Vector3(0.0, 0.58, -depth * 0.43), _crew_panel)
		_:
			_cover_box(prop, Vector3(width, height, depth), Vector3(0.0, height * 0.5, 0.0), _iron_edge)

	if car_id == "cargo":
		# Handles and hinges distinguish a usable trunk/locker from a solid cube.
		_cover_box(prop, Vector3(width * 0.30, 0.035, 0.07), Vector3(0, height * 0.56, depth * 0.54), _aged_brass)
		for handle_x in [-width * 0.15, width * 0.15]:
			_cover_box(prop, Vector3(0.035, 0.11, 0.08), Vector3(handle_x, height * 0.61, depth * 0.54), _brass)
		for hinge_x in [-width * 0.30, width * 0.30]:
			_cover_box(prop, Vector3(0.09, 0.13, 0.025), Vector3(hinge_x, height * 0.86, -depth * 0.51), _aged_brass)
	# A subtle riveted brass maker's plate replaces the old luminous cyan diamond.
	# Cover remains legible through the furniture silhouette and inspector readout.
	var badge_y := height-0.075 if car_id == "dining" else maxf(0.46,height*0.60)
	var badge := _cover_box(prop, Vector3(0.21, 0.048, 0.024), Vector3(0.0, badge_y, depth * (0.405 if car_id == "dining" else 0.535)), _cover_badge_material)
	badge.name = "CoverBadge"
	badge.set_meta("cover_badge", true)
	for rivet_x in [-0.085, 0.085]:
		var rivet := MeshInstance3D.new()
		var rivet_mesh := SphereMesh.new()
		rivet_mesh.radius = 0.009
		rivet_mesh.height = 0.018
		rivet.mesh = rivet_mesh
		rivet.position = badge.position+Vector3(rivet_x,0,0.016)
		rivet.material_override = _brass
		prop.add_child(rivet)
	prop.set_meta("cover_style_index", index)
	prop.set_meta("silhouette_version", 2)


func _cover_trunk(parent: Node3D, width: float, depth: float, height: float, index: int) -> void:
	var leather:=_material(Color("#5c3a2b") if index%2==0 else Color("#3d5048"),0.02,0.86)
	_cover_beveled(parent,Vector3(width,height*0.73,depth),Vector3(0,height*0.365,0),leather,0.045)
	_cover_beveled(parent,Vector3(width*1.015,height*0.27,depth*1.015),Vector3(0,height*0.865,0),leather,0.045)
	_cover_box(parent,Vector3(width*0.94,0.018,depth*1.015),Vector3(0,height*0.735,0),_aged_brass)
	for strap_x in [-width*0.30,width*0.30]:
		_cover_box(parent,Vector3(0.063,height*0.90,depth*1.035),Vector3(strap_x,height*0.50,0),_wood_dark)
		_cover_box(parent,Vector3(0.075,0.018,depth*0.92),Vector3(strap_x,height+0.006,0),_wood_dark)
		_cover_beveled(parent,Vector3(0.092,0.11,0.023),Vector3(strap_x,height*0.72,depth*0.527),_aged_brass,0.008)
		_cover_box(parent,Vector3(0.046,0.066,0.027),Vector3(strap_x,height*0.72,depth*0.548),_wood_dark)
	for x in [-1,1]:
		for z in [-1,1]:
			_cover_beveled(parent,Vector3(0.10,0.12,0.10),Vector3(x*(width*0.5-0.036),0.073,z*(depth*0.5-0.036)),_aged_brass,0.012)
	_cover_strut(parent,Vector3(-0.10,height*0.57,depth*0.55),Vector3(0.10,height*0.57,depth*0.55),0.019,_wood_dark)
	for x in [-0.10,0.10]:
		_cover_box(parent,Vector3(0.026,0.07,0.025),Vector3(x,height*0.61,depth*0.54),_aged_brass)
	var tag:=_cover_box(parent,Vector3(0.10,0.12,0.006),Vector3(width*0.40,height*0.55,depth*0.54),_material(Color("#c8b38b"),0,0.98))
	tag.rotation_degrees.z=-12
	parent.set_meta("furniture_kind","leather_trunk")


func _cover_locker(parent: Node3D, width: float, depth: float, height: float, armored: bool, timber: bool) -> void:
	var paint:=_vault_panel if armored else (_wood_dark if timber else _crew_panel)
	_cover_beveled(parent,Vector3(width,height,depth),Vector3(0,height*0.5,0),_iron_edge,0.045)
	for x in [-1,1]:
		var panel_x:float=x*width*0.238
		_cover_beveled(parent,Vector3(width*0.455,height*0.86,0.035),Vector3(panel_x,height*0.52,depth*0.505),paint,0.014)
		for vent in range(3):
			_cover_box(parent,Vector3(width*0.26,0.012,0.013),Vector3(panel_x,height*0.77-vent*0.037,depth*0.54),_wood_dark)
		_cover_cylinder(parent,0.015,0.095,Vector3(x*width*0.075,height*0.53,depth*0.56),_aged_brass)
		for hinge_y in [height*0.22,height*0.76]:
			_cover_cylinder(parent,0.021,0.075,Vector3(x*width*0.46,hinge_y,depth*0.53),_aged_brass)
	if armored:
		_cover_beveled(parent,Vector3(width*0.35,0.16,0.028),Vector3(0,height*0.29,depth*0.56),_iron_edge,0.015)
		_cover_cylinder(parent,0.040,0.05,Vector3(0,height*0.29,depth*0.595),_brass,Vector3(90,0,0))
		for x in [-1,1]:
			for y in [0.10,height-0.10]:
				_cover_cylinder(parent,0.018,0.022,Vector3(x*width*0.40,y,depth*0.523),_aged_brass,Vector3(90,0,0))
	parent.set_meta("furniture_kind","armored_locker" if armored else "crew_locker")


func _cover_beveled(parent: Node3D, size: Vector3, at: Vector3, material: Material, bevel: float) -> MeshInstance3D:
	# Octagonal footprint with bevelled top/bottom: readable edges, no oversized collider.
	var b:=minf(bevel,minf(size.x,minf(size.y,size.z))*0.4)
	var outline:Array[Vector2]=[Vector2(-size.x/2+b,-size.z/2),Vector2(size.x/2-b,-size.z/2),Vector2(size.x/2,-size.z/2+b),Vector2(size.x/2,size.z/2-b),Vector2(size.x/2-b,size.z/2),Vector2(-size.x/2+b,size.z/2),Vector2(-size.x/2,size.z/2-b),Vector2(-size.x/2,-size.z/2+b)]
	var surface:=SurfaceTool.new();surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rings:Array[PackedVector3Array]=[]
	for ring in range(4):
		var points:=PackedVector3Array()
		var y:float=[-size.y/2,-size.y/2+b,size.y/2-b,size.y/2][ring]
		for point in outline:
			var inset:=b*0.55 if ring in [0,3] else 0.0
			points.append(Vector3(point.x-signf(point.x)*inset,y,point.y-signf(point.y)*inset))
		rings.append(points)
	for ring in range(3):
		for edge in range(8):
			var next:=(edge+1)%8
			for vertex in [rings[ring][edge],rings[ring+1][edge],rings[ring+1][next],rings[ring][edge],rings[ring+1][next],rings[ring][next]]:surface.add_vertex(vertex)
	for edge in range(8):
		var next:=(edge+1)%8
		for vertex in [Vector3(0,size.y/2,0),rings[3][next],rings[3][edge],Vector3(0,-size.y/2,0),rings[0][edge],rings[0][next]]:surface.add_vertex(vertex)
	surface.generate_normals()
	var instance:=MeshInstance3D.new();instance.mesh=surface.commit();instance.position=at;instance.material_override=material;parent.add_child(instance)
	return instance


func _cover_strut(parent: Node3D, from: Vector3, to: Vector3, radius: float, material: Material) -> MeshInstance3D:
	var piece:=_cover_cylinder(parent,radius,from.distance_to(to),(from+to)*0.5,material)
	piece.quaternion=Quaternion(Vector3.UP,(to-from).normalized())
	return piece


func _cover_box(parent: Node3D, size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	parent.add_child(instance)
	return instance


func _cover_cylinder(parent: Node3D, radius: float, height: float, at: Vector3, material: Material, rotation_value: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 20
	instance.mesh = mesh
	instance.position = at
	instance.rotation_degrees = rotation_value
	instance.material_override = material
	parent.add_child(instance)
	return instance


func _build_active_car_shell(car_id: String, accent_material: Material) -> void:
	var shell_material: Material = _iron
	var underframe := "train/train-carriage-flatbed.glb"
	if car_id == "baggage":
		shell_material = _carriage_panel
		underframe = "train/train-carriage-flatbed-wood.glb"
	elif car_id in ["dining", "bar", "casino", "sleeper"]:
		shell_material = _wood_dark
		underframe = "train/train-carriage-flatbed-wood.glb"
	elif car_id == "crew":
		shell_material = _crew_panel
	elif car_id == "engine":
		shell_material = _boiler_panel
	elif car_id == "armory":
		shell_material = _vault_panel

	# One continuous rolling-stock silhouette replaces the old three-room diorama.
	_dynamic_place(underframe, Vector3(0.0, -0.70, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(6.2, 0.54, 10.25), "ActiveCarUnderframe")
	var length := 30.0
	_dynamic_box(Vector3(length, 0.86, 0.22), Vector3(0.0, 0.44, -3.84), shell_material)
	_dynamic_box(Vector3(length, 0.42, 0.22), Vector3(0.0, 2.66, -3.84), shell_material)
	_dynamic_box(Vector3(length, 0.11, 0.28), Vector3(0.0, 0.93, -3.82), _aged_brass)
	_dynamic_box(Vector3(length, 0.11, 0.30), Vector3(0.0, 2.39, -3.82), accent_material)
	_dynamic_box(Vector3(length, 0.46, 0.22), Vector3(0.0, 0.26, 3.84), shell_material)
	_dynamic_box(Vector3(length, 0.11, 0.28), Vector3(0.0, 0.78, 3.82), _aged_brass)

	# Solid end caps make the visible space read as one bounded carriage.
	for end_x in [-14.92, 14.92]:
		_dynamic_box(Vector3(0.28, 2.82, 2.72), Vector3(end_x, 1.41, -2.36), shell_material)
		_dynamic_box(Vector3(0.28, 0.84, 2.72), Vector3(end_x, 0.42, 2.36), shell_material)
		_dynamic_box(Vector3(0.34, 0.46, 1.72), Vector3(end_x, 2.60, 0.0), _iron_edge)
		_dynamic_box(Vector3(0.36, 2.68, 0.15), Vector3(end_x, 1.34, -0.92), _brass)

	if car_id == "engine":
		_build_porthole_windows(accent_material)
	elif car_id == "armory":
		_build_armored_windows(accent_material)
	else:
		_build_passenger_windows(car_id, accent_material)

	var rib_spacing := 3.72 if car_id == "observation" else 4.95
	var rib_x := -14.75
	while rib_x <= 14.76:
		_dynamic_box(Vector3(0.16, 1.72, 0.16), Vector3(rib_x, 1.67, -3.72), _brass)
		# The cut roof ends at the far wall; full spans obscured the crew below.
		_dynamic_box(Vector3(0.16, 0.15, 0.52), Vector3(rib_x, 2.92, -3.47), _aged_brass)
		rib_x += rib_spacing

	if car_id == "baggage":
		_build_baggage_hero_architecture(accent_material)

	if car_id == "observation":
		for roof_x in [-12.9, -9.2, -5.5, -1.8, 1.9, 5.6, 9.3, 13.0]:
			var roof_glass := _dynamic_box(Vector3(3.38, 0.05, 0.48), Vector3(roof_x, 2.91, -3.47), _glass)
			roof_glass.rotation_degrees.z = 0.0


func _build_baggage_hero_architecture(accent_material: Material) -> void:
	# The first encounter is the visual sales pitch: a plated railcar, not a room
	# full of unrelated boxes. These overlays keep the tactical footprint intact.
	for x in [-12.3, -7.4, -2.5, 2.4, 7.3, 12.2]:
		var lower_panel := _dynamic_box(Vector3(4.42, 0.66, 0.055), Vector3(x, 0.54, -3.965), _carriage_panel)
		lower_panel.name = "BaggageRivetedPanel"
		_dynamic_box(Vector3(4.48, 0.075, 0.085), Vector3(x, 0.91, -3.94), _aged_brass).name = "BaggagePanelSill"
		for edge_x in [x - 2.22, x + 2.22]:
			_dynamic_box(Vector3(0.095, 0.82, 0.10), Vector3(edge_x, 0.55, -3.94), _brass).name = "BaggagePanelRivetStrip"

	# A sliding freight door, track and handwheel make the boarding car legible
	# even before a player reads a single label.
	var door_x := 10.2
	_dynamic_box(Vector3(3.72, 1.48, 0.075), Vector3(door_x, 1.60, -3.975), _carriage_panel).name = "BaggageFreightDoor"
	_dynamic_box(Vector3(4.28, 0.13, 0.16), Vector3(door_x, 2.42, -3.91), _iron_edge).name = "BaggageDoorTrack"
	_dynamic_box(Vector3(0.10, 1.52, 0.13), Vector3(door_x - 1.76, 1.60, -3.91), _brass).name = "BaggageDoorRail"
	_dynamic_box(Vector3(0.10, 1.52, 0.13), Vector3(door_x + 1.76, 1.60, -3.91), _brass).name = "BaggageDoorRail"
	var wheel := _dynamic_torus(0.18, 0.26, Vector3(door_x + 1.15, 1.35, -3.87), accent_material)
	wheel.name = "BaggageDoorHandwheel"
	wheel.rotation_degrees.x = 90.0
	_dynamic_box(Vector3(0.10, 0.84, 0.10), Vector3(door_x + 1.15, 1.35, -3.84), _aged_brass)

	# Repeating overhead rails and warm work lamps make cargo stacks feel mounted
	# within a carriage instead of sitting on a featureless board.
	for x in [-10.2, -4.0, 2.2, 8.4]:
		_dynamic_box(Vector3(0.12, 0.12, 0.40), Vector3(x, 2.62, -3.48), _iron_edge).name = "BaggageCeilingRail"
		var hook := _dynamic_torus(0.08, 0.14, Vector3(x, 2.30, -3.39), accent_material)
		hook.name = "BaggageLuggageHook"
		hook.rotation_degrees.x = 90.0

	for lamp_x in [-7.2, 5.8]:
		var cage := _dynamic_torus(0.15, 0.23, Vector3(lamp_x, 2.22, -3.78), _aged_brass)
		cage.name = "BaggageWorkLampCage"
		cage.rotation_degrees.x = 90.0
		var lamp := _dynamic_sphere(0.10, Vector3(lamp_x, 2.22, -3.75), _lamp_material)
		lamp.name = "BaggageWorkLamp"
		lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _build_passenger_windows(car_id: String, accent_material: Material) -> void:
	var pane_width := 3.34 if car_id == "observation" else 2.80
	var pane_height := 1.35 if car_id == "observation" else 1.16
	var window_y := 1.65
	for x in [-12.0, -8.0, -4.0, 0.0, 4.0, 8.0, 12.0]:
		var pane := _dynamic_box(Vector3(pane_width, pane_height, 0.055), Vector3(x, window_y, -3.91), _glass)
		pane.name = "PassengerWindow"
		_dynamic_box(Vector3(pane_width - 0.12, 0.08, 0.27), Vector3(x, 1.02, -3.80), accent_material)
		for edge_x in [x - pane_width * 0.52, x + pane_width * 0.52]:
			_dynamic_box(Vector3(0.14, pane_height + 0.28, 0.26), Vector3(edge_x, window_y, -3.83), _iron_edge)
		if car_id in ["dining", "bar", "casino", "sleeper"]:
			_dynamic_box(Vector3(0.08, pane_height, 0.08), Vector3(x, window_y, -3.76), _brass)


func _build_armored_windows(accent_material: Material) -> void:
	for x in [-12.0, -8.0, -4.0, 0.0, 4.0, 8.0, 12.0]:
		var slit := _dynamic_box(Vector3(2.35, 0.46, 0.055), Vector3(x, 1.72, -3.91), _glass)
		slit.name = "ArmoredWindowSlit"
		_dynamic_box(Vector3(2.72, 0.12, 0.30), Vector3(x, 1.42, -3.82), accent_material)
		_dynamic_box(Vector3(2.72, 0.12, 0.30), Vector3(x, 2.02, -3.82), _iron_edge)
		for edge_x in [x - 1.36, x + 1.36]:
			_dynamic_box(Vector3(0.15, 0.74, 0.30), Vector3(edge_x, 1.72, -3.82), _iron_edge)


func _build_porthole_windows(accent_material: Material) -> void:
	for x in [-11.8, -7.9, -4.0, 0.0, 4.0, 7.9, 11.8]:
		var pane := _dynamic_cylinder(0.48, 0.055, Vector3(x, 1.72, -3.91), _glass)
		pane.name = "EnginePorthole"
		pane.rotation_degrees.x = 90.0
		var ring := _dynamic_torus(0.43, 0.56, Vector3(x, 1.72, -3.76), accent_material)
		ring.rotation_degrees.x = 90.0


func _build_baggage_car(accent_material: Material) -> void:
	for data in [[-11.6, -2.70, 8.0], [-7.8, 2.76, -14.0], [-3.8, -2.76, 11.0], [5.7, 2.72, -8.0], [10.8, -2.70, 17.0]]:
		_dynamic_place("factory/box-large.glb", Vector3(float(data[0]), 0.08, float(data[1])), Vector3(0.0, float(data[2]), 0.0), Vector3(0.90, 0.92, 0.90), "FreightStack")
	for x in [-9.8, -1.2, 7.6]:
		_dynamic_box(Vector3(3.4, 0.13, 0.72), Vector3(x, 1.90, -2.92), _wood)
		_dynamic_box(Vector3(3.5, 0.08, 0.82), Vector3(x, 2.06, -2.92), accent_material)
	for x in [-5.7, 2.8, 12.4]:
		_dynamic_place("factory/box-wide.glb", Vector3(x, 0.08, -2.62), Vector3(0.0, 90.0, 0.0), Vector3(0.76, 0.80, 0.76), "TravelTrunk")
	# Restraint rails and deck rings make the new Lash the Freight plan literal.
	for side_z in [-2.34, 2.34]:
		_dynamic_box(Vector3(25.8, 0.08, 0.10), Vector3(0.0, 0.16, side_z), _aged_brass)
		for x in [-10.5, -5.2, 0.0, 5.2, 10.5]:
			var tie_down := _dynamic_torus(0.10, 0.15, Vector3(x, 0.24, side_z), _brass)
			tie_down.rotation_degrees.x = 90.0
	for x in [-11.6, -3.8, 5.7, 10.8]:
		var strap := _dynamic_box(Vector3(0.10, 1.22, 1.72), Vector3(x, 0.66, -2.55 if x < 0.0 else 2.55), accent_material)
		strap.name = "FreightRestraint"


func _build_cargo_car(accent_material: Material) -> void:
	var cargo_floor := _material(Color("#202423"), 0.50, 0.78)
	_dynamic_box(Vector3(27.8, 0.035, 6.70), Vector3(0.0, 0.055, 0.0), cargo_floor)
	# A fixed overhead loading gantry gives this car a tall industrial silhouette,
	# distinct from the passenger-height baggage racks.
	for gantry_x in [-10.8, 0.0, 10.8]:
		_dynamic_box(Vector3(0.20, 2.52, 0.20), Vector3(gantry_x, 1.30, -2.72), _iron_edge).name = "CargoGantryPost"
		_dynamic_box(Vector3(0.22, 0.22, 0.50), Vector3(gantry_x, 2.52, -3.45), _brass).name = "CargoGantryBeam"
	for hook_x in [-7.2, -2.6, 3.4, 8.4]:
		_dynamic_cylinder(0.035, 0.82, Vector3(hook_x, 2.04, 1.92 if hook_x > 0.0 else -1.92), _aged_brass).name = "CargoChain"
		var hook := _dynamic_torus(0.11, 0.17, Vector3(hook_x, 1.62, 1.92 if hook_x > 0.0 else -1.92), accent_material)
		hook.name = "CargoHook"
		hook.rotation_degrees.x = 90.0
	# Palletized machinery, caged contraband, and loader parts replace luggage.
	for data in [[-11.7, -2.30, 0.96], [-7.7, 2.26, 0.82], [-2.8, -2.24, 1.04], [4.8, 2.26, 0.90], [9.5, -2.24, 1.08]]:
		var x := float(data[0]); var z := float(data[1]); var scale_value := float(data[2])
		_dynamic_box(Vector3(3.10, 0.12, 1.78), Vector3(x, 0.14, z), _aged_brass).name = "CargoPallet"
		_dynamic_place("factory/box-large.glb", Vector3(x, 0.20, z), Vector3(0.0, 90.0, 0.0), Vector3(scale_value, scale_value, scale_value), "IndustrialFreight")
		for cage_x in [x - 1.35, x + 1.35]:
			_dynamic_box(Vector3(0.07, 1.22, 0.07), Vector3(cage_x, 0.72, z - 0.72), _brass).name = "CargoCage"
			_dynamic_box(Vector3(0.07, 1.22, 0.07), Vector3(cage_x, 0.72, z + 0.72), _brass).name = "CargoCage"
	_dynamic_place("factory/machine-fortified.glb", Vector3(12.1, 0.10, 2.18), Vector3(0.0, -90.0, 0.0), Vector3(0.82, 0.82, 0.82), "HeavyLoaderRig")
	for x in [-12.4, -4.2, 4.0, 12.2]:
		_dynamic_box(Vector3(0.65, 0.045, 1.90), Vector3(x, 0.085, 0.0), accent_material).name = "CargoFloorGuide"


func _build_dining_car(_accent_material: Material) -> void:
	# All tables are created from blocked cells in _build_tactical_cover_prop.
	# Wall shelves supply the galley character without occupying walking lanes.
	for x in [-10.8, -5.4, 0.0, 5.4, 10.8]:
		_dynamic_box(Vector3(2.40, 0.08, 0.18), Vector3(x, 1.16, -3.60), _aged_brass)
	_dynamic_place("factory/screen-panel-wide.glb", Vector3(12.7, 0.08, 2.75), Vector3(0.0, 180.0, 0.0), Vector3(0.76, 0.82, 0.76), "GalleyOrders")
	_dynamic_place("factory/box-long.glb", Vector3(12.7, 0.08, -2.72), Vector3(0.0, 90.0, 0.0), Vector3(0.82, 0.86, 0.82), "GalleySideboard")
	var chandelier := Node3D.new()
	chandelier.name = "DiningChandelier"
	chandelier.position = Vector3(0.0, 2.45, -0.95)
	_active_dressing.add_child(chandelier)
	_overhead_dressing.append(chandelier)
	_cover_cylinder(chandelier, 0.035, 0.78, Vector3(0.0, 0.32, 0.0), _aged_brass)
	var crown := MeshInstance3D.new()
	var crown_mesh := TorusMesh.new()
	crown_mesh.inner_radius = 0.78; crown_mesh.outer_radius = 0.89; crown_mesh.rings = 28; crown_mesh.ring_segments = 12
	crown.mesh = crown_mesh; crown.rotation_degrees.x = 90.0; crown.material_override = _brass; chandelier.add_child(crown)
	for spoke_angle in range(0, 360, 45):
		var radians := deg_to_rad(float(spoke_angle))
		var lamp := MeshInstance3D.new(); var lamp_mesh := SphereMesh.new(); lamp_mesh.radius = 0.105; lamp_mesh.height = 0.21
		lamp.mesh = lamp_mesh; lamp.position = Vector3(cos(radians) * 0.84, -0.04, sin(radians) * 0.84); lamp.material_override = _lamp_material; chandelier.add_child(lamp)
	var cart := Node3D.new()
	cart.name = "DiningServiceCart"
	cart.position = Vector3(-1.8, 0.0, -3.58)
	cart.scale = Vector3(0.78, 1.0, 0.30)
	_active_dressing.add_child(cart)
	_cover_box(cart, Vector3(1.55, 0.13, 0.76), Vector3(0.0, 0.72, 0.0), _wood)
	_cover_box(cart, Vector3(1.48, 0.08, 0.70), Vector3(0.0, 0.32, 0.0), _aged_brass)
	for wheel_x in [-0.56, 0.56]:
		for wheel_z in [-0.26, 0.26]:
			var wheel := MeshInstance3D.new(); var wheel_mesh := CylinderMesh.new(); wheel_mesh.top_radius = 0.12; wheel_mesh.bottom_radius = 0.12; wheel_mesh.height = 0.07
			wheel.mesh = wheel_mesh; wheel.position = Vector3(wheel_x, 0.14, wheel_z); wheel.rotation_degrees.x = 90.0; wheel.material_override = _iron_edge; cart.add_child(wheel)


func _build_bar_car(accent_material: Material) -> void:
	_dynamic_box(Vector3(18.4, 0.90, 0.72), Vector3(3.1, 0.46, -2.68), _wood_dark)
	_dynamic_box(Vector3(18.7, 0.13, 0.92), Vector3(3.1, 0.96, -2.68), _brass)
	_dynamic_box(Vector3(18.0, 1.34, 0.12), Vector3(3.1, 1.70, -3.28), _wood_dark)
	for x in [-5.2, -3.7, -2.2, -0.7, 0.8, 2.3, 3.8, 5.3, 6.8, 8.3, 9.8, 11.3]:
		var bottle := _dynamic_cylinder(0.07, 0.35 + float(posmod(roundi(x * 10.0), 3)) * 0.06, Vector3(x, 1.32, -3.12), accent_material)
		bottle.name = "BackbarBottle"
	for x in [-5.5, -1.8, 1.9, 5.6, 9.3]:
		_dynamic_cylinder(0.34, 0.10, Vector3(x, 0.52, -1.34), _wood)
		_dynamic_cylinder(0.09, 0.48, Vector3(x, 0.26, -1.34), _aged_brass)
	for x in [-11.0, -7.4]:
		_dynamic_cylinder(0.90, 0.12, Vector3(x, 0.74, 1.20), _wood_dark)
		_dynamic_cylinder(0.12, 0.68, Vector3(x, 0.38, 1.20), _aged_brass)


func _build_casino_car(accent_material: Material) -> void:
	var felt := _material(Color("#421d43"), 0.10, 0.90)
	var felt_dark := _material(Color("#241326"), 0.08, 0.94)
	_dynamic_box(Vector3(27.8, 0.035, 6.70), Vector3(0.0, 0.055, 0.0), felt_dark)
	_dynamic_box(Vector3(26.2, 0.018, 2.20), Vector3(0.0, 0.082, 0.0), felt)
	# Cashier cage and strongbox establish the secured money end of the room.
	_dynamic_box(Vector3(7.2, 0.82, 0.72), Vector3(9.5, 0.43, -2.64), _wood_dark).name = "CasinoCashierDesk"
	_dynamic_box(Vector3(7.4, 0.11, 0.90), Vector3(9.5, 0.88, -2.64), _brass).name = "CasinoCashierRail"
	for x in [6.3, 7.35, 8.4, 9.45, 10.5, 11.55, 12.6]:
		_dynamic_box(Vector3(0.055, 1.42, 0.055), Vector3(x, 1.58, -3.02), _aged_brass).name = "CashierCageBar"
	_dynamic_box(Vector3(2.10, 1.48, 0.24), Vector3(12.0, 1.30, -3.12), _vault_panel).name = "CasinoStrongbox"
	var safe_ring := _dynamic_torus(0.27, 0.36, Vector3(12.0, 1.30, -2.96), accent_material)
	safe_ring.name = "CasinoSafeWheel"
	safe_ring.rotation_degrees.x = 90.0
	# Four dedicated gaming tables replace the Bar's long counter and booths.
	for data in [[-9.8, -1.52], [-4.0, 1.52], [2.4, -1.52], [8.0, 1.52]]:
		var x := float(data[0]); var z := float(data[1])
		_dynamic_cylinder(1.06, 0.18, Vector3(x, 0.74, z), _wood_dark).name = "CasinoGamingTable"
		_dynamic_cylinder(0.96, 0.035, Vector3(x, 0.86, z), felt).name = "CasinoFelt"
		_dynamic_cylinder(0.12, 0.70, Vector3(x, 0.38, z), _aged_brass).name = "CasinoTablePedestal"
		for angle in range(0, 360, 90):
			var radians := deg_to_rad(float(angle))
			_dynamic_cylinder(0.11, 0.25, Vector3(x + cos(radians) * 1.34, 0.24, z + sin(radians) * 1.34), _wood).name = "CasinoStool"
		for chip_offset in [-0.26, 0.0, 0.26]:
			_dynamic_cylinder(0.09, 0.08, Vector3(x + chip_offset, 0.93, z), accent_material).name = "ChipStack"
	# A low brass chandelier makes the gaming floor read immediately in the cutaway.
	var chandelier := Node3D.new()
	chandelier.name = "CasinoChandelier"
	chandelier.position = Vector3(-1.0, 2.62, 0.0)
	_active_dressing.add_child(chandelier)
	_overhead_dressing.append(chandelier)
	var crown := MeshInstance3D.new(); var crown_mesh := TorusMesh.new()
	crown_mesh.inner_radius = 0.72; crown_mesh.outer_radius = 0.84; crown_mesh.rings = 24; crown_mesh.ring_segments = 10
	crown.mesh = crown_mesh; crown.material_override = _brass; chandelier.add_child(crown)
	for angle in range(0, 360, 60):
		var radians := deg_to_rad(float(angle))
		var lamp := MeshInstance3D.new(); var lamp_mesh := SphereMesh.new(); lamp_mesh.radius = 0.10; lamp_mesh.height = 0.20
		lamp.mesh = lamp_mesh; lamp.position = Vector3(cos(radians) * 0.78, -0.10, sin(radians) * 0.78); lamp.material_override = _lamp_material; chandelier.add_child(lamp)


func _build_authored_control(car_id: String, accent_material: Material) -> void:
	match car_id:
		"bar":
			_dynamic_place("factory/lever-double.glb", Vector3(-10.8, 0.10, -2.08), Vector3(0.0, 180.0, 0.0), Vector3(0.72, 0.72, 0.72), "BackbarIgniter")
			_dynamic_box(Vector3(1.55, 0.08, 0.36), Vector3(-10.8, 0.12, -1.92), accent_material).name = "BackbarSpillRail"
		"crew":
			for x in [-1.0, 1.1, 3.2]:
				_dynamic_box(Vector3(0.16, 0.12, 0.42), Vector3(x, 1.12, -2.22), accent_material).name = "LockerDog"
		"armory":
			var clutch := _dynamic_place("factory/cog-e.glb", Vector3(9.8, 0.64, 1.88), Vector3(90.0, 0.0, 0.0), Vector3(0.62, 0.62, 0.62), "AmmoClutch")
			if is_instance_valid(clutch):
				_spinners.append(clutch)
			_dynamic_place("factory/lever-double.glb", Vector3(11.7, 0.10, 1.92), Vector3.ZERO, Vector3(0.76, 0.76, 0.76), "PressJamLever")
		"observation":
			for x in [-10.8, -5.4, 0.0, 5.4, 10.8]:
				var shutter := _dynamic_box(Vector3(4.38, 0.86, 0.10), Vector3(x, 2.82, -3.68), _iron_edge)
				shutter.name = "StormShutter"
				shutter.set_meta("raised_y", shutter.position.y)
				for slot_x in [-1.45, -0.48, 0.48, 1.45]:
					var slot := _dynamic_box(Vector3(0.58, 0.08, 0.04), Vector3(x + slot_x, 2.82, -3.61), accent_material)
					slot.name = "ShutterSightSlot"
		"cargo":
			var brake_wheel := _dynamic_place("factory/cog-e.glb", Vector3(-12.0, 0.92, 2.76), Vector3(90.0, 0.0, 0.0), Vector3(0.72, 0.72, 0.72), "CargoBrakeWheel")
			if is_instance_valid(brake_wheel):
				brake_wheel.set_meta("control", "independent_brake")
			_dynamic_place("factory/lever-double.glb", Vector3(-10.4, 0.10, 2.70), Vector3(0.0, 180.0, 0.0), Vector3(0.72, 0.72, 0.72), "CargoBrakeDog")
		"casino":
			var wheel := Node3D.new()
			wheel.name = "CasinoTimingWheel"
			wheel.position = Vector3(3.0, 0.78, 1.42)
			_active_dressing.add_child(wheel)
			_cover_cylinder(wheel, 0.92, 0.14, Vector3.ZERO, _wood_dark, Vector3(0.0, 0.0, 0.0))
			for angle in range(0, 360, 30):
				var radians := deg_to_rad(float(angle))
				var timing_bar := _cover_box(wheel, Vector3(0.07, 0.08, 0.72), Vector3(cos(radians) * 0.48, 0.10, sin(radians) * 0.48), accent_material)
				timing_bar.rotation_degrees.y = float(angle)


func _build_crew_run_car(_accent_material: Material) -> void:
	for x in [-11.6, -7.4, -3.2, 5.2, 9.4, 13.0]:
		_dynamic_box(Vector3(3.25, 0.16, 0.82), Vector3(x, 0.48, -2.72), _wood)
		_dynamic_box(Vector3(3.25, 0.16, 0.82), Vector3(x, 1.35, -2.72), _wood)
		_dynamic_box(Vector3(3.25, 0.56, 0.12), Vector3(x, 1.69, -3.10), _crew_panel)
	for x in [-1.0, 1.1, 3.2]:
		_dynamic_place("factory/box-long.glb", Vector3(x, 0.08, -2.70), Vector3(0.0, 90.0, 0.0), Vector3(0.72, 0.78, 0.72), "CrewLocker")
	_dynamic_place("factory/screen-hanging-wide.glb", Vector3(0.0, 1.42, -3.34), Vector3.ZERO, Vector3(1.08, 1.08, 1.08), "DutyBoard")
	_dynamic_place("factory/lever-double.glb", Vector3(-13.3, 0.08, 2.76), Vector3(0.0, 180.0, 0.0), Vector3(0.82, 0.82, 0.82), "EmergencyBrake")


func _build_armory_car(accent_material: Material) -> void:
	for x in [-11.8, -7.8, -3.8, 0.2, 4.2, 8.2, 12.2]:
		_dynamic_place("factory/box-long.glb", Vector3(x, 0.08, -2.66), Vector3(0.0, 90.0, 0.0), Vector3(0.82, 0.90, 0.82), "AmmoRack")
		_dynamic_box(Vector3(2.70, 0.08, 0.08), Vector3(x, 1.62, -3.18), accent_material)
		for bar_x in [x - 1.18, x, x + 1.18]:
			_dynamic_box(Vector3(0.055, 1.28, 0.055), Vector3(bar_x, 1.10, -3.10), _iron_edge)
	_dynamic_place("factory/machine-fortified.glb", Vector3(10.8, 0.08, 2.72), Vector3(0.0, 90.0, 0.0), Vector3(0.88, 0.88, 0.88), "AmmoPress")
	for x in [-12.8, -4.4, 4.0, 12.4]:
		_dynamic_place("factory/warning-orange.glb", Vector3(x, 0.08, 3.12), Vector3.ZERO, Vector3(0.72, 0.72, 0.72), "ArmoryWarning")


func _build_engine_car(_accent_material: Material) -> void:
	var boiler := _dynamic_cylinder(0.92, 10.8, Vector3(4.2, 1.34, -2.54), _iron)
	boiler.rotation_degrees.z = 90.0
	for x in [-0.2, 2.0, 4.2, 6.4, 8.6]:
		var band := _dynamic_cylinder(0.98, 0.15, Vector3(x, 1.34, -2.54), _aged_brass)
		band.rotation_degrees.z = 90.0
	_dynamic_box(Vector3(1.15, 0.94, 0.20), Vector3(9.72, 1.08, -1.68), _boiler_panel)
	_dynamic_box(Vector3(0.78, 0.62, 0.06), Vector3(9.72, 1.08, -1.55), _lamp_material)
	for x in [-11.8, -8.7, -5.6]:
		_dynamic_place("factory/pipe-large-junction.glb", Vector3(x, 0.08, -2.68), Vector3(0.0, 90.0, 0.0), Vector3(0.76, 0.82, 0.76), "SteamManifold")
	for x in [-9.8, -3.2, 11.8]:
		_dynamic_place("industrial/detail-tank.glb", Vector3(x, 0.08, 2.74), Vector3(0.0, 90.0, 0.0), Vector3(1.04, 1.04, 1.04), "PressureTank")
	for x in [-6.8, 0.0, 7.0]:
		var gear := _dynamic_place("factory/cog-e.glb", Vector3(x, 0.10, 3.20), Vector3.ZERO, Vector3(0.78, 0.78, 0.78), "DriveGear")
		if is_instance_valid(gear):
			_spinners.append(gear)
	for x in [-8.7, 9.7]:
		_dynamic_place("factory/pipe-large-valve.glb", Vector3(x, 0.18, -1.82), Vector3(0.0, 90.0, 0.0), Vector3(0.92, 0.92, 0.92), "RedPressureValve")
	var gauge := Node3D.new()
	gauge.name = "RedlineGauge"
	gauge.position = Vector3(9.72, 1.10, -1.49)
	_active_dressing.add_child(gauge)
	var gauge_face := MeshInstance3D.new(); var face_mesh := CylinderMesh.new(); face_mesh.top_radius = 0.27; face_mesh.bottom_radius = 0.29; face_mesh.height = 0.055
	gauge_face.mesh = face_mesh; gauge_face.rotation_degrees.x = 90.0; gauge_face.material_override = _iron_edge; gauge.add_child(gauge_face)
	var needle := MeshInstance3D.new(); var needle_mesh := BoxMesh.new(); needle_mesh.size = Vector3(0.035, 0.31, 0.035)
	needle.mesh = needle_mesh; needle.position = Vector3(0.0, 0.11, -0.05); needle.material_override = _material(Color("#c73528"), 0.52, 0.34, Color("#ff3c2f"), 1.8); gauge.add_child(needle)
	_add_dynamic_steam_column(Vector3(-8.7, 2.16, -2.58), 6)
	_add_dynamic_steam_column(Vector3(9.7, 1.72, -1.62), 5)


func _build_observation_car(_accent_material: Material) -> void:
	var carpet := _material(Color("#17383d"), 0.05, 0.84)
	_dynamic_box(Vector3(27.6, 0.025, 2.10), Vector3(0.0, 0.065, 0.0), carpet)
	for x in [-11.2, -5.6, 0.0, 5.6, 11.2]:
		_dynamic_box(Vector3(3.55, 0.20, 0.74), Vector3(x, 0.42, -2.36), _wood_dark)
		_dynamic_box(Vector3(3.55, 0.66, 0.15), Vector3(x, 0.82, -2.70), _crew_panel)
	var telescope := _dynamic_cylinder(0.18, 1.62, Vector3(10.5, 1.18, 1.92), _iron_edge)
	telescope.rotation_degrees.z = 63.0
	_dynamic_cylinder(0.12, 0.82, Vector3(10.0, 0.48, 1.92), _aged_brass)
	for x in [-8.4, 0.0, 8.4]:
		_dynamic_cylinder(0.78, 0.11, Vector3(x, 0.72, 1.28), _wood)
		_dynamic_cylinder(0.10, 0.65, Vector3(x, 0.38, 1.28), _aged_brass)


func _build_sleeper_car(accent_material: Material) -> void:
	for x in [-11.8, -7.6, -3.4, 0.8, 5.0, 9.2, 13.0]:
		_dynamic_box(Vector3(3.18, 0.17, 0.84), Vector3(x, 0.47, -2.70), _wood)
		_dynamic_box(Vector3(3.18, 0.17, 0.84), Vector3(x, 1.34, -2.70), _wood)
		_dynamic_box(Vector3(0.11, 2.05, 1.28), Vector3(x + 1.72, 1.28, -2.62), _aged_brass)
		_dynamic_box(Vector3(2.96, 1.48, 0.055), Vector3(x, 1.43, -2.10), accent_material)


func _add_dynamic_steam_column(origin: Vector3, count: int) -> void:
	for index in range(count):
		var puff := _dynamic_sphere(0.22, origin + Vector3(float(index % 3) * 0.08 - 0.08, -float(index) * 0.12, 0.0), _steam_material)
		puff.set_meta("steam_origin", origin)
		puff.set_meta("steam_speed", 0.48 + float(index % 4) * 0.08)
		puff.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_steam_puffs.append(puff)


func _dynamic_box(size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := _add_box(size, at, material)
	instance.reparent(_active_dressing, false)
	return instance


func _dynamic_cylinder(radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := _add_cylinder(radius, height, at, material)
	instance.reparent(_active_dressing, false)
	return instance


func _dynamic_torus(inner_radius: float, outer_radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := _add_torus(inner_radius, outer_radius, at, material)
	instance.reparent(_active_dressing, false)
	return instance


func _dynamic_sphere(radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := _add_sphere(radius, at, material)
	instance.reparent(_active_dressing, false)
	return instance


func _dynamic_place(path: String, at: Vector3, rotation_value: Vector3, model_scale: Vector3, instance_name: String) -> Node3D:
	var instance := _place(path, at, rotation_value, model_scale, instance_name)
	if is_instance_valid(instance):
		instance.reparent(_active_dressing, false)
	return instance


func _process(delta: float) -> void:
	_update_overhead_visibility()
	for index in range(_spinners.size()):
		if is_instance_valid(_spinners[index]):
			_spinners[index].rotate_y(delta * (0.58 + float(index) * 0.12))
	for index in range(_steam_puffs.size()):
		var puff := _steam_puffs[index]
		if not is_instance_valid(puff):
			continue
		var origin: Vector3 = puff.get_meta("steam_origin")
		var speed: float = float(puff.get_meta("steam_speed"))
		puff.position.y += delta * speed
		puff.position.x += sin(Time.get_ticks_msec() * 0.0017 + float(index)) * delta * 0.08
		var travel := puff.position.y - origin.y
		var size := 0.40 + travel * 0.24
		puff.scale = Vector3(size * 1.25, size, size)
		if travel > 2.8:
			puff.position = origin + Vector3(float(index % 3) * 0.09 - 0.09, -float(index) * 0.11, 0.0)


func _update_overhead_visibility() -> void:
	# A cutaway fixture may be attractive until it obscures a face or an injury.
	# Hide the whole overhead prop when its projection covers an active actor;
	# this responds to camera focus and movement without changing its gameplay.
	if _overhead_dressing.is_empty(): return
	var camera := get_viewport().get_camera_3d()
	if camera == null: return
	var scene := get_tree().current_scene
	if not is_instance_valid(scene): return
	var actor_rects: Array[Rect2] = []
	for child in scene.find_children("*", "CharacterBody3D", true, false):
		if not child is TacticalUnit or not child.is_visible_in_tree(): continue
		var unit := child as TacticalUnit
		if not unit.is_alive: continue
		actor_rects.append(_project_aabb(camera, AABB(unit.global_position + Vector3(-0.42, 0.45, -0.32), Vector3(0.84, 2.0, 0.64))))
	for prop in _overhead_dressing:
		if not is_instance_valid(prop): continue
		var obscures_actor := false
		for child in prop.find_children("*", "MeshInstance3D", true, false):
			var mesh := child as MeshInstance3D
			var projected := _project_aabb(camera, mesh.global_transform * mesh.get_aabb())
			for actor_rect in actor_rects:
				if projected.intersects(actor_rect): obscures_actor = true; break
			if obscures_actor: break
		prop.visible = not obscures_actor
		prop.set_meta("hidden_for_actor_readability", obscures_actor)


func _project_aabb(camera: Camera3D, bounds: AABB) -> Rect2:
	var projected := Rect2(camera.unproject_position(bounds.get_endpoint(0)), Vector2.ZERO)
	for corner in range(1, 8): projected = projected.expand(camera.unproject_position(bounds.get_endpoint(corner)))
	return projected


func _build_materials() -> void:
	_iron = _material(Color("#15191a"), 0.76, 0.48)
	_iron_edge = _material(Color("#303637"), 0.72, 0.40)
	_brass = _material(Color("#b27a32"), 0.90, 0.30)
	_aged_brass = _material(Color("#71502b"), 0.78, 0.52)
	_wood = _material(Color("#352018"), 0.08, 0.82)
	_wood_dark = _material(Color("#1c1110"), 0.05, 0.92)
	_carriage_panel = _material(Color("#344746"), 0.46, 0.74)
	_crew_panel = _material(Color("#17383a"), 0.54, 0.52)
	_boiler_panel = _material(Color("#47241a"), 0.48, 0.58)
	_vault_panel = _material(Color("#242331"), 0.68, 0.42)
	_glass = _material(Color(0.06, 0.20, 0.23, 0.40), 0.34, 0.18, Color("#174a50"), 0.35)
	_glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_lamp_material = _material(Color("#ffb651"), 0.24, 0.22, Color("#ff8c2d"), 5.0)
	_steam_material = _material(Color(0.46, 0.58, 0.57, 0.12), 0.0, 1.0, Color("#65817e"), 0.12)
	_steam_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_steam_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_cover_badge_material = _material(Color("#7a542c"), 0.88, 0.48)
	# High-frequency generated plate photographs shimmered on tiny boxes at
	# tactical zoom. Keep metal readable through broad values and real trim.
	_iron.albedo_color = Color("#2c383b"); _iron.roughness = 0.72
	_iron_edge.albedo_color = Color("#465357"); _iron_edge.roughness = 0.65
	_vault_panel.roughness = 0.72; _boiler_panel.roughness = 0.76
	# Train trim uses the same quiet painted metal as cover. The old generated
	# panel image became high-contrast black/gold noise when stretched over beams.


func _hide_graybox_cover() -> void:
	for cell in board.blocked_cells:
		board.set_cover_visual_visible(cell, false)


func _build_train_bases() -> void:
	# Real rolling-stock meshes remain below the tactical deck, providing wheels,
	# suspension, side skirts, couplers, a coal tender, and locomotive silhouette.
	_place("train/train-carriage-flatbed-wood.glb", Vector3(-10.5, -0.68, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(6.2, 0.54, 3.25), "CrewCarUnderframe")
	_place("train/train-carriage-flatbed.glb", Vector3(0.0, -0.68, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(6.2, 0.54, 3.25), "WorkshopUnderframe")
	_place("train/train-carriage-box.glb", Vector3(10.5, -0.84, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(6.0, 0.58, 3.25), "VaultUnderframe")
	_place("train/train-carriage-coal.glb", Vector3(-18.7, -0.68, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(5.8, 0.82, 3.0), "CoalTender")
	_place("train/train-locomotive-a.glb", Vector3(19.0, -0.68, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(5.35, 1.70, 3.45), "ClockworkLocomotive")
	_place("train/train-connector.glb", Vector3(-5.25, -0.57, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(3.5, 1.12, 1.8), "CrewCoupler")
	_place("train/train-connector.glb", Vector3(5.25, -0.57, 0.0), Vector3(0.0, 90.0, 0.0), Vector3(3.5, 1.12, 1.8), "VaultCoupler")


func _build_cutaway_carriages() -> void:
	_build_car_shell(-10.5, _wood, _crew_panel)
	_build_car_shell(0.0, _iron, _boiler_panel)
	_build_car_shell(10.5, _iron, _vault_panel)


func _build_car_shell(center_x: float, lower_material: Material, accent_material: Material) -> void:
	var length := 9.25
	# Far wall: a believable carriage body with an open window belt.
	_add_box(Vector3(length, 0.82, 0.20), Vector3(center_x, 0.44, -3.82), lower_material)
	_add_box(Vector3(length, 0.18, 0.22), Vector3(center_x, 2.50, -3.82), _iron_edge)
	_add_box(Vector3(length, 0.10, 0.25), Vector3(center_x, 0.92, -3.82), _aged_brass)

	for offset in [-4.45, -1.48, 1.48, 4.45]:
		_add_box(Vector3(0.20, 1.72, 0.24), Vector3(center_x + offset, 1.66, -3.82), _iron_edge)
	for offset in [-2.96, 0.0, 2.96]:
		_add_box(Vector3(2.58, 1.10, 0.05), Vector3(center_x + offset, 1.67, -3.88), _glass)
		_add_box(Vector3(2.42, 0.08, 0.28), Vector3(center_x + offset, 1.10, -3.80), accent_material)

	# Camera-side wall is deliberately cut away to keep tactical readability.
	_add_box(Vector3(length, 0.44, 0.20), Vector3(center_x, 0.25, 3.82), lower_material)
	_add_box(Vector3(length, 0.10, 0.22), Vector3(center_x, 0.78, 3.82), _aged_brass)
	for offset in [-4.45, 4.45]:
		_add_box(Vector3(0.22, 0.84, 0.24), Vector3(center_x + offset, 0.44, 3.82), _iron_edge)

	# Partial roof ribs sell the carriage volume while leaving the roof cut away.
	for offset in [-4.42, 0.0, 4.42]:
		_add_box(Vector3(0.18, 1.78, 0.18), Vector3(center_x + offset, 1.66, -3.73), _brass)
		_add_box(Vector3(0.18, 0.16, 5.30), Vector3(center_x + offset, 2.50, -1.18), _aged_brass)


func _build_bulkheads() -> void:
	for divider_x in [-5.25, 5.25]:
		# Tall far section, low near cutaway, and an overhead header leave a true
		# center gangway instead of four unrelated props at the seam.
		_add_box(Vector3(0.28, 2.62, 2.78), Vector3(divider_x, 1.31, -2.25), _iron)
		_add_box(Vector3(0.28, 0.82, 2.78), Vector3(divider_x, 0.41, 2.25), _iron)
		_add_box(Vector3(0.32, 0.42, 1.72), Vector3(divider_x, 2.40, 0.0), _iron_edge)
		_add_box(Vector3(0.36, 2.62, 0.16), Vector3(divider_x, 1.31, -0.91), _brass)
		_add_box(Vector3(0.36, 0.92, 0.16), Vector3(divider_x, 0.46, 0.91), _aged_brass)


func _build_crew_carriage() -> void:
	# Compact luggage and a route table give this car a lived-in heist staging area.
	_place_at_cell("factory/box-large.glb", Vector2i(2, 0), Vector3(0.0, 8.0, 0.0), Vector3(0.92, 0.96, 0.92))
	_place("factory/box-small.glb", _world(Vector2i(2, 0), 0.58) + Vector3(0.11, 0.0, -0.05), Vector3(0.0, -18.0, 0.0), Vector3(0.62, 0.62, 0.62), "TopKitBag")
	_place_at_cell("factory/box-long.glb", Vector2i(2, 4), Vector3(0.0, 90.0, 0.0), Vector3(0.82, 0.92, 0.82))
	_place_at_cell("factory/screen-panel-wide.glb", Vector2i(4, 1), Vector3(0.0, -28.0, 0.0), Vector3(0.78, 0.84, 0.78))
	_place("factory/screen-hanging-wide.glb", Vector3(-8.45, 1.28, -3.40), Vector3.ZERO, Vector3(1.08, 1.08, 1.08), "CrewRouteDisplay")
	_place("factory/lever-double.glb", Vector3(-12.55, 0.08, -3.16), Vector3(0.0, 18.0, 0.0), Vector3(0.82, 0.82, 0.82), "BrakeLevers")

	# Bench and planning table are deliberately simple, dark, and consistently scaled.
	_add_box(Vector3(3.0, 0.18, 0.72), Vector3(-11.15, 0.46, -2.70), _wood)
	_add_box(Vector3(3.0, 0.72, 0.14), Vector3(-11.15, 0.86, -3.02), _wood_dark)
	for x in [-12.35, -9.95]:
		_add_box(Vector3(0.12, 0.48, 0.12), Vector3(x, 0.24, -2.70), _aged_brass)
	_add_box(Vector3(1.85, 0.14, 1.02), Vector3(-7.35, 0.74, 2.48), _wood)
	for x in [-8.05, -6.65]:
		_add_box(Vector3(0.12, 0.68, 0.12), Vector3(x, 0.35, 2.48), _iron_edge)


func _build_boiler_workshop() -> void:
	_place_at_cell("factory/hopper-high-round.glb", Vector2i(8, 3), Vector3.ZERO, Vector3(0.90, 0.90, 0.90))
	_place_at_cell("factory/machine-window.glb", Vector2i(9, 1), Vector3(0.0, -12.0, 0.0), Vector3(0.86, 0.86, 0.86))
	_place_at_cell("factory/pipe-large-junction.glb", Vector2i(11, 0), Vector3(0.0, 90.0, 0.0), Vector3(0.66, 0.88, 0.66))
	_place_at_cell("factory/robot-arm-a.glb", Vector2i(11, 4), Vector3(0.0, 145.0, 0.0), Vector3(0.82, 0.82, 0.82))
	_place("industrial/detail-tank.glb", Vector3(3.45, 0.10, 3.23), Vector3(0.0, 90.0, 0.0), Vector3(1.18, 1.18, 1.18), "PressureTank")
	_place("industrial/chimney-medium.glb", Vector3(-3.65, 0.08, 3.28), Vector3.ZERO, Vector3(0.66, 0.92, 0.66), "WorkshopFlue")

	# The boiler is now the hero prop: dark iron barrel, aged brass bands, hot firebox.
	var boiler := _add_cylinder(0.78, 4.10, Vector3(0.20, 1.15, -2.62), _iron)
	boiler.rotation_degrees.z = 90.0
	for x in [-1.40, 0.20, 1.80]:
		var band := _add_cylinder(0.83, 0.13, Vector3(x, 1.15, -2.62), _aged_brass)
		band.rotation_degrees.z = 90.0
	_add_box(Vector3(0.86, 0.72, 0.18), Vector3(0.25, 0.92, -1.80), _boiler_panel)
	_add_box(Vector3(0.58, 0.42, 0.05), Vector3(0.25, 0.94, -1.69), _lamp_material)
	var stack := _add_cylinder(0.28, 1.55, Vector3(-1.18, 2.14, -2.62), _iron_edge)
	stack.rotation_degrees = Vector3.ZERO

	for gear_data in [
		["factory/cog-a.glb", Vector3(-2.30, 0.12, 3.20), 0.78],
		["factory/cog-c.glb", Vector3(-1.30, 0.12, 3.20), 0.60],
		["factory/cog-e.glb", Vector3(1.72, 0.12, 3.20), 0.72],
	]:
		var gear := _place(gear_data[0], gear_data[1], Vector3.ZERO, Vector3.ONE * float(gear_data[2]))
		if gear != null:
			_spinners.append(gear)


func _build_blueprint_vault() -> void:
	_place_at_cell("factory/machine-fortified.glb", Vector2i(15, 1), Vector3(0.0, 90.0, 0.0), Vector3(0.90, 0.90, 0.90))
	_place_at_cell("factory/door-wide-closed.glb", Vector2i(16, 3), Vector3(0.0, 90.0, 0.0), Vector3(0.72, 0.84, 0.72))
	_place_at_cell("factory/box-wide.glb", Vector2i(18, 0), Vector3(0.0, 12.0, 0.0), Vector3(0.86, 0.96, 0.86))
	_place_at_cell("factory/screen-panel-small.glb", Vector2i(18, 4), Vector3(0.0, 205.0, 0.0), Vector3(0.88, 0.88, 0.88))
	_place("factory/lever-double.glb", Vector3(12.62, 0.08, -3.16), Vector3(0.0, -22.0, 0.0), Vector3(0.86, 0.86, 0.86), "VaultLockLevers")
	_place("factory/screen-hanging-wide.glb", Vector3(8.25, 1.30, -3.42), Vector3.ZERO, Vector3(1.02, 1.02, 1.02), "BlueprintStatusDisplay")
	_place("industrial/detail-tank.glb", Vector3(7.08, 0.10, 3.25), Vector3(0.0, 90.0, 0.0), Vector3(1.05, 1.05, 1.05), "VaultHydraulics")

	# A proper round locking door makes the destination legible at a glance.
	var vault_door := _add_cylinder(1.13, 0.30, Vector3(11.58, 1.34, -3.48), _vault_panel)
	vault_door.rotation_degrees.x = 90.0
	var vault_ring := _add_torus(0.76, 0.94, Vector3(11.58, 1.34, -3.28), _brass)
	vault_ring.rotation_degrees.x = 90.0
	var hub := _add_cylinder(0.24, 0.38, Vector3(11.58, 1.34, -3.20), _brass)
	hub.rotation_degrees.x = 90.0
	for angle in [0.0, 45.0, 90.0, 135.0]:
		var spoke := _add_box(Vector3(1.46, 0.09, 0.09), Vector3(11.58, 1.34, -3.16), _aged_brass)
		spoke.rotation_degrees.z = angle

	var lock_gear := _place("factory/cog-e.glb", Vector3(9.50, 0.11, 3.22), Vector3.ZERO, Vector3(0.82, 0.82, 0.82), "VaultLockwork")
	if lock_gear != null:
		_spinners.append(lock_gear)


func _build_car_signs() -> void:
	_add_sign("CREW CAR", Vector3(-10.5, 2.18, -3.64), "CrewCarriageSign")
	_add_sign("BOILER WORKSHOP", Vector3(0.0, 2.18, -3.64), "BoilerWorkshopSign")
	_add_sign("BLUEPRINT VAULT", Vector3(8.82, 2.18, -3.64), "ArmoredBlueprintVaultSign")


func _add_sign(text: String, at: Vector3, node_name: String) -> void:
	_add_box(Vector3(3.35, 0.40, 0.08), at + Vector3(0.0, 0.0, -0.05), _iron)
	var sign := Label3D.new()
	sign.name = node_name
	sign.text = text
	sign.position = at + Vector3(0.0, -0.04, 0.02)
	sign.font_size = 26
	sign.pixel_size = 0.006
	sign.modulate = Color("#c89a50")
	sign.outline_modulate = Color("#080909")
	sign.outline_size = 8
	sign.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sign)


func _build_lamps() -> void:
	for light_data in [
		[Vector3(-10.5, 2.30, -2.95), Color("#e7a451")],
		[Vector3(0.0, 2.30, -2.95), Color("#f07a38")],
		[Vector3(10.5, 2.30, -2.95), Color("#9a72c8")],
	]:
		var housing := _add_cylinder(0.20, 0.28, light_data[0], _aged_brass)
		housing.rotation_degrees.z = 90.0
		var bulb := _add_sphere(0.14, light_data[0] + Vector3(0.0, -0.18, 0.0), _lamp_material)
		bulb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		var light := OmniLight3D.new()
		light.position = light_data[0] + Vector3(0.0, -0.24, 0.20)
		light.light_color = light_data[1]
		light.light_energy = 3.2
		light.omni_range = 5.2
		light.shadow_enabled = true
		add_child(light)


func _build_steam() -> void:
	_add_steam_column(Vector3(-1.18, 2.92, -2.62), 7)
	_add_steam_column(Vector3(18.45, 2.15, -0.15), 9)


func _add_steam_column(origin: Vector3, count: int) -> void:
	for index in range(count):
		var puff := _add_sphere(0.24, origin + Vector3(float(index % 3) * 0.09 - 0.09, -float(index) * 0.14, 0.0), _steam_material)
		puff.name = "SteamPuff_%02d" % _steam_puffs.size()
		puff.set_meta("steam_origin", origin)
		puff.set_meta("steam_speed", 0.52 + float(index % 4) * 0.09)
		puff.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_steam_puffs.append(puff)


func _place_at_cell(path: String, cell: Vector2i, rotation_degrees_value: Vector3, model_scale: Vector3) -> Node3D:
	return _place(path, _world(cell, 0.08), rotation_degrees_value, model_scale)


func _world(cell: Vector2i, y: float) -> Vector3:
	return board.cell_to_world(cell) + Vector3(0.0, y, 0.0)


func _place(
		path: String,
		at: Vector3,
		rotation_degrees_value: Vector3 = Vector3.ZERO,
		model_scale: Vector3 = Vector3.ONE,
		instance_name: String = ""
	) -> Node3D:
	var packed: PackedScene = _asset_cache.get(path)
	if packed == null:
		packed = load(ASSET_ROOT + path) as PackedScene
		if packed == null:
			push_warning("Could not load environment asset: %s" % path)
			return null
		_asset_cache[path] = packed
	var instance := packed.instantiate() as Node3D
	if instance == null:
		return null
	if not instance_name.is_empty():
		instance.name = instance_name
	instance.position = at
	instance.rotation_degrees = rotation_degrees_value
	instance.scale = model_scale
	add_child(instance)
	_apply_weathered_asset_materials(instance, path)
	return instance


func _apply_weathered_asset_materials(instance: Node3D, path: String) -> void:
	var tint := Color(0.37, 0.32, 0.25, 1.0)
	if path.begins_with("train/"):
		tint = Color(0.29, 0.27, 0.23, 1.0)
	elif path.begins_with("industrial/"):
		tint = Color(0.32, 0.34, 0.32, 1.0)
	if "screen" in path:
		tint = Color(0.38, 0.51, 0.48, 1.0)
	elif "warning" in path:
		tint = Color(0.55, 0.31, 0.16, 1.0)

	for child in instance.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		for surface in range(mesh_instance.mesh.get_surface_count()):
			var source := mesh_instance.mesh.surface_get_material(surface) as StandardMaterial3D
			if source == null:
				continue
			var weathered := source.duplicate() as StandardMaterial3D
			weathered.albedo_color = weathered.albedo_color * tint
			weathered.metallic = maxf(weathered.metallic, 0.28)
			weathered.roughness = maxf(weathered.roughness, 0.62)
			mesh_instance.set_surface_override_material(surface, weathered)


func _material(
		color: Color,
		metallic: float,
		roughness: float,
		emission: Color = Color.BLACK,
		emission_energy: float = 0.0
	) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission
		material.emission_energy_multiplier = emission_energy
	return material


func _add_box(size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _add_cylinder(radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 14
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _add_torus(inner_radius: float, outer_radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := TorusMesh.new()
	mesh.inner_radius = inner_radius
	mesh.outer_radius = outer_radius
	mesh.rings = 24
	mesh.ring_segments = 10
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance


func _add_sphere(radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 12
	mesh.rings = 6
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	add_child(instance)
	return instance
