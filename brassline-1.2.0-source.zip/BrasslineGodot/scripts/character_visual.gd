class_name CharacterVisual
extends Node3D

const Types := preload("res://scripts/game_types.gd")
const WeaponModelScript := preload("res://scripts/weapon_model.gd")
const WeaponSupportScript := preload("res://scripts/weapon_support_pose.gd")

var animation_player: AnimationPlayer
var skeleton: Skeleton3D
var model_root: Node3D
var target_marker: MeshInstance3D
var is_defeated := false
var in_cover_stance := false
var weapon_root: Node3D
var weapon_attachment: BoneAttachment3D
var _stance_tween: Tween

var _gunmetal: StandardMaterial3D
var _brass: StandardMaterial3D
var _wood: StandardMaterial3D
var muzzle_socket: Node3D
var _weapon_id := "service_revolver"
var _weapon_recoil_tween: Tween
var _muzzle_flash: MeshInstance3D
var _muzzle_light: OmniLight3D
var _weapon_rest_position := Vector3(0.0, -0.04, 0.08)
var _weapon_rest_rotation := Vector3(2.0, 0.0, 0.0)
var _weapon_mount: Node3D
var _support_pose: SkeletonModifier3D


func setup(model_path: String, team: Types.Team) -> bool:
	var packed := load(model_path) as PackedScene
	if packed == null:
		return false
	model_root = packed.instantiate()
	model_root.name = "RiggedCharacter"
	model_root.scale = Vector3.ONE * 0.96
	add_child(model_root)

	skeleton = _find_first_skeleton(model_root)
	animation_player = _find_first_animation_player(model_root)
	_build_materials(team)
	_apply_weathered_character_materials(team)
	_build_target_marker()
	_build_revolver()
	play_idle()
	return true


func _build_materials(team: Types.Team) -> void:
	_gunmetal = StandardMaterial3D.new()
	_gunmetal.albedo_color = Color("#38444a")
	_gunmetal.metallic = 0.74
	_gunmetal.roughness = 0.40
	_brass = StandardMaterial3D.new()
	_brass.albedo_color = Color("#ba8848") if team == Types.Team.PLAYER else Color("#9b7554")
	_brass.metallic = 0.88
	_brass.roughness = 0.24
	_wood = StandardMaterial3D.new()
	_wood.albedo_color = Color("#62432c")
	_wood.metallic = 0.05
	_wood.roughness = 0.70


func _apply_weathered_character_materials(team: Types.Team) -> void:
	var tint := Color(0.86, 0.82, 0.76, 1.0) if team == Types.Team.PLAYER else Color(0.80, 0.70, 0.65, 1.0)
	for child in model_root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		for surface in range(mesh_instance.mesh.get_surface_count()):
			var source := mesh_instance.mesh.surface_get_material(surface) as StandardMaterial3D
			if source == null:
				continue
			var weathered := source.duplicate() as StandardMaterial3D
			weathered.albedo_color = weathered.albedo_color * tint
			# Recolour the imported clothing by material, retaining skin and face
			# colours. A global brown tint left neon workwear and red trainers intact.
			match source.resource_name:
				"Worker_Yellow", "Gold": weathered.albedo_color = Color("#a97c36")
				"Worker_Vest", "Brown2": weathered.albedo_color = Color("#614332")
				"LightBlue", "Swat": weathered.albedo_color = Color("#385859")
				"Red", "Red_Dark": weathered.albedo_color = Color("#693e39")
				"White", "Grey": weathered.albedo_color = Color("#ada18b")
				"Green", "LightGreen": weathered.albedo_color = Color("#56604b")
			weathered.roughness = maxf(weathered.roughness, 0.58)
			mesh_instance.set_surface_override_material(surface, weathered)


func apply_cosmetic_palette(palette_id: String) -> void:
	if not is_instance_valid(model_root):
		return
	var tint := Color.WHITE
	match palette_id:
		"brassbound":
			tint = Color("#d9b46f")
		"night_rail":
			tint = Color("#789aa4")
		_:
			tint = Color.WHITE
	if tint == Color.WHITE:
		return
	for child in model_root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		for surface in range(mesh_instance.mesh.get_surface_count()):
			var source := mesh_instance.get_surface_override_material(surface) as StandardMaterial3D
			if source == null:
				source = mesh_instance.mesh.surface_get_material(surface) as StandardMaterial3D
			if source == null:
				continue
			var treated := source.duplicate() as StandardMaterial3D
			treated.albedo_color *= tint
			treated.metallic = maxf(treated.metallic, 0.18 if palette_id == "night_rail" else 0.28)
			mesh_instance.set_surface_override_material(surface, treated)


func _build_target_marker() -> void:
	target_marker = MeshInstance3D.new()
	target_marker.name = "CalledShotReticle"
	var torus := TorusMesh.new()
	torus.inner_radius = 0.13
	torus.outer_radius = 0.19
	torus.rings = 18
	torus.ring_segments = 8
	target_marker.mesh = torus
	target_marker.rotation_degrees.x = 90.0
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(1.0, 0.69, 0.12, 0.72)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.emission_enabled = true
	material.emission = Color("#ffb331")
	material.emission_energy_multiplier = 3.0
	target_marker.material_override = material
	target_marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	target_marker.visible = false
	add_child(target_marker)


func _build_revolver() -> void:
	build_weapon("service_revolver")


func build_weapon(weapon_id: String) -> void:
	if not is_instance_valid(skeleton): return
	_weapon_id = weapon_id
	if is_instance_valid(_support_pose): _support_pose.free()
	if is_instance_valid(weapon_root): weapon_root.free()
	if is_instance_valid(_weapon_mount): _weapon_mount.free()
	_support_pose = null; _weapon_mount = null
	if skeleton.find_bone("Wrist.R") < 0: return
	if not is_instance_valid(weapon_attachment):
		weapon_attachment=BoneAttachment3D.new(); weapon_attachment.name="WeaponAttachment"; weapon_attachment.bone_name="Wrist.R"; skeleton.add_child(weapon_attachment)
	weapon_root=Node3D.new(); weapon_root.name="Equipped_%s"%weapon_id
	weapon_root.set_meta("weapon_id",weapon_id)
	var long_weapon := weapon_id in ["longshot_rifle","breach_gun","rivet_carbine"]
	if long_weapon:
		_weapon_mount=Node3D.new(); _weapon_mount.name="SupportedWeaponMount"; add_child(_weapon_mount)
		_weapon_mount.add_child(weapon_root)
		_weapon_rest_position=Vector3.ZERO; _weapon_rest_rotation=Vector3.ZERO
	else:
		# Wrist +Y is the animation's finger/barrel axis. Grip centre sits in
		# the palm, not on the forearm or at the bottom of an oversized handle.
		var grip_basis:=Basis(Vector3(0,0,-1),Vector3(-1,0,0),Vector3(0,1,0))
		_weapon_rest_position=Vector3(-0.045,0.17,0)
		_weapon_rest_rotation=grip_basis.get_euler()*(180.0/PI)
		weapon_attachment.add_child(weapon_root)
	weapon_root.position=_weapon_rest_position; weapon_root.rotation_degrees=_weapon_rest_rotation
	var dark:=StandardMaterial3D.new(); dark.albedo_color=Color("#080e10"); dark.roughness=0.9
	var geometry:Dictionary=WeaponModelScript.build(weapon_root,weapon_id,{"iron":_gunmetal,"brass":_brass,"wood":_wood,"dark":dark})
	muzzle_socket=Node3D.new(); muzzle_socket.name="MuzzleSocket"; muzzle_socket.position=Vector3(geometry.muzzle); weapon_root.add_child(muzzle_socket)
	if long_weapon:
		_support_pose=WeaponSupportScript.new(); _support_pose.name="TwoHandWeaponSupport"
		_support_pose.character=self; _support_pose.mount=_weapon_mount; _support_pose.gun=weapon_root
		_support_pose.animation_player=animation_player; _support_pose.support_grip=Vector3(geometry.support_grip)
		skeleton.add_child(_support_pose)
	_build_muzzle_flash()


func _build_muzzle_flash() -> void:
	_muzzle_flash = MeshInstance3D.new()
	_muzzle_flash.name = "MuzzleFlash"
	var mesh := SphereMesh.new()
	mesh.radius = 0.035
	mesh.height = 0.10
	_muzzle_flash.mesh = mesh
	_muzzle_flash.position = Vector3(0.0, 0.0, 0.055)
	_muzzle_flash.rotation_degrees.x = 90.0
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#fff0b3")
	material.emission_enabled = true
	material.emission = Color("#ff9f35")
	material.emission_energy_multiplier = 9.0
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_muzzle_flash.material_override = material
	_muzzle_flash.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_muzzle_flash.visible = false
	muzzle_socket.add_child(_muzzle_flash)
	_muzzle_light = OmniLight3D.new()
	_muzzle_light.name = "MuzzleFlashLight"
	_muzzle_light.position = Vector3(0.0, 0.0, 0.10)
	_muzzle_light.light_color = Color("#ffad45")
	_muzzle_light.light_energy = 3.6
	_muzzle_light.omni_range = 2.8
	_muzzle_light.shadow_enabled = false
	_muzzle_light.visible = false
	muzzle_socket.add_child(_muzzle_light)


func _build_revolver_shape(length: float, ornate: bool) -> void:
	_add_box(weapon_root, Vector3(0.09 if not ornate else 0.11, 0.09, length), Vector3(0.0, 0.0, length * 0.43), _gunmetal)
	var chamber := _add_cylinder(weapon_root, 0.105 if not ornate else 0.12, 0.15, Vector3(0.0, 0.0, -0.015), _brass)
	chamber.rotation_degrees.z = 90.0
	var grip := _add_box(weapon_root, Vector3(0.10, 0.27, 0.12), Vector3(0.0, -0.15, -0.08), _wood)
	grip.rotation_degrees.x = -14.0
	if ornate:
		_add_box(weapon_root, Vector3(0.14, 0.04, 0.30), Vector3(0.0, 0.08, 0.18), _brass)


func muzzle_global_position() -> Vector3:
	return muzzle_socket.global_position if is_instance_valid(muzzle_socket) else global_position + Vector3(0.0, 1.1, 0.0)


func set_called_shot_zone(zone: int) -> void:
	if not is_instance_valid(target_marker):
		return
	if zone < 0:
		target_marker.visible = false
		return
	target_marker.position = zone_position(zone)
	target_marker.visible = true


func zone_position(zone: int) -> Vector3:
	match zone:
		Types.BodyZone.HEAD:
			return Vector3(0.0, 1.67, -0.03)
		Types.BodyZone.TORSO:
			return Vector3(0.0, 1.19, -0.12)
		Types.BodyZone.ARMS:
			return Vector3(0.0, 1.17, -0.03)
		Types.BodyZone.LEGS:
			return Vector3(0.0, 0.52, -0.02)
	return Vector3(0.0, 1.0, 0.0)


func play_idle() -> void:
	if is_defeated:
		return
	if in_cover_stance:
		_play_first(["Idle_Gun_Pointing", "Idle_Gun", "Idle"], 0.16)
	else:
		_play_first(["Idle_Gun", "Idle", "Idle_Neutral"], 0.16)


func set_cover_stance(value: bool, animate: bool = true) -> void:
	in_cover_stance = value
	# The supplied rigs have a weapon-ready pose, but no crouch clip. Keep feet
	# on the deck instead of sinking the whole skeleton through the floor.
	var target_y := 0.0
	if is_instance_valid(_stance_tween):
		_stance_tween.kill()
	if animate and is_inside_tree():
		_stance_tween = create_tween()
		_stance_tween.set_trans(Tween.TRANS_QUINT)
		_stance_tween.set_ease(Tween.EASE_OUT)
		_stance_tween.tween_property(self, "position:y", target_y, 0.18)
	else:
		position.y = target_y
	play_idle()


func play_move() -> void:
	if is_defeated:
		return
	_play_first(["Run_Shoot", "Run", "Walk"], 0.16, 1.05)


func play_shoot() -> void:
	if is_defeated:
		return
	_play_first(["Idle_Gun_Shoot", "Gun_Shoot"], 0.08, 1.15)
	_play_weapon_recoil()
	_return_to_idle_after(0.48)


func _play_weapon_recoil() -> void:
	if not is_instance_valid(weapon_root):
		return
	if is_instance_valid(_weapon_recoil_tween):
		_weapon_recoil_tween.kill()
	weapon_root.position = _weapon_rest_position
	weapon_root.rotation_degrees = _weapon_rest_rotation
	if is_instance_valid(_muzzle_flash):
		_muzzle_flash.visible = true
		_muzzle_flash.scale = Vector3(0.45, 1.4, 0.45)
	if is_instance_valid(_muzzle_light):
		_muzzle_light.visible = true
	_weapon_recoil_tween = create_tween()
	_weapon_recoil_tween.set_parallel(true)
	# Recoil along the wrist's barrel axis. The skeleton supplies wrist kick;
	# rotating a corrected grip in parent Euler axes would twist it sideways.
	var recoil_axis:=Vector3(0,0,0.030) if is_instance_valid(_weapon_mount) else Vector3(0,0.022,0)
	_weapon_recoil_tween.tween_property(weapon_root, "position", _weapon_rest_position-recoil_axis, 0.045).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	if is_instance_valid(_muzzle_flash):
		_weapon_recoil_tween.tween_property(_muzzle_flash, "scale", Vector3(1.0, 2.7, 1.0), 0.045)
	await _weapon_recoil_tween.finished
	if not is_instance_valid(weapon_root):
		return
	if is_instance_valid(_muzzle_flash):
		_muzzle_flash.visible = false
	if is_instance_valid(_muzzle_light):
		_muzzle_light.visible = false
	var settle := create_tween()
	settle.set_parallel(true)
	settle.tween_property(weapon_root, "position", _weapon_rest_position, 0.13).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	settle.tween_property(weapon_root, "rotation_degrees", _weapon_rest_rotation, 0.13).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)


func play_reload() -> void:
	if is_defeated:
		return
	_play_first(["Interact", "Idle_Gun"], 0.10, 1.25)
	_return_to_idle_after(0.42)


func play_throw() -> void:
	if is_defeated:
		return
	_play_first(["Interact", "Punch_Right"], 0.08, 1.18)
	_return_to_idle_after(0.52)


func play_hit() -> void:
	if is_defeated:
		return
	_play_first(["HitRecieve_2", "HitRecieve"], 0.08, 1.12)
	_return_to_idle_after(0.52)


func play_death() -> void:
	is_defeated = true
	if is_instance_valid(_support_pose): _support_pose.arms_available=false
	# The ready-pose mount no longer solves during death. Hand the long gun
	# back to the animated wrist so it falls with its owner instead of floating.
	if is_instance_valid(_weapon_mount) and is_instance_valid(weapon_root) and is_instance_valid(weapon_attachment):
		if is_instance_valid(_weapon_recoil_tween): _weapon_recoil_tween.kill()
		var keep_world_pose:=weapon_root.is_inside_tree()
		weapon_root.reparent(weapon_attachment,keep_world_pose)
		if not keep_world_pose:
			weapon_root.position=Vector3(-0.045,0.17,0)
			weapon_root.basis=Basis(Vector3(0,0,-1),Vector3(-1,0,0),Vector3(0,1,0))
		if is_instance_valid(_muzzle_flash): _muzzle_flash.visible=false
		if is_instance_valid(_muzzle_light): _muzzle_light.visible=false
	set_called_shot_zone(-1)
	_play_first(["Death"], 0.08)


func play_surrender() -> void:
	if is_instance_valid(weapon_root):
		weapon_root.visible = false
	if is_instance_valid(_support_pose): _support_pose.arms_available=false
	in_cover_stance = false
	_play_first(["Idle_Neutral", "Idle"], 0.12, 0.82)
	position.y = -0.16


func build_limb_fragment_meshes(zone: Types.BodyZone) -> Array[Dictionary]:
	var fragments: Array[Dictionary] = []
	var limb_specs: Array[Dictionary] = []
	match zone:
		Types.BodyZone.ARMS:
			limb_specs = [
				{"bone": "UpperArm.L", "center": Vector3(-0.43, 1.17, -0.03), "side": -1.0},
				{"bone": "UpperArm.R", "center": Vector3(0.43, 1.17, -0.03), "side": 1.0},
			]
		Types.BodyZone.LEGS:
			limb_specs = [
				{"bone": "UpperLeg.L", "center": Vector3(-0.16, 0.52, -0.02), "side": -1.0},
				{"bone": "UpperLeg.R", "center": Vector3(0.16, 0.52, -0.02), "side": 1.0},
			]
	for spec in limb_specs:
		var mesh := _build_limb_fragment_mesh(String(spec["bone"]), Vector3(spec["center"]))
		if mesh != null and mesh.get_surface_count() > 0:
			fragments.append({"mesh": mesh, "center": spec["center"], "side": spec["side"]})
	return fragments


func _build_limb_fragment_mesh(limb_root_name: String, fragment_center: Vector3) -> ArrayMesh:
	if not is_instance_valid(skeleton) or not is_instance_valid(model_root):
		return null
	var limb_root_index := skeleton.find_bone(limb_root_name)
	if limb_root_index < 0:
		return null
	var limb_bones := _bone_branch(limb_root_index)
	var fragment := ArrayMesh.new()

	# Bake only triangles weighted to the requested bone branch. The result is a
	# real posed piece of the imported character, including clothing and textures.
	for child in model_root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		if mesh_instance.mesh == null or mesh_instance.skin == null:
			continue
		var skin := mesh_instance.skin
		for surface_index in range(mesh_instance.mesh.get_surface_count()):
			var arrays := mesh_instance.mesh.surface_get_arrays(surface_index)
			var vertices := PackedVector3Array()
			var bones := PackedInt32Array()
			var weights := PackedFloat32Array()
			var normals := PackedVector3Array()
			var uvs := PackedVector2Array()
			var indices := PackedInt32Array()
			if arrays[Mesh.ARRAY_VERTEX] != null:
				vertices = arrays[Mesh.ARRAY_VERTEX]
			if arrays[Mesh.ARRAY_BONES] != null:
				bones = arrays[Mesh.ARRAY_BONES]
			if arrays[Mesh.ARRAY_WEIGHTS] != null:
				weights = arrays[Mesh.ARRAY_WEIGHTS]
			if vertices.is_empty() or bones.size() < vertices.size() * 4 or weights.size() < vertices.size() * 4:
				continue
			if arrays[Mesh.ARRAY_NORMAL] != null:
				normals = arrays[Mesh.ARRAY_NORMAL]
			if arrays[Mesh.ARRAY_TEX_UV] != null:
				uvs = arrays[Mesh.ARRAY_TEX_UV]
			if arrays[Mesh.ARRAY_INDEX] != null:
				indices = arrays[Mesh.ARRAY_INDEX]
			var triangle_count := indices.size() / 3 if not indices.is_empty() else vertices.size() / 3
			var surface_tool := SurfaceTool.new()
			surface_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
			var emitted_triangles := 0
			for triangle_index in range(triangle_count):
				var triangle_vertices: Array[int] = []
				var triangle_weight := 0.0
				for corner in range(3):
					var source_index := int(indices[triangle_index * 3 + corner]) if not indices.is_empty() else triangle_index * 3 + corner
					triangle_vertices.append(source_index)
					triangle_weight += _vertex_branch_weight(source_index, bones, weights, skin, limb_bones)
				if triangle_weight / 3.0 < 0.46:
					continue
				for source_index in triangle_vertices:
					if not uvs.is_empty():
						surface_tool.set_uv(uvs[source_index])
					if not normals.is_empty():
						var posed_normal := _pose_vertex_normal(normals[source_index], source_index, bones, weights, skin)
						surface_tool.set_normal(posed_normal)
					var posed_vertex := _pose_vertex(vertices[source_index], source_index, bones, weights, skin)
					surface_tool.add_vertex(posed_vertex - fragment_center)
				emitted_triangles += 1
			if emitted_triangles == 0:
				continue
			var previous_surface_count := fragment.get_surface_count()
			surface_tool.index()
			surface_tool.commit(fragment)
			var material := mesh_instance.get_surface_override_material(surface_index)
			if material == null:
				material = mesh_instance.mesh.surface_get_material(surface_index)
			if material != null and fragment.get_surface_count() > previous_surface_count:
				fragment.surface_set_material(fragment.get_surface_count() - 1, material)
	return fragment if fragment.get_surface_count() > 0 else null


func sever_limb(zone: Types.BodyZone) -> void:
	if not is_instance_valid(skeleton):
		return
	var bone_names: Array[String] = []
	match zone:
		Types.BodyZone.ARMS:
			bone_names = ["UpperArm.L", "LowerArm.L", "Wrist.L", "UpperArm.R", "LowerArm.R", "Wrist.R"]
			if is_instance_valid(_support_pose): _support_pose.arms_available=false
			if is_instance_valid(weapon_root):
				weapon_root.visible = false
		Types.BodyZone.LEGS:
			bone_names = ["UpperLeg.L", "LowerLeg.L", "Foot.L", "UpperLeg.R", "LowerLeg.R", "Foot.R"]
	for bone_name in bone_names:
		var index := skeleton.find_bone(bone_name)
		if index >= 0:
			skeleton.set_bone_pose_scale(index, Vector3.ONE * 0.001)

func _bone_branch(root_index: int) -> Dictionary:
	var branch := {}
	for bone_index in range(skeleton.get_bone_count()):
		var cursor := bone_index
		while cursor >= 0:
			if cursor == root_index:
				branch[bone_index] = true
				break
			cursor = skeleton.get_bone_parent(cursor)
	return branch


func _vertex_branch_weight(
		vertex_index: int,
		bones: PackedInt32Array,
		weights: PackedFloat32Array,
		skin: Skin,
		branch: Dictionary
	) -> float:
	var result := 0.0
	for influence in range(4):
		var packed_index := vertex_index * 4 + influence
		var bone_index := _skeleton_bone_for_bind(skin, bones[packed_index])
		if branch.has(bone_index):
			result += weights[packed_index]
	return result


func _pose_vertex(
		source: Vector3,
		vertex_index: int,
		bones: PackedInt32Array,
		weights: PackedFloat32Array,
		skin: Skin
	) -> Vector3:
	var posed := Vector3.ZERO
	var total_weight := 0.0
	for influence in range(4):
		var packed_index := vertex_index * 4 + influence
		var weight := weights[packed_index]
		if weight <= 0.0001:
			continue
		var bind_index := bones[packed_index]
		var bone_index := _skeleton_bone_for_bind(skin, bind_index)
		if bone_index < 0:
			continue
		var skinning_transform := skeleton.get_bone_global_pose(bone_index) * skin.get_bind_pose(bind_index)
		posed += (skinning_transform * source) * weight
		total_weight += weight
	if total_weight <= 0.0001:
		posed = source
	else:
		posed /= total_weight
	var world_vertex := skeleton.to_global(posed)
	return to_local(world_vertex)


func _pose_vertex_normal(
		source: Vector3,
		vertex_index: int,
		bones: PackedInt32Array,
		weights: PackedFloat32Array,
		skin: Skin
	) -> Vector3:
	var posed := Vector3.ZERO
	var total_weight := 0.0
	for influence in range(4):
		var packed_index := vertex_index * 4 + influence
		var weight := weights[packed_index]
		if weight <= 0.0001:
			continue
		var bind_index := bones[packed_index]
		var bone_index := _skeleton_bone_for_bind(skin, bind_index)
		if bone_index < 0:
			continue
		var skinning_basis := (skeleton.get_bone_global_pose(bone_index) * skin.get_bind_pose(bind_index)).basis
		posed += (skinning_basis * source) * weight
		total_weight += weight
	if total_weight <= 0.0001:
		posed = source
	var world_normal := skeleton.global_basis * posed.normalized()
	return (global_basis.inverse() * world_normal).normalized()


func _skeleton_bone_for_bind(skin: Skin, bind_index: int) -> int:
	if bind_index < 0 or bind_index >= skin.get_bind_count():
		return -1
	var bone_index := skin.get_bind_bone(bind_index)
	if bone_index >= 0:
		return bone_index
	var bind_name := String(skin.get_bind_name(bind_index))
	return skeleton.find_bone(bind_name) if not bind_name.is_empty() else -1


func _return_to_idle_after(delay: float) -> void:
	await get_tree().create_timer(delay).timeout
	play_idle()


func _play_first(candidates: Array[String], blend: float, speed: float = 1.0) -> void:
	if not is_instance_valid(animation_player):
		return
	for candidate in candidates:
		if animation_player.has_animation(candidate):
			animation_player.play(candidate, blend, speed)
			return


func _find_first_skeleton(node: Node) -> Skeleton3D:
	if node is Skeleton3D:
		return node as Skeleton3D
	for child in node.get_children():
		var result := _find_first_skeleton(child)
		if is_instance_valid(result):
			return result
	return null


func _find_first_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child in node.get_children():
		var result := _find_first_animation_player(child)
		if is_instance_valid(result):
			return result
	return null


func _add_box(parent: Node3D, size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	parent.add_child(instance)
	return instance


func _add_cylinder(parent: Node3D, radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	instance.mesh = mesh
	instance.position = at
	instance.material_override = material
	parent.add_child(instance)
	return instance
