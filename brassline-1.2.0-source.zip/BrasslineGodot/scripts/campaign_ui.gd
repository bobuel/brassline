class_name CampaignUI
extends CanvasLayer

signal crew_confirmed(crew_ids: Array[String])
signal car_selected(car_index: int)
signal car_prep_requested(car_id: String)
signal next_car_chosen(car_id: String)
signal prep_back_requested
signal item_requested(item_id: String, crew_id: String)
signal event_resolved
signal event_choice_requested(choice_id: String)
signal crew_scene_choice_requested(choice_id: String)
signal continue_requested
signal audio_captions_changed(enabled: bool)
signal retry_requested
signal abandon_requested
signal training_requested
signal daily_challenge_requested(seed: int)
signal presentation_settings_changed(cinematic_focus: String, reduced_motion: bool, text_scale: float)
signal share_card_requested
signal challenge_code_copy_requested(code: String)
signal challenge_code_requested(code: String)
signal crew_review_requested(car_id: String)
signal profile_changed
signal settings_visibility_changed(open: bool)

const CrewEmblem := preload("res://assets/ui/faction_crew.png")
const Types := preload("res://scripts/game_types.gd")
const CombatCatalog := preload("res://scripts/combat_catalog.gd")
const RunStateScript := preload("res://scripts/run_state.gd")
const SignatureArcScript := preload("res://scripts/signature_arc.gd")
const SETTINGS_PATH := "user://brassline_settings.cfg"
const CrewPreviewStageScript := preload("res://scripts/crew_preview_stage.gd")
const CrewSelectionStageScript := preload("res://scripts/crew_selection_stage.gd")

const ROSTER := [
	{
		"id": "ada",
		"name": "Ada Brass",
		"role": "SHARPSHOOTER",
		"model": "Casual_2.gltf",
		"damage": 3.4,
		"range": 10,
		"move": 4,
		"weapon_id": "longshot_rifle",
		"weapon": "LONGSHOT RIFLE / 4 ROUNDS",
		"ability_id": "deadeye",
		"ability": "DEADEYE",
		"trait": "Deadeye / long-range precision",
		"accent": Color("#45b8d0"),
	},
	{
		"id": "marlow",
		"name": "Marlow Pike",
		"role": "VANGUARD",
		"model": "Adventurer.gltf",
		"damage": 4.4,
		"range": 5,
		"move": 5,
		"weapon_id": "breach_gun",
		"weapon": "BREACH GUN / 2 SHELLS",
		"ability_id": "breach_charge",
		"ability": "BREACH CHARGE",
		"trait": "Breacher / close-range stopping power",
		"accent": Color("#d39a50"),
	},
	{
		"id": "nix",
		"name": "Nix Bell",
		"role": "SABOTEUR",
		"model": "Punk.gltf",
		"damage": 2.9,
		"range": 8,
		"move": 6,
		"weapon_id": "coil_pistol",
		"weapon": "COIL PISTOL / 6 CHARGES",
		"ability_id": "overclock",
		"ability": "OVERCLOCK",
		"trait": "Wireghost / fastest boarder",
		"accent": Color("#bc79d6"),
	},
	{
		"id": "iona",
		"name": "Iona Wrench",
		"role": "MECHANIST",
		"model": "Worker.gltf",
		"damage": 3.2,
		"range": 7,
		"move": 5,
		"weapon_id": "rivet_carbine",
		"weapon": "RIVET CARBINE / 5 BOLTS",
		"ability_id": "field_repair",
		"ability": "FIELD REPAIR",
		"trait": "Mechanist / balanced workshop fighter",
		"accent": Color("#d8aa48"),
	},
	{
		"id": "silas",
		"name": "Silas Crow",
		"role": "GUNSLINGER",
		"model": "Suit.gltf",
		"damage": 3.3,
		"range": 8,
		"move": 5,
		"weapon_id": "duelist_revolver",
		"weapon": "DUELIST REVOLVER / 6 ROUNDS",
		"ability_id": "quickdraw",
		"ability": "QUICKDRAW",
		"trait": "Quickdraw / flexible marksman",
		"accent": Color("#72b49c"),
	},
	{
		"id": "rook",
		"name": "Rook Mercer",
		"role": "ENFORCER",
		"model": "Swat.gltf",
		"damage": 4.1,
		"range": 6,
		"move": 4,
		"weapon_id": "hand_cannon",
		"weapon": "HAND CANNON / 3 ROUNDS",
		"ability_id": "iron_stance",
		"ability": "IRON STANCE",
		"trait": "Ironclad / maximum weapon damage",
		"accent": Color("#c76753"),
	},
]

const INTRO_ROUTE_NAMES := ["BOARD", "?", "?", "?", "?", "?", "ENGINE"]
const DIFFICULTIES := {
	"story": {
		"label": "STORY",
		"description": "Fewer guards and 18% less enemy damage. After casualties, fewer opponents help surviving crew continue.",
	},
	"standard": {
		"label": "STANDARD",
		"description": "Full guard strength, even after crew losses. Injuries and supplies carry between cars.",
	},
	"brutal": {
		"label": "BRUTAL",
		"description": "Extra guards, 18% more enemy damage, and less room for a wounded crew.",
	},
}

var front_overlay: Control
var front_panel: PanelContainer
var front_content: VBoxContainer
var navigator: PanelContainer
var navigator_buttons: Array[Button] = []
var navigator_label: Label
var navigator_buff_label: Label
var car_alert: Label
var roster_buttons: Dictionary = {}
var selection_label: Label
var confirm_button: Button
var selected_crew_ids: Array[String] = ["ada", "marlow", "nix"]
var selected_difficulty := "standard"
var reduced_motion_enabled := false
var audio_captions_enabled := false
var unlocked_car_index := 0
var selected_car_index := 0
var _cinematic_capture := false
var _active_run_state: RefCounted
var _management_crew_id := ""
var _continue_available := false
var _continue_summary := ""
var _management_feedback := ""
var _management_feedback_success := true
var management_feedback_label: Label
var crew_preview_stage: CrewPreviewStage
var prep_board_button: Button
var selection_preview_stage: CrewSelectionStage
var selection_detail_label: Label
var crew_assignment_button: Button
var _previewed_roster_id := "ada"
var profile_state: BrasslineProfileState
var text_scale := 1.0
var cinematic_focus_mode := "key_beats"
var controller_mode := false
var share_feedback_label: Label
var cosmetic_button: Button
var challenge_input: LineEdit
var challenge_feedback: Label
var challenge_start_button: Button
var _settings_focus_prefix := ""
var _settings_return_context: Dictionary = {}

var _panel_color := Color(0.012, 0.035, 0.042, 0.965)
var _panel_border := Color(0.31, 0.60, 0.59, 0.62)
var _brass := Color("#e3b65c")
var _ink := Color("#d8f5f1")
var _muted := Color("#82a9ab")
var _green := Color("#72d8b6")
var _danger := Color("#e66e5d")


func _ready() -> void:
	layer = 20
	if not _is_automation_session():
		load_settings()
	_build_front_overlay()
	_build_navigator()
	show_intro()


func _is_automation_session() -> bool:
	for argument in OS.get_cmdline_args():
		if "tests/" in argument or "--capture" in argument:
			return true
	return false


func save_settings(path: String = SETTINGS_PATH) -> bool:
	var config := ConfigFile.new()
	config.set_value("comfort", "text_scale", text_scale)
	config.set_value("comfort", "reduced_motion", reduced_motion_enabled)
	config.set_value("comfort", "audio_captions", audio_captions_enabled)
	config.set_value("comfort", "cinematic_focus", cinematic_focus_mode)
	config.set_value("comfort", "master_muted", AudioServer.is_bus_mute(0))
	config.set_value("run", "difficulty", selected_difficulty)
	return config.save(path) == OK


func load_settings(path: String = SETTINGS_PATH) -> bool:
	var config := ConfigFile.new()
	if config.load(path) != OK:
		return false
	text_scale = clampf(float(config.get_value("comfort", "text_scale", 1.0)), 1.0, 1.30)
	reduced_motion_enabled = bool(config.get_value("comfort", "reduced_motion", false))
	audio_captions_enabled = bool(config.get_value("comfort", "audio_captions", false))
	var focus := String(config.get_value("comfort", "cinematic_focus", "key_beats"))
	cinematic_focus_mode = focus if focus in ["key_beats", "full", "off"] else "key_beats"
	var difficulty := String(config.get_value("run", "difficulty", "standard"))
	selected_difficulty = difficulty if DIFFICULTIES.has(difficulty) else "standard"
	AudioServer.set_bus_mute(0, bool(config.get_value("comfort", "master_muted", false)))
	return true


func _save_settings_and_return() -> void:
	if not _is_automation_session() and not save_settings():
		push_warning("Brassline settings could not be saved.")
	if in_run_settings_open():
		_close_in_run_settings()
		return
	show_intro()


func in_run_settings_open() -> bool:
	return not _settings_return_context.is_empty()


func show_in_run_settings(return_focus: Control = null) -> void:
	if in_run_settings_open():
		return
	var focused := return_focus if is_instance_valid(return_focus) else get_viewport().gui_get_focus_owner()
	_settings_return_context = {
		"content": front_content, "front_visible": front_overlay.visible, "navigator_visible": navigator.visible,
		"focus": weakref(focused) if is_instance_valid(focused) else null,
		"management_feedback_label": management_feedback_label, "crew_preview_stage": crew_preview_stage,
		"prep_board_button": prep_board_button, "selection_preview_stage": selection_preview_stage,
		"selection_detail_label": selection_detail_label,
	}
	front_content.hide()
	var settings_content := VBoxContainer.new()
	settings_content.alignment = BoxContainer.ALIGNMENT_CENTER
	front_content.get_parent().add_child(settings_content)
	front_content = settings_content
	_settings_focus_prefix = "REDUCED MOTION:"
	settings_visibility_changed.emit(true)
	show_settings()


func _close_in_run_settings() -> void:
	var temporary := front_content
	front_content = _settings_return_context["content"] as VBoxContainer
	temporary.get_parent().remove_child(temporary)
	temporary.queue_free()
	front_content.show()
	front_overlay.visible = bool(_settings_return_context["front_visible"])
	navigator.visible = bool(_settings_return_context["navigator_visible"])
	for property_name in ["management_feedback_label", "crew_preview_stage", "prep_board_button", "selection_preview_stage", "selection_detail_label"]:
		set(property_name, _settings_return_context[property_name])
	var reference = _settings_return_context.get("focus")
	_settings_return_context.clear()
	_settings_focus_prefix = ""
	settings_visibility_changed.emit(false)
	if reference is WeakRef:
		var control = reference.get_ref()
		if is_instance_valid(control):
			_schedule_focus(control)


func _input(event: InputEvent) -> void:
	if in_run_settings_open() and event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_save_settings_and_return()


func set_profile(value: BrasslineProfileState) -> void:
	profile_state = value
	if is_node_ready() and is_instance_valid(front_overlay) and front_overlay.visible:
		show_intro()


func set_controller_mode(enabled: bool) -> void:
	if controller_mode == enabled:
		return
	controller_mode = enabled
	if is_instance_valid(front_overlay) and front_overlay.visible and front_content.get_child_count() > 0:
		# Rebuild only the settings reference, where the input legend is visible.
		var title := _front_screen_title()
		if title == "SETTINGS":
			show_settings()


func show_intro() -> void:
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()

	var header := HBoxContainer.new()
	header.alignment = BoxContainer.ALIGNMENT_CENTER
	header.add_theme_constant_override("separation", 16)
	header.add_child(_make_emblem(74.0))
	var title_stack := VBoxContainer.new()
	header.add_child(title_stack)
	title_stack.add_child(_make_label("A CLOCKWORK TACTICS HEIST", 13, _brass))
	var title := _make_label("BRASSLINE", 58, _ink)
	title_stack.add_child(title)
	front_content.add_child(header)
	front_content.add_child(_make_rule())

	var job := _make_label("TAKE THE GREEN RAIL", 24, _brass)
	job.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(job)
	var brief := _make_label(
		"Board the armored Green Rail. Break its guards. Steal the locomotive before it steals the crew.",
		16,
		_ink
	)
	brief.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	brief.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	brief.custom_minimum_size = Vector2(760.0, 66.0)
	front_content.add_child(brief)

	var feature_row := HBoxContainer.new()
	feature_row.alignment = BoxContainer.ALIGNMENT_CENTER
	feature_row.add_theme_constant_override("separation", 14)
	for feature in ["7-CAR ROGUELITE RUN", "NARRATIVE HEIST PLANS", "ANATOMICAL AUTOBATTLES"]:
		feature_row.add_child(_make_badge(feature))
	front_content.add_child(feature_row)

	var route := HBoxContainer.new()
	route.alignment = BoxContainer.ALIGNMENT_CENTER
	route.add_theme_constant_override("separation", 8)
	for index in range(INTRO_ROUTE_NAMES.size()):
		var card := PanelContainer.new()
		card.custom_minimum_size = Vector2(102.0, 72.0)
		card.add_theme_stylebox_override("panel", _box_style(Color(0.025, 0.075, 0.082, 0.94), _panel_border.darkened(0.22), 5))
		var margin := _make_margin(12, 12, 10, 10)
		card.add_child(margin)
		var stack := VBoxContainer.new()
		margin.add_child(stack)
		stack.add_child(_make_label("CAR 0%d" % [index + 1], 11, _ink))
		stack.add_child(_make_label(INTRO_ROUTE_NAMES[index], 10, _muted))
		route.add_child(card)
		if index < INTRO_ROUTE_NAMES.size() - 1:
			route.add_child(_make_label("->", 19, _brass))
	front_content.add_child(route)

	var start := _make_primary_button("START HEIST", 320.0)
	start.pressed.connect(show_crew_selection)
	var start_row := HBoxContainer.new()
	start_row.alignment = BoxContainer.ALIGNMENT_CENTER
	start_row.add_theme_constant_override("separation", 14)
	start_row.add_child(start)
	if _continue_available:
		var continue_button := _make_secondary_button("CONTINUE RUN", 240.0)
		continue_button.tooltip_text = _continue_summary
		continue_button.pressed.connect(func() -> void: continue_requested.emit())
		start_row.add_child(continue_button)
	front_content.add_child(start_row)
	if _continue_available:
		var continue_label := _make_label("CHECKPOINT / %s" % _continue_summary, 10, _brass)
		continue_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		front_content.add_child(continue_label)
	var info_row := HBoxContainer.new()
	info_row.alignment = BoxContainer.ALIGNMENT_CENTER
	info_row.add_theme_constant_override("separation", 12)
	var how_to := _make_secondary_button("HOW TO PLAY", 200.0)
	how_to.custom_minimum_size.y = 38.0
	how_to.pressed.connect(show_how_to_play)
	info_row.add_child(how_to)
	var settings := _make_secondary_button("SETTINGS / %s" % String(DIFFICULTIES[selected_difficulty]["label"]), 240.0)
	settings.custom_minimum_size.y = 38.0
	settings.pressed.connect(show_settings)
	info_row.add_child(settings)
	if is_instance_valid(profile_state):
		var daily_seed := profile_state.daily_seed()
		var daily := _make_secondary_button("DAILY TRAIN / %06d" % daily_seed, 230.0)
		daily.custom_minimum_size.y = 38.0
		daily.tooltip_text = "A deterministic train shared by everyone using today's date. Standard difficulty and the default crew."
		daily.pressed.connect(func() -> void: daily_challenge_requested.emit(daily_seed))
		info_row.add_child(daily)
		var import_button := _make_secondary_button("IMPORT CHALLENGE", 200.0)
		import_button.custom_minimum_size.y = 38.0
		import_button.pressed.connect(show_challenge_import)
		info_row.add_child(import_button)
	front_content.add_child(info_row)
	var profile_note := ""
	if is_instance_valid(profile_state):
		profile_note = "  •  BLUEPRINT KNOWLEDGE %d" % profile_state.blueprint_knowledge
	var footer := _make_label("SEVEN CARS. ONE SHOT AT FREEDOM.%s\nBUILD %s" % [profile_note, String(ProjectSettings.get_setting("application/config/version", "DEV"))], 10, _muted)
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(footer)
	_schedule_focus(start)


func show_challenge_import() -> void:
	_clear_front_content()
	var title := _make_label("PLAY A SHARED HEIST", 28, _brass)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	var note := _make_label("Paste a Brassline code to preview its crew, seed and rules.", 14, _ink)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(note)
	challenge_input = LineEdit.new()
	challenge_input.placeholder_text = "BR1..."
	challenge_input.custom_minimum_size = Vector2(900, 46)
	challenge_input.add_theme_font_size_override("font_size", _scaled_font(14))
	challenge_input.text_changed.connect(_validate_challenge_input)
	front_content.add_child(challenge_input)
	challenge_feedback = _make_label("Awaiting challenge code.", 14, _muted)
	challenge_feedback.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	challenge_feedback.custom_minimum_size = Vector2(900, 92)
	front_content.add_child(challenge_feedback)
	var actions := HBoxContainer.new()
	actions.alignment = BoxContainer.ALIGNMENT_CENTER
	front_content.add_child(actions)
	var back := _make_secondary_button("BACK", 200)
	back.pressed.connect(show_intro)
	actions.add_child(back)
	challenge_start_button = _make_primary_button("START THIS CHALLENGE", 350)
	challenge_start_button.disabled = true
	challenge_start_button.pressed.connect(func() -> void: challenge_code_requested.emit(challenge_input.text.strip_edges()))
	actions.add_child(challenge_start_button)
	_schedule_focus(challenge_input)


func _validate_challenge_input(value: String) -> void:
	var parsed: Dictionary = profile_state.parse_challenge_code(value) if is_instance_valid(profile_state) else {"ok": false, "reason": "Profile unavailable."}
	challenge_start_button.disabled = not bool(parsed.get("ok", false))
	if not bool(parsed.get("ok", false)):
		challenge_feedback.text = String(parsed.get("reason", "Invalid code."))
		challenge_feedback.add_theme_color_override("font_color", _danger)
		return
	var names: Array[String] = []
	for crew_id in Array(parsed.get("crew_ids", [])):
		names.append(String(roster_member(String(crew_id)).get("name", crew_id)))
	challenge_feedback.text = "%s\nSEED %s / %s / %s\nStarting this challenge replaces the current run checkpoint." % [", ".join(names), parsed.get("seed", 0), String(parsed.get("difficulty", "standard")).to_upper(), String(parsed.get("ruleset", "train_takeover")).replace("_", " ").to_upper()]
	challenge_feedback.add_theme_color_override("font_color", _green)


func show_how_to_play() -> void:
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	var kicker := _make_label("FIELD MANUAL / NO PRIOR TACTICS EXPERIENCE REQUIRED", 12, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label("HOW TO ROB THE BRASSLINE", 36, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	front_content.add_child(_make_rule())
	var manual := _make_label(
		"1 / PICK THREE OPERATIVES\nWeapons, injuries, specialties, and signature abilities determine which heist plans the crew can execute well.\n\n"
		+ "2 / CHOOSE THE APPROACH\nEach carriage offers three or four authored plans built from its layout, guards, hazards, crew, wounds, and earned buffs. Compare the advantage, named risk carrier, opening target, body priority, exact hit chance, confidence, and ghosted starting marks.\n\n"
		+ "3 / SET THE FALLBACK\nChoose what matters when the opening bends: hold formation, protect the wounded, finish the target, save the crew, or improvise. Then commit. The crew moves, uses cover and abilities, reloads, and attacks automatically in discrete initiative order.\n\n"
		+ "4 / READ THE FIGHT\nGreen intent labels mean on plan, brass means adapting, and red means the plan broke. Arms shots wreck aim and weapon handling; leg shots wreck movement. Press Space to pause, 1/2/4 for speed, and I for body, weapon, and car-buff details.\n\n"
		+ "5 / TAKE THE TRAIN\nAfter the narrative aftermath, choose the next carriage and treat persistent wounds. The Engine is always car seven: break Voss's command, force isolated guards to surrender, and seize the locomotive controls.",
		14,
		_ink
	)
	manual.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	manual.custom_minimum_size = Vector2(860.0, 390.0)
	front_content.add_child(manual)
	var back := _make_primary_button("BACK TO JOB BRIEF", 300.0)
	back.pressed.connect(show_intro)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	row.add_child(back)
	var training := _make_secondary_button("REPLAY TRAINING", 260.0)
	training.pressed.connect(func() -> void: training_requested.emit())
	row.add_child(training)
	front_content.add_child(row)


func show_settings() -> void:
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	var kicker := _make_label("COMFORT / FIGHT PAUSED" if in_run_settings_open() else "ACCESSIBILITY / RUN RULES", 12, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label("SETTINGS", 42, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	front_content.add_child(_make_rule())
	front_content.add_child(_make_label("DIFFICULTY / LOCKS WHEN THE CREW BOARDS", 12, _brass))
	var difficulty_row := HBoxContainer.new()
	difficulty_row.alignment = BoxContainer.ALIGNMENT_CENTER
	difficulty_row.add_theme_constant_override("separation", 10)
	for difficulty_id in ["story", "standard", "brutal"]:
		var data: Dictionary = DIFFICULTIES[difficulty_id]
		var button := _make_secondary_button(String(data["label"]), 210.0)
		button.custom_minimum_size.y = 44.0
		button.disabled = in_run_settings_open()
		if difficulty_id == selected_difficulty:
			button.add_theme_stylebox_override("normal", _box_style(Color(0.28, 0.20, 0.07, 0.99), _brass, 5))
		button.pressed.connect(_select_difficulty.bind(String(difficulty_id)))
		difficulty_row.add_child(button)
	front_content.add_child(difficulty_row)
	var description: Dictionary = DIFFICULTIES[selected_difficulty]
	var difficulty_note := _make_label(String(description["description"]), 13, _ink)
	difficulty_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	difficulty_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	difficulty_note.custom_minimum_size = Vector2(800.0, 50.0)
	front_content.add_child(difficulty_note)
	front_content.add_child(_make_rule())
	var comfort_row := HBoxContainer.new()
	comfort_row.alignment = BoxContainer.ALIGNMENT_CENTER
	comfort_row.add_theme_constant_override("separation", 12)
	var motion := _make_secondary_button("REDUCED MOTION: %s" % ("ON" if reduced_motion_enabled else "OFF"), 250.0)
	motion.tooltip_text = "Stops moving scenery and removes animated camera travel and hit-stop emphasis."
	motion.pressed.connect(_toggle_reduced_motion)
	comfort_row.add_child(motion)
	var mute := _make_secondary_button("MASTER AUDIO: %s" % ("MUTED" if AudioServer.is_bus_mute(0) else "ON"), 250.0)
	mute.pressed.connect(_toggle_master_audio)
	comfort_row.add_child(mute)
	front_content.add_child(comfort_row)
	var presentation_row := HBoxContainer.new()
	presentation_row.alignment = BoxContainer.ALIGNMENT_CENTER
	presentation_row.add_theme_constant_override("separation", 10)
	var focus_label: String = String({"key_beats": "KEY BEATS", "full": "FULL", "off": "OFF"}.get(cinematic_focus_mode, "KEY BEATS"))
	var focus := _make_secondary_button("CINEMATIC FOCUS: %s" % focus_label, 260.0)
	focus.tooltip_text = "Choose whether the camera spotlights decisive events, every attack, or stays fixed."
	focus.pressed.connect(_cycle_cinematic_focus)
	presentation_row.add_child(focus)
	var text_button := _make_secondary_button("TEXT SCALE: %d%%" % roundi(text_scale * 100.0), 210.0)
	text_button.tooltip_text = "Cycle interface text between 100%, 115%, and 130%."
	text_button.pressed.connect(_cycle_text_scale)
	presentation_row.add_child(text_button)
	var captions := _make_secondary_button("SOUND CAPTIONS: %s" % ("ON" if audio_captions_enabled else "OFF"), 260.0)
	captions.tooltip_text = "Show brief text for weapon fire, train hazards, doctrine breaks, and other important sounds."
	captions.pressed.connect(_toggle_audio_captions)
	presentation_row.add_child(captions)
	front_content.add_child(presentation_row)
	var setting_note := _make_label(
		"Controller: Menu pauses / LB-RB changes speed / Y opens operative stats / B closes panels. All choices use directional focus and A to confirm."
		if controller_mode else
		"Keyboard: Space pauses / 1, 2, or 4 changes speed / I opens operative stats / Home reframes the carriage.",
		12,
		_muted
	)
	setting_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(setting_note)
	var back := _make_primary_button("SAVE AND RETURN", 300.0)
	back.pressed.connect(_save_settings_and_return)
	var back_row := HBoxContainer.new()
	back_row.alignment = BoxContainer.ALIGNMENT_CENTER
	back_row.add_child(back)
	front_content.add_child(back_row)
	_focus_settings_control.call_deferred()


func _focus_settings_control() -> void:
	var prefix := _settings_focus_prefix if not _settings_focus_prefix.is_empty() else String(DIFFICULTIES[selected_difficulty]["label"])
	_focus_button_with_prefix(front_content, prefix)


func _focus_button_with_prefix(node: Node, prefix: String) -> bool:
	if node is Button and String(node.text).begins_with(prefix):
		node.grab_focus()
		return true
	for child in node.get_children():
		if _focus_button_with_prefix(child, prefix):
			return true
	return false


func _select_difficulty(difficulty_id: String) -> void:
	if in_run_settings_open():
		return
	selected_difficulty = difficulty_id
	_settings_focus_prefix = String(DIFFICULTIES[selected_difficulty]["label"])
	show_settings()


func _toggle_reduced_motion() -> void:
	_settings_focus_prefix = "REDUCED MOTION:"
	reduced_motion_enabled = not reduced_motion_enabled
	presentation_settings_changed.emit(cinematic_focus_mode, reduced_motion_enabled, text_scale)
	show_settings()


func _toggle_master_audio() -> void:
	_settings_focus_prefix = "MASTER AUDIO:"
	AudioServer.set_bus_mute(0, not AudioServer.is_bus_mute(0))
	show_settings()


func _toggle_audio_captions() -> void:
	_settings_focus_prefix = "SOUND CAPTIONS:"
	audio_captions_enabled = not audio_captions_enabled
	audio_captions_changed.emit(audio_captions_enabled)
	show_settings()


func _cycle_cinematic_focus() -> void:
	_settings_focus_prefix = "CINEMATIC FOCUS:"
	var modes := ["key_beats", "full", "off"]
	cinematic_focus_mode = String(modes[posmod(modes.find(cinematic_focus_mode) + 1, modes.size())])
	presentation_settings_changed.emit(cinematic_focus_mode, reduced_motion_enabled, text_scale)
	show_settings()


func _cycle_text_scale() -> void:
	_settings_focus_prefix = "TEXT SCALE:"
	var scales := [1.0, 1.15, 1.30]
	var current := 0
	for index in range(scales.size()):
		if is_equal_approx(text_scale, float(scales[index])):
			current = index
			break
	text_scale = float(scales[posmod(current + 1, scales.size())])
	presentation_settings_changed.emit(cinematic_focus_mode, reduced_motion_enabled, text_scale)
	show_settings()


func _front_screen_title() -> String:
	for child in front_content.get_children():
		if child is Label and String((child as Label).text) in ["SETTINGS", "HOW TO PLAY", "WHO BOARDS THE BRASSLINE?", "BRASSLINE"]:
			return String((child as Label).text)
	return ""


func show_crew_selection() -> void:
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	front_content.add_theme_constant_override("separation", 5)
	roster_buttons.clear()

	var kicker := _make_label("CREW MANIFEST / THREE OPERATIVES / DEFAULT CREW READY", 11, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label("WHO BOARDS THE BRASSLINE?", 30, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	selection_label = _make_label("", 13, _muted)
	selection_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(selection_label)
	var difficulty_badge := _make_label("RUN DIFFICULTY / %s" % String(DIFFICULTIES[selected_difficulty]["label"]), 11, _brass)
	difficulty_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(difficulty_badge)

	var body := HBoxContainer.new()
	body.alignment = BoxContainer.ALIGNMENT_CENTER
	body.add_theme_constant_override("separation", 14)
	front_content.add_child(body)
	var preview_column := VBoxContainer.new()
	preview_column.add_theme_constant_override("separation", 4)
	body.add_child(preview_column)
	selection_preview_stage = CrewSelectionStageScript.new()
	preview_column.add_child(selection_preview_stage)
	selection_preview_stage.custom_minimum_size = Vector2(450.0, 226.0)
	selection_detail_label = _make_label("", 11, _ink)
	selection_detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	selection_detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	selection_detail_label.custom_minimum_size = Vector2(450.0, 82.0)
	preview_column.add_child(selection_detail_label)
	var rotation_hint := _make_label("DRAG THE OPERATIVE TO ROTATE  •  CLICK A PORTRAIT TO INSPECT", 9, _muted)
	rotation_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	preview_column.add_child(rotation_hint)
	cosmetic_button = _make_secondary_button("FINISH / WEATHERED", 450.0)
	cosmetic_button.custom_minimum_size.y = 30.0
	cosmetic_button.pressed.connect(_cycle_focused_cosmetic)
	preview_column.add_child(cosmetic_button)
	crew_assignment_button = _make_secondary_button("", 450.0)
	crew_assignment_button.custom_minimum_size.y = 34.0
	crew_assignment_button.pressed.connect(_toggle_previewed_crew)
	preview_column.add_child(crew_assignment_button)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	body.add_child(grid)
	for member in ROSTER:
		var button := Button.new()
		# A portrait card has exactly one job: focus the turntable and details.
		# Assignment is an explicit action beneath the focused operative.
		button.custom_minimum_size = Vector2(250.0, 78.0)
		button.text = "%s\n%s  •  %s\nAVAILABLE" % [
			member["name"].to_upper(),
			member["role"],
			member["ability"],
		]
		button.add_theme_font_size_override("font_size", _scaled_font(10))
		button.icon = _portrait_texture(String(member["id"]))
		button.expand_icon = true
		button.add_theme_constant_override("icon_max_width", 56)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.add_theme_color_override("font_color", _ink)
		button.add_theme_color_override("font_pressed_color", Color("#fff4d2"))
		button.add_theme_stylebox_override("normal", _box_style(Color(0.028, 0.085, 0.095, 0.97), Color(member["accent"], 0.56), 6))
		button.add_theme_stylebox_override("hover", _box_style(Color(0.06, 0.15, 0.16, 0.99), Color(member["accent"]), 6))
		button.add_theme_stylebox_override("pressed", _box_style(Color(0.22, 0.17, 0.07, 0.99), _brass, 6))
		button.tooltip_text = "Inspect %s. Add or remove them below the turntable." % String(member["name"])
		button.pressed.connect(_preview_roster_member.bind(String(member["id"])))
		button.mouse_entered.connect(_preview_roster_member.bind(String(member["id"])))
		button.focus_entered.connect(_preview_roster_member.bind(String(member["id"])))
		grid.add_child(button)
		roster_buttons[String(member["id"])] = button

	var action_row := HBoxContainer.new()
	action_row.alignment = BoxContainer.ALIGNMENT_CENTER
	action_row.add_theme_constant_override("separation", 14)
	var back := _make_secondary_button("BACK TO JOB BRIEF", 220.0)
	back.pressed.connect(show_intro)
	action_row.add_child(back)
	confirm_button = _make_primary_button("BOARD THE TRAIN", 300.0)
	confirm_button.pressed.connect(_confirm_crew)
	action_row.add_child(confirm_button)
	front_content.add_child(action_row)
	_refresh_roster_selection()
	if _previewed_roster_id.is_empty() or roster_member(_previewed_roster_id).is_empty():
		_previewed_roster_id = selected_crew_ids[0] if not selected_crew_ids.is_empty() else "ada"
	_preview_roster_member(_previewed_roster_id)
	if roster_buttons.has(_previewed_roster_id):
		var initial_button := roster_buttons[_previewed_roster_id] as Button
		_schedule_focus(initial_button)


func _schedule_focus(control: Control) -> void:
	_focus_weak.call_deferred(weakref(control))


func _focus_weak(reference: WeakRef) -> void:
	var control = reference.get_ref()
	if is_instance_valid(control) and control.is_inside_tree() and control.is_visible_in_tree():
		control.grab_focus()


func set_continue_available(value: bool, summary: String = "") -> void:
	_continue_available = value
	_continue_summary = summary


func skip_to_mission() -> void:
	front_overlay.visible = false
	navigator.visible = not _cinematic_capture
	_refresh_navigator()


func is_frontend_open() -> bool:
	return is_instance_valid(front_overlay) and front_overlay.visible


func roster_member(member_id: String) -> Dictionary:
	for member in ROSTER:
		if String(member["id"]) == member_id:
			return member
	return {}


func update_train_progress(furthest_crew_x: int, selected_crew_x: int = -1) -> void:
	# Retained for compatibility with prototype calls. Seven-car progression is
	# now driven by the persistent run model, not x-position in one large scene.
	var _unused := furthest_crew_x + selected_crew_x


func update_run_progress(run_state: RefCounted) -> void:
	_active_run_state = run_state
	_refresh_navigator()


func show_intermission(run_state: RefCounted, reset_feedback: bool = false) -> void:
	_active_run_state = run_state
	if run_state.has_pending_crew_scene():
		show_crew_scene(run_state)
		return
	if reset_feedback or _management_feedback.is_empty():
		_reset_recovery_feedback(run_state)
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()

	_compact_management_frame()
	front_content.add_theme_constant_override("separation", 8)
	var kicker := _make_label("STEP 1 OF 2 / CAR %d SECURED / TRIAGE / %d HP RESTORED" % [run_state.completed_car_ids.size(), int(run_state.last_recovery.get("total", 0))], 11, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label("CHOOSE THE NEXT CAR", 26, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	front_content.add_child(_build_train_diagram(run_state, true))
	var buffs := _make_label("TRAIN BUFFS / %s" % run_state.squad_bonus_summary(), 10, _muted)
	buffs.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	buffs.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	buffs.tooltip_text = String(run_state.campaign_chapter().get("label", "THE TAKEOVER"))
	front_content.add_child(buffs)
	front_content.add_child(_build_offer_column(run_state))
	var instruction := _make_label("BOARD TO CONTINUE / REVIEW CREW TO TREAT WOUNDS", 10, _muted)
	instruction.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(instruction)


func show_crew_scene(run_state: RefCounted) -> void:
	_active_run_state = run_state
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	var data: Dictionary = run_state.crew_scene_data()
	var kicker := _make_label(String(data.get("chapter", "ACT BREAK / CREW COUNCIL")), 12, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label(String(data.get("title", "THE CREW DECIDES")), 38, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	var body := _make_label(String(data.get("prompt", data.get("body", "The route waits while the crew decides."))), 14, Color("#72b49c"))
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.custom_minimum_size = Vector2(920.0, 54.0)
	front_content.add_child(body)
	front_content.add_child(_build_train_diagram(run_state))
	var campaign_context: Dictionary = run_state.crew_campaign_context()
	var crew_readout: Array[String] = []
	var has_losses := false
	for crew_id in run_state.selected_crew_ids:
		var member: Dictionary = roster_member(crew_id)
		var operative: Dictionary = Dictionary(campaign_context.get("operatives", {})).get(crew_id, {})
		if run_state.crew_is_down(crew_id):
			has_losses = true
			crew_readout.append("%s / LOST" % String(member.get("name", crew_id)).to_upper())
		else:
			crew_readout.append("%s / %s %+d" % [String(member.get("name", crew_id)).to_upper(), String(operative.get("nerve_label", "TESTED")), int(operative.get("nerve", 0))])
	var crew_label := _make_label("CREW STATE / %s  •  BUILD / %s" % ["  ·  ".join(crew_readout), run_state.squad_bonus_summary()], 10, _muted)
	crew_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	crew_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	front_content.add_child(crew_label)
	var choice_row := HBoxContainer.new()
	choice_row.alignment = BoxContainer.ALIGNMENT_CENTER
	choice_row.add_theme_constant_override("separation", 12)
	for raw_choice in Array(data.get("choices", [])):
		var choice := Dictionary(raw_choice)
		var choice_id := String(choice.get("id", ""))
		var choice_title := "BRING THE REST HOME" if has_losses and choice_id == "bring_them_home" else String(choice.get("title", "CHOOSE"))
		var button := _make_secondary_button("%s\n%s\nRISK  %s" % [choice_title, String(choice.get("effect_short", choice.get("effect", "No effect"))), String(choice.get("risk_short", choice.get("risk", "None")))], 300.0)
		button.custom_minimum_size.y = 90.0
		button.add_theme_font_size_override("font_size", _scaled_font(10))
		button.pressed.connect(func() -> void: crew_scene_choice_requested.emit(choice_id))
		choice_row.add_child(button)
	front_content.add_child(choice_row)
	var instruction := _make_label("THE CHOICE PERSISTS.", 10, _brass)
	instruction.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(instruction)


func show_crew_prep(run_state: RefCounted, reset_feedback: bool = false) -> void:
	_active_run_state = run_state
	if reset_feedback or _management_feedback.is_empty():
		_reset_recovery_feedback(run_state)
	if _management_crew_id.is_empty() or _management_crew_id not in run_state.selected_crew_ids:
		_management_crew_id = ""
		for crew_id in run_state.selected_crew_ids:
			if not run_state.crew_is_down(crew_id):
				_management_crew_id = crew_id
				break
		if _management_crew_id.is_empty() and not run_state.selected_crew_ids.is_empty():
			_management_crew_id = run_state.selected_crew_ids[0]
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	front_content.add_theme_constant_override("separation", 8)
	_compact_management_frame()

	var car_data: Dictionary = run_state.car_data(run_state.pending_car_id)
	var kicker := _make_label("READY THE CREW / STEP 2 OF 2", 20, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var destination := PanelContainer.new()
	destination.add_theme_stylebox_override("panel", _box_style(Color(0.035, 0.10, 0.11, 0.97), Color(_brass, 0.62), 5))
	var destination_label := _make_label(
		"%s / THREAT %d\nON CLEAR: %s" % [
			String(car_data.get("name", run_state.pending_car_id)).to_upper(),
			int(car_data.get("difficulty", 1)),
			_route_reward_text(run_state, run_state.pending_car_id),
		],
		11,
		_ink
	)
	destination_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	destination_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	destination_label.custom_minimum_size.y = 42.0
	destination.add_child(destination_label)
	front_content.add_child(destination)
	var condition_row := HBoxContainer.new(); condition_row.alignment = BoxContainer.ALIGNMENT_CENTER; condition_row.add_theme_constant_override("separation", 8)
	for crew_id in run_state.selected_crew_ids:
		var crew_member := roster_member(crew_id)
		var readiness: Dictionary = run_state.crew_readiness(crew_id)
		var status := String(readiness.get("status", "READY"))
		var condition_card := PanelContainer.new(); condition_card.custom_minimum_size = Vector2(280, 42); condition_card.add_theme_stylebox_override("panel", _box_style(Color(0.025, 0.075, 0.082, 0.96), _danger if status in ["LOST", "CRIPPLED", "CRITICAL"] else _panel_border, 5))
		var condition_label := _make_label("%s / %s\n%s" % [String(crew_member.get("name", crew_id)).to_upper(), status, String(readiness.get("summary", ""))], 10, _ink); condition_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; condition_card.add_child(condition_label); condition_row.add_child(condition_card)
	front_content.add_child(condition_row)

	var body_row := HBoxContainer.new()
	body_row.add_theme_constant_override("separation", 16)
	body_row.alignment = BoxContainer.ALIGNMENT_CENTER
	body_row.add_child(_build_crew_stage_column(run_state))
	body_row.add_child(_build_prep_management_column(run_state))
	front_content.add_child(body_row)

	var action_row := HBoxContainer.new()
	action_row.alignment = BoxContainer.ALIGNMENT_CENTER
	action_row.add_theme_constant_override("separation", 14)
	var back_button := _make_secondary_button("‹ BACK TO ROUTE", 230.0)
	back_button.custom_minimum_size.y = 44.0
	back_button.pressed.connect(func() -> void: prep_back_requested.emit())
	action_row.add_child(back_button)
	prep_board_button = _make_primary_button("BOARD %s  ›" % String(car_data.get("name", "NEXT CAR")).to_upper(), 450.0)
	prep_board_button.custom_minimum_size.y = 44.0
	prep_board_button.disabled = _living_crew_count(run_state) <= 0
	prep_board_button.pressed.connect(func() -> void: next_car_chosen.emit(run_state.pending_car_id))
	action_row.add_child(prep_board_button)
	front_content.add_child(action_row)


func show_run_complete(run_state: RefCounted) -> void:
	_active_run_state = run_state
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	_compact_management_frame()
	front_content.add_theme_constant_override("separation", 8)
	var epilogue: Dictionary = run_state.campaign_epilogue()
	var kicker_text := "SEVEN CARS / TRAIN SEIZED / GRADE %s" % String(epilogue.get("grade", "C")) if String(run_state.ruleset_id) == "train_takeover" else "SEVEN CARS / BLUEPRINTS SECURED"
	var kicker := _make_label(kicker_text, 13, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label(String(epilogue.get("title", "THE BRASSLINE IS YOURS")), 32, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	var thesis := _make_label(String(epilogue.get("short_thesis", epilogue.get("thesis", "The Green Rail changes hands."))), 13, Color("#72b49c"))
	thesis.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	thesis.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	thesis.custom_minimum_size.x = 960.0
	front_content.add_child(thesis)
	front_content.add_child(_build_train_diagram(run_state, true))
	var summary := _make_label(
		"%s  •  %d SURVIVORS  •  %d DOCTRINES BROKEN" % [
			run_state.difficulty_label(),
			Array(epilogue.get("metrics", {}).get("survivors", [])).size(),
			int(Dictionary(epilogue.get("metrics", {})).get("doctrine_breaks", 0)),
		],
		15,
		_brass
	)
	summary.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(summary)
	var highlight_row := HBoxContainer.new(); highlight_row.alignment = BoxContainer.ALIGNMENT_CENTER; highlight_row.add_theme_constant_override("separation", 8)
	var highlight_metrics: Dictionary = epilogue.get("metrics", {})
	for highlight in ["%d DOCTRINES" % int(highlight_metrics.get("doctrine_breaks", 0)), "%d TRAIN COUNTERS" % int(highlight_metrics.get("train_counters", 0)), "%d CLEAN PLANS" % int(highlight_metrics.get("clean_plans", 0))]:
		highlight_row.add_child(_make_badge(highlight))
	front_content.add_child(highlight_row)
	var stats: Dictionary = run_state.run_stats
	var outcome: Dictionary = epilogue.get("metrics", {})
	var shots := int(stats.get("shots", 0))
	var hits := int(stats.get("hits", 0))
	var accuracy := roundi(float(hits) / maxf(1.0, float(shots)) * 100.0)
	var survivor_count := 0
	for crew_id in run_state.selected_crew_ids:
		if not run_state.crew_is_down(crew_id):
			survivor_count += 1
	var telemetry := _make_label(
		(
			"TACTICAL REPORT / %d CARS / %d SURVIVORS / %d KILLS / %d%% ACCURACY\n"
			+ "HEIST MASTERY / %d DOCTRINES BROKEN / %d TRAIN EVENTS COUNTERED / %d CLEAN PLANS\n"
			+ "%d SHOTS / %d MOVES / %d ROUNDS / %d RELOADS / %d SIGNATURES / %d ITEMS\n"
			+ "GUARD RESPONSE / %d SHOTS / %d COVER MOVES / %d FLANKS  •  TAKEOVER / %d SURRENDERS / %d CONTROL CLAIMS"
		) % [
			int(stats.get("cars_cleared", 0)), survivor_count, int(stats.get("kills", 0)), accuracy,
			int(outcome.get("doctrine_breaks", 0)), int(outcome.get("train_counters", 0)), int(outcome.get("clean_plans", 0)),
			shots, int(stats.get("moves", 0)), int(stats.get("rounds", 0)), int(stats.get("reloads", 0)),
			int(stats.get("abilities", 0)), int(stats.get("items_used", 0)),
			int(stats.get("ai_shots", 0)), int(stats.get("ai_cover_moves", 0)), int(stats.get("ai_flanks", 0)),
			int(stats.get("surrenders", 0)), int(stats.get("control_claims", 0)),
		],
		11,
		_ink
	)
	var detail_scroll := ScrollContainer.new()
	detail_scroll.name = "RunDetails"
	detail_scroll.custom_minimum_size.y = 120
	detail_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	detail_scroll.focus_mode = Control.FOCUS_ALL
	detail_scroll.follow_focus = true
	detail_scroll.visible = false
	front_content.add_child(detail_scroll)
	var detail_column := VBoxContainer.new()
	detail_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_scroll.add_child(detail_column)
	telemetry.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	telemetry.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail_column.add_child(telemetry)
	var crew_epilogue_lines: Array[String] = []
	for raw_line in Array(epilogue.get("crew_lines", [])):
		var crew_line := Dictionary(raw_line)
		var crew_id := String(crew_line.get("crew_id", ""))
		var crew_name := String(roster_member(crew_id).get("name", crew_id)).to_upper()
		crew_epilogue_lines.append("%s / %s — %s" % [crew_name, "FALLEN" if bool(crew_line.get("down", false)) else "SURVIVED", String(crew_line.get("line", "The run leaves a mark."))])
	var crew_epilogue := _make_label("CREW EPILOGUE / %s" % "  •  ".join(crew_epilogue_lines), 10, _brass)
	crew_epilogue.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	crew_epilogue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail_column.add_child(crew_epilogue)
	var challenge_code := profile_state.build_challenge_code(run_state.run_seed, run_state.difficulty_id, run_state.selected_crew_ids, run_state.ruleset_id) if is_instance_valid(profile_state) else ""
	var progression := _make_label("BLUEPRINT KNOWLEDGE / %d  •  RUN CODE / %s" % [profile_state.blueprint_knowledge if is_instance_valid(profile_state) else 0, challenge_code], 11, _green)
	progression.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(progression)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 10)
	var details := _make_secondary_button("DETAILS", 150.0)
	details.pressed.connect(func() -> void:
		detail_scroll.visible = not detail_scroll.visible
		details.text = "HIDE DETAILS" if detail_scroll.visible else "DETAILS"
	)
	row.add_child(details)
	var share := _make_secondary_button("SAVE HEIST CARD", 250.0)
	share.name = "SaveHeistCard"
	share.pressed.connect(func() -> void: share_card_requested.emit())
	row.add_child(share)
	var copy_code := _make_secondary_button("COPY CHALLENGE CODE", 270.0)
	copy_code.disabled = challenge_code.is_empty()
	copy_code.pressed.connect(func() -> void: challenge_code_copy_requested.emit(challenge_code))
	row.add_child(copy_code)
	var again := _make_primary_button("PLAN ANOTHER HEIST", 270.0)
	again.pressed.connect(show_intro)
	row.add_child(again)
	front_content.add_child(row)
	share_feedback_label = _make_label("", 11, _green)
	share_feedback_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	share_feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	front_content.add_child(share_feedback_label)


func set_share_ready(ready: bool) -> void:
	var button := front_content.find_child("SaveHeistCard", true, false) as Button
	if is_instance_valid(button):
		button.disabled = not ready
		button.text = "SAVE HEIST CARD" if ready else "PREPARING HEIST CARD"


func set_share_feedback(message: String, success: bool = true) -> void:
	if not is_instance_valid(share_feedback_label):
		return
	share_feedback_label.text = message
	share_feedback_label.add_theme_color_override("font_color", _green if success else _danger)


func show_run_failed(run_state: RefCounted, message: String, aftermath: Dictionary = {}) -> void:
	_active_run_state = run_state
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	var kicker := _make_label("THE LINE HELD / CAR %02d" % run_state.car_number(), 13, _danger)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label("THE HEIST BREAKS HERE", 40, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	var reason := _make_label(message.to_upper(), 15, _danger)
	reason.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reason.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	reason.custom_minimum_size.x = 850.0
	front_content.add_child(reason)
	front_content.add_child(_make_rule())
	var analysis: Dictionary = aftermath.get("failure_analysis", {})
	var analysis_grid := GridContainer.new()
	analysis_grid.columns = 2
	analysis_grid.add_theme_constant_override("h_separation", 12)
	analysis_grid.add_theme_constant_override("v_separation", 10)
	analysis_grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	front_content.add_child(analysis_grid)
	var analysis_entries := [
		["WHY THE PLAN BROKE", String(analysis.get("why_plan_broke", "The guard line outlasted the opening.")), _danger],
		["WHAT THE FALLBACK DID", String(analysis.get("fallback_effect", "The fallback did not change the result.")), _green],
		["DECISIVE INJURY", String(analysis.get("decisive_injury", "The final injury was not recorded.")), _brass],
		["SUGGESTED ADJUSTMENT", String(analysis.get("suggested_adjustment", "Change the plan family or fallback before retrying.")), _ink],
	]
	for entry in analysis_entries:
		var card := PanelContainer.new()
		card.custom_minimum_size = Vector2(440.0, 86.0)
		card.add_theme_stylebox_override("panel", _box_style(Color(0.026, 0.073, 0.077, 0.97), Color(entry[2], 0.66), 5))
		var label := _make_label("%s\n%s" % [String(entry[0]), String(entry[1])], 11, Color(entry[2]))
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		card.add_child(label)
		analysis_grid.add_child(card)
	var recovery := _make_label("RETRY restores the crew, supplies, and carriage to the moment before this fight. ABANDON ends this run and returns to the title.", 12, _brass)
	recovery.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	recovery.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	recovery.custom_minimum_size.x = 900.0
	front_content.add_child(recovery)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	var abandon := _make_secondary_button("ABANDON THIS RUN", 270.0)
	abandon.pressed.connect(func() -> void: abandon_requested.emit())
	row.add_child(abandon)
	var retry := _make_primary_button("RETRY THIS CAR", 330.0)
	retry.pressed.connect(func() -> void: retry_requested.emit())
	row.add_child(retry)
	front_content.add_child(row)


func show_car_event(run_state: RefCounted) -> void:
	_active_run_state = run_state
	front_overlay.visible = true
	navigator.visible = false
	_clear_front_content()
	var data: Dictionary = run_state.car_data(run_state.current_car_id)
	var kicker := _make_label("CAR %02d / NON-COMBAT OPPORTUNITY" % run_state.car_number(), 12, _brass)
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(kicker)
	var title := _make_label(String(data.get("name", "Quiet Car")).to_upper(), 42, _ink)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	front_content.add_child(title)
	front_content.add_child(_build_train_diagram(run_state))
	var description := _make_label(String(data.get("tagline", data.get("description", ""))), 17, _ink)
	description.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	description.custom_minimum_size = Vector2(760.0, 90.0)
	front_content.add_child(description)
	var reward := _make_badge("MAKE A CHOICE / WOUNDS PERSIST")
	var reward_row := HBoxContainer.new()
	reward_row.alignment = BoxContainer.ALIGNMENT_CENTER
	reward_row.add_child(reward)
	front_content.add_child(reward_row)
	var action_row := HBoxContainer.new()
	action_row.alignment = BoxContainer.ALIGNMENT_CENTER
	action_row.add_theme_constant_override("separation", 14)
	var rest := _make_primary_button("REST IN THE BERTHS\n+6 HEALING / NO SUPPLIES", 360.0)
	rest.custom_minimum_size.y = 70.0
	rest.pressed.connect(func() -> void: event_choice_requested.emit("rest"))
	action_row.add_child(rest)
	var scavenge := _make_secondary_button("RAID THE MEDICINE CABINETS\n+2 HEALING / 2 MEDKITS / 1 TONIC", 390.0)
	scavenge.custom_minimum_size.y = 70.0
	scavenge.pressed.connect(func() -> void: event_choice_requested.emit("scavenge"))
	action_row.add_child(scavenge)
	front_content.add_child(action_row)


func select_next_unlocked_car() -> void:
	if navigator.visible and is_instance_valid(_active_run_state):
		_show_car_alert("ROUTE CHOICES OPEN AFTER THE CURRENT CAR IS SECURED")


func set_cinematic_capture(value: bool) -> void:
	_cinematic_capture = value
	if value:
		navigator.visible = false
	elif not front_overlay.visible:
		navigator.visible = true


func _build_front_overlay() -> void:
	front_overlay = Control.new()
	front_overlay.name = "FrontEndOverlay"
	front_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	front_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(front_overlay)

	var blackout := ColorRect.new()
	blackout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	blackout.color = Color(0.005, 0.018, 0.021, 0.91)
	blackout.mouse_filter = Control.MOUSE_FILTER_STOP
	front_overlay.add_child(blackout)

	for side in [-1.0, 1.0]:
		var rail := ColorRect.new()
		rail.anchor_left = 0.5
		rail.anchor_right = 0.5
		rail.offset_left = side * 526.0 - 1.0
		rail.offset_right = side * 526.0 + 1.0
		rail.offset_top = 26.0
		rail.offset_bottom = -26.0
		rail.color = Color(_brass, 0.42)
		rail.mouse_filter = Control.MOUSE_FILTER_IGNORE
		front_overlay.add_child(rail)

	front_panel = PanelContainer.new()
	front_panel.anchor_left = 0.5
	front_panel.anchor_right = 0.5
	front_panel.anchor_top = 0.5
	front_panel.anchor_bottom = 0.5
	front_panel.offset_left = -520.0
	front_panel.offset_right = 520.0
	front_panel.offset_top = -330.0
	front_panel.offset_bottom = 330.0
	front_panel.add_theme_stylebox_override("panel", _box_style(_panel_color, _panel_border, 8))
	front_overlay.add_child(front_panel)

	var margin := _make_margin(44, 44, 30, 28)
	front_panel.add_child(margin)
	front_content = VBoxContainer.new()
	front_content.alignment = BoxContainer.ALIGNMENT_CENTER
	front_content.add_theme_constant_override("separation", 14)
	margin.add_child(front_content)


func _build_navigator() -> void:
	navigator = PanelContainer.new()
	navigator.name = "TrainNavigator"
	navigator.anchor_left = 0.0
	navigator.anchor_right = 0.0
	navigator.offset_left = 12.0
	navigator.offset_right = 708.0
	navigator.offset_top = 90.0
	navigator.offset_bottom = 156.0
	navigator.add_theme_stylebox_override("panel", _box_style(Color(0.012, 0.038, 0.044, 0.93), _panel_border, 6))
	add_child(navigator)
	var margin := _make_margin(12, 12, 8, 8)
	navigator.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 4)
	margin.add_child(column)
	navigator_label = _make_label("CAR 01 / 07  •  BOARDING CAR", 11, _brass)
	navigator_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	column.add_child(navigator_label)
	navigator_buff_label = _make_label("EARNED CAR BUFFS / NONE YET", 10, _muted)
	navigator_buff_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	column.add_child(navigator_buff_label)
	navigator.visible = false

	car_alert = _make_label("", 12, _brass)
	car_alert.anchor_left = 0.5
	car_alert.anchor_right = 0.5
	car_alert.offset_left = -210.0
	car_alert.offset_right = 210.0
	car_alert.offset_top = 160.0
	car_alert.offset_bottom = 186.0
	car_alert.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	car_alert.visible = false
	add_child(car_alert)
	_refresh_navigator()


func _build_train_diagram(run_state: RefCounted, compact: bool = false) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 5)
	var sequence: Array[String] = run_state.train_sequence()
	for index in range(7):
		var car_id := sequence[index] if index < sequence.size() else ""
		var complete: bool = index < run_state.completed_car_ids.size()
		var panel := PanelContainer.new()
		panel.custom_minimum_size = Vector2(110.0 if compact else 122.0, 50.0 if compact else 62.0)
		var border := _panel_border if complete else Color(_panel_border, 0.30)
		panel.add_theme_stylebox_override("panel", _box_style(Color(0.022, 0.066, 0.073, 0.96), border, 4))
		var margin := _make_margin(4, 4, 2, 2) if compact else _make_margin(8, 8, 7, 7)
		panel.add_child(margin)
		var stack := VBoxContainer.new()
		margin.add_child(stack)
		var name_text := "-" if compact else "UNROUTED"
		if not car_id.is_empty():
			name_text = _short_car_name(car_id) if compact else String(run_state.car_data(car_id).get("name", car_id)).to_upper()
		stack.add_child(_make_label("CAR %02d" % [index + 1], 10, _brass if complete else _muted))
		var car_label := _make_label(name_text, 10, _ink if not car_id.is_empty() else _muted.darkened(0.30))
		car_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		stack.add_child(car_label)
		row.add_child(panel)
		if index < 6:
			row.add_child(_make_label("-", 13, _muted))
	return row


func _build_offer_column(run_state: RefCounted) -> VBoxContainer:
	var column := VBoxContainer.new()
	column.custom_minimum_size.x = 920.0
	column.add_theme_constant_override("separation", 7)
	var cards := HBoxContainer.new()
	cards.alignment = BoxContainer.ALIGNMENT_CENTER
	cards.add_theme_constant_override("separation", 10)
	column.add_child(cards)
	for car_id in run_state.current_offers:
		var data: Dictionary = run_state.car_data(car_id)
		var card_column := VBoxContainer.new()
		card_column.custom_minimum_size.x = 300.0
		cards.add_child(card_column)
		var card := PanelContainer.new()
		card.custom_minimum_size = Vector2(300, 160)
		card.size_flags_vertical = Control.SIZE_EXPAND_FILL
		card.add_theme_stylebox_override("panel", _box_style(Color(0.028, 0.085, 0.095, 0.98), _panel_border, 5))
		card.tooltip_text = "%s\n%s" % [String(data.get("description", "")), String(data.get("challenge", ""))]
		card_column.add_child(card)
		var contents := VBoxContainer.new(); contents.add_theme_constant_override("separation", 6); card.add_child(contents)
		contents.add_child(_make_label(String(data.get("name", car_id)).to_upper(), 16, _ink))
		var profile := SignatureArcScript.car_profile(String(car_id))
		var hazard := String(profile.get("hazard_name", "REST / SUPPLIES"))
		var threat := _make_label("THREAT %d/4 / %s" % [int(data.get("difficulty", 1)), hazard], 10, _brass)
		threat.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; contents.add_child(threat)
		contents.add_child(_make_label("ON CLEAR", 10, _green))
		var reward := _make_label(_route_reward_text(run_state, String(car_id)), 11, _ink)
		reward.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; contents.add_child(reward)
		var actions := HBoxContainer.new(); actions.add_theme_constant_override("separation", 6); card_column.add_child(actions)
		var board := _make_primary_button("BOARD", 140)
		board.name = "Board_" + String(car_id); board.custom_minimum_size.y = 40
		board.pressed.connect(_choose_offer.bind(String(car_id))); actions.add_child(board)
		var review := _make_secondary_button("REVIEW CREW", 154)
		review.name = "Review_" + String(car_id); review.custom_minimum_size.y = 40
		review.pressed.connect(func() -> void: crew_review_requested.emit(String(car_id)))
		actions.add_child(review)
	return column


func _short_car_name(car_id: String) -> String:
	return String({"baggage": "BOARD", "observation": "LOOKOUT", "sleeper": "SLEEPER"}.get(car_id, car_id.to_upper()))


func _compact_management_frame() -> void:
	front_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	var margin := front_content.get_parent() as MarginContainer
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)


func _route_reward_text(run_state: RefCounted, car_id: String) -> String:
	# Use the same reward implementation on a detached copy so order bonuses are exact.
	if String(run_state.car_data(car_id).get("kind", "combat")) == "event":
		return "+6 healing OR +2 healing, 2 Medkits, 1 Tonic"
	var projection := RunStateScript.new()
	if not projection.load_from_save_data(run_state.to_save_data()):
		return String(run_state.car_data(car_id).get("buff_preview", "Unknown reward"))
	projection.current_car_id = car_id
	projection.phase = "encounter"
	var result := projection.complete_current_car()
	var buff := Dictionary(result.get("buff", {}))
	return " / ".join(PackedStringArray(buff.get("details", [])))


func _visual_roster() -> Array:
	var result: Array = []
	for raw_member in ROSTER:
		var member := Dictionary(raw_member).duplicate(true)
		member["cosmetic_id"] = profile_state.cosmetic_for(String(member["id"])) if is_instance_valid(profile_state) else "weathered"
		result.append(member)
	return result


func _portrait_texture(crew_id: String) -> Texture2D:
	var path := "res://assets/ui/portraits/%s.png" % crew_id
	return load(path) as Texture2D if ResourceLoader.exists(path) else null


func _cycle_focused_cosmetic() -> void:
	if not is_instance_valid(profile_state) or _previewed_roster_id.is_empty():
		return
	var cosmetics := profile_state.available_cosmetics(_previewed_roster_id)
	if cosmetics.size() < 2:
		return
	var index := cosmetics.find(profile_state.cosmetic_for(_previewed_roster_id))
	if profile_state.select_cosmetic(_previewed_roster_id, cosmetics[posmod(index + 1, cosmetics.size())]):
		profile_changed.emit()
		_preview_roster_member(_previewed_roster_id)


func _build_crew_stage_column(run_state: RefCounted) -> VBoxContainer:
	var column := VBoxContainer.new()
	column.custom_minimum_size.x = 460.0
	column.add_theme_constant_override("separation", 4)
	var stage_panel := PanelContainer.new()
	stage_panel.add_theme_stylebox_override("panel", _box_style(Color(0.008, 0.026, 0.031, 0.99), Color(_panel_border, 0.72), 6))
	crew_preview_stage = CrewPreviewStageScript.new()
	crew_preview_stage.setup(run_state, _visual_roster(), _management_crew_id)
	stage_panel.add_child(crew_preview_stage)
	column.add_child(stage_panel)

	var navigation := HBoxContainer.new()
	navigation.add_theme_constant_override("separation", 8)
	var previous := _make_secondary_button("‹ PREVIOUS", 105.0)
	previous.custom_minimum_size.y = 32.0
	previous.add_theme_font_size_override("font_size", _scaled_font(12))
	previous.pressed.connect(_rotate_management_crew.bind(-1))
	navigation.add_child(previous)
	var active_member := roster_member(_management_crew_id)
	var active_name := _make_label("%s / %s" % [
		String(active_member.get("name", _management_crew_id)).to_upper(),
		String(active_member.get("role", "OPERATIVE")),
	], 11, _brass)
	active_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	active_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	active_name.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	navigation.add_child(active_name)
	var next := _make_secondary_button("NEXT ›", 105.0)
	next.custom_minimum_size.y = 32.0
	next.add_theme_font_size_override("font_size", _scaled_font(12))
	next.pressed.connect(_rotate_management_crew.bind(1))
	navigation.add_child(next)
	column.add_child(navigation)

	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 5)
	for crew_id in run_state.selected_crew_ids:
		var member := roster_member(crew_id)
		var button := Button.new()
		button.custom_minimum_size = Vector2(150.0, 28.0)
		button.text = "%s%s" % [String(member.get("name", crew_id)).to_upper(), " / DOWN" if run_state.crew_is_down(crew_id) else ""]
		button.add_theme_font_size_override("font_size", _scaled_font(11))
		var selected: bool = crew_id == _management_crew_id
		var border := _danger if run_state.crew_is_down(crew_id) else (_brass if selected else _panel_border)
		button.add_theme_stylebox_override("normal", _box_style(Color(0.18, 0.12, 0.05, 0.98) if selected else Color(0.025, 0.075, 0.082, 0.98), border, 4))
		button.pressed.connect(_select_management_crew.bind(String(crew_id)))
		tabs.add_child(button)
	column.add_child(tabs)
	return column


func _build_prep_management_column(run_state: RefCounted) -> VBoxContainer:
	var column := VBoxContainer.new()
	column.custom_minimum_size.x = 400.0
	column.add_theme_constant_override("separation", 4)
	var member := roster_member(_management_crew_id)
	var down: bool = run_state.crew_is_down(_management_crew_id)
	var status_color := _danger if down else Color("#72b49c")
	column.add_child(_make_label("OPERATIVE READINESS / %s" % ("LOST" if down else "ACTIVE"), 11, status_color))
	var name_label := _make_label(String(member.get("name", _management_crew_id)).to_upper(), 23, _ink)
	column.add_child(name_label)
	var role_line := _make_label("%s / %s" % [String(member.get("role", "OPERATIVE")), String(member.get("ability", ""))], 10, _brass)
	role_line.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	column.add_child(role_line)
	var campaign_context: Dictionary = run_state.crew_campaign_context()
	var operative_state: Dictionary = Dictionary(campaign_context.get("operatives", {})).get(_management_crew_id, {})
	var trust_lines: Array[String] = []
	for raw_relationship in Array(campaign_context.get("relationships", [])):
		var relationship := Dictionary(raw_relationship)
		if _management_crew_id in Array(relationship.get("crew_ids", [])):
			var partner := ""
			for crew_id in Array(relationship.get("crew_ids", [])):
				if String(crew_id) != _management_crew_id:
					partner = String(roster_member(String(crew_id)).get("name", crew_id)).get_slice(" ", 0).to_upper()
			trust_lines.append("%s %s (%+d)" % [partner, String(relationship.get("label", "WORKING")), int(relationship.get("bond", 0))])
	var campaign_line := _make_label("NERVE / %s (%+d)  •  TRUST / %s  •  COMBAT EFFECT / %+d%% AIM, +%d%% CRIT" % [
		String(operative_state.get("nerve_label", "TESTED")), int(operative_state.get("nerve", 0)),
		" · ".join(trust_lines) if not trust_lines.is_empty() else "UNTESTED",
		roundi(run_state.crew_bond_accuracy_bonus(_management_crew_id) * 100.0) + mini(0, int(operative_state.get("nerve", 0))),
		maxi(0, int(operative_state.get("nerve", 0))),
	], 10, Color("#72b49c"))
	campaign_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	campaign_line.custom_minimum_size.y = 26.0
	campaign_line.visible = false
	column.add_child(campaign_line)
	var combat_line := _make_label("%s  •  DMG %.1f  •  RNG %d  •  MOVE %d  •  %s\nEARNED CAR BUFFS / %s" % [
		String(member.get("weapon", "UNKNOWN WEAPON")),
		float(member.get("damage", 0.0)) + float(run_state.squad_bonuses.get("damage", 0.0)),
		int(member.get("range", 0)) + int(run_state.squad_bonuses.get("range", 0)),
		int(member.get("move", 0)) + int(run_state.squad_bonuses.get("movement", 0)),
		String(member.get("ability", "NO SIGNATURE")),
		run_state.squad_bonus_summary(),
	], 10, _muted)
	combat_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	combat_line.custom_minimum_size.y = 34.0
	combat_line.visible = false
	column.add_child(combat_line)

	var body: Dictionary = run_state.body_state_for(_management_crew_id)
	var selected_readiness: Dictionary = run_state.crew_readiness(_management_crew_id)
	var health_heading := _make_label("BODY STATUS / %s" % String(selected_readiness.get("status", "READY")), 10, _brass)
	column.add_child(health_heading)
	var zone_readout := _make_label("%s\n%s" % [
		_zone_readout(body, Types.BodyZone.HEAD, "HEAD") + "  •  " + _zone_readout(body, Types.BodyZone.TORSO, "TORSO"),
		_zone_readout(body, Types.BodyZone.ARMS, "ARMS") + "  •  " + _zone_readout(body, Types.BodyZone.LEGS, "LEGS"),
	], 10, _ink)
	zone_readout.custom_minimum_size.y = 32.0
	column.add_child(zone_readout)

	var recommended_item := String(selected_readiness.get("treatment_recommended", ""))
	var recommendation := "RECOMMENDED / %s" % recommended_item.replace("_", " ").to_upper() if not recommended_item.is_empty() else String(selected_readiness.get("summary", "NO TREATMENT NEEDED"))
	column.add_child(_make_label(recommendation, 11, _green if recommendation == "NO TREATMENT NEEDED" else _brass))
	column.add_child(_make_label("TREATMENTS", 10, _muted))
	for item_id in ["medkit", "limb_brace"]:
		var count := int(run_state.inventory.get(item_id, 0))
		var preview: Dictionary = run_state.item_use_preview(item_id, _management_crew_id)
		var item_button := Button.new()
		item_button.custom_minimum_size = Vector2(400.0, 44.0)
		var effect := String(preview.get("description", preview.get("reason", "Unavailable")))
		item_button.text = "%s  x%d\n%s" % [item_id.replace("_", " ").to_upper(), count, effect.to_upper()]
		item_button.icon = _item_icon(item_id)
		item_button.add_theme_constant_override("icon_max_width", 38)
		item_button.expand_icon = true
		item_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		item_button.disabled = not bool(preview.get("can_use", false))
		item_button.tooltip_text = effect
		item_button.add_theme_font_size_override("font_size", _scaled_font(11))
		item_button.add_theme_stylebox_override("normal", _box_style(Color(0.08, 0.18, 0.14, 0.98), Color("#72b49c"), 4))
		item_button.add_theme_stylebox_override("hover", _box_style(Color(0.14, 0.29, 0.20, 1.0), _brass, 4))
		item_button.pressed.connect(_request_item.bind(item_id))
		column.add_child(item_button)
	management_feedback_label = _make_label(_management_feedback, 10, Color("#72b49c") if _management_feedback_success else _danger)
	management_feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	management_feedback_label.custom_minimum_size.y = 20.0
	column.add_child(management_feedback_label)
	return column


func _build_management_column(run_state: RefCounted) -> VBoxContainer:
	var column := VBoxContainer.new()
	column.custom_minimum_size.x = 310.0
	column.add_theme_constant_override("separation", 5)
	column.add_child(_make_label("FIELD TRIAGE / SAVES IMMEDIATELY", 12, _brass))
	for crew_id in run_state.selected_crew_ids:
		var member := roster_member(crew_id)
		var health := roundi(run_state.crew_health_ratio(crew_id) * 100.0)
		var down: bool = run_state.crew_is_down(crew_id)
		var body: Dictionary = run_state.body_state_for(crew_id)
		var vital_text := ""
		if not body.is_empty():
			vital_text = "  •  H %d/%d  T %d/%d" % [
				int(body[Types.BodyZone.HEAD]["hp"]), int(body[Types.BodyZone.HEAD]["max_hp"]),
				int(body[Types.BodyZone.TORSO]["hp"]), int(body[Types.BodyZone.TORSO]["max_hp"]),
			]
		var button := Button.new()
		button.custom_minimum_size = Vector2(310.0, 38.0)
		button.text = "%s  /  %s%s" % [String(member.get("name", crew_id)).to_upper(), "DOWN" if down else "%d%%" % health, "" if down else vital_text]
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.add_theme_font_size_override("font_size", _scaled_font(12))
		button.add_theme_stylebox_override(
			"normal",
			_box_style(Color(0.20, 0.15, 0.06, 0.98), _brass, 4)
			if crew_id == _management_crew_id
			else _box_style(Color(0.03, 0.09, 0.10, 0.96), _panel_border.darkened(0.22), 4)
		)
		button.disabled = down
		button.pressed.connect(_select_management_crew.bind(String(crew_id)))
		column.add_child(button)

	if not _management_crew_id.is_empty():
		var selected_member := roster_member(_management_crew_id)
		var selected_body: Dictionary = run_state.body_state_for(_management_crew_id)
		var selected_readout := _make_label(
			"SELECTED / %s\n%s\n%s\n%s" % [
				String(selected_member.get("name", _management_crew_id)).to_upper(),
				_zone_readout(selected_body, Types.BodyZone.HEAD, "HEAD") + "  •  " + _zone_readout(selected_body, Types.BodyZone.TORSO, "TORSO"),
				_zone_readout(selected_body, Types.BodyZone.ARMS, "ARMS"),
				_zone_readout(selected_body, Types.BodyZone.LEGS, "LEGS"),
			],
			10,
			_ink
		)
		selected_readout.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		selected_readout.custom_minimum_size.y = 60.0
		column.add_child(selected_readout)
	column.add_child(_make_label("SUPPLIES / EXACT EFFECT SHOWN BEFORE USE", 10, _muted))
	for item_id in ["medkit", "limb_brace"]:
		var count := int(run_state.inventory.get(item_id, 0))
		var preview: Dictionary = run_state.item_use_preview(item_id, _management_crew_id)
		var item_button := Button.new()
		item_button.custom_minimum_size = Vector2(310.0, 48.0)
		var effect := String(preview.get("description", preview.get("reason", "Unavailable")))
		item_button.text = "%s  x%d\n%s" % [item_id.replace("_", " ").to_upper(), count, effect.to_upper()]
		item_button.icon = _item_icon(item_id)
		item_button.add_theme_constant_override("icon_max_width", 42)
		item_button.expand_icon = true
		item_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		item_button.disabled = not bool(preview.get("can_use", false))
		item_button.tooltip_text = effect
		item_button.add_theme_font_size_override("font_size", _scaled_font(12))
		item_button.add_theme_stylebox_override("normal", _box_style(Color(0.08, 0.18, 0.14, 0.98), Color("#72b49c"), 4))
		item_button.add_theme_stylebox_override("hover", _box_style(Color(0.14, 0.29, 0.20, 1.0), _brass, 4))
		item_button.pressed.connect(_request_item.bind(item_id))
		column.add_child(item_button)
	management_feedback_label = _make_label(_management_feedback, 10, Color("#72b49c") if _management_feedback_success else _danger)
	management_feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	management_feedback_label.custom_minimum_size.y = 28.0
	column.add_child(management_feedback_label)
	column.add_child(_build_combat_kit_strip(run_state, 310.0))
	return column


func _choose_offer(car_id: String) -> void:
	car_prep_requested.emit(car_id)


func _select_management_crew(crew_id: String) -> void:
	_management_crew_id = crew_id
	_management_feedback = "Inspecting %s. Choose a supply only when its preview shows recovered HP." % String(roster_member(crew_id).get("name", crew_id))
	_management_feedback_success = true
	if is_instance_valid(_active_run_state):
		if _active_run_state.phase == "preparation":
			show_crew_prep(_active_run_state)
		else:
			show_intermission(_active_run_state)


func _rotate_management_crew(direction: int) -> void:
	if not is_instance_valid(_active_run_state) or _active_run_state.selected_crew_ids.is_empty():
		return
	var current_index: int = _active_run_state.selected_crew_ids.find(_management_crew_id)
	if current_index < 0:
		current_index = 0
	var next_index := posmod(current_index + direction, _active_run_state.selected_crew_ids.size())
	_select_management_crew(String(_active_run_state.selected_crew_ids[next_index]))


func _request_item(item_id: String) -> void:
	if _management_crew_id.is_empty():
		return
	item_requested.emit(item_id, _management_crew_id)


func set_management_feedback(message: String, success: bool) -> void:
	_management_feedback = message
	_management_feedback_success = success


func _reset_recovery_feedback(run_state: RefCounted) -> void:
	var recovered := int(run_state.last_recovery.get("total", 0))
	if recovered > 0:
		var recovered_crew: Array[String] = []
		for crew_id in Dictionary(run_state.last_recovery.get("crew", {})):
			var member := roster_member(String(crew_id))
			recovered_crew.append("%s +%d" % [
				String(member.get("name", crew_id)).to_upper(),
				int(run_state.last_recovery["crew"][crew_id]),
			])
		_management_feedback = "FIELD TRIAGE / %d HP RESTORED AUTOMATICALLY / %s" % [recovered, "  •  ".join(recovered_crew)]
	else:
		_management_feedback = "AFTER LAST CAR / 0 HP RESTORED BY AUTOMATIC TRIAGE"
	_management_feedback_success = true


func _living_crew_count(run_state: RefCounted) -> int:
	var count := 0
	for crew_id in run_state.selected_crew_ids:
		if not run_state.crew_is_down(crew_id):
			count += 1
	return count


func _zone_readout(body: Dictionary, zone: Types.BodyZone, short_name: String) -> String:
	if body.is_empty() or not body.has(zone):
		return "%s --" % short_name
	var state: Dictionary = body[zone]
	var condition := ""
	if bool(state.get("detached", false)):
		condition = " SEVERED"
	elif bool(state.get("disabled", false)):
		condition = " CRIPPLED"
	elif int(state["hp"]) < int(state["max_hp"]):
		condition = " WOUNDED"
	return "%s %d/%d%s" % [short_name, int(state["hp"]), int(state["max_hp"]), condition]


func _toggle_crew(member_id: String) -> void:
	_preview_roster_member(member_id)
	if member_id in selected_crew_ids:
		selected_crew_ids.erase(member_id)
	elif selected_crew_ids.size() < 3:
		selected_crew_ids.append(member_id)
	_refresh_roster_selection()


func _toggle_previewed_crew() -> void:
	if not _previewed_roster_id.is_empty():
		_toggle_crew(_previewed_roster_id)


func _preview_roster_member(member_id: String) -> void:
	var member := roster_member(member_id)
	if member.is_empty():
		return
	_previewed_roster_id = member_id
	var mastery := profile_state.mastery_for(member_id) if is_instance_valid(profile_state) else 0
	var cosmetic := profile_state.cosmetic_for(member_id) if is_instance_valid(profile_state) else "weathered"
	var scars: Array[String] = []
	if is_instance_valid(profile_state):
		scars.assign(profile_state.scars_for(member_id))
	var relationship_text := profile_state.relationship_summary_for(member_id) if is_instance_valid(profile_state) else "UNTESTED"
	if is_instance_valid(selection_preview_stage):
		selection_preview_stage.show_member(member, cosmetic)
	if is_instance_valid(selection_detail_label):
		selection_detail_label.text = "%s  /  %s\n%s\n%s\nDMG %.1f  /  RANGE %d  /  MOVE %d" % [
			String(member.get("name", member_id)).to_upper(),
			String(member.get("role", "OPERATIVE")),
			String(member.get("weapon", "UNKNOWN WEAPON")),
			_signature_summary(String(member.get("ability_id", ""))),
			float(member.get("damage", 0.0)),
			int(member.get("range", 0)),
			int(member.get("move", 0)),
		]
		selection_detail_label.tooltip_text = "SCARS / %s\nBONDS / %s\n%s" % ["NONE" if scars.is_empty() else ", ".join(scars).to_upper(), relationship_text, String(Dictionary(CombatCatalog.ABILITIES.get(String(member.get("ability_id", "")), {})).get("description", ""))]
	if is_instance_valid(cosmetic_button):
		cosmetic_button.text = "FINISH / %s  -  MASTERY %d" % [cosmetic.replace("_", " ").to_upper(), mastery]
		cosmetic_button.disabled = not is_instance_valid(profile_state) or profile_state.available_cosmetics(member_id).size() < 2
		cosmetic_button.tooltip_text = "Clear 3 cars with this operative for Brassbound; 7 for Night Rail. Click to cycle earned finishes."
	_refresh_roster_selection()


func _signature_summary(ability_id: String) -> String:
	return String({
		"deadeye": "DEADEYE / Next shot +25% hit, +20% crit. Once per car.",
		"breach_charge": "BREACH / Next shot +55% damage, +10% hit. Once per car.",
		"overclock": "OVERCLOCK / +1 action, +2 movement this turn. Once per car.",
		"field_repair": "REPAIR / Restore 4 HP to weakest intact zone. Once per car.",
		"quickdraw": "QUICKDRAW / +1 action, next shot +12% crit. Once per car.",
		"iron_stance": "STANCE / 40% less damage until next turn. Once per car.",
	}.get(ability_id, ""))


func _refresh_roster_selection() -> void:
	if not is_instance_valid(selection_label):
		return
	var names: Array[String] = []
	for member_id in selected_crew_ids:
		var member := roster_member(member_id)
		if not member.is_empty():
			names.append(String(member["name"]))
	selection_label.text = "CREW / %d OF 3  •  %s" % [selected_crew_ids.size(), ", ".join(names)]
	for member_id in roster_buttons:
		var button: Button = roster_buttons[member_id]
		var is_selected: bool = String(member_id) in selected_crew_ids
		var is_focused: bool = String(member_id) == _previewed_roster_id
		var member := roster_member(String(member_id))
		var accent: Color = member.get("accent", _panel_border)
		button.text = "%s\n%s  •  %s\n%s" % [
			String(member.get("name", member_id)).to_upper(),
			String(member.get("role", "OPERATIVE")),
			String(member.get("ability", "SIGNATURE")),
			"IN CREW" if is_selected else "AVAILABLE",
		]
		button.disabled = false
		button.add_theme_stylebox_override("normal", _box_style(
			Color(0.18, 0.13, 0.045, 0.97) if is_selected else Color(0.028, 0.085, 0.095, 0.97),
			accent.lightened(0.28) if is_focused else (_brass if is_selected else Color(accent, 0.56)),
			6
		))
	confirm_button.disabled = selected_crew_ids.size() != 3
	if is_instance_valid(crew_assignment_button) and not _previewed_roster_id.is_empty():
		var focus_member := roster_member(_previewed_roster_id)
		var focus_is_selected := _previewed_roster_id in selected_crew_ids
		crew_assignment_button.text = ("REMOVE %s FROM CREW" if focus_is_selected else "ADD %s TO CREW") % String(focus_member.get("name", _previewed_roster_id)).to_upper()
		crew_assignment_button.disabled = not focus_is_selected and selected_crew_ids.size() >= 3


func _confirm_crew() -> void:
	if selected_crew_ids.size() != 3:
		return
	front_overlay.visible = false
	navigator.visible = not _cinematic_capture
	crew_confirmed.emit(selected_crew_ids.duplicate())


func _select_car(index: int) -> void:
	if index < 0 or index > unlocked_car_index:
		return
	selected_car_index = index
	_refresh_navigator()
	car_selected.emit(index)


func _refresh_navigator() -> void:
	var completed_count := 0
	var active_car_id := ""
	if is_instance_valid(_active_run_state):
		completed_count = _active_run_state.completed_car_ids.size()
		active_car_id = String(_active_run_state.current_car_id)
		if active_car_id.is_empty():
			active_car_id = String(_active_run_state.pending_car_id)
	if is_instance_valid(navigator_label):
		var car_number := mini(7, completed_count + (1 if not active_car_id.is_empty() else 0))
		var car_name := "ROUTE SELECTION"
		if not active_car_id.is_empty() and is_instance_valid(_active_run_state):
			car_name = String(_active_run_state.car_data(active_car_id).get("name", active_car_id)).to_upper()
		navigator_label.text = "CAR %02d / 07  •  %s  •  %d CLEARED" % [car_number, car_name, completed_count]
	if is_instance_valid(navigator_buff_label):
		var summary := "NONE YET"
		if is_instance_valid(_active_run_state):
			summary = _active_run_state.squad_bonus_summary()
		navigator_buff_label.text = "EARNED CAR BUFFS / %s" % summary
		navigator_buff_label.add_theme_color_override("font_color", _muted if summary == "NONE YET" else Color("#72b49c"))


func _show_car_alert(message: String) -> void:
	car_alert.text = message
	car_alert.modulate.a = 1.0
	car_alert.visible = true
	var tween := car_alert.create_tween()
	tween.tween_interval(1.6)
	tween.tween_property(car_alert, "modulate:a", 0.0, 0.5)
	tween.tween_callback(func() -> void: car_alert.visible = false)


func _clear_front_content() -> void:
	front_content.add_theme_constant_override("separation", 14)
	management_feedback_label = null
	crew_preview_stage = null
	prep_board_button = null
	selection_preview_stage = null
	selection_detail_label = null
	for child in front_content.get_children():
		front_content.remove_child(child)
		child.queue_free()
	# Previous screens may have expanded this container to their minimum size.
	# Restore its centered frame before measuring the next screen's content.
	front_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	front_panel.offset_top = -330; front_panel.offset_bottom = 330
	front_panel.offset_left = -520; front_panel.offset_right = 520
	var margin := front_content.get_parent() as MarginContainer
	margin.add_theme_constant_override("margin_top", 30)
	margin.add_theme_constant_override("margin_bottom", 28)


func _make_emblem(edge: float) -> TextureRect:
	var emblem := TextureRect.new()
	emblem.texture = CrewEmblem
	emblem.custom_minimum_size = Vector2(edge, edge)
	emblem.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	emblem.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	emblem.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return emblem


func _item_icon(item_id: String) -> AtlasTexture:
	var texture := AtlasTexture.new()
	texture.atlas = load("res://assets/ui/items/brassline_item_atlas.png") as Texture2D
	var tile_size := texture.atlas.get_size() * 0.5
	var cells := {"medkit": Vector2.ZERO, "limb_brace": Vector2.RIGHT, "clockwork_grenade": Vector2.DOWN, "focus_tonic": Vector2.ONE}
	texture.region = Rect2(Vector2(cells.get(item_id, Vector2.ZERO)) * tile_size, tile_size)
	return texture


func _build_combat_kit_strip(run_state: RefCounted, width: float) -> HBoxContainer:
	var strip := HBoxContainer.new()
	strip.custom_minimum_size = Vector2(width, 28.0)
	strip.add_theme_constant_override("separation", 10)
	for item_id in ["clockwork_grenade", "focus_tonic"]:
		var badge := PanelContainer.new()
		badge.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var badge_style := _box_style(Color(0.045, 0.095, 0.095, 0.96), Color(_brass.darkened(0.30), 0.65), 4)
		badge_style.content_margin_top = 1.0
		badge_style.content_margin_bottom = 1.0
		badge_style.content_margin_left = 5.0
		badge_style.content_margin_right = 5.0
		badge.add_theme_stylebox_override("panel", badge_style)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 7)
		badge.add_child(row)
		var icon := TextureRect.new()
		icon.texture = _item_icon(item_id)
		icon.custom_minimum_size = Vector2(24.0, 24.0)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(icon)
		var count := int(run_state.inventory.get(item_id, 0))
		var label := _make_label("%s x%d / PLAN" % ["GRENADE" if item_id == "clockwork_grenade" else "TONIC", count], 7, _ink if count > 0 else _muted)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		strip.add_child(badge)
	return strip


func _make_badge(text: String) -> PanelContainer:
	var badge := PanelContainer.new()
	badge.add_theme_stylebox_override("panel", _box_style(Color(0.055, 0.12, 0.13, 0.86), Color(_brass, 0.48), 4))
	var margin := _make_margin(12, 12, 7, 7)
	badge.add_child(margin)
	margin.add_child(_make_label(text, 10, _ink))
	return badge


func _make_primary_button(text: String, width: float) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(width, 50.0)
	button.add_theme_font_size_override("font_size", _scaled_font(14))
	button.add_theme_color_override("font_color", Color("#fff2d0"))
	button.add_theme_stylebox_override("normal", _box_style(Color(0.35, 0.23, 0.06, 0.99), _brass, 5))
	button.add_theme_stylebox_override("hover", _box_style(Color(0.50, 0.33, 0.08, 1.0), Color("#ffe09a"), 5))
	button.add_theme_stylebox_override("disabled", _box_style(Color(0.07, 0.09, 0.09, 0.96), Color(0.2, 0.3, 0.3, 0.55), 5))
	return button


func _make_secondary_button(text: String, width: float) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(width, 50.0)
	button.add_theme_font_size_override("font_size", _scaled_font(12))
	button.add_theme_color_override("font_color", _ink)
	button.add_theme_stylebox_override("normal", _box_style(Color(0.04, 0.11, 0.12, 0.98), _panel_border, 5))
	button.add_theme_stylebox_override("hover", _box_style(Color(0.09, 0.23, 0.24, 1.0), _brass, 5))
	return button


func _make_label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	var readable_size := size
	if size <= 10:
		readable_size = size + 2
	elif size <= 13:
		readable_size = size + 1
	label.add_theme_font_size_override("font_size", _scaled_font(readable_size))
	label.add_theme_color_override("font_color", color)
	return label


func _scaled_font(size: int) -> int:
	return maxi(8, roundi(float(size) * text_scale))


func _make_rule() -> HSeparator:
	var rule := HSeparator.new()
	rule.add_theme_constant_override("separation", 10)
	return rule


func _make_margin(left: int, right: int, top: int, bottom: int) -> MarginContainer:
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", left)
	margin.add_theme_constant_override("margin_right", right)
	margin.add_theme_constant_override("margin_top", top)
	margin.add_theme_constant_override("margin_bottom", bottom)
	return margin


func _box_style(color: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 10.0
	style.content_margin_right = 10.0
	style.content_margin_top = 8.0
	style.content_margin_bottom = 8.0
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.34)
	style.shadow_size = 8
	return style
