class_name BrasslineAudioDirector
extends Node

const Types := preload("res://scripts/game_types.gd")

const AUDIO_ROOT := "res://assets/audio/kenney/"
const CUE_PATHS := {
	"weapon_1": "weapon_coil_1.ogg",
	"weapon_2": "weapon_coil_2.ogg",
	"weapon_3": "weapon_coil_3.ogg",
	"body_hit": "impact_body_heavy.ogg",
	"metal_heavy_1": "impact_metal_heavy_1.ogg",
	"metal_heavy_2": "impact_metal_heavy_2.ogg",
	"metal_medium_1": "impact_metal_medium_1.ogg",
	"metal_medium_2": "impact_metal_medium_2.ogg",
	"metal_light": "impact_metal_light.ogg",
	"glass": "impact_glass_heavy.ogg",
	"wood": "impact_wood_heavy.ogg",
	"bell": "impact_bell_heavy.ogg",
	"ability": "ability_power.ogg",
	"doctrine_break": "doctrine_break.ogg",
	"steam": "steam_zap.ogg",
	"casino_chips": "casino_chips.ogg",
	"casino_dice": "casino_dice.ogg",
	"ui_select": "ui_select.ogg",
	"ui_confirm": "ui_confirm.ogg",
	"ui_back": "ui_back.ogg",
	"ui_error": "ui_error.ogg",
	"ui_switch": "ui_switch.ogg",
	"ui_tick": "ui_tick.ogg",
	"ui_open": "ui_open.ogg",
	"ui_close": "ui_close.ogg",
}

var captions_enabled := true
var sfx_enabled := true
var ambience_enabled := true
var current_car_id := "baggage"

var _cues: Dictionary = {}
var _sfx_pool: Array[AudioStreamPlayer] = []
var _pool_index := 0
var _ambience_player: AudioStreamPlayer
var _caption_panel: PanelContainer
var _caption_label: Label
var _caption_serial := 0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.seed = 0xB2A551
	for cue_id in CUE_PATHS:
		var stream := load(AUDIO_ROOT + String(CUE_PATHS[cue_id])) as AudioStream
		if stream != null:
			_cues[cue_id] = stream
	for index in range(12):
		var player := AudioStreamPlayer.new()
		player.name = "SFX_%02d" % index
		add_child(player)
		_sfx_pool.append(player)
	_ambience_player = AudioStreamPlayer.new()
	_ambience_player.name = "LivingTrainAmbience"
	_ambience_player.stream = _build_train_ambience()
	_ambience_player.volume_db = -22.0
	add_child(_ambience_player)
	_ambience_player.play()
	_build_caption_layer()
	get_tree().node_added.connect(_on_node_added)
	_connect_existing_buttons.call_deferred()


func set_captions_enabled(enabled: bool) -> void:
	captions_enabled = enabled
	if not enabled and is_instance_valid(_caption_panel):
		_caption_panel.visible = false


func clear_caption() -> void:
	_caption_serial += 1
	if is_instance_valid(_caption_panel):
		_caption_panel.visible = false


func set_sfx_enabled(enabled: bool) -> void:
	sfx_enabled = enabled


func set_ambience_enabled(enabled: bool) -> void:
	ambience_enabled = enabled
	if is_instance_valid(_ambience_player):
		_ambience_player.volume_db = -22.0 if enabled else -80.0


func set_car(car_id: String) -> void:
	current_car_id = car_id
	if is_instance_valid(_ambience_player):
		_ambience_player.pitch_scale = 1.08 if car_id == "engine" else (0.94 if car_id in ["sleeper", "observation"] else 1.0)
	if car_id == "casino":
		_play_cue("casino_chips", "", -16.0, 0.98)


func play_plan_committed(plan: Dictionary) -> void:
	_play_cue("ui_confirm", "PLAN COMMITTED — %s" % String(plan.get("title", "THE CREW MOVES")).to_upper(), -9.0)


func play_consumable(item_id: String, unit: TacticalUnit) -> void:
	_play_cue("ability", "%s USES %s" % [unit.display_name.to_upper(), item_id.replace("_", " ").to_upper()], -10.0, 0.92)


func play_mission_result(victory: bool, message: String) -> void:
	_play_cue("ui_confirm" if victory else "ui_error", message.to_upper(), -7.0, 0.82 if victory else 0.72)


func on_round_started(round_number: int) -> void:
	_play_cue("ui_tick", "", -20.0, 0.90 + float(posmod(round_number, 3)) * 0.05)


func weapon_audio_profile(weapon_id: String) -> Dictionary:
	match weapon_id:
		"longshot_rifle": return {"cue": "weapon_1", "pitch": 0.82, "volume": -7.0, "label": "LONGSHOT"}
		"breach_gun": return {"cue": "weapon_2", "pitch": 0.65, "volume": -6.0, "label": "BREACH GUN"}
		"coil_pistol": return {"cue": "weapon_3", "pitch": 1.24, "volume": -9.0, "label": "COIL PISTOL"}
		"rivet_carbine": return {"cue": "weapon_1", "pitch": 1.08, "volume": -8.0, "label": "RIVET CARBINE"}
		"hand_cannon": return {"cue": "weapon_2", "pitch": 0.75, "volume": -6.0, "label": "HAND CANNON"}
		"duelist_revolver": return {"cue": "weapon_3", "pitch": 0.96, "volume": -8.0, "label": "DUELIST"}
	return {"cue": "weapon_1", "pitch": 1.0, "volume": -9.0, "label": "REVOLVER"}


func on_attack_resolved(attacker: TacticalUnit, _target: TacticalUnit, zone: Types.BodyZone, result: Dictionary) -> void:
	var sound := weapon_audio_profile(attacker.weapon_id if is_instance_valid(attacker) else "service_revolver")
	var hit := bool(result.get("hit", false))
	var caption := "%s — %s" % [String(sound["label"]), "MISS" if not hit else "%s HIT" % Types.zone_name(zone).to_upper()]
	if bool(result.get("detached", false)):
		caption = "%s SEVERED" % Types.zone_name(zone).to_upper()
	elif bool(result.get("disabled", false)):
		caption = "%s CRIPPLED" % Types.zone_name(zone).to_upper()
	_play_cue(String(sound["cue"]), caption, float(sound["volume"]), float(sound["pitch"]) * _rng.randf_range(0.98, 1.02))
	if hit:
		_play_cue("body_hit", "", -13.0, _rng.randf_range(0.88, 1.04))


func on_environment_resolved(action_id: String, _actor: TacticalUnit, result: Dictionary) -> void:
	var cue := "metal_heavy_1"
	if action_id in ["chandelier", "bottle_fire"]:
		cue = "glass"
	elif action_id == "steam_valve":
		cue = "steam"
	elif action_id == "lock_the_tables":
		cue = "casino_dice"
	var outcome := "COUNTER SET" if bool(result.get("train_counter", false)) else "ENVIRONMENT TRIGGERED"
	_play_cue(cue, "%s — %s" % [action_id.replace("_", " ").to_upper(), outcome], -8.0)


func on_train_event(event: Dictionary, result: Dictionary) -> void:
	var warning := String(event.get("phase", "warning")) == "warning"
	if warning:
		_play_cue("bell", "TRAIN WARNING — %s" % String(event.get("title", "THE CARRIAGE MOVES")).to_upper(), -10.0, 0.86)
		return
	var cue := "metal_heavy_2"
	if current_car_id in ["bar", "observation"]:
		cue = "glass"
	elif current_car_id == "dining":
		cue = "wood"
	elif current_car_id == "engine":
		cue = "steam"
	var caption := "%s — %s" % [String(event.get("title", "TRAIN EVENT")).to_upper(), "COUNTERED" if bool(result.get("countered", false)) else "IMPACT"]
	_play_cue(cue, caption, -8.0)


func on_doctrine_changed(doctrine: Dictionary) -> void:
	if bool(doctrine.get("broken", false)):
		_play_cue("doctrine_break", "DOCTRINE BROKEN — %s" % String(doctrine.get("name", "GUARD LINE")).to_upper(), -10.0, 0.78)
	elif String(doctrine.get("status", "")) == "active":
		_play_cue("ui_open", "ENEMY DOCTRINE — %s" % String(doctrine.get("name", "GUARD LINE")).to_upper(), -18.0, 0.72)


func _play_cue(cue_id: String, caption: String = "", volume_db: float = -10.0, pitch: float = 1.0) -> void:
	if not sfx_enabled or not _cues.has(cue_id) or _sfx_pool.is_empty():
		if not caption.is_empty():
			_show_caption(caption)
		return
	var player := _sfx_pool[_pool_index]
	_pool_index = (_pool_index + 1) % _sfx_pool.size()
	player.stop()
	player.stream = _cues[cue_id]
	player.volume_db = volume_db
	player.pitch_scale = pitch
	player.play()
	if not caption.is_empty():
		_show_caption(caption)


func _build_caption_layer() -> void:
	var layer := CanvasLayer.new()
	layer.name = "AudioCaptionLayer"
	layer.layer = 95
	add_child(layer)
	_caption_panel = PanelContainer.new()
	_caption_panel.name = "AudioCaption"
	_caption_panel.anchor_left = 0.5
	_caption_panel.anchor_right = 0.5
	_caption_panel.offset_left = -300.0
	_caption_panel.offset_right = 300.0
	_caption_panel.offset_top = 128.0
	_caption_panel.offset_bottom = 158.0
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.006, 0.020, 0.024, 0.90)
	style.border_color = Color("#3e7774")
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	_caption_panel.add_theme_stylebox_override("panel", style)
	layer.add_child(_caption_panel)
	_caption_label = Label.new()
	_caption_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_caption_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_caption_label.add_theme_font_size_override("font_size", 11)
	_caption_label.add_theme_color_override("font_color", Color("#e6f3ee"))
	_caption_panel.add_child(_caption_label)
	_caption_panel.visible = false


func _show_caption(text_value: String) -> void:
	if not captions_enabled or not is_instance_valid(_caption_panel):
		return
	_caption_serial += 1
	var serial := _caption_serial
	_caption_label.text = "[SOUND]  %s" % text_value
	_caption_panel.visible = true
	_hide_caption_later(serial)


func _hide_caption_later(serial: int) -> void:
	await get_tree().create_timer(1.25).timeout
	if serial == _caption_serial and is_instance_valid(_caption_panel):
		_caption_panel.visible = false


func _connect_existing_buttons() -> void:
	for node in get_tree().get_nodes_in_group("__brassline_audio_buttons"):
		_connect_button(node)
	_connect_buttons_recursive(get_tree().root)


func _connect_buttons_recursive(node: Node) -> void:
	if node is Button:
		_connect_button(node)
	for child in node.get_children():
		_connect_buttons_recursive(child)


func _on_node_added(node: Node) -> void:
	if node is Button:
		# UI rebuilds may free the button before this runs. Resolve its ID before
		# passing a typed Node argument, which otherwise fails during conversion.
		_connect_button_id.call_deferred(node.get_instance_id())


func _connect_button_id(instance_id: int) -> void:
	if not is_instance_id_valid(instance_id):
		return
	var node := instance_from_id(instance_id)
	if node is Button and not node.is_queued_for_deletion():
		_connect_button(node)


func _connect_button(node: Node) -> void:
	var button := node as Button
	if not is_instance_valid(button) or button.has_meta("brassline_audio_hook"):
		return
	button.set_meta("brassline_audio_hook", true)
	button.add_to_group("__brassline_audio_buttons")
	button.pressed.connect(_on_button_pressed.bind(button))


func _on_button_pressed(button: Button) -> void:
	var label := button.text.to_upper()
	if "BACK" in label or "RETURN" in label or "CANCEL" in label:
		_play_cue("ui_back", "", -18.0)
	elif "COMMIT" in label or "BOARD" in label or "CONTINUE" in label or "FINISH" in label or "ASSEMBLE" in label or "SAVE" in label:
		_play_cue("ui_confirm", "", -16.0)
	else:
		_play_cue("ui_select", "", -20.0)


func _build_train_ambience() -> AudioStreamWAV:
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 22050
	stream.stereo = false
	var seconds := 6.0
	var frames := int(float(stream.mix_rate) * seconds)
	var data := PackedByteArray()
	data.resize(frames * 2)
	for frame in range(frames):
		var t := float(frame) / float(stream.mix_rate)
		var wheel_phase := fmod(t, 0.72)
		var second_wheel_phase := fmod(t + 0.36, 0.72)
		var wheel := exp(-wheel_phase * 20.0) * sin(TAU * 82.0 * t)
		wheel += exp(-second_wheel_phase * 20.0) * sin(TAU * 67.0 * t)
		var boiler := sin(TAU * 44.0 * t) * 0.12 + sin(TAU * 88.4 * t) * 0.045
		var pseudo_noise := fmod(sin(float(frame) * 12.9898) * 43758.5453, 1.0) * 2.0 - 1.0
		var sample := clampf(wheel * 0.18 + boiler + pseudo_noise * 0.018, -0.92, 0.92)
		data.encode_s16(frame * 2, roundi(sample * 32767.0))
	stream.data = data
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = frames
	return stream
