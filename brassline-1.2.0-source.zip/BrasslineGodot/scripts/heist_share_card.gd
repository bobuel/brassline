class_name BrasslineHeistShareCard
extends Control

const CARD_SIZE := Vector2i(1280, 720)

var brass := Color("#e3b65c")
var ink := Color("#e5f6f2")
var green := Color("#72d8b6")
var muted := Color("#8fb3b2")
var danger := Color("#ff7d6e")


func setup(data: Dictionary) -> void:
	custom_minimum_size = CARD_SIZE
	size = CARD_SIZE
	var background := ColorRect.new()
	background.position = Vector2.ZERO
	background.size = CARD_SIZE
	background.color = Color("#071416")
	add_child(background)
	_add_rail(Vector2(30, 28), Vector2(1220, 4))
	_add_rail(Vector2(30, 688), Vector2(1220, 4))

	var title := _label("BRASSLINE / HEIST RECORD", 38, ink)
	title.position = Vector2(64, 50)
	title.size = Vector2(780, 54)
	add_child(title)
	var route := _label(String(data.get("route", "THE GREEN RAIL")).to_upper(), 17, muted)
	route.position = Vector2(66, 108)
	route.size = Vector2(880, 34)
	add_child(route)
	var grade := _label("GRADE %s" % String(data.get("grade", "C")), 54, brass)
	grade.position = Vector2(960, 44)
	grade.size = Vector2(250, 78)
	grade.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	add_child(grade)

	var crew_panel := PanelContainer.new()
	crew_panel.position = Vector2(58, 170)
	crew_panel.size = Vector2(560, 416)
	crew_panel.add_theme_stylebox_override("panel", _style(Color("#0b2528"), Color(brass, 0.66), 8))
	add_child(crew_panel)
	var crew_margin := MarginContainer.new()
	crew_margin.add_theme_constant_override("margin_left", 24)
	crew_margin.add_theme_constant_override("margin_right", 24)
	crew_margin.add_theme_constant_override("margin_top", 20)
	crew_margin.add_theme_constant_override("margin_bottom", 20)
	crew_panel.add_child(crew_margin)
	var crew_column := VBoxContainer.new()
	crew_column.add_theme_constant_override("separation", 12)
	crew_margin.add_child(crew_column)
	crew_column.add_child(_label("CREW / WHAT THE TRAIN LEFT BEHIND", 16, brass))
	for raw_crew in Array(data.get("crew", [])):
		var crew := Dictionary(raw_crew)
		var row := HBoxContainer.new()
		row.custom_minimum_size.y = 92
		row.add_theme_constant_override("separation", 14)
		crew_column.add_child(row)
		var crew_id := String(crew.get("id", String(crew.get("name", "")).get_slice(" ", 0).to_lower()))
		var portrait_path := "res://assets/ui/portraits/%s.png" % crew_id
		if ResourceLoader.exists(portrait_path):
			var portrait := TextureRect.new()
			portrait.name = "Portrait_%s" % crew_id
			portrait.texture = load(portrait_path)
			portrait.custom_minimum_size = Vector2(82, 92)
			portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			if String(crew.get("condition", "")).begins_with("FALLEN"):
				portrait.modulate = Color(0.62, 0.55, 0.55)
			row.add_child(portrait)
		var line := _label(
			"%s / %s\n%s  •  MASTERY %d  •  %s" % [
				String(crew.get("name", "OPERATIVE")).to_upper(),
				String(crew.get("role", "CREW")),
				String(crew.get("condition", "SURVIVED")),
				int(crew.get("mastery", 0)),
				String(crew.get("finish", "WEATHERED")).replace("_", " ").to_upper(),
			],
			17,
			ink if not String(crew.get("condition", "")).begins_with("FALLEN") else danger
		)
		line.custom_minimum_size.y = 92
		line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		line.max_lines_visible = 4
		line.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		line.add_theme_stylebox_override("normal", _style(Color("#0a1d20"), Color(muted, 0.38), 5))
		row.add_child(line)

	var story_panel := PanelContainer.new()
	story_panel.position = Vector2(644, 170)
	story_panel.size = Vector2(578, 416)
	story_panel.add_theme_stylebox_override("panel", _style(Color("#0a1d20"), Color(green, 0.58), 8))
	add_child(story_panel)
	var story_margin := MarginContainer.new()
	for side in ["margin_left", "margin_right"]:
		story_margin.add_theme_constant_override(side, 28)
	story_margin.add_theme_constant_override("margin_top", 24)
	story_margin.add_theme_constant_override("margin_bottom", 24)
	story_panel.add_child(story_margin)
	var story_column := VBoxContainer.new()
	story_column.add_theme_constant_override("separation", 16)
	story_margin.add_child(story_column)
	story_column.add_child(_label("DECISIVE MOMENT", 16, brass))
	var decisive := _label(String(data.get("decisive_moment", "The crew took the locomotive.")), 25, ink)
	decisive.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decisive.custom_minimum_size.y = 116
	decisive.max_lines_visible = 4
	decisive.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	story_column.add_child(decisive)
	story_column.add_child(HSeparator.new())
	story_column.add_child(_label("RUN / %d  •  %s  •  %d SURVIVORS" % [int(data.get("seed", 0)), String(data.get("difficulty", "STANDARD")).to_upper(), int(data.get("survivors", 0))], 17, green))
	var injuries := _label("INJURIES / %s" % String(data.get("injuries", "NO LASTING INJURIES")), 16, danger)
	injuries.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	injuries.custom_minimum_size.y = 72
	injuries.max_lines_visible = 3
	injuries.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	story_column.add_child(injuries)
	story_column.add_child(_label("BLUEPRINT KNOWLEDGE / %d" % int(data.get("blueprint_knowledge", 0)), 17, brass))

	var code := _label("CHALLENGE CODE / %s" % String(data.get("run_code", "UNAVAILABLE")), 18, ink)
	code.position = Vector2(62, 614)
	code.size = Vector2(1160, 42)
	code.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(code)
	var footer := _label("SAME SEED / SAME ROUTE RULES / SIDEGRADES ONLY", 13, muted)
	footer.position = Vector2(62, 655)
	footer.size = Vector2(1160, 24)
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(footer)


func _add_rail(position_value: Vector2, size_value: Vector2) -> void:
	var rail := ColorRect.new()
	rail.position = position_value
	rail.size = size_value
	rail.color = brass
	add_child(rail)


func _label(text_value: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text_value
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return label


func _style(color: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style
