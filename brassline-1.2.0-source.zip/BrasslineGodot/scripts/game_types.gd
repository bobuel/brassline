class_name BrasslineTypes
extends RefCounted

enum Team {
	PLAYER,
	ENEMY,
}

enum Phase {
	PLAYER,
	ENEMY,
	BUSY,
	VICTORY,
	DEFEAT,
}

enum BodyZone {
	HEAD,
	TORSO,
	ARMS,
	LEGS,
}

const BODY_ZONE_NAMES := {
	BodyZone.HEAD: "Head",
	BodyZone.TORSO: "Torso",
	BodyZone.ARMS: "Arms",
	BodyZone.LEGS: "Legs",
}

const BODY_ZONE_SHORTCUTS := {
	BodyZone.HEAD: "1",
	BodyZone.TORSO: "2",
	BodyZone.ARMS: "3",
	BodyZone.LEGS: "4",
}

const BODY_ZONE_MAX_HP := {
	BodyZone.HEAD: 4,
	BodyZone.TORSO: 8,
	BodyZone.ARMS: 8,
	BodyZone.LEGS: 9,
}

const BODY_ZONE_AIM_PENALTY := {
	BodyZone.HEAD: 0.24,
	BodyZone.TORSO: 0.0,
	BodyZone.ARMS: 0.11,
	BodyZone.LEGS: 0.09,
}

const BODY_ZONE_DAMAGE_MULTIPLIER := {
	BodyZone.HEAD: 1.45,
	BodyZone.TORSO: 1.0,
	BodyZone.ARMS: 0.86,
	BodyZone.LEGS: 0.90,
}

const BODY_ZONE_AP_COST := {
	BodyZone.HEAD: 2,
	BodyZone.TORSO: 1,
	BodyZone.ARMS: 2,
	BodyZone.LEGS: 2,
}

const BODY_ZONE_EFFECT := {
	BodyZone.HEAD: "Lethal critical / severe aim penalty",
	BodyZone.TORSO: "Reliable center-mass damage",
	BodyZone.ARMS: "Cripple: -36% accuracy, half damage, no reload or overwatch",
	BodyZone.LEGS: "Cripple: movement reduced to 1 and cannot take cover",
}

static func zone_name(zone: BodyZone) -> String:
	return BODY_ZONE_NAMES.get(zone, "Unknown")

static func zone_ap_cost(zone: BodyZone) -> int:
	return int(BODY_ZONE_AP_COST.get(zone, 1))

static func zone_effect(zone: BodyZone) -> String:
	return BODY_ZONE_EFFECT.get(zone, "")

static func is_severable(zone: BodyZone) -> bool:
	return zone in [BodyZone.ARMS, BodyZone.LEGS]

static func team_name(team: Team) -> String:
	return "Crew" if team == Team.PLAYER else "Rail Guard"
