class_name CrewSelectionStage
extends SubViewportContainer

const Types := preload("res://scripts/game_types.gd")
const CharacterVisualScript := preload("res://scripts/character_visual.gd")
const CHARACTER_ROOT := "res://assets/characters/quaternius/"

var viewport_3d: SubViewport
var stage_root: Node3D
var active_visual: CharacterVisual
var active_member_id := ""
var _dragging := false


func _ready() -> void:
	custom_minimum_size = Vector2(430.0, 330.0)
	stretch = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	tooltip_text = "Drag to inspect the operative and their equipped weapon."
	gui_input.connect(_on_gui_input)
	viewport_3d = SubViewport.new()
	viewport_3d.name = "CrewSelectionViewport"
	viewport_3d.size = Vector2i(860, 660)
	viewport_3d.transparent_bg = true
	viewport_3d.own_world_3d = true
	viewport_3d.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport_3d.msaa_3d = Viewport.MSAA_2X
	add_child(viewport_3d)
	stage_root = Node3D.new()
	stage_root.name = "ManifestTurntable"
	viewport_3d.add_child(stage_root)
	_build_environment()


func show_member(member: Dictionary, cosmetic_id: String = "weathered") -> void:
	if member.is_empty() or not is_instance_valid(stage_root):
		return
	active_member_id = String(member.get("id", ""))
	if is_instance_valid(active_visual):
		active_visual.queue_free()
	active_visual = CharacterVisualScript.new()
	active_visual.name = "Manifest_%s" % active_member_id
	active_visual.position = Vector3(0.0, 0.02, 0.0)
	stage_root.add_child(active_visual)
	if active_visual.setup(CHARACTER_ROOT + String(member.get("model", "Casual_2.gltf")), Types.Team.PLAYER):
		active_visual.build_weapon(String(member.get("weapon_id", "service_revolver")))
		active_visual.apply_cosmetic_palette(cosmetic_id)
		active_visual.play_idle()


func _build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#061116")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#8bbab3")
	environment.ambient_light_energy = 0.68
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = true
	environment.glow_intensity = 0.38
	world_environment.environment = environment
	stage_root.add_child(world_environment)

	var camera := Camera3D.new()
	camera.name = "ManifestCamera"
	camera.fov = 35.0
	camera.look_at_from_position(Vector3(0.0, 1.30, 4.0), Vector3(0.0, 1.03, 0.0), Vector3.UP)
	camera.current = true
	stage_root.add_child(camera)

	var key := DirectionalLight3D.new()
	key.light_color = Color("#ffd58d")
	key.light_energy = 1.75
	key.rotation_degrees = Vector3(-36.0, -32.0, 0.0)
	key.shadow_enabled = true
	stage_root.add_child(key)
	var rim := DirectionalLight3D.new()
	rim.light_color = Color("#5dd8e2")
	rim.light_energy = 1.10
	rim.rotation_degrees = Vector3(-25.0, 142.0, 0.0)
	stage_root.add_child(rim)

	var floor := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(5.2, 4.0)
	floor.mesh = plane
	floor.material_override = _material(Color("#17343a"), 0.70, 0.46)
	stage_root.add_child(floor)
	var ring := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.66
	torus.outer_radius = 0.73
	torus.rings = 36
	torus.ring_segments = 12
	ring.mesh = torus
	ring.position.y = 0.018
	ring.material_override = _material(Color("#e3b65c"), 0.88, 0.22, true)
	stage_root.add_child(ring)
	for x_value in [-2.15, 2.15]:
		_add_box(Vector3(0.08, 3.1, 0.10), Vector3(x_value, 1.50, -0.75), _material(Color("#a47431"), 0.86, 0.32))
	_add_box(Vector3(4.38, 0.08, 0.10), Vector3(0.0, 3.0, -0.75), _material(Color("#a47431"), 0.86, 0.32))
	_add_box(Vector3(4.4, 3.1, 0.12), Vector3(0.0, 1.50, -0.82), _material(Color("#09171b"), 0.55, 0.72))


func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_dragging = event.pressed
		accept_event()
	elif event is InputEventMouseMotion and _dragging and is_instance_valid(active_visual):
		active_visual.rotate_y(-event.relative.x * 0.012)
		accept_event()


func _add_box(size: Vector3, position_value: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	instance.mesh = box
	instance.position = position_value
	instance.material_override = material
	stage_root.add_child(instance)
	return instance


func _material(color: Color, metallic: float, roughness: float, emission: bool = false) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if emission:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.65
	return material
