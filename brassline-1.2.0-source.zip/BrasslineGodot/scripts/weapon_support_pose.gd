class_name WeaponSupportPose
extends SkeletonModifier3D

var character: Node3D
var mount: Node3D
var gun: Node3D
var animation_player: AnimationPlayer
var support_grip := Vector3(0.025,-0.045,0.17)
var last_hand_error := 0.0
var arms_available := true


func _process_modification_with_delta(_delta: float) -> void:
	_update_supported_pose()


func _process_modification() -> void:
	_update_supported_pose()


func _update_supported_pose() -> void:
	var rig := get_skeleton()
	if not is_instance_valid(rig) or not is_instance_valid(gun) or not arms_available: return
	var clip := String(animation_player.assigned_animation) if is_instance_valid(animation_player) else ""
	var ready := clip.contains("Gun") or clip.contains("Run") or clip.contains("Walk") or clip == "Idle"
	if not ready: return
	var chest_index := rig.find_bone("Chest")
	if chest_index<0:return
	var chest_local := character.to_local(rig.global_transform * rig.get_bone_global_pose(chest_index).origin)
	var aimed := clip.contains("Pointing") or clip.contains("Shoot")
	mount.position=chest_local+Vector3(-0.035,-0.005,0.21)
	mount.rotation_degrees=Vector3(0.0 if aimed else 14.0,-3.0 if aimed else -12.0,0.0)
	var world_basis := gun.global_basis.orthonormalized()
	var right_hand := gun.to_global(Vector3(0,-0.058,-0.080))
	var left_hand := gun.to_global(support_grip+Vector3(0,0.025,-0.09))
	_solve_arm(rig,"R",right_hand,character.global_basis*Vector3(-0.40,-0.32,-0.05),Basis(-world_basis.y,world_basis.z,-world_basis.x))
	_solve_arm(rig,"L",left_hand,character.global_basis*Vector3(0.40,-0.32,0.05),Basis(-world_basis.x,world_basis.z,world_basis.y))
	for finger in ["Index","Middle","Ring","Pinky"]:
		for joint in [2,3,4]:
			var bone:=rig.find_bone("%s%d.L"%[finger,joint])
			if bone>=0:
				var rest:=rig.get_bone_rest(bone).basis.get_rotation_quaternion()
				rig.set_bone_pose_rotation(bone,rest*Quaternion(Vector3.RIGHT,0.95 if joint==2 else 1.1))
	last_hand_error=maxf((rig.global_transform*rig.get_bone_global_pose(rig.find_bone("Wrist.R"))).origin.distance_to(right_hand),(rig.global_transform*rig.get_bone_global_pose(rig.find_bone("Wrist.L"))).origin.distance_to(left_hand))


func _solve_arm(rig: Skeleton3D, side: String, world_target: Vector3, world_pole: Vector3, hand_basis: Basis) -> void:
	var upper:=rig.find_bone("UpperArm."+side); var lower:=rig.find_bone("LowerArm."+side); var wrist:=rig.find_bone("Wrist."+side)
	if upper<0 or lower<0 or wrist<0:return
	var a:=rig.get_bone_global_pose(upper); var b:=rig.get_bone_global_pose(lower); var c:=rig.get_bone_global_pose(wrist)
	var target:=rig.to_local(world_target)
	var l1:=a.origin.distance_to(b.origin); var l2:=b.origin.distance_to(c.origin)
	var direction:=(target-a.origin).normalized(); var distance:=clampf(a.origin.distance_to(target),0.02,l1+l2-0.002)
	target=a.origin+direction*distance
	var pole:=rig.global_basis.inverse()*world_pole
	pole=(pole-direction*pole.dot(direction)).normalized()
	var along:=(l1*l1-l2*l2+distance*distance)/(2.0*distance)
	var elbow:=a.origin+direction*along+pole*sqrt(maxf(0,l1*l1-along*along))
	a.basis=Basis(Quaternion((b.origin-a.origin).normalized(),(elbow-a.origin).normalized()))*a.basis
	rig.set_bone_global_pose(upper,a)
	b=rig.get_bone_global_pose(lower); c=rig.get_bone_global_pose(wrist)
	b.basis=Basis(Quaternion((c.origin-b.origin).normalized(),(target-b.origin).normalized()))*b.basis
	rig.set_bone_global_pose(lower,b)
	c=rig.get_bone_global_pose(wrist); c.basis=rig.global_basis.inverse()*hand_basis
	rig.set_bone_global_pose(wrist,c)
