class_name TacticalFamilyIcon
extends Control

# A compact, text-free plan language. It keeps the four tactical families
# readable at a glance without relying on a font glyph or a downloaded atlas.

var family := "safe_control":
	set(value):
		family = value
		queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(26, 26)
	queue_redraw()


func _draw() -> void:
	var c := _color_for_family()
	var center := size * 0.5
	var stroke := maxf(1.5, minf(size.x, size.y) * 0.095)
	match family:
		"safe_control":
			var shield := PackedVector2Array([
				Vector2(center.x, 3), Vector2(size.x - 4, 7), Vector2(size.x - 6, size.y * 0.63),
				Vector2(center.x, size.y - 3), Vector2(6, size.y * 0.63), Vector2(4, 7),
			])
			draw_polyline(shield, c, stroke, true)
			draw_line(Vector2(center.x, 7), Vector2(center.x, size.y - 7), c, stroke * 0.62, true)
		"body_disable":
			draw_circle(Vector2(center.x, 6), 3.2, c, false, stroke, true)
			draw_line(Vector2(center.x, 10), Vector2(center.x, size.y - 7), c, stroke, true)
			draw_line(Vector2(center.x, 13), Vector2(5, 18), c, stroke, true)
			draw_line(Vector2(center.x, 13), Vector2(size.x - 5, 18), c, stroke, true)
			draw_line(Vector2(center.x, size.y - 8), Vector2(7, size.y - 3), c, stroke, true)
			draw_line(Vector2(center.x, size.y - 8), Vector2(size.x - 7, size.y - 3), c, stroke, true)
		"environment_gear":
			draw_arc(center, 8.0, 0.0, TAU, 16, c, stroke, true)
			draw_circle(center, 2.7, c, false, stroke, true)
			for index in range(8):
				var angle := TAU * float(index) / 8.0
				var direction := Vector2(cos(angle), sin(angle))
				draw_line(center + direction * 8.0, center + direction * 11.2, c, stroke, true)
		"high_risk":
			var bolt := PackedVector2Array([
				Vector2(center.x + 1, 2), Vector2(6, center.y + 1), Vector2(center.x - 1, center.y + 1),
				Vector2(center.x - 4, size.y - 2), Vector2(size.x - 6, center.y - 2), Vector2(center.x + 1, center.y - 2),
			])
			draw_colored_polygon(bolt, c)
		_:
			draw_arc(center, 8.0, 0.0, TAU, 16, c, stroke, true)


func _color_for_family() -> Color:
	match family:
		"safe_control": return Color("#62d9c4")
		"body_disable": return Color("#ed7460")
		"environment_gear": return Color("#d9a947")
		"high_risk": return Color("#f0b04b")
	return Color("#c9ded9")
