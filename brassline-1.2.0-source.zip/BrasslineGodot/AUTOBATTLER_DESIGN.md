# Brassline: Narrative Heist Autobattler

## High concept

**Brassline is a steampunk train-heist autobattler in which the player assembles a crew, chooses a route through seven dangerous carriages, and selects context-sensitive heist plans that the crew carries out automatically.**

The player is not an invisible commander issuing a movement order and selecting a body part every few seconds. The player is the planner. They decide what the crew is trying to accomplish, who takes the risk, which enemy capability must be disabled, and when the plan should be abandoned. The operatives then interpret that plan according to their personalities, weapons, injuries, relationships, and surroundings.

The fantasy is:

> **Know your crew. Read the carriage. Choose the plan. Watch the robbery go right—or spectacularly wrong.**

This direction preserves Brassline's strongest existing systems:

- Distinct crew members and weapons
- Persistent body-part injuries
- Fallout-inspired called shots
- Car-specific cover and hazards
- Logical enemy roles and positions
- Seven-car route building
- Permanent, order-sensitive car upgrades
- Persistent casualties and limited supplies
- A moving armored train with a strong visual identity

It replaces repeated tactical clicking with consequential preparation, readable automatic combat, and emergent stories.

---

## Design pillars

### 1. Plans, not commands

The player chooses an approach expressed in plain, flavorful language:

> **"Ada pins the officer while Marlow crosses the aisle. Nix waits for the bruiser to leave cover, then ruins his legs."**

The game translates that choice into deployment positions, movement priorities, target priorities, called-shot doctrines, ability triggers, and retreat conditions.

The player should understand the likely outcome without needing to program an AI routine.

### 2. Bodies tell the story

Enemies are not merely health bars. They are collections of capabilities that can be dismantled:

- Arms control weapon handling, reloads, and Overwatch.
- Legs control movement, flanking, and access to cover.
- Head injuries disrupt reactions, leadership, and special abilities.
- Torso damage is the direct route to incapacitation.

The central question is not always **"Who do we kill first?"** It is often **"What must this enemy stop being able to do?"**

### 3. Knowledge creates better options

The player's growing knowledge of operatives, enemy roles, car layouts, route synergies, and hazards should reveal stronger plans.

A new player can select a safe, legible option. An experienced player sees why a strange, character-specific plan is powerful in this exact situation.

### 4. The train is the build

Every cleared car changes the crew. Route order determines the run's emerging build:

- Dining creates durability.
- Bar improves accuracy.
- Crew improves mobility.
- Armory adds damage and ammunition.
- Engine increases range and ability tempo.
- Observation improves critical attacks.
- Cargo adds weapons and gadgets.
- Sleeper trades tempo for recovery.

The next battle should visibly demonstrate what the previous carriage added.

### 5. Watching must be fun

Automatic combat needs strong anticipation, readable cause and effect, dramatic reversals, and short encounter lengths. The player should frequently think:

> **"That happened because of the plan I chose."**

---

## The run loop

### 1. Assemble the crew

Choose three operatives. Crew selection determines which narrative plans can appear later.

The selection screen should clearly show:

- Role and preferred range
- Weapon behavior
- Called-shot strengths
- Signature ability
- Personal instincts
- Important relationships
- Current injuries

### 2. Choose the next carriage

The route screen shows up to three eligible cars with exact information:

- Car identity and threat level
- Known enemy roles
- Dominant cover and hazards
- Permanent reward on clear
- Route-order synergy
- Which crew members have special knowledge or opportunities there

### 3. Read the situation

Before combat, the player sees a concise scene-setting report:

> **DINING CAR / OFFICER'S SUPPER**  
> Two railhands hold the table line. An officer commands from the galley door. A service cart blocks the center aisle. The chandelier chain looks weak.

This is not perfect information. Scouting abilities, previous choices, and character knowledge determine how much is revealed.

### 4. Choose a heist plan

The player receives three or four contextual narrative options. Each option previews:

- The operative taking the greatest risk
- Intended opening positions
- Primary body-part priorities
- Abilities or environmental interactions used
- Expected advantage
- Major failure condition
- Confidence estimate based on known information

Example:

#### Pin the command

> Ada fires through the serving hatch to ruin the officer's arms. Marlow advances under that cover while Nix watches the aisle.

- **Likely result:** Officer loses leadership and ranged pressure.
- **Risk:** Ada begins exposed to the opposing marksman.
- **Uses:** Ada's rifle doctrine and Marlow's advance instinct.
- **Confidence:** High.

#### Break the room

> Nix drops the chandelier across the central tables. Marlow breaches through the debris while Ada hunts anyone forced into the open.

- **Likely result:** Enemy cover is disrupted and the center lane closes.
- **Risk:** Uncontrolled debris may injure Marlow's legs.
- **Uses:** Dining Car hazard knowledge and Nix's Saboteur tag.
- **Confidence:** Medium.

#### Make them chase us

> The crew retreats toward the boarding door. Nix baits the bruiser into the aisle, Ada targets his legs, and Marlow holds the choke.

- **Likely result:** Strong isolation of the frontline guard.
- **Risk:** The officer remains active longer and may reinforce the room.
- **Uses:** Long-range crew composition.
- **Confidence:** Medium-high.

### 5. Set the contingency

After choosing a plan, select one fallback rule:

- **Hold the plan:** Preserve roles unless someone is downed.
- **Protect the wounded:** Cover or extract anyone whose torso falls below 40%.
- **Finish the target:** Continue the opening objective despite injuries.
- **Save the crew:** Retreat if two operatives suffer crippling wounds.
- **Improvise:** Let each operative follow their personal instinct when the plan breaks.

This creates agency without turning combat back into micromanagement.

### 6. Watch the encounter

Combat runs automatically through a visible initiative timeline. The player can:

- Pause
- Inspect characters and effects
- Change playback speed
- Read the current intent above each character
- Review why a unit chose an action
- Use one limited emergency command per round, if the design retains intervention

### 7. Read the aftermath

The report should explain the story, not merely list damage:

> **The plan succeeded.** Ada disabled the officer's arms before he issued Reinforce. Marlow crossed the aisle but suffered a crippled leg. Nix never received a clean trigger for Overclock.

Then show:

- Permanent injuries and casualties
- Supplies consumed
- Car reward earned
- Newly unlocked plan knowledge
- Relationship changes
- Current cumulative run buffs

---

## Narrative plans as the primary player action

### Why narrative selection is stronger than a tactics menu

A menu containing **Advance / Hold / Flank / Nearest / Weakest / Arms / Legs** is functional, but it asks the player to think like a programmer. Narrative plans let the same mechanics feel like a heist.

They also combine several decisions into one meaningful choice. A plan can encode:

- Who stands where
- Who moves first
- Which enemy is considered most dangerous
- Which body zone matters
- When a signature ability triggers
- Which piece of scenery is used
- What level of injury is acceptable
- What happens when the opening fails

The choice remains readable because the interface summarizes its mechanical consequences before confirmation.

### Plans must not be fake choices

Each offered plan must produce meaningfully different behavior. A good set usually includes:

- A reliable, lower-upside plan
- A character-driven specialist plan
- A high-risk environmental or aggressive plan
- Occasionally, an unusual plan unlocked by history, injury, or relationships

Options should not reduce to differently worded accuracy bonuses.

---

## Managing the permutation problem

The possible combinations are large:

- Six or more operatives
- Three-person crew combinations
- Multiple enemy role combinations
- Nine car identities
- Several layouts per car
- Body injuries
- Permanent run buffs
- Route-order synergies
- Supplies and signature abilities
- Relationship and knowledge states

Hand-authoring every complete combination would be impossible. The solution is a **tag-driven plan generator using authored narrative templates**.

### Operative tags

Each operative exposes mechanical and narrative tags.

Examples:

#### Ada Brass

- `precision`
- `long_range`
- `arm_breaker`
- `patient`
- `needs_sightline`
- `poor_frontline`

#### Marlow Pike

- `breacher`
- `frontline`
- `close_range`
- `protective`
- `cover_destroyer`
- `accepts_risk`

#### Nix Bell

- `saboteur`
- `fast`
- `hazard_user`
- `flanker`
- `opportunist`
- `fragile`

### Car tags

Each layout exposes tags and interaction points.

#### Dining Car

- `table_cover`
- `narrow_aisle`
- `galley_choke`
- `chandelier_hazard`
- `service_cart`
- `civilian_history`

#### Engine Car

- `steam_vents`
- `pressure_valves`
- `short_sightlines`
- `machinery_cover`
- `fire_hazard`
- `mechanist_knowledge`

### Enemy tags

- `marksman`
- `bruiser`
- `leader`
- `medic`
- `overwatcher`
- `flanker`
- `armored`
- `reinforcement_caller`

### State tags

- `crew_member_arms_crippled`
- `crew_member_legs_crippled`
- `low_supplies`
- `accuracy_build`
- `movement_build`
- `explosive_build`
- `previous_plan_failed`
- `operative_relationship_strained`

### Authored plan template

A plan template defines requirements and consequences without naming every possible character.

Conceptual example:

```yaml
id: disable_enemy_leader
requires:
  crew:
    - precision
    - frontline
  enemy:
    - leader
  layout:
    - protected_rear_position

roles:
  shooter: precision
  mover: frontline

narrative:
  title: "Pin the command"
  summary: "{shooter} ruins {leader}'s arms while {mover} crosses into the space the officer can no longer control."

orders:
  shooter:
    target_role: leader
    body_priority: arms
    position: preserve_sightline
  mover:
    position: advance_to_mid_cover
    target_role: nearest_threat

preview:
  advantage: "Prevents leadership and reinforcement abilities."
  risk: "{shooter} begins exposed to long-range return fire."
```

At runtime, the system fills valid roles with actual operatives and enemies. The prose remains authored, but the cast and tactical execution are contextual.

### Selection scoring

The generator should:

1. Gather templates whose required tags are present.
2. Assign valid operatives and targets to each template role.
3. Reject plans made impossible by injuries, missing ammunition, blocked paths, or destroyed hazards.
4. Score plans for mechanical relevance and narrative freshness.
5. Avoid offering multiple plans with nearly identical execution.
6. Prefer at least one safe plan and one character-specific plan.
7. Display exact mechanical previews generated from the actual battle state.

Authored templates provide quality; tags provide breadth.

---

## Automatic combat model

### Recommended structure: discrete initiative autobattler

Combat remains turn-based internally but resolves automatically.

An initiative timeline shows the upcoming order:

`NIX → RAILHAND → ADA → OFFICER → MARLOW → BRUISER`

On activation, a unit:

1. Evaluates the active plan.
2. Checks whether its assigned objective is still valid.
3. Applies the selected contingency if the plan has broken.
4. Chooses one visible action.
5. Moves, attacks, reloads, takes cover, or uses an ability.

Discrete actions make cause and effect readable and allow existing movement, cover, body damage, and animations to survive the conversion.

### Character interpretation

Operatives should not execute plans identically. Their traits influence how they interpret ambiguity.

- Ada waits for a strong shot rather than firing into poor odds.
- Marlow closes distance when no explicit instruction remains.
- Nix seeks hazards and flanking opportunities.
- Iona protects damaged allies and machinery objectives.
- Silas prefers exposed duel targets.
- Rook holds dangerous ground and absorbs pressure.

This produces personality without randomly disobeying the player.

### Plan integrity

The interface should show whether the plan is still functioning:

- **Green:** On plan
- **Brass:** Adapting
- **Red:** Plan broken

When a unit adapts, a short intent caption explains why:

> **PLAN BLOCKED / Marlow cannot cross while the service cart burns. Holding the aisle instead.**

---

## Called shots in automatic combat

### Body-part priorities are contextual objectives

The player should rarely choose **Arms** in isolation. The plan explains why arms matter now.

Examples:

- **Silence the rifles:** Prioritize the arms of marksmen and Overwatch units.
- **Stop the charge:** Break the bruiser's legs before he reaches the crew.
- **Cut off command:** Injure the officer's head or arms to suppress leadership abilities.
- **Drop them quickly:** Concentrate torso damage on the most exposed target.
- **Take one alive:** Disable arms and legs while avoiding torso finishing damage.

### Conditional doctrine

Plans can include intelligent thresholds:

- Shoot Head only above 70% hit chance.
- Switch from Arms to Torso after the target is crippled.
- Do not spend a two-action called shot on a nearly defeated enemy.
- Preserve ammunition when no priority target is exposed.
- Prefer Legs only while the enemy can still reach a vulnerable ally.

These conditions should be previewed in plain language, not exposed as scripting syntax.

### Immediate mechanical consequences

Crippling must visibly change behavior during the battle:

- A marksman with ruined arms loses Overwatch and struggles to reload.
- A bruiser with ruined legs abandons a charge and fires poorly from the aisle.
- A wounded officer issues commands later or loses access to Reinforce.
- A crippled medic cannot reach the ally they intended to save.

This is how the player learns that their narrative choice mattered.

---

## Knowledge and discovery

Narrative plans become more satisfying if information is earned.

### Knowledge categories

- **Operative knowledge:** Learned by using and observing a crew member.
- **Enemy knowledge:** Learned after encountering a role or capturing documents.
- **Car knowledge:** Learned by clearing layouts and interacting with hazards.
- **Relationship knowledge:** Learned through repeated crew pairings and events.
- **Blueprint knowledge:** Permanent meta-progression revealing train systems.

### Knowledge should improve clarity, not merely power

Early description:

> **The officer appears to be coordinating the room.**

After learning the role:

> **Officer / Command whistle activates after his second turn. Crippling Arms prevents Reinforce.**

The plan may always exist, but knowledge reveals its exact risk and consequence.

### Avoid a wiki dependency

The game should surface relevant knowledge at the moment of choice. Players should not need to memorize a codex to understand why an option appeared.

Each plan card should highlight the facts it uses:

> **Uses known information:** Officer's whistle requires intact arms.

---

## Car and build interaction

### Rewards must change future plans

Car buffs should do more than alter invisible percentages.

- Accuracy can unlock ambitious called-shot plans.
- Movement can make crossing or flanking plans viable.
- Range can allow rear deployment options.
- Health can make sacrificial breach plans survivable.
- Critical chance can enable precise decapitation strategies.
- Gadgets can introduce entirely new environmental plans.

Example:

> Before clearing the Bar, Ada's **Pin the command** plan is Medium confidence. After the Bar grants +6% total accuracy, the same plan becomes High confidence and changes its expected opening outcome.

### Route-order synergies should appear in prose

> **Because the crew cleared the Engine before the Armory, the ammunition press can produce boiler-loaded rounds: +0.75 damage instead of +0.50.**

This makes the build feel like a journey through the train rather than a collection of passive stat modifiers.

---

## Player intervention

The cleanest version is mostly hands-off after the plan begins. However, one limited intervention system could preserve tension.

### Recommended option: one Command token per round

Possible commands:

- **Retarget:** Change the current priority enemy.
- **Pull Back:** Order one operative toward the boarding side.
- **Commit:** Force an available signature ability now.
- **Hold Fire:** Preserve ammunition until the next activation.
- **Save Them:** Redirect available allies to protect one operative.

Commands should alter intent, not manually select tiles or calculate individual shots.

An even purer autobattler version can remove Command tokens entirely after playtesting.

---

## Interface direction

### Planning screen

The planning screen should have four clear areas:

1. **Car view:** The carriage, enemies, cover, hazards, and possible starting positions.
2. **Crew strip:** Operative portraits, wounds, weapons, and relevant traits.
3. **Plan cards:** Three or four contextual narrative options.
4. **Mechanical preview:** Risk, intended targets, body priorities, and predicted opening positions.

Selecting a plan previews ghosted starting positions and colored intent lines in the carriage.

### Combat screen

Keep the HUD restrained:

- Initiative timeline
- Current plan and status
- Small crew health/body indicators
- Speed and pause controls
- Optional inspector
- Limited Command tokens, if retained

Remove the large manual action bar and persistent called-shot panel during automatic combat. Body targeting appears in intent captions and the inspector.

### Readable intent

Above or beside each operative:

- `MOVING / GALLEY COVER`
- `AIMING / OFFICER ARMS`
- `RELOADING / 1 TURN`
- `ADAPTING / PROTECTING NIX`
- `PLAN BROKEN / NO SAFE PATH`

---

## Encounter duration and pacing

Target combat length:

- Ordinary car: 25–45 seconds at normal speed
- Dangerous car: 45–75 seconds
- Finale: 90–150 seconds with distinct phases

Controls:

- Pause
- 1×
- 2×
- 4×
- Skip to outcome only after a battle has become mathematically decided

Avoid long miss chains. Accuracy should remain meaningful, but plans must produce visible progress. Consider escalating aim, suppression, armor damage, or guaranteed setup effects so every activation changes the state.

---

## Failure and fairness

Because wounds persist, the player must understand why a plan failed.

Before confirmation, show:

- Known danger
- Uncertain information
- Operative most exposed
- Estimated opening advantage
- Conditions that invalidate the plan

After failure, report:

- Which assumption became false
- Whether the plan or contingency responded
- Which enemy action caused the pivotal injury
- What knowledge would improve the decision next time

Randomness may change an outcome, but it should not conceal causality.

---

## Minimum viable prototype

Do not convert the complete campaign immediately. Build a focused vertical slice.

### Content

- Boarding Car
- Dining Car
- Three operatives: Ada, Marlow, and Nix
- Three enemy roles: Railhand, Officer, and Bruiser
- Two Dining layouts
- Six to eight plan templates
- Four fallback contingencies
- Automatic initiative combat
- Pause, 1×, 2×, and 4× speed
- Post-battle narrative report

### Required plan examples

1. Disable the officer's arms.
2. Break the bruiser's legs.
3. Concentrate torso fire on the nearest threat.
4. Use Marlow to breach the table line.
5. Use Nix to trigger the chandelier hazard.
6. Retreat into a choke and force the enemy forward.

### Questions the prototype must answer

- Is choosing a narrative plan more interesting than issuing tactical commands?
- Can the player predict how the plan will affect the fight?
- Is watching the crew execute enjoyable for at least ten repeated battles?
- Do body-part consequences remain readable without manual targeting?
- Do operatives feel distinct when interpreting the same broad objective?
- Are three plan options enough to produce agency without overload?
- Does a limited emergency command improve tension or reintroduce micromanagement?

### Success criteria

The direction is working if players:

- Can explain why they chose a plan.
- Can identify the moment the plan succeeded or broke.
- Attribute outcomes to crew composition and route choices.
- Want to retry with a different plan rather than merely hoping for better rolls.
- Develop favorite operatives because of behavior and personality, not only statistics.

---

## Conversion strategy for the existing prototype

Much of the current game can remain.

### Keep

- Train-car scenes and cover maps
- Character models and combat animations
- Body-zone health and crippling rules
- Weapons, magazines, abilities, and supplies
- Enemy roles and logical spawn positions
- Pathfinding and line of sight
- Seven-car route state and rewards
- Persistent wounds, healing, and checkpoints
- Existing AI scoring as the foundation for action selection

### Replace or reframe

- Manual movement becomes plan-directed automatic movement.
- Manual attack buttons become automatic target/body-part evaluation.
- The large command bar becomes plan status, speed controls, and optional intervention.
- The called-shot panel moves primarily into planning previews and inspection.
- Combat start becomes a narrative plan-selection screen.
- Combat logs become concise intent explanations and an aftermath story.

### First implementation order

1. Add automatic player-unit turns using the existing enemy-AI action framework.
2. Create a simple internal plan object containing role assignments and priorities.
3. Implement three fixed Boarding Car plans.
4. Add visible intents and an initiative timeline.
5. Add fallback contingencies.
6. Build the tag-driven template selector.
7. Add Dining Car environmental plans.
8. Playtest repeatedly before converting additional cars.

---

## North-star example

The player enters the Engine Car with Ada, Nix, and Iona. Ada's arms are wounded. The crew previously cleared the Bar and Observation cars, creating a precision-critical build. A Surgeon is protected behind a pressure cylinder while a Bruiser prepares to cross the piston lane.

The game offers:

### Bleed the pressure

> Iona opens the red valve when the piston retracts. Nix drives the bruiser into the steam lane while Ada targets the surgeon's arms from the rear platform.

- High environmental damage
- Risks Nix's legs
- Uses Iona's Engine knowledge
- Ada's wounded arms reduce confidence from High to Medium

### Remove the healer

> Ada and Nix concentrate on the surgeon. Iona holds the piston lane and repairs whoever the bruiser reaches first.

- Reliable elimination plan
- Leaves the bruiser mobile
- Strongly benefits from the Bar and Observation accuracy build

### Stop the charge

> Ada waits for the bruiser to enter the lamp light, then breaks his legs. Nix flanks the surgeon while Iona seals the steam vents.

- Safest crew-preservation plan
- Slower fight
- Surgeon may restore the bruiser's torso before Nix arrives

The player chooses **Bleed the pressure**, then selects **Protect the wounded** as the fallback. During combat, Ada misses the surgeon's first arm shot. Nix successfully draws the bruiser into the vent, but suffers a leg injury. The fallback activates: Iona abandons the valve and moves to shield Nix. The original burst plan becomes a defensive recovery fight.

The result is not simply a won or lost damage calculation. It is a story produced by the player's plan, the crew's capabilities, the car, prior route choices, injury state, and contingency.

That is the game Brassline can become.
