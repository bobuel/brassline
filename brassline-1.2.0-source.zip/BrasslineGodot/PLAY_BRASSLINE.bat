@echo off
setlocal
set "BRASSLINE_GODOT="
for /d %%D in ("%LOCALAPPDATA%\Microsoft\WinGet\Packages\GodotEngine.GodotEngine_*") do (
  for %%G in ("%%~fD\Godot_v*-stable_win64.exe") do (
    if exist "%%~fG" set "BRASSLINE_GODOT=%%~fG"
  )
)

if not defined BRASSLINE_GODOT (
  echo Godot was not found. Install Godot 4.7.1, then open project.godot.
  pause
  exit /b 1
)

"%BRASSLINE_GODOT%" --path "%~dp0." %*
