# Brassline screen-pattern rationale

This is a decision record, not a mandate to imitate another game's art. Each
screen must answer one immediate player question before it exposes optional
detail.

## Shared rule

Every screen has one **anchor**, one **action**, and no more than three
decision-changing fact groups. Character, item, and train detail belongs behind
an explicit focused view rather than competing with the live carriage.

## Crew selection — *Who am I taking?*

**Anchor:** one full-size animated operative on a turntable.

**Action:** inspect a portrait, then explicitly add or remove that operative.
Inspection and assignment must never share a click. The selected operative owns
the large model, weapon, signature, three core numbers, scars, and bonds. A
player can drag the model to rotate it before committing.

**Pattern source:** Divinity: Original Sin 2 separates its party/character focus
from the larger character-sheet and inventory views; XCOM 2 uses soldier
selection as the entry point to a focused squad-management view. Brassline uses
the same character-first hierarchy, with a smaller three-person draft.

## Planning — *What happens if I choose this?*

**Anchor:** the complete active carriage with starting marks, target, cover,
and one short preview.

**Action:** choose one plan and one fallback.

Four plan cards are enough because they represent the four tactical families.
They show family icon, title, opening chance, and risk; exact arithmetic and
authored prose live in Plan Details. Selecting a plan changes the board before
the player commits.

**Pattern source:** Into the Breach treats the board as the explanation: the
important future state is projected directly into the encounter, not buried in
a menu.

## Combat — *What is happening right now?*

**Anchor:** the carriage and the currently consequential action.

**Action:** pause, alter pace, or open the Ledger; the autobattle itself owns
initiative.

The persistent HUD is limited to plan integrity, three crew condition chips,
initiative, and current action. Logs are history, not the center of the screen.
Key beats may take the camera closer; ordinary attacks stay fast and readable.

**Pattern source:** XCOM's tactical display keeps battlefield position, health,
and the current combat decision visible while deeper soldier management stays
outside the firing view.

## Ledger — *What can this person do or carry?*

**Anchor:** selected operative, body silhouette, weapon, and inventory.

**Action:** switch Crew, Gear, Injuries, or Train tabs.

This is a full-screen deliberate-management view, never a permanent combat
overlay. It is where exact stats, buffs, relationships, and item explanations
belong.

**Pattern source:** Divinity's character sheet/inventory makes the active hero
the organizing element while leaving the play scene visible only as context.

## Recovery and aftermath — *Who changed, and what did we earn?*

**Anchor:** three visual cards—what happened, who was hurt, what we gained.

**Action:** treat a focused operative or continue to the next car.

Injury treatment needs a selected character and a visible before/after outcome;
reward needs a concrete item, buff, or train change before the campaign prose.
Chronology and lore remain optional detail.

## Reference material

- [Into the Breach Design Postmortem (Subset Games / GDC)](https://media.gdcvault.com/gdc2019/presentations/Into%20the%20Breach%20Postmortem%20Final.pdf)
- [XCOM 2 manual tactical-screen reference](https://cdn.cloudflare.steamstatic.com/steam/apps/268500/manuals/XCOM2_Manual_English.pdf?t=1600177724)
- [Divinity: Original Sin 2 interface reference](https://www.gamepressure.com/originalsinii/interface/z491a9)

